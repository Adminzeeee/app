/* Commitments — social-accountability system generated from survey asks. */

export type CommitStatus = "pending" | "committed" | "declined" | "snoozed" | "honored" | "broken";
export type CommitCategory = "Market" | "Farming" | "Health" | "Civic" | "Education" | "Environment" | "Trade";

export interface Commitment {
  id: string;
  category: CommitCategory;
  ask: string;               // the question generated from the survey
  detail: string;            // context/why it matters
  location: string;
  dueAt: string;             // ISO-ish date string
  proofRequired: boolean;
  status: CommitStatus;
  partners?: string[];       // other committed users (avatars)
  reminders?: number;
  color: string;
}

export interface StandingBadge {
  id: string;
  name: string;
  desc: string;
  tier: "bronze" | "silver" | "gold" | "platinum";
  earned: boolean;
}

export interface LedgerEntry {
  id: string;
  title: string;
  when: string;
  result: "honored" | "broken";
  category: CommitCategory;
}

export const CATEGORY_COLORS: Record<CommitCategory, string> = {
  Market: "#f59e0b",
  Farming: "#22c55e",
  Health: "#ef4444",
  Civic: "#3b82f6",
  Education: "#a855f7",
  Environment: "#14b8a6",
  Trade: "#eab308",
};

export const UPCOMING: Commitment[] = [
  {
    id: "c1", category: "Market",
    ask: "Who will attend the Saturday market event in Gaborone West?",
    detail: "Vendors need a headcount by Thursday to plan stalls and fresh stock.",
    location: "Gaborone West Community Ground",
    dueAt: "2024-07-13T09:00:00",
    proofRequired: true,
    status: "committed",
    partners: ["Kabo", "Thato", "Neo"],
    reminders: 2,
    color: CATEGORY_COLORS.Market,
  },
  {
    id: "c2", category: "Farming",
    ask: "Who will buy oranges from the Tlokweng co-op on Wednesday?",
    detail: "The co-op has a surplus batch that will spoil if not sold by midweek.",
    location: "Tlokweng Co-op Stand 4",
    dueAt: "2024-07-10T15:00:00",
    proofRequired: true,
    status: "pending",
    partners: ["Boitumelo"],
    color: CATEGORY_COLORS.Farming,
  },
  {
    id: "c3", category: "Health",
    ask: "Who will bring a neighbour to the free clinic screening?",
    detail: "Mobile clinic is only in Mogoditshane this month — one visit per household.",
    location: "Mogoditshane Health Post",
    dueAt: "2024-07-15T08:30:00",
    proofRequired: false,
    status: "pending",
    partners: ["Lesego", "Kagiso"],
    color: CATEGORY_COLORS.Health,
  },
  {
    id: "c4", category: "Civic",
    ask: "Who will attend the ward water-supply meeting?",
    detail: "Council needs quorum of 25 residents to approve the new borehole budget.",
    location: "Ward 14 Kgotla",
    dueAt: "2024-07-11T17:00:00",
    proofRequired: true,
    status: "snoozed",
    partners: ["Onalenna", "Tumelo", "Kabo", "Refilwe"],
    reminders: 1,
    color: CATEGORY_COLORS.Civic,
  },
  {
    id: "c5", category: "Education",
    ask: "Who will tutor a student for the Friday numeracy drop-in?",
    detail: "3 volunteers signed up so far; 2 more needed to cover all grades.",
    location: "Block 8 Primary School",
    dueAt: "2024-07-12T14:00:00",
    proofRequired: false,
    status: "pending",
    color: CATEGORY_COLORS.Education,
  },
  {
    id: "c6", category: "Environment",
    ask: "Who will join the Notwane riverbank clean-up?",
    detail: "Rains are coming — clearing waste now prevents downstream blockages.",
    location: "Notwane River, near the old bridge",
    dueAt: "2024-07-14T07:00:00",
    proofRequired: true,
    status: "committed",
    partners: ["Neo", "Lorato"],
    color: CATEGORY_COLORS.Environment,
  },
];

export const LEDGER: LedgerEntry[] = [
  { id: "l1", title: "Attended the Naledi youth jobs fair", when: "3 days ago", result: "honored", category: "Civic" },
  { id: "l2", title: "Bought tomatoes from Kanye co-op", when: "5 days ago", result: "honored", category: "Farming" },
  { id: "l3", title: "Brought supplies to the Old Naledi shelter", when: "1 week ago", result: "honored", category: "Health" },
  { id: "l4", title: "Missed the borehole repair volunteer slot", when: "2 weeks ago", result: "broken", category: "Environment" },
  { id: "l5", title: "Hosted a numeracy drop-in session", when: "2 weeks ago", result: "honored", category: "Education" },
  { id: "l6", title: "Skipped the Saturday market stall shift", when: "3 weeks ago", result: "broken", category: "Market" },
  { id: "l7", title: "Delivered market survey results to ward council", when: "3 weeks ago", result: "honored", category: "Civic" },
  { id: "l8", title: "Traded seed stock with Ramotswa farmers", when: "1 month ago", result: "honored", category: "Trade" },
];

export const BADGES: StandingBadge[] = [
  { id: "b1", name: "Reliable Neighbour", desc: "10+ commitments honored in a row", tier: "gold", earned: true },
  { id: "b2", name: "Market Regular", desc: "5 market commitments kept", tier: "silver", earned: true },
  { id: "b3", name: "First Responder", desc: "Joined a health commitment within 1hr", tier: "bronze", earned: true },
  { id: "b4", name: "Community Pillar", desc: "50 lifetime commitments honored", tier: "platinum", earned: false },
  { id: "b5", name: "Green Streak", desc: "3 environment clean-ups in a month", tier: "silver", earned: false },
  { id: "b6", name: "Trusted Trader", desc: "No broken trade commitments ever", tier: "gold", earned: true },
];

export const PROFILE = {
  name: "Kabo M.",
  handle: "@kabo_gwithubl",
  reliability: 92,          // %
  streak: 11,               // consecutive honored
  honored: 47,
  broken: 4,
  collabs: 23,              // successful collabs with other users
  tier: "Gold Standing" as const,
  nextTierAt: 96,
};
