/* Always-on analysis engine — shared singleton store powering Workspace v3 / v4.
   Runs 24/7: agents think, feeds stream in, findings appear over time. */

import { useEffect, useState } from "react";

export interface Agent {
  id: string;
  name: string;
  role: string;
  color: string;
  focus: string;
}

export const AGENT_POOL: Agent[] = [
  { id: "ag1", name: "ORCHESTRATOR", role: "Coordinator", color: "#B7E34B", focus: "task routing" },
  { id: "ag2", name: "HYDROLOGY", role: "Water analyst", color: "#22d3ee", focus: "water & flood pulse" },
  { id: "ag3", name: "PATTERN", role: "Pattern miner", color: "#a78bfa", focus: "cross-source clusters" },
  { id: "ag4", name: "RISK", role: "Risk sentinel", color: "#f87171", focus: "risk register" },
  { id: "ag5", name: "ECONOMY", role: "Economist", color: "#facc15", focus: "trade & prices" },
  { id: "ag6", name: "SENTIMENT", role: "Sentiment reader", color: "#f472b6", focus: "surveys & social" },
  { id: "ag7", name: "LOGISTICS", role: "Logistics planner", color: "#4ade80", focus: "freight & cold-chain" },
  { id: "ag8", name: "GEOCODER", role: "Geo decomposer", color: "#2dd4bf", focus: "ward attribution" },
  { id: "ag9", name: "ENERGY", role: "Energy watcher", color: "#fb923c", focus: "grid & outages" },
  { id: "ag10", name: "CLIMATE", role: "Climate modeller", color: "#60a5fa", focus: "rainfall models" },
  { id: "ag11", name: "TRADE", role: "Trade scout", color: "#c084fc", focus: "border & customs" },
  { id: "ag12", name: "TOURISM", role: "Tourism analyst", color: "#34d399", focus: "occupancy" },
  { id: "ag13", name: "HEALTH", role: "Health signal", color: "#fda4af", focus: "clinics & supply" },
  { id: "ag14", name: "VERIFIER", role: "Verification", color: "#93c5fd", focus: "evidence chains" },
  { id: "ag15", name: "SIMULATION", role: "Counterfactual", color: "#fbbf24", focus: "synthetic controls" },
  { id: "ag16", name: "NARRATOR", role: "Report writer", color: "#5eead4", focus: "report drafting" },
  { id: "ag17", name: "URBAN", role: "Urban analyst", color: "#818cf8", focus: "housing & jobs" },
  { id: "ag18", name: "DROUGHT", role: "Drought watch", color: "#f59e0b", focus: "rangeland stress" },
  { id: "ag19", name: "INDUSTRY", role: "Industry scan", color: "#38f8b0", focus: "mining & plants" },
  { id: "ag20", name: "SUPPLY", role: "Water supply", color: "#7dd3fc", focus: "dam levels" },
];


export type AgentState = "thinking" | "fetching" | "debating" | "waiting" | "writing" | "verifying";

export const STATE_LABEL: Record<AgentState, string> = {
  thinking: "reasoning",
  fetching: "pulling data",
  debating: "in debate",
  waiting: "awaiting update",
  writing: "drafting",
  verifying: "verifying",
};

export interface FeedSource {
  k: string;
  label: string;
  kind: "rss" | "api" | "survey" | "sensor";
  cadence: number; // seconds between items
}

export const FEEDS: FeedSource[] = [
  { k: "mmegi", label: "Mmegi Online · RSS", kind: "rss", cadence: 9 },
  { k: "sunday", label: "Sunday Standard · RSS", kind: "rss", cadence: 13 },
  { k: "bwgov", label: "BW Daily News · RSS", kind: "rss", cadence: 11 },
  { k: "guardian", label: "Botswana Guardian · RSS", kind: "rss", cadence: 17 },
  { k: "voice", label: "The Voice BW · RSS", kind: "rss", cadence: 15 },
  { k: "weather", label: "Weather API · BW Met", kind: "api", cadence: 7 },
  { k: "prices", label: "Commodity price API", kind: "api", cadence: 12 },
  { k: "surveys", label: "Survey wave stream", kind: "survey", cadence: 19 },
  { k: "sensors", label: "Sensor mesh · 1,204 nodes", kind: "sensor", cadence: 5 },
  { k: "directory", label: "Directory graph delta", kind: "api", cadence: 21 },
];

const HEADLINES: Record<string, string[]> = {
  mmegi: [
    "Water utility flags pump downtime in three wards",
    "Youth digital academy proposal reaches cabinet",
    "Cattle prices firm ahead of export window",
    "Council approves Gaborone housing tranche",
  ],
  sunday: [
    "Tourism arrivals up 11% year on year",
    "Fuel levy review to hit freight margins",
    "Solar tender shortlist narrowed to five",
    "Teacher shortage reported in Kgalagadi",
  ],
  bwgov: [
    "Ministry publishes borehole rehabilitation list",
    "New grant window opens for agri-SMEs",
    "Road maintenance budget reallocated to A3",
    "Health posts receive cold-chain upgrade",
  ],
  guardian: [
    "Diamond output steady, beneficiation debate grows",
    "Small traders report slow customs clearance",
    "Okavango lodge bookings near capacity",
    "Digital ID rollout enters second phase",
  ],
  voice: [
    "Community reports water outage in Molepolole",
    "Local welders win district contract",
    "Flood pulse arrives early in Maun",
    "Enumerators recruited for Central wave",
  ],
  weather: [
    "Rain probability 62% · North-West, 48h",
    "Heat index climbing · Kgalagadi +3.4°C",
    "Dry spell extends to 19 days · Ghanzi",
    "Wind shear advisory · Chobe corridor",
  ],
  prices: [
    "Diesel +1.8% week on week",
    "Maize spot price -2.4%",
    "Beef export index 104.6",
    "Freight rate index +0.9%",
  ],
  surveys: [
    "Wave 15 · 412 new responses ingested",
    "Water sentiment -6 pts in two wards",
    "Youth employment optimism +4 pts",
    "Service trust index stable at 61",
  ],
  sensors: [
    "Pump 44-B downtime 3h12m",
    "Reservoir level -1.2% · Letsibogo",
    "Grid frequency deviation logged",
    "Cold-chain unit temp excursion · Ghanzi",
  ],
  directory: [
    "+318 new registrations today",
    "Cold-chain category +12 listings",
    "Solar installers overtake plumbers in demand",
    "24 businesses verified this hour",
  ],
};

export const EXTRA_HEADLINES = [
  "Border post queue length 41 trucks, rising",
  "Ward-level complaint volume up 14% on the hour",
  "New tender published: rural water reticulation",
  "Mobile money volumes spike in Francistown",
  "Bus operators report route consolidation",
  "Two clinics report stock-out of test kits",
  "Rain gauge network reports 12mm overnight",
  "Cattle auction clears 340 head above reserve",
  "Fibre backbone maintenance window announced",
  "Tourist arrivals at Kasane +9% week on week",
  "Municipal refuse contract goes out to bid",
  "Retail footfall index recovers to 98.2",
  "Grid load shedding avoided, reserve margin 6%",
  "Three new solar installers registered today",
  "Freight insurance premiums quoted up 3%",
  "School feeding deliveries delayed in two wards",
  "Groundwater abstraction permit approved",
  "Second-hand vehicle imports slow at Kazungula",
  "Housing waiting list grows by 212 applicants",
  "Cold-chain audit scheduled for Ghanzi depot",
  "Youth cooperative registers 48 members",
  "Sensor mesh adds 26 nodes in the Central district",
];

export const TAILS = [
  "confidence 0.71",
  "2 sources",
  "unverified",
  "corroborated",
  "auto-tagged",
  "priority queue",
  "delta +2.4%",
  "flagged for review",
];

export const THOUGHTS = [
  "cross-referencing rainfall deficit against water complaints (r=0.82)",
  "deduplicating 1,204 entities across directory + trade records",
  "testing Granger causality: sensor downtime → sentiment drop",
  "clustering 88 weak signals with HDBSCAN, min_samples=4",
  "re-weighting survey coverage gap in Kgalagadi wards",
  "drawing 400 synthetic controls for the borehole counterfactual",
  "scoring impact × effort for 31 candidate actions",
  "tracing claim to source record sensors/44B/2026-08-11",
  "detecting anomaly: freight margin 2.1σ below seasonal baseline",
  "matching grant window calendar against project readiness",
  "asking HYDROLOGY to confirm flood pulse timing before publishing",
  "RISK disputes severity — escalating to coordinator vote",

  "found repeated co-occurrence: outage reports + school absence",
  "compressing 46,867 directory rows into 214 skill clusters",
  "calibrating confidence with isotonic regression on backtests",
  "watching Mmegi feed for confirmation of the tender shortlist",
  "benchmarking against 6 SADC peer baselines",
  "surfacing hidden opportunity: reefer pre-booking on the A3",
  "linking tourism occupancy to flood pulse with 9-day lag",
  "flagging data staleness on satellite tiles (3h)",
];

export const DEBATES = [
  ["PATTERN", "RISK", "is the outage cluster causal or seasonal?"],
  ["HYDROLOGY", "CLIMATE", "flood pulse timing: 6-day vs 9-day lag"],
  ["ECONOMY", "LOGISTICS", "does the diesel move justify reefer pre-booking?"],
  ["SENTIMENT", "VERIFIER", "sentiment drop needs a second corroborating source"],
  ["DROUGHT", "HEALTH", "rangeland stress vs clinic supply priority"],
  ["URBAN", "INDUSTRY", "housing tranche competes with plant maintenance"],
];


/* ---------------- findings ---------------- */

export interface LiveFinding {
  id: string;
  kind: "opportunity" | "risk";
  title: string;
  detail: string;
  region: string;
  sector: string;
  score: number;
  confidence: number;
  value: string;
  when: number;
  agent: string;
  read: boolean;
  fav: boolean;
  saved: boolean;
}

const OPP_SEEDS = [
  ["400-seat digital skills academy", "Directory demand + youth cohort supports a Gaborone campus", "Digital", "P41.2M"],
  ["Reefer pre-booking on the A3 corridor", "Freight margin dip opens a 6-week hedging window", "Logistics", "P12.6M"],
  ["Solar micro-grid at 18 clinics", "Outage clusters overlap with clinic cold-chain risk", "Energy", "P26.8M"],
  ["Borehole rehab shortlist, 40 sites", "Sensor downtime + complaint density converge", "Water", "P18.4M"],
  ["Green-season lodge packaging", "Occupancy lags flood pulse by 9 days", "Tourism", "P9.4M"],
  ["Cold-chain hub in Ghanzi", "Livestock volume justifies a shared facility", "Agriculture", "P26.8M"],
  ["Setswana content localisation unit", "Creative registrations up 18% quarter on quarter", "Digital", "P4.1M"],
  ["Enumerator academy, Central district", "Survey coverage gap of 9 wards is closable", "Education", "P2.8M"],
  ["Drone survey service for councils", "Only 288 licensed pilots against rising demand", "Digital", "P6.9M"],
  ["Shared welding yard, Selebi-Phikwe", "Fabrication contracts leaving the district", "Industry", "P7.7M"],
  ["Maize bulk-buy cooperative", "Spot price dip plus 20t open demand", "Agriculture", "P5.2M"],
  ["Tourism labour pipeline with lodges", "Guide vacancies persist through peak", "Tourism", "P3.6M"],
];

const RISK_SEEDS = [
  ["Water sentiment falling two waves running", "Three wards below trust threshold", "Water", "high"],
  ["Pump downtime spike, 44-B cluster", "3h12m outage repeating on a weekly cycle", "Water", "critical"],
  ["Fuel levy review squeezes freight margin", "Small operators most exposed", "Logistics", "high"],
  ["Grant window closes in 27 days", "Two projects are not submission-ready", "Funding", "medium"],
  ["Teacher shortage widening in Kgalagadi", "Absence rate correlated with outages", "Education", "high"],
  ["Cold-chain temp excursions in Ghanzi", "Vaccine stock at risk within 48h", "Health", "critical"],
  ["Dry spell extends to 19 days", "Rangeland stress index rising", "Agriculture", "high"],
  ["Customs clearance times up 22%", "Small traders reporting stock-outs", "Trade", "medium"],
  ["Satellite tiles stale by 3 hours", "Confidence penalty on geo findings", "Data", "low"],
  ["Directory verification backlog", "318 registrations awaiting review", "Data", "medium"],
  ["Grid frequency deviations logged", "Second event this week on the same feeder", "Energy", "high"],
  ["Lodge staffing gap into peak season", "Service quality risk in Maun", "Tourism", "medium"],
];

const REGIONS = ["South-East", "North-West", "Central", "Ghanzi", "Kgalagadi", "Chobe", "Kweneng", "North-East", "Southern"];

let seq = 0;
function mk(kind: "opportunity" | "risk", ageMs: number): LiveFinding {
  const i = seq++;
  const seeds = kind === "opportunity" ? OPP_SEEDS : RISK_SEEDS;
  const s = seeds[i % seeds.length];
  return {
    id: `${kind}-${i}-${Math.random().toString(36).slice(2, 7)}`,
    kind,
    title: s[0],
    detail: s[1],
    region: REGIONS[(i * 3) % REGIONS.length],
    sector: s[2],
    score: 48 + ((i * 37) % 52),
    confidence: 55 + ((i * 17) % 44),
    value: kind === "opportunity" ? s[3] : s[3],
    when: Date.now() - ageMs,
    agent: AGENT_POOL[(i * 5) % AGENT_POOL.length].name,
    read: false,
    fav: false,
    saved: false,
  };
}

/* ---------------- singleton store ---------------- */

interface Store {
  findings: LiveFinding[];
  thoughts: { id: number; agent: Agent; text: string; when: number }[];
  feed: { id: number; src: FeedSource; text: string; when: number }[];
  states: Record<string, AgentState>;
  runtimeMs: number;
  ops: number;
  agentCount: number;
}

const subs = new Set<(s: Store) => void>();
let tid: number | null = null;
let tick = 0;

const store: Store = {
  findings: [
    ...Array.from({ length: 7 }, (_, i) => mk("opportunity", (i + 1) * 42e4)),
    ...Array.from({ length: 6 }, (_, i) => mk("risk", (i + 1) * 51e4)),
  ],
  thoughts: [],
  feed: [],
  states: Object.fromEntries(AGENT_POOL.map((a, i) => [a.id, (["thinking", "fetching", "debating", "waiting", "writing", "verifying"] as AgentState[])[i % 6]])),
  runtimeMs: 1000 * 60 * 60 * 197 + 42_000,
  ops: 18_400_233,
  agentCount: 14,
};

let tSeq = 0;
function emit() { subs.forEach((f) => f({ ...store })); }

function step() {
  tick++;
  store.runtimeMs += 700;
  store.ops += 800 + Math.floor(Math.random() * 2600);

  // agent state churn
  const a = AGENT_POOL[Math.floor(Math.random() * store.agentCount)];
  const pool: AgentState[] = ["thinking", "fetching", "debating", "waiting", "writing", "verifying"];
  store.states[a.id] = pool[Math.floor(Math.random() * pool.length)];

  // thought stream
  if (tick % 1 === 0) {
    const ag = AGENT_POOL[Math.floor(Math.random() * store.agentCount)];
    const text = Math.random() < 0.22
      ? (() => { const d = DEBATES[Math.floor(Math.random() * DEBATES.length)]; return `debating with ${d[1]} — ${d[2]}`; })()
      : THOUGHTS[Math.floor(Math.random() * THOUGHTS.length)];
    store.thoughts = [{ id: tSeq++, agent: ag, text, when: Date.now() }, ...store.thoughts].slice(0, 40);
  }

  // feed items — fast, high-volume stream
  const burst = 1 + Math.floor(Math.random() * 3);
  for (let i = 0; i < burst; i++) {
    const f = FEEDS[Math.floor(Math.random() * FEEDS.length)];
    const items = [...HEADLINES[f.k], ...EXTRA_HEADLINES];
    const base = items[Math.floor(Math.random() * items.length)];
    const text = Math.random() < 0.35 ? `${base} · ${TAILS[Math.floor(Math.random() * TAILS.length)]}` : base;
    store.feed = [{ id: tSeq++, src: f, text, when: Date.now() }, ...store.feed].slice(0, 160);
  }

  // new findings — steady but not spammy
  if (tick % 7 === 0) {
    store.findings = [mk(Math.random() < 0.55 ? "opportunity" : "risk", 0), ...store.findings].slice(0, 80);
  }

  emit();
}

function ensureRunning() {
  if (tid != null || typeof window === "undefined") return;
  tid = window.setInterval(step, 700);
}

export function setAgentCount(n: number) {
  store.agentCount = Math.max(8, Math.min(20, n));
  emit();
}

export function mutateFinding(id: string, patch: Partial<LiveFinding>) {
  store.findings = store.findings.map((f) => (f.id === id ? { ...f, ...patch } : f));
  emit();
}

export function removeFinding(id: string) {
  store.findings = store.findings.filter((f) => f.id !== id);
  emit();
}

export function useEngine() {
  const [s, setS] = useState<Store>(() => ({ ...store }));
  useEffect(() => {
    ensureRunning();
    subs.add(setS);
    setS({ ...store });
    return () => { subs.delete(setS); };
  }, []);
  return s;
}

export function ago(when: number) {
  const d = Math.max(0, Date.now() - when);
  if (d < 60_000) return `${Math.floor(d / 1000)}s ago`;
  if (d < 3.6e6) return `${Math.floor(d / 60_000)}m ago`;
  if (d < 8.64e7) return `${Math.floor(d / 3.6e6)}h ago`;
  return `${Math.floor(d / 8.64e7)}d ago`;
}

export function uptime(ms: number) {
  const h = Math.floor(ms / 3.6e6);
  const m = Math.floor((ms % 3.6e6) / 60_000);
  const s = Math.floor((ms % 60_000) / 1000);
  return `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
}
