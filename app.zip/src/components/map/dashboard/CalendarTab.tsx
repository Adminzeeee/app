import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  AlertTriangle, Brain, ChevronLeft, ChevronRight, CloudRain, CloudSun, Cloud, Droplets, Sun, Users, Wind, Zap,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Kpi, Panel, Ring, Sheet, Tap, hash, useSkin } from "./ui";
import { Columns, DrawLine } from "./charts";
import { ATTENDEE_POOL, EVENT_POOL, WARDS, WEATHER_KINDS, type DayEvent, type WeatherKind } from "./data";

const DOW = ["S", "M", "T", "W", "T", "F", "S"];
const WEEKDAY_FULL = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

interface DayProfile {
  weather: WeatherKind;
  tempHi: number;
  tempLo: number;
  rain: number;
  wind: number;
  events: DayEvent[];
  activity: number;
  fieldTeams: number;
  responses: number;
}

function profile(y: number, m: number, d: number): DayProfile {
  const h = hash(`${y}-${m}-${d}`);
  const weather = WEATHER_KINDS[h % WEATHER_KINDS.length];
  const nEvents = 1 + (h % 4);
  const events = Array.from({ length: nEvents }, (_, i) => EVENT_POOL[(h + i * 3) % EVENT_POOL.length])
    .sort((a, b) => a.time.localeCompare(b.time));
  return {
    weather,
    tempHi: 24 + (h % 14),
    tempLo: 8 + (h % 11),
    rain: weather === "rain" || weather === "storm" ? 30 + (h % 60) : h % 18,
    wind: 5 + (h % 26),
    events,
    activity: 25 + (h % 70),
    fieldTeams: 1 + (h % 9),
    responses: 120 + (h % 900),
  };
}

/** Hourly temperature curve for the day-detail sheet. */
function hourlyTemps(seed: string, hi: number, lo: number) {
  const hrs = ["06:00", "09:00", "12:00", "15:00", "18:00", "21:00"];
  return hrs.map((t, i) => {
    const h = hash(`${seed}-${t}`);
    const swing = Math.sin((i / hrs.length) * Math.PI); // warmer midday
    return { t, v: Math.round(lo + (hi - lo) * (0.25 + 0.6 * swing) + (h % 3) - 1) };
  });
}

function attendeesFor(seed: string, n: number) {
  const h = hash(seed);
  return Array.from({ length: n }, (_, i) => ATTENDEE_POOL[(h + i * 5) % ATTENDEE_POOL.length]);
}

const WICON: Record<WeatherKind, React.ReactNode> = {
  sun: <Sun className="h-3 w-3" />,
  cloud: <Cloud className="h-3 w-3" />,
  rain: <CloudRain className="h-3 w-3" />,
  storm: <Zap className="h-3 w-3" />,
  haze: <CloudSun className="h-3 w-3" />,
};

const KIND_COLOR: Record<DayEvent["kind"], string> = {
  survey: "#38bdf8",
  civic: "#a78bfa",
  business: "#34d399",
  field: "#fbbf24",
};

function overlaps(a: DayEvent, b: DayEvent) {
  const toMin = (t: string) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
  return Math.abs(toMin(a.time) - toMin(b.time)) < 75;
}

export function CalendarTab({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSkin(isLight);
  const today = useMemo(() => new Date(), []);
  const [cursor, setCursor] = useState({ y: today.getFullYear(), m: today.getMonth() });
  const [sel, setSel] = useState<number | null>(null);
  const [density, setDensity] = useState<"events" | "weather" | "activity">("events");
  const [forecast, setForecast] = useState(false);

  const first = new Date(cursor.y, cursor.m, 1).getDay();
  const days = new Date(cursor.y, cursor.m + 1, 0).getDate();
  const cells = useMemo(
    () => [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)],
    [first, days],
  );

  const monthProfiles = useMemo(
    () => Array.from({ length: days }, (_, i) => profile(cursor.y, cursor.m, i + 1)),
    [cursor, days],
  );
  const totalEvents = monthProfiles.reduce((a, p) => a + p.events.length, 0);
  const avgHi = Math.round(monthProfiles.reduce((a, p) => a + p.tempHi, 0) / days);
  const rainDays = monthProfiles.filter((p) => p.weather === "rain" || p.weather === "storm").length;
  const busiestIdx = monthProfiles.reduce((a, p, i) => (p.activity > monthProfiles[a].activity ? i : a), 0);
  const busiest = busiestIdx + 1;

  const weekdayTotals = useMemo(() => {
    const t = [0, 0, 0, 0, 0, 0, 0];
    const c = [0, 0, 0, 0, 0, 0, 0];
    monthProfiles.forEach((p, i) => {
      const wd = new Date(cursor.y, cursor.m, i + 1).getDay();
      t[wd] += p.activity; c[wd] += 1;
    });
    return t.map((v, i) => (c[i] ? v / c[i] : 0));
  }, [monthProfiles, cursor]);
  const busiestWeekday = WEEKDAY_FULL[weekdayTotals.reduce((a, v, i) => (v > weekdayTotals[a] ? i : a), 0)];
  const avgEventsPerDay = (totalEvents / days).toFixed(1);
  const fieldHours = monthProfiles.reduce((a, p) => a + p.fieldTeams, 0) * 4;
  const responseVolume = monthProfiles.reduce((a, p) => a + p.responses, 0);

  const next7 = useMemo(
    () => Array.from({ length: 7 }, (_, i) => {
      const dt = new Date(today); dt.setDate(today.getDate() + i);
      return { dt, p: profile(dt.getFullYear(), dt.getMonth(), dt.getDate()) };
    }),
    [today],
  );

  const selProfile = sel ? profile(cursor.y, cursor.m, sel) : null;
  const selConflict = useMemo(() => {
    if (!selProfile) return null;
    for (let i = 0; i < selProfile.events.length - 1; i++) {
      if (overlaps(selProfile.events[i], selProfile.events[i + 1])) {
        return `${selProfile.events[i].title} and ${selProfile.events[i + 1].title} sit within 75 minutes of each other — same field team cannot cover both.`;
      }
    }
    return null;
  }, [selProfile]);

  const shift = (d: number) => {
    const m = cursor.m + d;
    setCursor({ y: cursor.y + Math.floor(m / 12), m: ((m % 12) + 12) % 12 });
    setSel(null);
  };

  return (
    <div className="space-y-1.5 pb-6">
      <div className="grid grid-cols-4 gap-1">
        <Kpi label="Events" value={String(totalEvents)} color={theme.markerCore.city} card={s.card} muted={s.muted} />
        <Kpi label="Avg high" value={`${avgHi}°`} color={theme.markerCore.landmark} card={s.card} muted={s.muted} />
        <Kpi label="Wet days" value={String(rainDays)} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
        <Kpi label="Peak day" value={String(busiest)} color={theme.markerCore.park} card={s.card} muted={s.muted} />
      </div>

      <div className={`mx-auto w-full max-w-[380px] border-y p-1.5 ${s.card}`}>
        <div className="flex items-center gap-1.5">
          <Tap color={theme.glow} effect="squish" onClick={() => shift(-1)} className={`grid h-5 w-5 place-items-center rounded-lg ${s.chip}`}>
            <ChevronLeft className="h-3 w-3" />
          </Tap>
          <div className="text-[11.5px] font-black" style={{ fontFamily: "'Sora',sans-serif" }}>
            {MONTHS[cursor.m]} <span className={s.muted}>{cursor.y}</span>
          </div>
          <Tap color={theme.glow} effect="squish" onClick={() => shift(1)} className={`grid h-5 w-5 place-items-center rounded-lg ${s.chip}`}>
            <ChevronRight className="h-3 w-3" />
          </Tap>
          <div className="ml-auto flex items-center gap-1">
            {(["events", "weather", "activity"] as const).map((k) => (
              <Tap key={k} color={theme.glow} effect="squish" onClick={() => setDensity(k)}
                className={`rounded-full px-1.5 py-[2px] text-[8.5px] font-bold capitalize ${density === k ? s.solid : `${s.chip} ${s.muted}`}`}>
                {k}
              </Tap>
            ))}
          </div>
        </div>

        <div className={`mt-1 grid grid-cols-7 gap-[2px] text-center text-[7.5px] font-bold uppercase tracking-[0.1em] ${s.muted}`}>
          {DOW.map((d, i) => <div key={i}>{d}</div>)}
        </div>

        <div className="mt-[3px] grid grid-cols-7 gap-[2px]">
          {cells.map((d, i) => {
            if (d === null) return <div key={`e${i}`} />;
            const p = monthProfiles[d - 1];
            const isToday = d === today.getDate() && cursor.m === today.getMonth() && cursor.y === today.getFullYear();
            const heat = density === "activity" ? p.activity / 100 : density === "weather" ? p.rain / 100 : p.events.length / 3;
            return (
              <Tap
                key={d} color={theme.glow} effect="ripple" onClick={() => setSel(d)}
                className="h-6 rounded-sm border border-current/10 sm:h-7"
                style={{
                  background: alpha(theme.glow, 0.05 + heat * 0.28),
                  boxShadow: sel === d
                    ? `inset 0 0 0 1.5px ${theme.glow}`
                    : isToday ? `inset 0 0 0 1px ${alpha(theme.glow, 0.6)}` : "none",
                }}
              >
                <div className="flex h-full w-full flex-col items-center justify-center gap-[1px]">
                  <span className="text-[8.5px] font-bold leading-none tabular-nums">{d}</span>
                  {density === "weather" ? (
                    <span style={{ color: theme.glow }}>{WICON[p.weather]}</span>
                  ) : density === "activity" ? (
                    <span className={`text-[7px] tabular-nums ${s.muted}`}>{p.activity}</span>
                  ) : (
                    <span className="flex gap-[2px]">
                      {p.events.slice(0, 3).map((ev, k) => (
                        <span key={k} className="h-[3px] w-[3px] rounded-full" style={{ background: KIND_COLOR[ev.kind] }} />
                      ))}
                    </span>
                  )}
                </div>
              </Tap>
            );
          })}
        </div>

        <div className={`mt-1 flex flex-wrap items-center gap-1.5 text-[7.5px] ${s.muted}`}>
          {Object.entries(KIND_COLOR).map(([k, c]) => (
            <span key={k} className="inline-flex items-center gap-1 capitalize">
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />{k}
            </span>
          ))}
        </div>
      </div>

      <Panel title="Next 7 days · field agenda" className={s.card} muted={s.muted}>
        <div className="space-y-1">
          {next7.map(({ dt, p }, i) => (
            <div key={i} className="rounded-lg border border-current/10 p-1.5">
              <div className="flex items-center gap-1.5">
                <span className="text-[9.5px] font-black tabular-nums">{dt.getDate()}</span>
                <span className={`text-[8.5px] font-bold ${s.muted}`}>{WEEKDAY_FULL[dt.getDay()].slice(0, 3)} · {MONTHS[dt.getMonth()].slice(0, 3)}</span>
                <span style={{ color: theme.glow }} className="ml-auto flex items-center gap-1 text-[8px]">
                  {WICON[p.weather]}{p.tempHi}°
                </span>
              </div>
              {p.events.length === 0 ? (
                <div className={`mt-1 text-[9px] ${s.muted}`}>No scheduled operations.</div>
              ) : (
                <div className="mt-1 space-y-[3px]">
                  {p.events.slice(0, 2).map((ev, k) => (
                    <div key={k} className="flex items-center gap-1.5">
                      <span className="w-[34px] shrink-0 text-[8.5px] font-bold tabular-nums" style={{ color: KIND_COLOR[ev.kind] }}>{ev.time}</span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[9.5px] font-semibold">{ev.title}</div>
                        <div className={`truncate text-[8px] ${s.muted}`}>{ev.owner} · {ev.where}</div>
                      </div>
                    </div>
                  ))}
                  {p.events.length > 2 && <div className={`text-[8px] ${s.muted}`}>+{p.events.length - 2} more</div>}
                </div>
              )}
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Month stats" className={s.card} muted={s.muted}>
        <div className="grid grid-cols-2 gap-1.5">
          <Kpi label="Busiest weekday" value={busiestWeekday.slice(0, 3)} color={theme.markerCore.city} card={s.card} muted={s.muted} />
          <Kpi label="Avg events/day" value={avgEventsPerDay} color={theme.markerCore.landmark} card={s.card} muted={s.muted} />
          <Kpi label="Field team hours" value={String(fieldHours)} suffix="hrs" color={theme.markerCore.park} card={s.card} muted={s.muted} />
          <Kpi label="Response volume" value={responseVolume.toLocaleString()} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
        <Panel title="Historical analysis · same month" className={s.card} muted={s.muted}>
          <Columns
            data={[2020, 2021, 2022, 2023, 2024, 2025].map((y) => ({ k: String(y).slice(2), v: 30 + (hash(`${y}-${cursor.m}`) % 65) }))}
            color={theme.markerCore.capital}
          />
        </Panel>
        <Panel
          title="Forecast engine"
          className={s.card}
          muted={s.muted}
          right={
            <Tap color={theme.glow} effect="glow" onClick={() => setForecast((v) => !v)}
              className="rounded-full px-2 py-[2px] text-[9px] font-bold" style={{ background: theme.glow, color: "#04060d" }}>
              {forecast ? "Reset" : "Run 30-day"}
            </Tap>
          }
        >
          <AnimatePresence mode="wait">
            {forecast ? (
              <motion.div key="f" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <DrawLine
                  series={Array.from({ length: 30 }, (_, i) => 40 + (hash(`${cursor.m}-f-${i}`) % 55))}
                  c1={theme.glow} c2={theme.markerCore.park}
                />
                <div className={`mt-1 text-[10px] ${s.muted}`}>
                  Projected field-activity index, 30-day horizon · confidence 87%
                </div>
              </motion.div>
            ) : (
              <motion.div key="i" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className={`py-4 text-center text-[10.5px] ${s.muted}`}>
                Run the engine to project activity, rainfall and survey yield.
              </motion.div>
            )}
          </AnimatePresence>
        </Panel>
      </div>

      <Sheet
        open={sel !== null}
        onClose={() => setSel(null)}
        isLight={isLight}
        title={sel ? `${MONTHS[cursor.m]} ${sel}, ${cursor.y}` : ""}
      >
        {selProfile && (
          <div className="space-y-2 p-3">
            <div className={`flex items-center gap-3 rounded-xl border p-2.5 ${s.card}`}>
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl" style={{ background: alpha(theme.glow, 0.14), color: theme.glow }}>
                <span className="scale-[1.9]">{WICON[selProfile.weather]}</span>
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-[18px] font-black leading-none" style={{ fontFamily: "'Sora',sans-serif" }}>
                  {selProfile.tempHi}° <span className={`text-[12px] ${s.muted}`}>/ {selProfile.tempLo}°</span>
                </div>
                <div className={`mt-0.5 text-[10.5px] capitalize ${s.muted}`}>{selProfile.weather} · Botswana composite</div>
              </div>
              <div className="shrink-0 space-y-0.5 text-right">
                <div className="flex items-center justify-end gap-1 text-[10px]"><Droplets className="h-3 w-3 opacity-60" />{selProfile.rain}%</div>
                <div className="flex items-center justify-end gap-1 text-[10px]"><Wind className="h-3 w-3 opacity-60" />{selProfile.wind} km/h</div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              <Kpi label="Events" value={String(selProfile.events.length)} color={theme.markerCore.city} card={s.card} muted={s.muted} />
              <Kpi label="Teams" value={String(selProfile.fieldTeams)} color={theme.markerCore.park} card={s.card} muted={s.muted} />
              <Kpi label="Responses" value={String(selProfile.responses)} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
              <Kpi label="Activity" value={String(selProfile.activity)} color={theme.markerCore.landmark} card={s.card} muted={s.muted} />
            </div>

            <Panel title="Weather timeline" className={s.card} muted={s.muted}>
              <DrawLine
                series={hourlyTemps(`${cursor.y}-${cursor.m}-${sel}`, selProfile.tempHi, selProfile.tempLo).map((h) => h.v)}
                c1={theme.glow} c2={theme.markerCore.landmark} height={44}
              />
              <div className={`mt-0.5 flex justify-between text-[8px] tabular-nums ${s.muted}`}>
                {hourlyTemps(`${cursor.y}-${cursor.m}-${sel}`, selProfile.tempHi, selProfile.tempLo).map((h) => (
                  <span key={h.t}>{h.t.slice(0, 2)}h · {h.v}°</span>
                ))}
              </div>
            </Panel>

            <Panel title="Schedule" className={s.card} muted={s.muted}>
              {selProfile.events.length === 0 ? (
                <div className={`py-3 text-center text-[10.5px] ${s.muted}`}>No scheduled operations.</div>
              ) : (
                <div className="space-y-1">
                  {selProfile.events.map((ev, i) => (
                    <Tap key={i} color={KIND_COLOR[ev.kind]} effect="ripple" className={`flex w-full items-center gap-2 rounded-lg p-1.5 ${s.chip}`}>
                      <span className="w-[38px] shrink-0 text-[10px] font-bold tabular-nums" style={{ color: KIND_COLOR[ev.kind] }}>{ev.time}</span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[11px] font-semibold">{ev.title}</div>
                        <div className={`truncate text-[9.5px] ${s.muted}`}>{ev.owner} · {ev.where}</div>
                      </div>
                      <span className="shrink-0 rounded-full px-1.5 py-[1px] text-[8.5px] font-black capitalize"
                        style={{ background: alpha(KIND_COLOR[ev.kind], 0.16), color: KIND_COLOR[ev.kind] }}>
                        {ev.kind}
                      </span>
                    </Tap>
                  ))}
                </div>
              )}
            </Panel>

            {selProfile.events.length > 0 && (
              <Panel title="Attendees & ward coverage" className={s.card} muted={s.muted}>
                <div className="flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5 shrink-0" style={{ color: theme.glow }} />
                  <div className={`text-[10px] ${s.muted}`}>
                    {attendeesFor(`${cursor.y}-${cursor.m}-${sel}-att`, 3 + (selProfile.fieldTeams % 3)).join(", ")}
                  </div>
                </div>
                <div className={`mt-1 text-[9.5px] ${s.muted}`}>
                  Ward coverage: {WARDS[hash(`${cursor.y}-${cursor.m}-${sel}-w`) % WARDS.length]}
                </div>
              </Panel>
            )}

            {selConflict && (
              <div className="flex gap-2 rounded-lg border p-2" style={{ borderColor: alpha("#f97316", 0.35), background: alpha("#f97316", 0.08) }}>
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color: "#f97316" }} />
                <p className="text-[10.5px] leading-snug">{selConflict}</p>
              </div>
            )}

            <Panel title="Day metrics" className={s.card} muted={s.muted}>
              <div className="flex items-center gap-3">
                <Ring value={selProfile.activity} color={theme.glow} size={52} />
                <div className="min-w-0 flex-1 space-y-1">
                  {[
                    { k: "Survey yield", v: Math.min(100, Math.round(selProfile.responses / 10)) },
                    { k: "Field coverage", v: selProfile.fieldTeams * 11 },
                    { k: "Weather risk", v: selProfile.rain },
                  ].map((r) => (
                    <div key={r.k} className="flex items-center gap-2">
                      <span className="w-[78px] shrink-0 text-[10px] font-semibold">{r.k}</span>
                      <div className="min-w-0 flex-1"><Bar v={Math.min(100, r.v)} color={theme.markerCore.city} chip={s.chip} /></div>
                    </div>
                  ))}
                </div>
              </div>
            </Panel>

            <Panel title="AI day analysis" className={s.card} muted={s.muted}>
              <div className="flex gap-2">
                <Brain className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color: theme.glow }} />
                <p className="text-[11px] leading-snug">
                  {selProfile.rain > 40
                    ? `High precipitation probability (${selProfile.rain}%) — reschedule the ${selProfile.events[0]?.kind ?? "field"} window and prioritise indoor kgotla sessions.`
                    : `Favourable conditions at ${selProfile.tempHi}° with ${selProfile.wind} km/h winds — optimal for drone mapping and door-to-door waves.`}{" "}
                  Historical same-day yield averages {selProfile.responses - 40}–{selProfile.responses + 60} responses.
                </p>
              </div>
            </Panel>
          </div>
        )}
      </Sheet>
    </div>
  );
}
