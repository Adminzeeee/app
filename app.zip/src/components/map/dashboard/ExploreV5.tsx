import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Building2, MapPin, Megaphone, Users, Plus, Pencil, Trash2,
  Eye, EyeOff, BarChart3, CheckCircle2, ArrowLeft,
} from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData } from "../types";
import { alpha } from "../color";
import { Tap, useSkin } from "./ui";
import { DIR_PEOPLE, DIR_BIZ, ADS } from "./directoryData";
import type { ExploreProps } from "./ExploreShell";

const DATA = raw as unknown as BotswanaData;

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}
const val = (scope: string, salt: number, min: number, max: number) =>
  Math.round(min + ((hash(scope + salt) % 1000) / 1000) * (max - min));

type Card = "people" | "business" | "listings";
type Kind = "business" | "freelancer" | "ad";

interface Entry {
  id: string;
  kind: Kind;
  name: string;
  detail: string;
  city: string;
  price?: string;
  live: boolean;
  views: number;
  contacts: number;
}

const KIND_META: Record<Kind, { label: string; icon: typeof Users; f2: string }> = {
  business: { label: "Business", icon: Building2, f2: "Category" },
  freelancer: { label: "Freelancer", icon: Users, f2: "Skill / role" },
  ad: { label: "Ad", icon: Megaphone, f2: "What you're offering" },
};

/** v5 — Atlas + owner console: register a business, freelance profile or ad and manage it. */
export function ExploreV5({ theme, isLight, place, onSelectPlace }: ExploreProps) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [open, setOpen] = useState<Card | null>(null);
  const [mode, setMode] = useState<"atlas" | "admin">("atlas");
  const [entries, setEntries] = useState<Entry[]>([
    { id: "e1", kind: "business", name: "Kgale Coffee Co.", detail: "Cafe · Retail", city: "Gaborone", live: true, views: 1284, contacts: 37 },
    { id: "e2", kind: "freelancer", name: "T. Moseki", detail: "Solar installer", city: "Francistown", live: true, views: 642, contacts: 21 },
    { id: "e3", kind: "ad", name: "Bakkie for hire", detail: "Transport · Daily", city: "Maun", price: "P450/day", live: false, views: 208, contacts: 6 },
  ]);
  const [form, setForm] = useState<Entry | null>(null);

  const scope = place?.name ?? "All Botswana";
  const strip = useMemo(() => DATA.places.filter((p) => p.type !== "village").slice(0, 24), []);
  const score = val(scope, 7, 38, 96);
  const R = 26;
  const circ = 2 * Math.PI * R;

  const lists: Record<Card, { title: string; sub: string; right: string }[]> = {
    people: DIR_PEOPLE.slice(0, 12).map((p) => ({ title: p.name, sub: `${p.role} · ${p.city}`, right: `★ ${p.rating}` })),
    business: DIR_BIZ.slice(0, 12).map((b) => {
      const o = b as unknown as Record<string, string | number>;
      return { title: String(o.name ?? "Business"), sub: `${o.cat ?? ""} · ${o.city ?? "Botswana"}`, right: o.rating ? `★ ${o.rating}` : "" };
    }),
    listings: ADS.slice(0, 12).map((a) => ({ title: a.title, sub: `${a.kind} · ${a.city}`, right: a.price })),
  };

  const cards: { k: Card; label: string; icon: typeof Users; n: number }[] = [
    { k: "people", label: "People", icon: Users, n: val(scope, 1, 180, 6400) },
    { k: "business", label: "Business", icon: Building2, n: val(scope, 2, 40, 1900) },
    { k: "listings", label: "Listings", icon: Megaphone, n: val(scope, 3, 60, 2600) },
  ];

  const startNew = (kind: Kind) =>
    setForm({ id: "", kind, name: "", detail: "", city: place?.name ?? "Gaborone", price: "", live: true, views: 0, contacts: 0 });

  const save = () => {
    if (!form || !form.name.trim()) return;
    setEntries((prev) =>
      form.id ? prev.map((e) => (e.id === form.id ? form : e)) : [{ ...form, id: `e${Date.now()}` }, ...prev],
    );
    setForm(null);
  };

  const inputCls = "w-full rounded-xl border bg-transparent px-2 py-[7px] text-[10px] outline-none";
  const inputStyle = { borderColor: alpha(g, 0.2) };

  const totals = entries.reduce(
    (a, e) => ({ views: a.views + e.views, contacts: a.contacts + e.contacts, live: a.live + (e.live ? 1 : 0) }),
    { views: 0, contacts: 0, live: 0 },
  );

  return (
    <div className="space-y-2">
      {/* mode switch */}
      <div className="flex items-center gap-1">
        {(["atlas", "admin"] as const).map((m) => (
          <Tap key={m} color={g} effect="squish" onClick={() => { setMode(m); setForm(null); }}
            className="rounded-full px-3 py-[5px] text-[9px] font-black uppercase tracking-[0.14em]"
            style={mode === m ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
            {m === "atlas" ? "Explore" : "My listings"}
          </Tap>
        ))}
        {mode === "admin" && (
          <span className={`ml-auto text-[8px] ${s.muted}`}>{totals.live} live · {totals.views.toLocaleString()} views</span>
        )}
      </div>

      {mode === "atlas" && (
        <>
          {/* place strip */}
          <div className="-mx-0.5 flex gap-1 overflow-x-auto pb-1">
            <Tap color={g} effect="squish" onClick={() => onSelectPlace?.(null)}
              className="shrink-0 rounded-full px-2.5 py-[4px] text-[9px] font-black"
              style={!place ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
              All Botswana
            </Tap>
            {strip.map((p) => (
              <Tap key={p.name} color={g} effect="squish" onClick={() => onSelectPlace?.(p)}
                className="shrink-0 rounded-full px-2.5 py-[4px] text-[9px] font-bold"
                style={place?.name === p.name ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
                {p.name}
              </Tap>
            ))}
          </div>

          {/* dial + headline */}
          <div className="flex items-center gap-3 rounded-2xl border p-3" style={{ borderColor: alpha(g, 0.16), background: alpha(g, 0.04) }}>
            <svg width="64" height="64" viewBox="0 0 64 64" className="shrink-0">
              <circle cx="32" cy="32" r={R} fill="none" stroke={alpha(g, 0.15)} strokeWidth="6" />
              <motion.circle
                cx="32" cy="32" r={R} fill="none" stroke={g} strokeWidth="6" strokeLinecap="round"
                transform="rotate(-90 32 32)" strokeDasharray={circ}
                initial={{ strokeDashoffset: circ }}
                animate={{ strokeDashoffset: circ - (circ * score) / 100 }}
                transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              />
              <text x="32" y="36" textAnchor="middle" fontSize="16" fontWeight="800" fill={g}>{score}</text>
            </svg>
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <MapPin className="h-3 w-3 shrink-0" style={{ color: g }} />
                <span className="truncate text-[15px] font-black leading-none">{scope}</span>
              </div>
              <div className={`mt-1 text-[8.5px] leading-snug ${s.muted}`}>
                Opportunity score across services, demand and talent supply. Updated live by the engine.
              </div>
              <div className="mt-1 flex gap-2 text-[8px]">
                <span className={s.muted}>growth <b style={{ color: g }}>+{val(scope, 9, 2, 24)}%</b></span>
                <span className={s.muted}>demand <b style={{ color: g }}>{val(scope, 11, 30, 99)}</b></span>
              </div>
            </div>
          </div>

          {/* deep-dive cards */}
          <div className="grid grid-cols-3 gap-1.5">
            {cards.map((c) => {
              const on = open === c.k;
              const Icon = c.icon;
              return (
                <Tap key={c.k} color={g} effect="lift" onClick={() => setOpen(on ? null : c.k)}
                  className="rounded-2xl border p-2"
                  style={{ borderColor: on ? alpha(g, 0.45) : alpha(g, 0.14), background: on ? alpha(g, 0.1) : "transparent" }}>
                  <Icon className="h-3.5 w-3.5" style={{ color: g }} />
                  <div className="mt-1 text-[13px] font-black leading-none tabular-nums">{c.n.toLocaleString()}</div>
                  <div className={`mt-[2px] text-[7px] font-bold uppercase tracking-[0.16em] ${s.muted}`}>{c.label}</div>
                </Tap>
              );
            })}
          </div>

          {open && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl border p-1.5" style={{ borderColor: alpha(g, 0.14) }}>
              <div className="max-h-[240px] overflow-y-auto">
                {lists[open].map((it, i) => (
                  <div key={i} className="flex items-center gap-2 border-b px-1 py-[6px] last:border-0" style={{ borderColor: alpha(g, 0.08) }}>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[10px] font-bold">{it.title}</span>
                      <span className={`block truncate text-[7.5px] ${s.muted}`}>{it.sub}</span>
                    </span>
                    <span className="shrink-0 text-[8.5px] font-black" style={{ color: g }}>{it.right}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* join the directory */}
          <div className="rounded-2xl border p-2.5" style={{ borderColor: alpha(g, 0.16), background: alpha(g, 0.04) }}>
            <div className="text-[10.5px] font-black">Get listed in {scope}</div>
            <div className={`mt-[2px] text-[8px] ${s.muted}`}>Register a business, offer freelance work or post an ad — free.</div>
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {(Object.keys(KIND_META) as Kind[]).map((k) => {
                const Icon = KIND_META[k].icon;
                return (
                  <Tap key={k} color={g} effect="lift" onClick={() => { setMode("admin"); startNew(k); }}
                    className="flex items-center justify-center gap-1 rounded-xl border py-2 text-[8.5px] font-black"
                    style={{ borderColor: alpha(g, 0.2) }}>
                    <Icon className="h-3 w-3" style={{ color: g }} />
                    {KIND_META[k].label}
                  </Tap>
                );
              })}
            </div>
          </div>
        </>
      )}

      {mode === "admin" && (
        <AnimatePresence mode="wait">
          {form ? (
            <motion.div key="form" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="space-y-1.5 rounded-2xl border p-2.5" style={{ borderColor: alpha(g, 0.16) }}>
              <div className="flex items-center gap-1.5">
                <Tap color={g} effect="squish" onClick={() => setForm(null)} className="rounded-full p-1" style={{ background: alpha(g, 0.1) }}>
                  <ArrowLeft className="h-3 w-3" style={{ color: g }} />
                </Tap>
                <span className="text-[11px] font-black">{form.id ? "Edit" : "Register"} {KIND_META[form.kind].label.toLowerCase()}</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {(Object.keys(KIND_META) as Kind[]).map((k) => (
                  <Tap key={k} color={g} effect="squish" onClick={() => setForm({ ...form, kind: k })}
                    className="rounded-lg py-[5px] text-[8.5px] font-bold"
                    style={form.kind === k ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
                    {KIND_META[k].label}
                  </Tap>
                ))}
              </div>
              <input className={inputCls} style={inputStyle} placeholder="Name / title"
                value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <input className={inputCls} style={inputStyle} placeholder={KIND_META[form.kind].f2}
                value={form.detail} onChange={(e) => setForm({ ...form, detail: e.target.value })} />
              <div className="flex gap-1.5">
                <input className={inputCls} style={inputStyle} placeholder="City"
                  value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                {form.kind === "ad" && (
                  <input className={inputCls} style={inputStyle} placeholder="Price"
                    value={form.price ?? ""} onChange={(e) => setForm({ ...form, price: e.target.value })} />
                )}
              </div>
              <div className="flex items-center gap-2 pt-0.5">
                <Tap color={g} effect="squish" onClick={() => setForm({ ...form, live: !form.live })}
                  className="flex items-center gap-1 rounded-full px-2 py-[4px] text-[8.5px] font-black"
                  style={{ background: alpha(g, form.live ? 0.16 : 0.06), color: form.live ? g : undefined }}>
                  {form.live ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                  {form.live ? "Visible" : "Hidden"}
                </Tap>
                <Tap color={g} effect="lift" onClick={save}
                  className="ml-auto rounded-full px-3 py-[5px] text-[9px] font-black"
                  style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
                  {form.id ? "Save changes" : "Publish listing"}
                </Tap>
              </div>
            </motion.div>
          ) : (
            <motion.div key="list" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-2">
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  ["Views", totals.views.toLocaleString()],
                  ["Contacts", String(totals.contacts)],
                  ["Live", `${totals.live}/${entries.length}`],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-2xl border p-2" style={{ borderColor: alpha(g, 0.14) }}>
                    <BarChart3 className="h-3 w-3" style={{ color: g }} />
                    <div className="mt-1 text-[13px] font-black leading-none tabular-nums">{v}</div>
                    <div className={`mt-[2px] text-[7px] font-bold uppercase tracking-[0.16em] ${s.muted}`}>{k}</div>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border" style={{ borderColor: alpha(g, 0.14) }}>
                {entries.length === 0 && (
                  <div className={`px-2 py-4 text-center text-[9px] ${s.muted}`}>Nothing registered yet.</div>
                )}
                {entries.map((e) => {
                  const Icon = KIND_META[e.kind].icon;
                  return (
                    <div key={e.id} className="flex items-center gap-2 border-b px-2 py-[8px] last:border-0" style={{ borderColor: alpha(g, 0.08) }}>
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg" style={{ background: alpha(g, 0.12) }}>
                        <Icon className="h-3 w-3" style={{ color: g }} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1">
                          <span className="truncate text-[10.5px] font-bold">{e.name}</span>
                          {e.live && <CheckCircle2 className="h-2.5 w-2.5 shrink-0" style={{ color: g }} />}
                        </span>
                        <span className={`block truncate text-[7.5px] ${s.muted}`}>
                          {e.detail} · {e.city}{e.price ? ` · ${e.price}` : ""} · {e.views.toLocaleString()} views · {e.contacts} contacts
                        </span>
                      </span>
                      <Tap color={g} effect="squish" onClick={() => setEntries((p) => p.map((x) => x.id === e.id ? { ...x, live: !x.live } : x))}
                        className="shrink-0 rounded-lg p-1" style={{ background: alpha(g, 0.08) }}>
                        {e.live ? <Eye className="h-3 w-3" style={{ color: g }} /> : <EyeOff className="h-3 w-3 opacity-60" />}
                      </Tap>
                      <Tap color={g} effect="squish" onClick={() => setForm(e)} className="shrink-0 rounded-lg p-1" style={{ background: alpha(g, 0.08) }}>
                        <Pencil className="h-3 w-3" style={{ color: g }} />
                      </Tap>
                      <Tap color={g} effect="squish" onClick={() => setEntries((p) => p.filter((x) => x.id !== e.id))}
                        className="shrink-0 rounded-lg p-1" style={{ background: alpha(g, 0.08) }}>
                        <Trash2 className="h-3 w-3 opacity-70" />
                      </Tap>
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-3 gap-1.5">
                {(Object.keys(KIND_META) as Kind[]).map((k) => (
                  <Tap key={k} color={g} effect="lift" onClick={() => startNew(k)}
                    className="flex items-center justify-center gap-1 rounded-xl border py-2 text-[8.5px] font-black"
                    style={{ borderColor: alpha(g, 0.2) }}>
                    <Plus className="h-3 w-3" style={{ color: g }} />
                    {KIND_META[k].label}
                  </Tap>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      )}
    </div>
  );
}
