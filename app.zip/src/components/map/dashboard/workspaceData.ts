/* Workspace AI engine — sources, findings, scenarios. */

export type FindingKind = "opportunity" | "gap" | "risk";
export type Severity = "critical" | "high" | "medium" | "low";

export interface SourceDef {
  k: string;
  label: string;
  records: number;
  fresh: string;
}

export const SOURCES: SourceDef[] = [
  { k: "news", label: "News & press", records: 12_840, fresh: "4m" },
  { k: "surveys", label: "Survey waves", records: 15_492, fresh: "1h" },
  { k: "directory", label: "Directory", records: 46_867, fresh: "9m" },
  { k: "weather", label: "Weather API", records: 88_120, fresh: "2m" },
  { k: "calendar", label: "Calendar", records: 1_204, fresh: "18m" },
  { k: "events", label: "Public events", records: 3_318, fresh: "31m" },
  { k: "notes", label: "Custom notes", records: 214, fresh: "just now" },
  { k: "trade", label: "Trade & customs", records: 22_006, fresh: "1h" },
  { k: "sensors", label: "Sensor mesh", records: 190_442, fresh: "12s" },
  { k: "social", label: "Social listening", records: 61_775, fresh: "7m" },
];

export const REGIONS = [
  "All Botswana", "South-East", "Central", "North-East", "North-West",
  "Chobe", "Ghanzi", "Kgalagadi", "Kweneng", "Southern",
];

export const SECTORS = [
  "All sectors", "Energy", "Water", "Agriculture", "Tourism", "Logistics",
  "Housing", "Health", "Education", "Digital", "Mining", "Retail",
];

export const HORIZONS = ["30 days", "90 days", "6 months", "12 months", "3 years"];
export const DEPTHS = ["Fast sweep", "Standard", "Deep analysis", "Exhaustive"];

export const SCAN_STAGES = [
  "Authenticating source connectors",
  "Streaming records from 10 sources",
  "Normalising schema · resolving entities",
  "Geo-joining to district boundaries",
  "Building temporal feature vectors",
  "Detecting anomalies against 24-month baseline",
  "Cross-correlating weather × supply signals",
  "Scoring opportunity clusters",
  "Stress-testing against risk register",
  "Ranking by confidence × impact",
  "Drafting executive narrative",
];

export interface Finding {
  id: string;
  kind: FindingKind;
  title: string;
  region: string;
  sector: string;
  score: number;
  confidence: number;
  impact: number;
  effort: number;
  severity: Severity;
  value: string;
  horizon: string;
  summary: string;
  evidence: { src: string; text: string; weight: number }[];
  actions: string[];
  trend: number[];
}

export const FINDINGS: Finding[] = [
  {
    id: "f1", kind: "opportunity", title: "Digital skills academy · Francistown",
    region: "North-East", sector: "Education", score: 92, confidence: 88, impact: 84, effort: 46,
    severity: "high", value: "P41.2M / 3yr", horizon: "12 months",
    summary: "5,120 youth survey responses cite digital skills as the top employment pathway while the directory shows zero accredited training providers within 180km. Employer demand for React and data roles is up 48% on the directory feed.",
    evidence: [
      { src: "surveys", text: "Youth employment wave 8: digital skills demand +24% YoY", weight: 0.31 },
      { src: "directory", text: "0 accredited digital training providers registered in North-East", weight: 0.27 },
      { src: "news", text: "3 press mentions of employer skills shortages in 30 days", weight: 0.18 },
      { src: "trade", text: "IT services imports up 12% — spend leaving the district", weight: 0.14 },
      { src: "notes", text: "Field note: Francistown council offered a disused annex", weight: 0.10 },
    ],
    actions: ["Scope a 400-seat academy", "Approach 2 anchor employers", "Model 3-year fee structure"],
    trend: [22, 30, 28, 41, 46, 52, 61, 68, 74, 82, 88, 92],
  },
  {
    id: "f2", kind: "opportunity", title: "Cold-chain hub · Ghanzi",
    region: "Ghanzi", sector: "Agriculture", score: 78, confidence: 81, impact: 76, effort: 62,
    severity: "high", value: "P26.8M / 3yr", horizon: "6 months",
    summary: "Agri output in Ghanzi rose 14% while the directory lists zero refrigerated depots. Spoilage estimated at 9-13% of perishable output based on transit distance modelling.",
    evidence: [
      { src: "directory", text: "0 cold-chain depots registered in Ghanzi district", weight: 0.34 },
      { src: "sensors", text: "Mean transit temp exceeds 8°C on 61% of runs", weight: 0.26 },
      { src: "trade", text: "Perishable outbound volume +14% over 12 months", weight: 0.22 },
      { src: "weather", text: "Mean daytime max up 1.4°C vs 10-year baseline", weight: 0.18 },
    ],
    actions: ["Site survey 3 candidate plots", "Model 600-pallet capacity", "Test anchor tenant demand"],
    trend: [40, 42, 47, 44, 52, 58, 55, 63, 68, 71, 74, 78],
  },
  {
    id: "f3", kind: "opportunity", title: "Solar borehole retrofit programme · Kgalagadi",
    region: "Kgalagadi", sector: "Energy", score: 71, confidence: 90, impact: 88, effort: 55,
    severity: "high", value: "P18.4M / 3yr", horizon: "90 days",
    summary: "81% of Kgalagadi respondents report water outages. Sensor telemetry attributes 64% of downtime to diesel pump supply, not aquifer depletion. Grant windows close in 74 days.",
    evidence: [
      { src: "surveys", text: "81% outage report rate — highest of any district", weight: 0.29 },
      { src: "sensors", text: "64% of pump downtime is fuel-supply related", weight: 0.28 },
      { src: "calendar", text: "Renewable grant window closes in 74 days", weight: 0.24 },
      { src: "directory", text: "12 certified solar installers within range", weight: 0.19 },
    ],
    actions: ["Shortlist 40 priority boreholes", "Assemble grant application", "Pre-qualify 4 installers"],
    trend: [55, 52, 58, 61, 57, 64, 66, 63, 68, 70, 69, 71],
  },
  {
    id: "f4", kind: "opportunity", title: "Community tourism circuit · Tsodilo",
    region: "North-West", sector: "Tourism", score: 64, confidence: 72, impact: 61, effort: 38,
    severity: "medium", value: "P9.1M / 3yr", horizon: "6 months",
    summary: "Visitor intent for heritage sites up 18% YoY across social listening while bed capacity within 90km is unchanged since 2019.",
    evidence: [
      { src: "social", text: "Heritage-site intent mentions +18% YoY", weight: 0.33 },
      { src: "directory", text: "Bed capacity flat since 2019 within 90km", weight: 0.30 },
      { src: "events", text: "4 new cultural festivals scheduled next season", weight: 0.21 },
      { src: "news", text: "UNESCO maintenance funding announcement", weight: 0.16 },
    ],
    actions: ["Map 6 community-owned camps", "Bundle a 3-night circuit", "Train 20 local guides"],
    trend: [30, 34, 38, 36, 42, 47, 45, 52, 56, 59, 62, 64],
  },
  {
    id: "f5", kind: "gap", title: "No paediatric coverage · Kgalagadi South",
    region: "Kgalagadi", sector: "Health", score: 84, confidence: 93, impact: 90, effort: 71,
    severity: "critical", value: "36k residents", horizon: "12 months",
    summary: "Zero registered paediatric practitioners in a catchment of 36,000. Nearest coverage is a 214km drive. Directory registrations show no inbound movement in 18 months.",
    evidence: [
      { src: "directory", text: "0 paediatric practitioners registered in catchment", weight: 0.42 },
      { src: "surveys", text: "Health access satisfaction at 31/100 — lowest nationally", weight: 0.31 },
      { src: "calendar", text: "No scheduled outreach clinics in next 90 days", weight: 0.27 },
    ],
    actions: ["Fund 2 rotating outreach posts", "Incentivise relocation", "Telehealth bridge pilot"],
    trend: [70, 72, 74, 73, 76, 78, 80, 79, 82, 83, 84, 84],
  },
  {
    id: "f6", kind: "gap", title: "Freight capacity gap on A3 corridor",
    region: "North-West", sector: "Logistics", score: 69, confidence: 79, impact: 72, effort: 58,
    severity: "high", value: "P12.6M leakage", horizon: "90 days",
    summary: "Registered haulage capacity covers 61% of modelled seasonal demand. Green-season peak will exceed available refrigerated units by an estimated 34 trucks.",
    evidence: [
      { src: "directory", text: "Registered capacity covers 61% of modelled demand", weight: 0.36 },
      { src: "weather", text: "Green-season onset forecast 11 days early", weight: 0.24 },
      { src: "trade", text: "Northbound perishable bookings +21%", weight: 0.22 },
      { src: "events", text: "3 large tourism events overlap the peak window", weight: 0.18 },
    ],
    actions: ["Broker cross-district capacity pool", "Publish spot-rate board", "Pre-book 12 reefers"],
    trend: [45, 48, 52, 50, 55, 58, 61, 64, 62, 66, 68, 69],
  },
  {
    id: "f7", kind: "gap", title: "Survey coverage blind spot · Central rural",
    region: "Central", sector: "Digital", score: 52, confidence: 86, impact: 48, effort: 24,
    severity: "medium", value: "9 wards", horizon: "30 days",
    summary: "Nine wards have returned fewer than 20 responses across the last four waves. Weighting models are extrapolating from thin samples, inflating uncertainty bands nationally.",
    evidence: [
      { src: "surveys", text: "9 wards below the 20-response confidence floor", weight: 0.44 },
      { src: "directory", text: "Only 3 enumerators registered in those wards", weight: 0.31 },
      { src: "notes", text: "Field note: network coverage drops after Serule", weight: 0.25 },
    ],
    actions: ["Recruit 12 local enumerators", "Offline capture kit rollout", "Re-weight current wave"],
    trend: [38, 40, 42, 44, 43, 46, 48, 47, 50, 51, 52, 52],
  },
  {
    id: "f8", kind: "risk", title: "Water reliability decline — eight-wave trend",
    region: "Kgalagadi", sector: "Water", score: 88, confidence: 94, impact: 91, effort: 66,
    severity: "critical", value: "P31M exposure", horizon: "90 days",
    summary: "Sentiment on water reliability has fallen every wave for eight consecutive periods. Sensor data confirms deterioration is real, not perceptual. Escalation risk to civic unrest is rated material.",
    evidence: [
      { src: "surveys", text: "8 consecutive waves of declining sentiment", weight: 0.30 },
      { src: "sensors", text: "Pump uptime down 14pts over 6 months", weight: 0.28 },
      { src: "news", text: "5 press items on outages in 21 days", weight: 0.22 },
      { src: "social", text: "Complaint volume +62% month over month", weight: 0.20 },
    ],
    actions: ["Escalate to district ops", "Publish outage transparency dashboard", "Emergency pump contracts"],
    trend: [50, 55, 58, 62, 66, 70, 74, 78, 81, 84, 86, 88],
  },
  {
    id: "f9", kind: "risk", title: "Housing affordability gap widening",
    region: "South-East", sector: "Housing", score: 76, confidence: 84, impact: 79, effort: 82,
    severity: "high", value: "P54M / 3yr", horizon: "12 months",
    summary: "Serviced-plot supply is growing at 2.1% against 7.4% household formation. 38% of respondents name serviced land as the single largest blocker.",
    evidence: [
      { src: "surveys", text: "38% name serviced plots as the #1 blocker", weight: 0.34 },
      { src: "trade", text: "Construction input costs +9.2% YoY", weight: 0.26 },
      { src: "directory", text: "Registered developers flat while demand rises", weight: 0.21 },
      { src: "news", text: "Two stalled servicing tenders reported", weight: 0.19 },
    ],
    actions: ["Fast-track 3 servicing tenders", "Publish plot pipeline", "Review density rules"],
    trend: [58, 60, 63, 61, 66, 68, 70, 69, 72, 74, 75, 76],
  },
  {
    id: "f10", kind: "risk", title: "Human–elephant conflict escalation · Chobe",
    region: "Chobe", sector: "Agriculture", score: 58, confidence: 77, impact: 64, effort: 49,
    severity: "medium", value: "P6.2M crop loss", horizon: "6 months",
    summary: "Incident reports up 11% with the dry-season corridor shifting 12km closer to cultivated land based on movement telemetry.",
    evidence: [
      { src: "sensors", text: "Corridor shifted 12km toward cultivated land", weight: 0.35 },
      { src: "surveys", text: "Conflict tops conservation concerns in Chobe", weight: 0.27 },
      { src: "weather", text: "Rainfall deficit pushing herds to river line", weight: 0.22 },
      { src: "events", text: "Community mitigation workshops undersubscribed", weight: 0.16 },
    ],
    actions: ["Deploy 30 beehive fences", "Fund rapid-response unit", "Compensation scheme review"],
    trend: [42, 44, 46, 48, 47, 50, 53, 52, 55, 56, 57, 58],
  },
  {
    id: "f11", kind: "risk", title: "Fuel pass-through compressing freight margins",
    region: "All Botswana", sector: "Logistics", score: 47, confidence: 71, impact: 52, effort: 34,
    severity: "medium", value: "P8.9M margin", horizon: "90 days",
    summary: "Diesel pass-through lags contract repricing by roughly 6 weeks. Directory operators report margin compression of 3-5 points across the last two quarters.",
    evidence: [
      { src: "trade", text: "Diesel landed cost +7.8% over two quarters", weight: 0.38 },
      { src: "directory", text: "Operators report 3-5pt margin compression", weight: 0.33 },
      { src: "news", text: "Regional fuel levy adjustment announced", weight: 0.29 },
    ],
    actions: ["Introduce indexed fuel clauses", "Route optimisation audit", "Backhaul matching pilot"],
    trend: [30, 33, 36, 34, 38, 41, 40, 43, 44, 46, 46, 47],
  },
  {
    id: "f12", kind: "opportunity", title: "Green-season flash demand · Maun lodging",
    region: "North-West", sector: "Tourism", score: 66, confidence: 74, impact: 58, effort: 22,
    severity: "medium", value: "P4.4M / season", horizon: "30 days",
    summary: "Flood pulse arriving 11 days early against a booking curve that has not adjusted. Short window to reprice and market mokoro-linked packages.",
    evidence: [
      { src: "weather", text: "Flood pulse 11 days ahead of 10-year mean", weight: 0.37 },
      { src: "social", text: "Delta search intent spiking 2 weeks early", weight: 0.28 },
      { src: "directory", text: "Operators still on dry-season pricing", weight: 0.20 },
      { src: "calendar", text: "Two operator forums scheduled this month", weight: 0.15 },
    ],
    actions: ["Alert 40 operators", "Push early-season campaign", "Reprice mokoro bundles"],
    trend: [28, 32, 36, 41, 45, 44, 50, 55, 58, 61, 64, 66],
  },
];

export interface ScenarioLever {
  k: string;
  label: string;
  unit: string;
  min: number;
  max: number;
  def: number;
  /** How strongly this lever moves the modelled outcome. */
  weight: number;
}

export const LEVERS: ScenarioLever[] = [
  { k: "budget", label: "Budget deployed", unit: "M pula", min: 0, max: 60, def: 18, weight: 1.0 },
  { k: "speed", label: "Delivery speed", unit: "%", min: 40, max: 200, def: 100, weight: 0.55 },
  { k: "partners", label: "Delivery partners", unit: "orgs", min: 1, max: 12, def: 4, weight: 0.4 },
  { k: "adoption", label: "Adoption rate", unit: "%", min: 10, max: 95, def: 55, weight: 0.85 },
  { k: "risk", label: "Risk tolerance", unit: "%", min: 0, max: 100, def: 45, weight: 0.3 },
];

export const SCENARIO_PRESETS = [
  { k: "base", label: "Base case", mods: { budget: 18, speed: 100, partners: 4, adoption: 55, risk: 45 } },
  { k: "aggressive", label: "Aggressive", mods: { budget: 42, speed: 165, partners: 9, adoption: 78, risk: 80 } },
  { k: "lean", label: "Lean pilot", mods: { budget: 6, speed: 80, partners: 2, adoption: 34, risk: 25 } },
  { k: "drought", label: "Drought shock", mods: { budget: 22, speed: 70, partners: 5, adoption: 40, risk: 90 } },
  { k: "boom", label: "Tourism boom", mods: { budget: 30, speed: 140, partners: 7, adoption: 84, risk: 55 } },
];

export const NOTES_SEED = [
  { t: "Francistown council offered a disused annex for training use", when: "2d ago", tag: "Education" },
  { t: "Network coverage drops badly after Serule — offline kits needed", when: "5d ago", tag: "Digital" },
  { t: "Ghanzi farmers association open to anchor-tenant conversation", when: "1w ago", tag: "Agriculture" },
  { t: "Grant window for renewable retrofits closes in 74 days", when: "1w ago", tag: "Energy" },
];
