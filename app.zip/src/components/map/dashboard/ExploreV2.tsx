import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Building2, MapPin, Megaphone, Users } from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData } from "../types";
import { alpha } from "../color";
import { Tap, useSkin } from "./ui";
import { DIR_PEOPLE, DIR_BIZ, ADS } from "./directoryData";
import type { ExploreProps } from "./ExploreShell";

const DATA = raw as unknown as BotswanaData;

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}
const val = (scope: string, salt: number, min: number, max: number) =>
  Math.round(min + ((hash(scope + salt) % 1000) / 1000) * (max - min));

type Card = "people" | "business" | "listings";

/** v2 — Atlas: place strip, a live score dial and three deep-dive cards. */
export function ExploreV2({ theme, isLight, place, onSelectPlace }: ExploreProps) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [open, setOpen] = useState<Card | null>(null);
  const scope = place?.name ?? "All Botswana";

  const strip = useMemo(
    () => DATA.places.filter((p) => p.type !== "village").slice(0, 24),
    [],
  );

  const score = val(scope, 7, 38, 96);
  const R = 26;
  const circ = 2 * Math.PI * R;

  const lists: Record<Card, { title: string; sub: string; right: string }[]> = {
    people: DIR_PEOPLE.slice(0, 12).map((p) => ({ title: p.name, sub: `${p.role} · ${p.city}`, right: `★ ${p.rating}` })),
    business: DIR_BIZ.slice(0, 12).map((b) => {
      const o = b as unknown as Record<string, string | number>;
      return { title: String(o.name ?? "Business"), sub: `${o.cat ?? ""} · ${o.city ?? "Botswana"}`, right: o.rating ? `★ ${o.rating}` : "" };
    }),
    listings: ADS.slice(0, 12).map((a) => ({ title: a.title, sub: `${a.kind} · ${a.city}`, right: a.price })),
  };

  const cards: { k: Card; label: string; icon: typeof Users; n: number }[] = [
    { k: "people", label: "People", icon: Users, n: val(scope, 1, 180, 6400) },
    { k: "business", label: "Business", icon: Building2, n: val(scope, 2, 40, 1900) },
    { k: "listings", label: "Listings", icon: Megaphone, n: val(scope, 3, 60, 2600) },
  ];

  return (
    <div className="space-y-2">
      {/* place strip */}
      <div className="-mx-0.5 flex gap-1 overflow-x-auto pb-1">
        <Tap color={g} effect="squish" onClick={() => onSelectPlace?.(null)}
          className="shrink-0 rounded-full px-2.5 py-[4px] text-[9px] font-black"
          style={!place ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
          All Botswana
        </Tap>
        {strip.map((p) => (
          <Tap key={p.name} color={g} effect="squish" onClick={() => onSelectPlace?.(p)}
            className="shrink-0 rounded-full px-2.5 py-[4px] text-[9px] font-bold"
            style={place?.name === p.name ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
            {p.name}
          </Tap>
        ))}
      </div>

      {/* dial + headline */}
      <div className="flex items-center gap-3 rounded-2xl border p-3" style={{ borderColor: alpha(g, 0.16), background: alpha(g, 0.04) }}>
        <svg width="64" height="64" viewBox="0 0 64 64" className="shrink-0">
          <circle cx="32" cy="32" r={R} fill="none" stroke={alpha(g, 0.15)} strokeWidth="6" />
          <motion.circle
            cx="32" cy="32" r={R} fill="none" stroke={g} strokeWidth="6" strokeLinecap="round"
            transform="rotate(-90 32 32)" strokeDasharray={circ}
            initial={{ strokeDashoffset: circ }}
            animate={{ strokeDashoffset: circ - (circ * score) / 100 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          />
          <text x="32" y="36" textAnchor="middle" fontSize="16" fontWeight="800" fill={g}>{score}</text>
        </svg>
        <div className="min-w-0">
          <div className="flex items-center gap-1">
            <MapPin className="h-3 w-3 shrink-0" style={{ color: g }} />
            <span className="truncate text-[15px] font-black leading-none">{scope}</span>
          </div>
          <div className={`mt-1 text-[8.5px] leading-snug ${s.muted}`}>
            Opportunity score across services, demand and talent supply. Updated live by the engine.
          </div>
          <div className="mt-1 flex gap-2 text-[8px]">
            <span className={s.muted}>growth <b style={{ color: g }}>+{val(scope, 9, 2, 24)}%</b></span>
            <span className={s.muted}>demand <b style={{ color: g }}>{val(scope, 11, 30, 99)}</b></span>
          </div>
        </div>
      </div>

      {/* deep-dive cards */}
      <div className="grid grid-cols-3 gap-1.5">
        {cards.map((c) => {
          const on = open === c.k;
          const Icon = c.icon;
          return (
            <Tap key={c.k} color={g} effect="lift" onClick={() => setOpen(on ? null : c.k)}
              className="rounded-2xl border p-2"
              style={{ borderColor: on ? alpha(g, 0.45) : alpha(g, 0.14), background: on ? alpha(g, 0.1) : "transparent" }}>
              <Icon className="h-3.5 w-3.5" style={{ color: g }} />
              <div className="mt-1 text-[13px] font-black leading-none tabular-nums">{c.n.toLocaleString()}</div>
              <div className={`mt-[2px] text-[7px] font-bold uppercase tracking-[0.16em] ${s.muted}`}>{c.label}</div>
            </Tap>
          );
        })}
      </div>

      {open && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border p-1.5" style={{ borderColor: alpha(g, 0.14) }}>
          <div className="max-h-[240px] overflow-y-auto">
            {lists[open].map((it, i) => (
              <div key={i} className="flex items-center gap-2 border-b px-1 py-[6px] last:border-0" style={{ borderColor: alpha(g, 0.08) }}>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[10px] font-bold">{it.title}</span>
                  <span className={`block truncate text-[7.5px] ${s.muted}`}>{it.sub}</span>
                </span>
                <span className="shrink-0 text-[8.5px] font-black" style={{ color: g }}>{it.right}</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
