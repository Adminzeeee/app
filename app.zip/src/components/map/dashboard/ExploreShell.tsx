import { useState } from "react";
import type { Place } from "../types";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Tap } from "./ui";
import { ExploreTab } from "./ExploreTab";
import { ExploreV2 } from "./ExploreV2";
import { ExploreV3 } from "./ExploreV3";
import { ExploreV4 } from "./ExploreV4";
import { ExploreV5 } from "./ExploreV5";
import { ExploreV6 } from "./ExploreV6";
import { ExploreV7 } from "./ExploreV7";
import { ExploreV8 } from "./ExploreV8";

export interface ExploreProps {
  theme: ThemeSpec;
  isLight: boolean;
  place: Place | null;
  onSelectPlace?: (p: Place | null) => void;
}

/** Version switcher across the Explore builds. */
export function ExploreShell(p: ExploreProps) {
  const [v, setV] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7 | 8>(8);

  return (
    <div>
      <div className="mb-1.5 flex items-center">
        <div className="ml-auto flex items-center gap-[2px] rounded-full p-[2px]" style={{ background: alpha(p.theme.glow, 0.12) }}>
          {([1, 2, 3, 4, 5, 6, 7, 8] as const).map((n) => (
            <Tap
              key={n} color={p.theme.glow} effect="squish" onClick={() => setV(n)}
              className="rounded-full px-2 py-[2px] text-[8px] font-black"
              style={v === n
                ? { background: p.theme.glow, color: p.isLight ? "#fff" : "#04121f" }
                : { color: "inherit", opacity: 0.6 }}
            >
              v{n}
            </Tap>
          ))}
        </div>
      </div>
      {v === 1 && <ExploreTab {...p} />}
      {v === 2 && <ExploreV2 {...p} />}
      {v === 3 && <ExploreV3 {...p} />}
      {v === 4 && <ExploreV4 {...p} />}
      {v === 5 && <ExploreV5 {...p} />}
      {v === 6 && <ExploreV6 {...p} />}
      {v === 7 && <ExploreV7 {...p} />}
      {v === 8 && <ExploreV8 {...p} />}
    </div>
  );
}
