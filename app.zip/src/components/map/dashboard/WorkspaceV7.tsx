import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useMemo, useState } from "react";
import {
  ArrowUp, Bookmark, Brain, Cpu, Rss, Sparkles, StickyNote, Trash2,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Tap, useSkin } from "./ui";
import { NOTES_SEED, SOURCES } from "./workspaceData";
import { SIGNAL_TAGS } from "./workspaceV2Data";
import {
  FEED_CATEGORIES, KIND_GLYPH, relTime, useFeedStream,
  type FeedCategory, type FeedItem,
} from "./feedData";

/* WorkspaceV7 — same tab set as v6 (Feed / Saved / Notes / Engine) but the
   Feed is rendered as a dense, table-like ticker rather than social cards. */

type View = "feed" | "saved" | "notes" | "engine";
const VIEWS: { k: View; label: string; icon: React.ReactNode }[] = [
  { k: "feed", label: "Findings", icon: <Rss className="h-2.5 w-2.5" /> },
  { k: "saved", label: "Saved", icon: <Bookmark className="h-2.5 w-2.5" /> },
  { k: "notes", label: "Notes", icon: <StickyNote className="h-2.5 w-2.5" /> },
  { k: "engine", label: "Engine", icon: <Brain className="h-2.5 w-2.5" /> },
];

type Sort = "latest" | "top" | "opportunity" | "risk" | "gap";
const SORTS: { k: Sort; label: string }[] = [
  { k: "latest", label: "Latest" },
  { k: "top", label: "Top" },
  { k: "opportunity", label: "Opp" },
  { k: "risk", label: "Risk" },
  { k: "gap", label: "Gap" },
];

export function WorkspaceV7({
  theme, isLight, scope,
}: { theme: ThemeSpec; isLight: boolean; scope: string }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [view, setView] = useState<View>("feed");
  const [toast, setToast] = useState<string | null>(null);
  const say = useCallback((m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 1700);
  }, []);

  const { items, pendingCount, reveal, bump } = useFeedStream(4600);
  const [sort, setSort] = useState<Sort>("latest");
  const [cat, setCat] = useState<FeedCategory | null>(null);
  const [saved, setSaved] = useState<FeedItem[]>([]);
  const savedIds = useMemo(() => new Set(saved.map((x) => x.id)), [saved]);
  const [open, setOpen] = useState<string | null>(null);

  const feed = useMemo(() => {
    let out = items.slice();
    if (cat) out = out.filter((f) => f.category === cat);
    if (sort === "top") out = out.sort((a, b) => (b.reactions + b.watchers) - (a.reactions + a.watchers));
    else if (sort === "latest") out = out.sort((a, b) => b.createdAt - a.createdAt);
    else out = out.filter((f) => f.kind === sort).sort((a, b) => b.createdAt - a.createdAt);
    return out;
  }, [items, sort, cat]);

  const toggleSave = (f: FeedItem) => {
    setSaved((p) => (p.some((x) => x.id === f.id) ? p.filter((x) => x.id !== f.id) : [f, ...p]));
    say(savedIds.has(f.id) ? "Removed from saved" : "Saved");
  };

  const [notes, setNotes] = useState(NOTES_SEED.map((n, i) => ({ id: "n" + i, ...n })));
  const [draft, setDraft] = useState("");
  const [tag, setTag] = useState(SIGNAL_TAGS[0]);

  const [running, setRunning] = useState(false);
  const [stage, setStage] = useState(0);

  const chip = (active: boolean) =>
    `rounded px-1.5 py-[2px] text-[7.5px] font-bold transition ${active ? s.solid : `${s.chip} ${s.muted}`}`;

  return (
    <div className="relative">
      <div className="mb-1.5 flex items-center gap-1 rounded-md p-[2px]" style={{ background: alpha(g, 0.08) }}>
        {VIEWS.map((v) => (
          <Tap key={v.k} color={g} effect="squish" onClick={() => setView(v.k)}
            className="flex flex-1 items-center justify-center gap-1 rounded py-[5px] text-[8.5px] font-bold"
            style={view === v.k ? { background: g, color: isLight ? "#fff" : "#04121f" } : { opacity: 0.55 }}>
            {v.icon}{v.label}
          </Tap>
        ))}
      </div>

      {view === "feed" && (
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-1">
            {SORTS.map((o) => (
              <button key={o.k} onClick={() => setSort(o.k)} className={chip(sort === o.k)}>{o.label}</button>
            ))}
            <select value={cat ?? ""} onChange={(e) => setCat((e.target.value || null) as FeedCategory | null)}
              className={`ml-auto rounded px-1 py-[2px] text-[7.5px] font-bold outline-none ${s.chip}`}>
              <option value="">All categories</option>
              {FEED_CATEGORIES.map((c) => <option key={c} value={c} className="bg-slate-900 text-white">{c}</option>)}
            </select>
          </div>

          <div className="relative">
            <AnimatePresence>
              {pendingCount > 0 && (
                <motion.button
                  initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
                  onClick={reveal}
                  className="mb-1 flex w-full items-center justify-center gap-1 rounded py-[4px] text-[8px] font-black"
                  style={{ background: alpha(g, 0.16), color: g }}>
                  <ArrowUp className="h-2.5 w-2.5" />{pendingCount} new — tap to load
                </motion.button>
              )}
            </AnimatePresence>

            <div className={`overflow-hidden rounded-md border ${s.card}`}>
              <AnimatePresence initial={false}>
                {feed.map((f, i) => {
                  const k = KIND_GLYPH[f.kind];
                  const isSaved = savedIds.has(f.id);
                  const isOpen = open === f.id;
                  return (
                    <motion.div
                      key={f.id}
                      layout
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className={i > 0 ? `border-t ${s.line}` : ""}
                    >
                      <button onClick={() => setOpen(isOpen ? null : f.id)}
                        className="grid w-full grid-cols-[14px_1fr_auto] items-center gap-1.5 px-1.5 py-[5px] text-left">
                        <span className="text-[10px] font-black" style={{ color: k.color }}>{k.glyph}</span>
                        <span className="min-w-0">
                          <span className="block truncate text-[8.5px] font-bold leading-tight">{f.heading}</span>
                          <span className={`block truncate text-[7px] ${s.muted}`}>{f.category} · {f.region}</span>
                        </span>
                        <span className={`shrink-0 text-right text-[7px] tabular-nums ${s.muted}`}>
                          {relTime(f.createdAt)}
                        </span>
                      </button>
                      <AnimatePresence>
                        {isOpen && (
                          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                            className="overflow-hidden px-1.5 pb-1.5">
                            <p className="text-[8px] leading-snug opacity-80">{f.detail}</p>
                            <div className="mt-1 flex items-center gap-2 text-[7px]">
                              <button onClick={() => bump(f.id, "reactions")} className={s.muted}>♥ {f.reactions}</button>
                              <span className={s.muted}>{f.watchers} watching</span>
                              <button onClick={() => toggleSave(f)} className="ml-auto font-bold" style={{ color: isSaved ? g : undefined, opacity: isSaved ? 1 : 0.6 }}>
                                {isSaved ? "Saved ✓" : "Save"}
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
              {!feed.length && <div className={`p-3 text-center text-[9px] ${s.muted}`}>Nothing here yet.</div>}
            </div>
          </div>
        </div>
      )}

      {view === "saved" && (
        <div className="space-y-1">
          {saved.map((f) => {
            const k = KIND_GLYPH[f.kind];
            return (
              <div key={f.id} className={`flex items-center gap-1.5 rounded border px-1.5 py-1 ${s.card}`}>
                <span className="text-[10px] font-black" style={{ color: k.color }}>{k.glyph}</span>
                <span className="min-w-0 flex-1 truncate text-[8.5px] font-bold">{f.heading}</span>
                <button onClick={() => setSaved((p) => p.filter((x) => x.id !== f.id))} className={s.muted}>
                  <Trash2 className="h-2.5 w-2.5" />
                </button>
              </div>
            );
          })}
          {!saved.length && <div className={`rounded-md border p-3 text-center text-[9px] ${s.card} ${s.muted}`}>Nothing saved yet.</div>}
        </div>
      )}

      {view === "notes" && (
        <div className="space-y-1">
          <div className={`flex items-center gap-1 rounded-md border px-1.5 py-1 ${s.card}`}>
            <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Add a note…"
              className="min-w-0 flex-1 bg-transparent text-[9px] outline-none placeholder:opacity-50" />
            <select value={tag} onChange={(e) => setTag(e.target.value)} className={`rounded px-1 py-[2px] text-[7.5px] font-bold outline-none ${s.chip}`}>
              {SIGNAL_TAGS.map((t) => <option key={t} className="bg-slate-900 text-white">{t}</option>)}
            </select>
            <Tap color={g} effect="squish"
              onClick={() => { if (!draft.trim()) return; setNotes((p) => [{ id: "n" + Date.now(), t: draft.trim(), when: "just now", tag }, ...p]); setDraft(""); }}
              className="shrink-0 rounded px-1.5 py-[3px] text-[8px] font-black" style={{ background: g, color: "#04060d" }}>Add</Tap>
          </div>
          {notes.map((n) => (
            <div key={n.id} className={`rounded border px-1.5 py-1 ${s.card}`}>
              <div className="flex items-center gap-1">
                <span className="rounded-full px-1 text-[7px] font-bold" style={{ background: alpha(g, 0.14), color: g }}>{n.tag}</span>
                <span className={`ml-auto text-[7px] ${s.muted}`}>{n.when}</span>
              </div>
              <p className="mt-[2px] text-[8.5px] leading-snug">{n.t}</p>
            </div>
          ))}
        </div>
      )}

      {view === "engine" && (
        <div className={`rounded-md border p-1.5 ${s.card}`}>
          <div className="flex items-center gap-1.5">
            <span className="grid h-6 w-6 place-items-center rounded-md" style={{ background: alpha(g, 0.18) }}>
              <Cpu className="h-3 w-3" style={{ color: g }} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[9.5px] font-bold">Signal engine · {scope}</div>
              <div className={`text-[7.5px] ${s.muted}`}>{SOURCES.length} sources connected</div>
            </div>
          </div>
          <Tap color={g} effect="glow"
            onClick={() => { setRunning(true); setStage(0); let i = 0; const id = window.setInterval(() => { i++; setStage(i); if (i >= 8) { window.clearInterval(id); setRunning(false); say("Run complete"); } }, 220); }}
            className="mt-1.5 flex w-full items-center justify-center gap-1.5 rounded-md py-1.5 text-[10px] font-black"
            style={{ background: g, color: "#04060d" }}>
            <Sparkles className="h-3 w-3" />{running ? `Analysing… ${stage}/8` : "Run scan"}
          </Tap>
          {running && <div className="mt-1"><Bar v={(stage / 8) * 100} color={g} chip={s.chip} /></div>}
        </div>
      )}

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-20 left-1/2 z-[80] -translate-x-1/2 rounded-full px-2.5 py-1 text-[10px] font-bold text-black"
            style={{ background: g, boxShadow: `0 8px 24px -6px ${g}` }}>
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
