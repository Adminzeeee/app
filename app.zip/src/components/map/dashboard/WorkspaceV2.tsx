import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, AlertTriangle, ArrowDown, ArrowUp, Bell, Bookmark, Brain, Check, ChevronRight,
  Coins, Columns3, Copy, Cpu, Download, FileText, FlaskConical, Gauge, GitBranch, Globe2,
  Layers, Lightbulb, Link2, Loader2, Mic, Network, Pin, Play, Radio, RotateCcw, Search,
  Share2, Sparkles, Square, StickyNote, Table2, Target, Trash2, TrendingUp, Waves, Zap,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Panel, Ring, Tap, useSkin } from "./ui";
import { DrawLine } from "./charts";
import { useCoins } from "./coins";
import { useRecordings } from "./recordings";
import {
  FINDINGS, HORIZONS, LEVERS, NOTES_SEED, REGIONS, SECTORS, type Finding, type FindingKind,
} from "./workspaceData";
import {
  ALERT_RULES, CORRELATIONS, ENGINE_FEATURES, ENGINE_MODES, GEO_HEAT, PIPELINE,
  REPORT_TEMPLATES, SIGNAL_TAGS, SIM_PRESETS, TIMELINE, V2_SOURCES, V2_STAGES,
  type AlertRule, type PipelineItem,
} from "./workspaceV2Data";

type View =
  | "engine" | "findings" | "reports" | "sim" | "signals"
  | "geo" | "timeline" | "alerts" | "pipeline" | "graph" | "studio";

const VIEWS: { k: View; label: string; icon: React.ReactNode }[] = [
  { k: "engine", label: "Engine", icon: <Brain className="h-2.5 w-2.5" /> },
  { k: "findings", label: "Findings", icon: <Table2 className="h-2.5 w-2.5" /> },
  { k: "reports", label: "Reports", icon: <FileText className="h-2.5 w-2.5" /> },
  { k: "sim", label: "Simulate", icon: <FlaskConical className="h-2.5 w-2.5" /> },
  { k: "signals", label: "Signals", icon: <StickyNote className="h-2.5 w-2.5" /> },
  { k: "geo", label: "Geo", icon: <Globe2 className="h-2.5 w-2.5" /> },
  { k: "timeline", label: "Timeline", icon: <Activity className="h-2.5 w-2.5" /> },
  { k: "alerts", label: "Alerts", icon: <Bell className="h-2.5 w-2.5" /> },
  { k: "pipeline", label: "Pipeline", icon: <GitBranch className="h-2.5 w-2.5" /> },
  { k: "graph", label: "Graph", icon: <Network className="h-2.5 w-2.5" /> },
  { k: "studio", label: "Studio", icon: <Radio className="h-2.5 w-2.5" /> },
];

const KIND: Record<FindingKind, { label: string; color: string; icon: React.ReactNode }> = {
  opportunity: { label: "Opp", color: "#22c55e", icon: <Lightbulb className="h-2.5 w-2.5" /> },
  gap: { label: "Gap", color: "#38bdf8", icon: <Layers className="h-2.5 w-2.5" /> },
  risk: { label: "Risk", color: "#ef4444", icon: <AlertTriangle className="h-2.5 w-2.5" /> },
};

type SortKey = "score" | "confidence" | "impact" | "effort" | "title";

interface SavedReport {
  id: string; name: string; when: string; template: string;
  count: number; filters: string; findings: string[]; avg: number; pinned?: boolean;
}

/* ------------------------------------------------------------------ */

export function WorkspaceV2({
  theme, isLight, scope,
}: { theme: ThemeSpec; isLight: boolean; scope: string }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [view, setView] = useState<View>("engine");
  const [toast, setToast] = useState<string | null>(null);
  const say = useCallback((m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 1800);
  }, []);

  const { balance, spend } = useCoins();

  /* ---------------- engine config ---------------- */
  const [sources, setSources] = useState<string[]>(V2_SOURCES.slice(0, 10).map((x) => x.k));
  const [mode, setMode] = useState(ENGINE_MODES[1].k);
  const [feats, setFeats] = useState<string[]>(["chain", "narr", "calib"]);
  const [kinds, setKinds] = useState<FindingKind[]>(["opportunity", "gap", "risk"]);
  const [region, setRegion] = useState(REGIONS[0]);
  const [sector, setSector] = useState(SECTORS[0]);
  const [horizon, setHorizon] = useState(HORIZONS[2]);
  const [minScore, setMinScore] = useState(40);
  const [minConf, setMinConf] = useState(55);
  const [maxEffort, setMaxEffort] = useState(100);
  const [q, setQ] = useState("");

  const modeDef = ENGINE_MODES.find((m) => m.k === mode)!;
  const stageCount = modeDef.stages;
  const secPerStage = 0.45 * modeDef.mult;
  const runtime = Math.round(stageCount * secPerStage * 10) / 10;
  const srcCost = V2_SOURCES.filter((x) => sources.includes(x.k)).reduce((a, b) => a + b.cost, 0);
  const featCost = ENGINE_FEATURES.filter((f) => feats.includes(f.k)).reduce((a, b) => a + b.cost, 0);
  const cost = Math.max(1, Math.round((srcCost + featCost) * modeDef.mult + runtime * 2));

  /* ---------------- engine run ---------------- */
  const [running, setRunning] = useState(false);
  const [stage, setStage] = useState(0);
  const [trace, setTrace] = useState<{ line: string; ms: number; rows: number }[]>([]);
  const [lastRun, setLastRun] = useState<string | null>(null);
  const timers = useRef<number[]>([]);
  const clearTimers = () => { timers.current.forEach(window.clearTimeout); timers.current = []; };
  useEffect(() => clearTimers, []);

  const run = useCallback(() => {
    if (running) { clearTimers(); setRunning(false); say("Run aborted"); return; }
    if (!sources.length) { say("Select at least one source"); return; }
    if (!spend(`Engine run · ${modeDef.label}`, cost)) { say(`Not enough coins — need ${cost}`); return; }
    clearTimers(); setRunning(true); setStage(0); setTrace([]);
    const lines = V2_STAGES.slice(0, stageCount);
    lines.forEach((line, i) => {
      timers.current.push(window.setTimeout(() => {
        setStage(i + 1);
        setTrace((t) => [...t, { line, ms: Math.round(secPerStage * 1000 * (0.5 + Math.random())), rows: Math.round(Math.random() * 42_000 + 800) }]);
        if (i === lines.length - 1) {
          setRunning(false);
          setLastRun(new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
          say(`Run complete · ${cost} coins`);
          timers.current.push(window.setTimeout(() => setView("findings"), 450));
        }
      }, secPerStage * 1000 * (i + 1)));
    });
  }, [running, sources.length, spend, cost, modeDef.label, stageCount, secPerStage, say]);

  /* ---------------- findings table ---------------- */
  const [sortKey, setSortKey] = useState<SortKey>("score");
  const [asc, setAsc] = useState(false);
  const [sel, setSel] = useState<string[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [cols, setCols] = useState<string[]>(["score", "conf", "impact", "effort", "value"]);

  const rows = useMemo(() => {
    const ql = q.trim().toLowerCase();
    const out = FINDINGS.filter((f) =>
      kinds.includes(f.kind) &&
      (region === REGIONS[0] || f.region === region || f.region === "All Botswana") &&
      (sector === SECTORS[0] || f.sector === sector) &&
      f.score >= minScore && f.confidence >= minConf && f.effort <= maxEffort &&
      f.evidence.some((e) => sources.includes(e.src)) &&
      (!ql || (f.title + f.summary + f.sector + f.region).toLowerCase().includes(ql)));
    out.sort((a, b) => {
      const va = sortKey === "title" ? a.title : (a[sortKey] as number);
      const vb = sortKey === "title" ? b.title : (b[sortKey] as number);
      const c = typeof va === "string" ? va.localeCompare(vb as string) : (va as number) - (vb as number);
      return asc ? c : -c;
    });
    return out;
  }, [kinds, region, sector, minScore, minConf, maxEffort, sources, q, sortKey, asc]);

  /* ---------------- reports ---------------- */
  const [reports, setReports] = useState<SavedReport[]>([
    { id: "r0", name: "Q3 national opportunity sweep", when: "3d ago", template: "Board pack", count: 9, filters: "All Botswana · All sectors · 6 months", findings: FINDINGS.slice(0, 9).map((f) => f.id), avg: 71, pinned: true },
    { id: "r1", name: "Kgalagadi water risk deep-dive", when: "1w ago", template: "Executive brief", count: 3, filters: "Kgalagadi · Water · 90 days", findings: ["f8", "f3", "f5"], avg: 81 },
  ]);
  const [tpl, setTpl] = useState(REPORT_TEMPLATES[0].k);
  const tplDef = REPORT_TEMPLATES.find((t) => t.k === tpl)!;

  const saveReport = () => {
    const picked = sel.length ? rows.filter((r) => sel.includes(r.id)) : rows;
    if (!picked.length) { say("Nothing to save"); return; }
    setReports((p) => [{
      id: "r" + Date.now(),
      name: `${region} · ${sector} · ${tplDef.label}`,
      when: "just now", template: tplDef.label, count: picked.length,
      filters: `${region} · ${sector} · ${horizon}`,
      findings: picked.map((f) => f.id),
      avg: Math.round(picked.reduce((a, b) => a + b.score, 0) / picked.length),
    }, ...p]);
    say(`Saved ${picked.length} findings`);
    setView("reports");
  };

  /* ---------------- simulate ---------------- */
  const [lev, setLev] = useState<Record<string, number>>(
    Object.fromEntries(LEVERS.map((l) => [l.k, l.def])));
  const [preset, setPreset] = useState("base");
  const [locked, setLocked] = useState<{ label: string; out: number } | null>(null);

  const outcome = useMemo(() => {
    const norm = LEVERS.map((l) => {
      const v = (lev[l.k] - l.min) / (l.max - l.min);
      return v * l.weight;
    });
    const raw = norm.reduce((a, b) => a + b, 0) / LEVERS.reduce((a, b) => a + b.weight, 0);
    return Math.round(raw * 100);
  }, [lev]);

  const draws = useMemo(() => {
    // deterministic-ish monte carlo band around outcome
    const arr: number[] = [];
    for (let i = 0; i < 40; i++) {
      const jitter = Math.sin(i * 12.9898 + outcome) * 43758.5453;
      const j = (jitter - Math.floor(jitter) - 0.5) * (30 - lev.risk * 0.15);
      arr.push(Math.max(2, Math.min(99, outcome + j)));
    }
    return arr;
  }, [outcome, lev.risk]);

  const p10 = Math.round(Math.min(...draws));
  const p90 = Math.round(Math.max(...draws));
  const roi = Math.max(0.1, (outcome / 100) * (48 / Math.max(2, lev.budget))).toFixed(2);

  /* ---------------- signals ---------------- */
  const [notes, setNotes] = useState(
    NOTES_SEED.map((n, i) => ({ id: "n" + i, ...n, pinned: i === 0, conf: 60 + i * 8 })));
  const [draft, setDraft] = useState("");
  const [tag, setTag] = useState(SIGNAL_TAGS[0]);
  const [tagFilter, setTagFilter] = useState<string | null>(null);

  /* ---------------- alerts / pipeline ---------------- */
  const [rules, setRules] = useState<AlertRule[]>(ALERT_RULES);
  const [pipe, setPipe] = useState<PipelineItem[]>(PIPELINE);
  const { items: recs, remove: removeRec } = useRecordings();

  /* ---------------- shared bits ---------------- */
  const chip = (active: boolean) =>
    `rounded px-1.5 py-[3px] text-[8.5px] font-bold transition ${active ? s.solid : `${s.chip} ${s.muted}`}`;

  const toggle = <T,>(arr: T[], v: T, set: (x: T[]) => void) =>
    set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const Slider = ({ label, v, set, min, max, unit }: { label: string; v: number; set: (n: number) => void; min: number; max: number; unit?: string }) => (
    <div>
      <div className="flex items-center justify-between text-[8px]">
        <span className={s.muted}>{label}</span>
        <span className="font-black tabular-nums" style={{ color: g }}>{v}{unit}</span>
      </div>
      <input
        type="range" min={min} max={max} value={v}
        onChange={(e) => set(Number(e.target.value))}
        className="h-[3px] w-full cursor-pointer appearance-none rounded-full"
        style={{ background: `linear-gradient(90deg, ${g} ${((v - min) / (max - min)) * 100}%, ${alpha(g, 0.15)} 0%)`, accentColor: g }}
      />
    </div>
  );

  return (
    <div className="relative">
      {/* view rail */}
      <div className="-mx-0.5 mb-1.5 flex gap-1 overflow-x-auto pb-0.5" style={{ scrollbarWidth: "none" }}>
        {VIEWS.map((v) => (
          <Tap
            key={v.k} color={g} effect="squish" onClick={() => setView(v.k)}
            className={`flex shrink-0 items-center gap-1 rounded-md px-1.5 py-[4px] text-[8.5px] font-bold ${view === v.k ? s.solid : `${s.chip} ${s.muted}`}`}
          >
            {v.icon}{v.label}
          </Tap>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.16 }}
          className="space-y-1.5"
        >
          {/* ================= ENGINE ================= */}
          {view === "engine" && (
            <>
              <div className={`rounded-md border p-1.5 ${s.card}`} style={{ background: alpha(g, 0.05) }}>
                <div className="flex items-center gap-1.5">
                  <div className="grid h-6 w-6 place-items-center rounded-md" style={{ background: alpha(g, 0.18) }}>
                    <Cpu className="h-3 w-3" style={{ color: g }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[10px] font-extrabold" style={{ fontFamily: "'Sora',sans-serif" }}>
                      Insight engine · v2
                    </div>
                    <div className={`text-[8px] ${s.muted}`}>
                      {sources.length} sources · {feats.length} modules · {scope}
                      {lastRun && ` · last ${lastRun}`}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-[11px] font-black tabular-nums" style={{ color: g }}>
                      <Coins className="h-2.5 w-2.5" />{cost}
                    </div>
                    <div className={`text-[7.5px] ${s.muted}`}>~{runtime}s · bal {balance}</div>
                  </div>
                </div>

                <Tap
                  color={g} effect="glow" onClick={run}
                  className="mt-1.5 flex w-full items-center justify-center gap-1.5 rounded-md py-[7px] text-[10px] font-black"
                  style={{ background: running ? alpha("#ef4444", 0.9) : g, color: isLight ? "#fff" : "#04121f" }}
                >
                  {running ? <><Square className="h-3 w-3" />Abort · stage {stage}/{stageCount}</> : <><Play className="h-3 w-3" />Run engine · {cost} coins</>}
                </Tap>

                {(running || trace.length > 0) && (
                  <div className="mt-1.5">
                    <div className="h-[3px] w-full overflow-hidden rounded-full" style={{ background: alpha(g, 0.15) }}>
                      <motion.div className="h-full rounded-full" style={{ background: g }}
                        animate={{ width: `${(stage / stageCount) * 100}%` }} transition={{ duration: 0.3 }} />
                    </div>
                    <div className="mt-1 max-h-[104px] space-y-[2px] overflow-y-auto rounded bg-current/[0.03] p-1 font-mono text-[7.5px]">
                      {trace.map((t, i) => (
                        <motion.div key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} className="flex gap-1">
                          <span style={{ color: g }}>▸</span>
                          <span className="min-w-0 flex-1 truncate">{t.line}</span>
                          <span className={s.muted}>{t.rows.toLocaleString()}r</span>
                          <span style={{ color: g }}>{t.ms}ms</span>
                        </motion.div>
                      ))}
                      {running && (
                        <div className="flex items-center gap-1 opacity-70">
                          <Loader2 className="h-2.5 w-2.5 animate-spin" style={{ color: g }} />
                          <span>working…</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* mode */}
              <Panel title="Depth" muted={s.muted} className={s.card}>
                <div className="grid grid-cols-2 gap-1">
                  {ENGINE_MODES.map((m) => (
                    <Tap key={m.k} color={g} effect="squish" onClick={() => setMode(m.k)}
                      className={`rounded-md border px-1.5 py-1 ${s.card}`}
                      style={mode === m.k ? { borderColor: g, background: alpha(g, 0.1) } : undefined}>
                      <div className="text-[9px] font-bold">{m.label}</div>
                      <div className={`truncate text-[7.5px] ${s.muted}`}>{m.blurb}</div>
                      <div className="mt-[2px] text-[7.5px] font-black" style={{ color: g }}>×{m.mult} · {m.stages} stages</div>
                    </Tap>
                  ))}
                </div>
              </Panel>

              {/* sources */}
              <Panel title={`Data sources · ${sources.length}/${V2_SOURCES.length}`} muted={s.muted} className={s.card}
                right={
                  <button onClick={() => setSources(sources.length === V2_SOURCES.length ? [] : V2_SOURCES.map((x) => x.k))}
                    className="text-[8px] font-bold" style={{ color: g }}>
                    {sources.length === V2_SOURCES.length ? "none" : "all"}
                  </button>
                }>
                <div className="space-y-[3px]">
                  {V2_SOURCES.map((src) => {
                    const on = sources.includes(src.k);
                    return (
                      <Tap key={src.k} color={g} effect="squish" onClick={() => toggle(sources, src.k, setSources)}
                        className={`flex w-full items-center gap-1.5 rounded border px-1.5 py-[4px] ${s.card}`}
                        style={on ? { borderColor: alpha(g, 0.5), background: alpha(g, 0.07) } : { opacity: 0.55 }}>
                        <span className="grid h-3 w-3 shrink-0 place-items-center rounded-[3px]"
                          style={{ background: on ? g : "transparent", border: `1px solid ${on ? g : "currentColor"}` }}>
                          {on && <Check className="h-2 w-2" style={{ color: isLight ? "#fff" : "#04121f" }} />}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-1">
                            <span className="truncate text-[9px] font-bold">{src.label}</span>
                            {src.tier !== "core" && (
                              <span className="rounded px-1 text-[6.5px] font-black uppercase"
                                style={{ background: alpha(src.tier === "beta" ? "#a855f7" : g, 0.2), color: src.tier === "beta" ? "#a855f7" : g }}>
                                {src.tier}
                              </span>
                            )}
                          </span>
                          <span className={`block truncate text-[7.5px] ${s.muted}`}>
                            {src.records.toLocaleString()} recs · {src.fresh} · {src.latency}ms
                          </span>
                        </span>
                        <span className="w-9 shrink-0">
                          <Bar v={src.health} color={src.health > 90 ? "#22c55e" : src.health > 80 ? g : "#f59e0b"} chip={s.chip} />
                          <span className={`mt-[2px] block text-right text-[7px] tabular-nums ${s.muted}`}>{src.health}%</span>
                        </span>
                        <span className="shrink-0 text-[8px] font-black tabular-nums" style={{ color: g }}>{src.cost}c</span>
                      </Tap>
                    );
                  })}
                </div>
              </Panel>

              {/* engine modules */}
              <Panel title={`Engine modules · ${feats.length}`} muted={s.muted} className={s.card}>
                <div className="grid grid-cols-2 gap-1">
                  {ENGINE_FEATURES.map((f) => {
                    const on = feats.includes(f.k);
                    return (
                      <Tap key={f.k} color={g} effect="squish" onClick={() => toggle(feats, f.k, setFeats)}
                        className={`rounded border px-1.5 py-1 ${s.card}`}
                        style={on ? { borderColor: g, background: alpha(g, 0.08) } : { opacity: 0.6 }}>
                        <div className="flex items-center gap-1">
                          <Zap className="h-2.5 w-2.5 shrink-0" style={{ color: on ? g : "currentColor" }} />
                          <span className="truncate text-[8.5px] font-bold">{f.label}</span>
                          <span className="ml-auto text-[7.5px] font-black" style={{ color: g }}>{f.cost}c</span>
                        </div>
                        <div className={`truncate text-[7px] ${s.muted}`}>{f.blurb}</div>
                      </Tap>
                    );
                  })}
                </div>
              </Panel>

              {/* filters */}
              <Panel title="Pre-scan filters" muted={s.muted} className={s.card}>
                <div className="mb-1 flex flex-wrap gap-1">
                  {(Object.keys(KIND) as FindingKind[]).map((k) => (
                    <Tap key={k} color={KIND[k].color} effect="squish" onClick={() => toggle(kinds, k, setKinds)}
                      className={`flex items-center gap-1 ${chip(kinds.includes(k))}`}
                      style={kinds.includes(k) ? { background: KIND[k].color, color: "#04121f" } : undefined}>
                      {KIND[k].icon}{KIND[k].label}
                    </Tap>
                  ))}
                </div>
                <div className="grid grid-cols-3 gap-1">
                  {[[REGIONS, region, setRegion], [SECTORS, sector, setSector], [HORIZONS, horizon, setHorizon]].map(([opts, val, set], i) => (
                    <select key={i} value={val as string} onChange={(e) => (set as (v: string) => void)(e.target.value)}
                      className={`min-w-0 rounded px-1 py-[3px] text-[8px] font-bold outline-none ${s.chip}`}
                      style={{ color: "inherit" }}>
                      {(opts as string[]).map((o) => <option key={o} value={o} className="bg-slate-900 text-white">{o}</option>)}
                    </select>
                  ))}
                </div>
                <div className="mt-1.5 space-y-1">
                  <Slider label="Min score" v={minScore} set={setMinScore} min={0} max={100} />
                  <Slider label="Min confidence" v={minConf} set={setMinConf} min={0} max={100} />
                  <Slider label="Max effort" v={maxEffort} set={setMaxEffort} min={0} max={100} />
                </div>
                <div className={`mt-1 text-[8px] ${s.muted}`}>
                  Matching now: <b style={{ color: g }}>{rows.length}</b> of {FINDINGS.length} findings
                </div>
              </Panel>
            </>
          )}

          {/* ================= FINDINGS TABLE ================= */}
          {view === "findings" && (
            <>
              <div className="flex items-center gap-1">
                <div className={`flex min-w-0 flex-1 items-center gap-1 rounded-md px-1.5 py-[4px] ${s.chip}`}>
                  <Search className="h-2.5 w-2.5 shrink-0 opacity-60" />
                  <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search findings, sectors, regions…"
                    className="min-w-0 flex-1 bg-transparent text-[9px] outline-none placeholder:opacity-40" />
                  {q && <button onClick={() => setQ("")} className="text-[8px] opacity-60">clear</button>}
                </div>
                <Tap color={g} effect="squish" onClick={() => setAsc(!asc)} className={`rounded-md px-1.5 py-[5px] ${s.chip}`} title="Sort direction">
                  {asc ? <ArrowUp className="h-2.5 w-2.5" /> : <ArrowDown className="h-2.5 w-2.5" />}
                </Tap>
              </div>

              <div className="flex flex-wrap items-center gap-1">
                {(["score", "confidence", "impact", "effort", "title"] as SortKey[]).map((k) => (
                  <Tap key={k} color={g} effect="squish" onClick={() => setSortKey(k)} className={chip(sortKey === k)}>
                    {k}
                  </Tap>
                ))}
                <span className="ml-auto flex items-center gap-1">
                  <Columns3 className="h-2.5 w-2.5 opacity-50" />
                  {["conf", "impact", "effort", "value"].map((c) => (
                    <Tap key={c} color={g} effect="squish" onClick={() => toggle(cols, c, setCols)} className={chip(cols.includes(c))}>{c}</Tap>
                  ))}
                </span>
              </div>

              <div className={`flex items-center gap-1 rounded-md border px-1.5 py-[4px] text-[8px] ${s.card}`}>
                <button onClick={() => setSel(sel.length === rows.length ? [] : rows.map((r) => r.id))} className="font-bold" style={{ color: g }}>
                  {sel.length === rows.length && rows.length > 0 ? "deselect all" : "select all"}
                </button>
                <span className={s.muted}>{sel.length} selected · {rows.length} rows</span>
                <span className="ml-auto flex gap-1">
                  <button onClick={saveReport} className="flex items-center gap-1 font-bold" style={{ color: g }}>
                    <Bookmark className="h-2.5 w-2.5" />save
                  </button>
                  <button onClick={() => say(`Exported ${sel.length || rows.length} rows to CSV`)} className="flex items-center gap-1 font-bold" style={{ color: g }}>
                    <Download className="h-2.5 w-2.5" />csv
                  </button>
                </span>
              </div>

              {/* header row */}
              <div className={`grid items-center gap-1 rounded-t border-b px-1.5 py-[3px] text-[7px] font-black uppercase tracking-wider ${s.muted} ${s.line}`}
                style={{ gridTemplateColumns: `12px 1fr repeat(${1 + cols.filter((c) => c !== "value").length}, 26px) ${cols.includes("value") ? "46px" : "0px"}` }}>
                <span />
                <span>Finding</span>
                <span className="text-right">Sc</span>
                {cols.includes("conf") && <span className="text-right">Cf</span>}
                {cols.includes("impact") && <span className="text-right">Im</span>}
                {cols.includes("effort") && <span className="text-right">Ef</span>}
                {cols.includes("value") && <span className="text-right">Value</span>}
              </div>

              <div className="space-y-[2px]">
                {rows.map((f) => (
                  <FindingRow key={f.id} f={f} cols={cols} g={g} s={s} isLight={isLight}
                    selected={sel.includes(f.id)} onSelect={() => toggle(sel, f.id, setSel)}
                    expanded={open === f.id} onToggle={() => setOpen(open === f.id ? null : f.id)}
                    onAct={(m) => say(m)} />
                ))}
                {!rows.length && <div className={`rounded-md border p-3 text-center text-[9px] ${s.card} ${s.muted}`}>No findings match these filters.</div>}
              </div>
            </>
          )}

          {/* ================= REPORTS ================= */}
          {view === "reports" && (
            <>
              <Panel title="Report builder" muted={s.muted} className={s.card}>
                <div className="grid grid-cols-2 gap-1">
                  {REPORT_TEMPLATES.map((t) => (
                    <Tap key={t.k} color={g} effect="squish" onClick={() => setTpl(t.k)}
                      className={`rounded border px-1.5 py-1 ${s.card}`}
                      style={tpl === t.k ? { borderColor: g, background: alpha(g, 0.08) } : undefined}>
                      <div className="text-[9px] font-bold">{t.label}</div>
                      <div className={`text-[7.5px] ${s.muted}`}>{t.pages} pages · {t.sections.length} sections</div>
                    </Tap>
                  ))}
                </div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {tplDef.sections.map((sec) => (
                    <span key={sec} className={`rounded px-1 py-[2px] text-[7.5px] ${s.chip}`}>{sec}</span>
                  ))}
                </div>
                <Tap color={g} effect="glow" onClick={saveReport}
                  className="mt-1.5 flex w-full items-center justify-center gap-1 rounded-md py-[6px] text-[9.5px] font-black"
                  style={{ background: alpha(g, 0.16), color: g }}>
                  <FileText className="h-3 w-3" />Generate from current findings ({sel.length || rows.length})
                </Tap>
              </Panel>

              {reports.map((r) => (
                <div key={r.id} className={`rounded-md border p-1.5 ${s.card}`}>
                  <div className="flex items-start gap-1.5">
                    <Ring value={r.avg} color={g} size={30} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1">
                        {r.pinned && <Pin className="h-2.5 w-2.5 shrink-0" style={{ color: g }} />}
                        <span className="truncate text-[9.5px] font-bold">{r.name}</span>
                      </div>
                      <div className={`truncate text-[7.5px] ${s.muted}`}>{r.template} · {r.filters}</div>
                      <div className={`text-[7.5px] ${s.muted}`}>{r.count} findings · avg {r.avg} · {r.when}</div>
                    </div>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {[
                      { l: "Open", i: <ChevronRight className="h-2.5 w-2.5" /> },
                      { l: "PDF", i: <Download className="h-2.5 w-2.5" /> },
                      { l: "Share", i: <Share2 className="h-2.5 w-2.5" /> },
                      { l: "Duplicate", i: <Copy className="h-2.5 w-2.5" /> },
                      { l: "Narrate", i: <Mic className="h-2.5 w-2.5" /> },
                    ].map((b) => (
                      <Tap key={b.l} color={g} effect="squish" onClick={() => say(`${b.l} · ${r.name}`)}
                        className={`flex items-center gap-1 ${chip(false)}`}>{b.i}{b.l}</Tap>
                    ))}
                    <Tap color="#ef4444" effect="squish" onClick={() => { setReports((p) => p.filter((x) => x.id !== r.id)); say("Report deleted"); }}
                      className={`ml-auto flex items-center gap-1 ${chip(false)}`}><Trash2 className="h-2.5 w-2.5" /></Tap>
                  </div>
                </div>
              ))}
            </>
          )}

          {/* ================= SIMULATE ================= */}
          {view === "sim" && (
            <>
              <div className={`rounded-md border p-1.5 ${s.card}`} style={{ background: alpha(g, 0.05) }}>
                <div className="flex items-center gap-2">
                  <Ring value={outcome} color={g} size={46} label={`${outcome}`} />
                  <div className="min-w-0 flex-1">
                    <div className="text-[9.5px] font-extrabold" style={{ fontFamily: "'Sora',sans-serif" }}>Modelled outcome index</div>
                    <div className={`text-[8px] ${s.muted}`}>P10 {p10} · P90 {p90} · ROI ×{roi}</div>
                    <div className="mt-1 flex h-6 items-end gap-[1px]">
                      {draws.map((d, i) => (
                        <motion.span key={i} className="flex-1 rounded-t"
                          initial={{ height: 0 }} animate={{ height: `${d}%` }} transition={{ delay: i * 0.006 }}
                          style={{ background: alpha(g, 0.35 + (d / 200)) }} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-1">
                {SIM_PRESETS.map((p) => (
                  <Tap key={p.k} color={g} effect="squish"
                    onClick={() => { setPreset(p.k); setLev(p.mods as Record<string, number>); }}
                    className={chip(preset === p.k)}>{p.label}</Tap>
                ))}
                <Tap color={g} effect="squish" onClick={() => { setLev(Object.fromEntries(LEVERS.map((l) => [l.k, l.def]))); setPreset("base"); }}
                  className={`flex items-center gap-1 ${chip(false)}`}><RotateCcw className="h-2.5 w-2.5" />reset</Tap>
              </div>

              <Panel title="Levers" muted={s.muted} className={s.card}>
                <div className="space-y-1.5">
                  {LEVERS.map((l) => (
                    <Slider key={l.k} label={`${l.label} (${l.unit})`} v={lev[l.k]}
                      set={(n) => { setLev({ ...lev, [l.k]: n }); setPreset("custom"); }} min={l.min} max={l.max} />
                  ))}
                </div>
              </Panel>

              <Panel title="Compare" muted={s.muted} className={s.card}>
                <div className="flex gap-1">
                  <Tap color={g} effect="squish" onClick={() => { setLocked({ label: preset, out: outcome }); say("Scenario A locked"); }}
                    className={`flex-1 ${chip(false)} text-center`}>Lock as A</Tap>
                  <Tap color={g} effect="squish" onClick={() => say(locked ? `Δ ${outcome - locked.out > 0 ? "+" : ""}${outcome - locked.out} vs A` : "Lock a scenario first")}
                    className={`flex-1 ${chip(false)} text-center`}>Compare B</Tap>
                </div>
                {locked && (
                  <div className="mt-1 flex items-center gap-2 text-[8.5px]">
                    <span className={s.muted}>A · {locked.label}</span>
                    <span className="font-black tabular-nums">{locked.out}</span>
                    <span className={s.muted}>→ B</span>
                    <span className="font-black tabular-nums" style={{ color: outcome >= locked.out ? "#22c55e" : "#ef4444" }}>
                      {outcome} ({outcome - locked.out >= 0 ? "+" : ""}{outcome - locked.out})
                    </span>
                  </div>
                )}
              </Panel>

              <Panel title="Sensitivity" muted={s.muted} className={s.card}>
                <div className="space-y-1">
                  {LEVERS.map((l) => (
                    <div key={l.k} className="flex items-center gap-1.5">
                      <span className={`w-[74px] shrink-0 truncate text-[8px] ${s.muted}`}>{l.label}</span>
                      <span className="min-w-0 flex-1"><Bar v={l.weight * 100} color={g} chip={s.chip} /></span>
                      <span className="w-6 shrink-0 text-right text-[8px] font-black tabular-nums" style={{ color: g }}>
                        {Math.round(l.weight * 100)}
                      </span>
                    </div>
                  ))}
                </div>
              </Panel>
            </>
          )}

          {/* ================= SIGNALS ================= */}
          {view === "signals" && (
            <>
              <div className={`rounded-md border p-1.5 ${s.card}`}>
                <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={2}
                  placeholder="Capture a field signal, rumour, or observation…"
                  className="w-full resize-none bg-transparent text-[9px] outline-none placeholder:opacity-40" />
                <div className="flex items-center gap-1">
                  <select value={tag} onChange={(e) => setTag(e.target.value)}
                    className={`rounded px-1 py-[3px] text-[8px] font-bold outline-none ${s.chip}`}>
                    {SIGNAL_TAGS.map((t) => <option key={t} className="bg-slate-900 text-white">{t}</option>)}
                  </select>
                  <Tap color={g} effect="glow"
                    onClick={() => {
                      if (!draft.trim()) return;
                      setNotes((p) => [{ id: "n" + Date.now(), t: draft.trim(), when: "just now", tag, pinned: false, conf: 70 }, ...p]);
                      setDraft(""); say("Signal captured");
                    }}
                    className="ml-auto rounded px-2 py-[4px] text-[8.5px] font-black"
                    style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>Add signal</Tap>
                </div>
              </div>

              <div className="flex flex-wrap gap-1">
                <Tap color={g} effect="squish" onClick={() => setTagFilter(null)} className={chip(!tagFilter)}>all</Tap>
                {SIGNAL_TAGS.map((t) => (
                  <Tap key={t} color={g} effect="squish" onClick={() => setTagFilter(t)} className={chip(tagFilter === t)}>{t}</Tap>
                ))}
              </div>

              {notes.filter((n) => !tagFilter || n.tag === tagFilter).map((n) => (
                <div key={n.id} className={`rounded-md border p-1.5 ${s.card}`}>
                  <div className="flex items-start gap-1.5">
                    <StickyNote className="mt-[2px] h-2.5 w-2.5 shrink-0" style={{ color: g }} />
                    <div className="min-w-0 flex-1">
                      <div className="text-[9px] leading-snug">{n.t}</div>
                      <div className={`mt-[2px] flex items-center gap-1 text-[7.5px] ${s.muted}`}>
                        <span className="rounded px-1" style={{ background: alpha(g, 0.15), color: g }}>{n.tag}</span>
                        <span>{n.when}</span>
                        <span>· weight {n.conf}%</span>
                      </div>
                    </div>
                    <button onClick={() => setNotes((p) => p.map((x) => x.id === n.id ? { ...x, pinned: !x.pinned } : x))}>
                      <Pin className="h-2.5 w-2.5" style={{ color: n.pinned ? g : "currentColor", opacity: n.pinned ? 1 : 0.4 }} />
                    </button>
                    <button onClick={() => setNotes((p) => p.filter((x) => x.id !== n.id))}>
                      <Trash2 className="h-2.5 w-2.5 opacity-40" />
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}

          {/* ================= GEO ================= */}
          {view === "geo" && (
            <>
              <Panel title="District heat · risk / opportunity / gap" muted={s.muted} className={s.card}>
                <div className="space-y-[3px]">
                  {GEO_HEAT.map((h) => (
                    <div key={h.region} className="flex items-center gap-1.5">
                      <span className="w-[62px] shrink-0 truncate text-[8.5px] font-bold">{h.region}</span>
                      <span className="flex min-w-0 flex-1 gap-[2px]">
                        {[["#ef4444", h.risk], ["#22c55e", h.opp], ["#38bdf8", h.gap]].map(([c, v], i) => (
                          <motion.span key={i} className="h-3 rounded-[2px]" initial={{ flexGrow: 0 }}
                            animate={{ flexGrow: v as number }} transition={{ duration: 0.6, delay: i * 0.05 }}
                            style={{ background: alpha(c as string, 0.75) }} />
                        ))}
                      </span>
                      <span className={`w-8 shrink-0 text-right text-[7.5px] ${s.muted}`}>{h.pop}</span>
                    </div>
                  ))}
                </div>
              </Panel>
              <Panel title="Cross-source correlations" muted={s.muted} className={s.card}>
                {CORRELATIONS.map((c) => (
                  <div key={c.a} className="flex items-center gap-1.5 py-[2px]">
                    <span className="min-w-0 flex-1 truncate text-[8.5px]">{c.a} <span className={s.muted}>×</span> {c.b}</span>
                    <span className="h-[3px] w-12 shrink-0 overflow-hidden rounded-full bg-current/10">
                      <motion.span className="block h-full rounded-full" initial={{ width: 0 }}
                        animate={{ width: `${Math.abs(c.r) * 100}%` }}
                        style={{ background: c.r > 0 ? "#22c55e" : "#ef4444" }} />
                    </span>
                    <span className="w-7 shrink-0 text-right text-[8px] font-black tabular-nums"
                      style={{ color: c.r > 0 ? "#22c55e" : "#ef4444" }}>{c.r.toFixed(2)}</span>
                  </div>
                ))}
              </Panel>
            </>
          )}

          {/* ================= TIMELINE ================= */}
          {view === "timeline" && (
            <div className={`rounded-md border p-1.5 ${s.card}`}>
              {TIMELINE.map((e, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                  className="flex gap-1.5 pb-1.5 last:pb-0">
                  <div className="flex flex-col items-center">
                    <span className="mt-[3px] h-1.5 w-1.5 rounded-full" style={{ background: g, boxShadow: `0 0 6px ${g}` }} />
                    {i < TIMELINE.length - 1 && <span className="w-px flex-1 bg-current/15" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[9px] font-semibold leading-snug">{e.t}</div>
                    <div className={`text-[7.5px] ${s.muted}`}>{e.when} · {e.src}</div>
                  </div>
                  <span className="shrink-0 self-start rounded px-1 text-[7px] font-black uppercase"
                    style={{ background: alpha(g, 0.14), color: g }}>{e.kind}</span>
                </motion.div>
              ))}
            </div>
          )}

          {/* ================= ALERTS ================= */}
          {view === "alerts" && (
            <>
              {rules.map((r) => (
                <div key={r.id} className={`rounded-md border p-1.5 ${s.card}`}>
                  <div className="flex items-center gap-1.5">
                    <Bell className="h-2.5 w-2.5 shrink-0" style={{ color: r.active ? g : "currentColor", opacity: r.active ? 1 : 0.4 }} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[9px] font-bold">{r.name}</div>
                      <div className={`truncate font-mono text-[7.5px] ${s.muted}`}>{r.when}</div>
                      <div className={`text-[7.5px] ${s.muted}`}>{r.channel} · fired {r.fired}×</div>
                    </div>
                    <button onClick={() => setRules((p) => p.map((x) => x.id === r.id ? { ...x, active: !x.active } : x))}
                      className="h-3.5 w-6 shrink-0 rounded-full p-[2px] transition"
                      style={{ background: r.active ? g : alpha(g, 0.2) }}>
                      <motion.span className="block h-2.5 w-2.5 rounded-full bg-white" animate={{ x: r.active ? 10 : 0 }} />
                    </button>
                  </div>
                </div>
              ))}
              <Tap color={g} effect="glow"
                onClick={() => { setRules((p) => [...p, { id: "a" + Date.now(), name: "New rule", when: "score > 70", channel: "Push", active: true, fired: 0 }]); say("Rule created"); }}
                className={`flex w-full items-center justify-center gap-1 rounded-md border border-dashed py-[6px] text-[9px] font-bold ${s.card}`}
                style={{ color: g }}>+ New alert rule</Tap>
            </>
          )}

          {/* ================= PIPELINE ================= */}
          {view === "pipeline" && (
            <div className="space-y-1.5">
              {(["backlog", "scoping", "active", "done"] as const).map((st) => (
                <Panel key={st} title={`${st} · ${pipe.filter((p) => p.stage === st).length}`} muted={s.muted} className={s.card}>
                  <div className="space-y-[3px]">
                    {pipe.filter((p) => p.stage === st).map((p) => (
                      <div key={p.id} className={`flex items-center gap-1.5 rounded px-1.5 py-1 ${s.chip}`}>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-[8.5px] font-bold">{p.title}</div>
                          <div className={`text-[7.5px] ${s.muted}`}>{p.owner} · due {p.due} · {p.value}</div>
                        </div>
                        <button
                          onClick={() => setPipe((all) => all.map((x) => x.id === p.id ? {
                            ...x, stage: (["backlog", "scoping", "active", "done"] as const)[
                              Math.min(3, (["backlog", "scoping", "active", "done"] as const).indexOf(x.stage) + 1)]
                          } : x))}
                          className="shrink-0 rounded px-1 py-[2px] text-[7.5px] font-black" style={{ background: alpha(g, 0.18), color: g }}>
                          advance
                        </button>
                      </div>
                    ))}
                    {!pipe.filter((p) => p.stage === st).length && <div className={`text-[8px] ${s.muted}`}>empty</div>}
                  </div>
                </Panel>
              ))}
            </div>
          )}

          {/* ================= GRAPH / MIND MAP ================= */}
          {view === "graph" && (
            <Panel title="Signal graph · sources → findings" muted={s.muted} className={s.card}>
              <MindMap g={g} muted={s.muted} />
              <div className={`mt-1 text-[7.5px] ${s.muted}`}>
                Node size = evidence weight · edges show which sources drove each finding.
              </div>
            </Panel>
          )}

          {/* ================= STUDIO (recordings) ================= */}
          {view === "studio" && (
            <>
              <div className={`rounded-md border p-1.5 ${s.card}`} style={{ background: alpha(g, 0.05) }}>
                <div className="flex items-center gap-1.5">
                  <Radio className="h-3 w-3" style={{ color: g }} />
                  <div className="min-w-0 flex-1">
                    <div className="text-[9.5px] font-extrabold" style={{ fontFamily: "'Sora',sans-serif" }}>Broadcast studio</div>
                    <div className={`text-[8px] ${s.muted}`}>{recs.length} items · recordings sent here from the radio</div>
                  </div>
                </div>
              </div>
              {recs.map((r) => (
                <div key={r.id} className={`flex items-center gap-1.5 rounded-md border p-1.5 ${s.card}`}>
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md" style={{ background: alpha(g, 0.15) }}>
                    {r.scheduled ? <Waves className="h-3 w-3" style={{ color: g }} /> : <Play className="h-3 w-3" style={{ color: g }} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[9px] font-bold">{r.title}</div>
                    <div className={`truncate text-[7.5px] ${s.muted}`}>
                      {r.channel} · {r.category} · {r.scheduled ? `scheduled ${r.at}` : `${Math.floor(r.seconds / 60)}:${String(r.seconds % 60).padStart(2, "0")}`}
                    </div>
                  </div>
                  <button onClick={() => removeRec(r.id)}><Trash2 className="h-2.5 w-2.5 opacity-40" /></button>
                </div>
              ))}
            </>
          )}
        </motion.div>
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
            className="pointer-events-none sticky bottom-1 z-20 mx-auto mt-1.5 w-fit rounded-full px-2.5 py-1 text-[8.5px] font-bold"
            style={{ background: alpha(g, 0.92), color: isLight ? "#fff" : "#04121f" }}>
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function FindingRow({
  f, cols, g, s, isLight, selected, onSelect, expanded, onToggle, onAct,
}: {
  f: Finding; cols: string[]; g: string; s: ReturnType<typeof useSkin>; isLight: boolean;
  selected: boolean; onSelect: () => void; expanded: boolean; onToggle: () => void; onAct: (m: string) => void;
}) {
  const k = KIND[f.kind];
  return (
    <div className={`rounded border ${s.card}`} style={selected ? { borderColor: alpha(g, 0.6), background: alpha(g, 0.05) } : undefined}>
      <div className="grid items-center gap-1 px-1.5 py-[4px]"
        style={{ gridTemplateColumns: `12px 1fr repeat(${1 + cols.filter((c) => c !== "value").length}, 26px) ${cols.includes("value") ? "46px" : "0px"}` }}>
        <button onClick={onSelect} className="grid h-3 w-3 place-items-center rounded-[3px]"
          style={{ background: selected ? g : "transparent", border: `1px solid ${selected ? g : "currentColor"}` }}>
          {selected && <Check className="h-2 w-2" style={{ color: isLight ? "#fff" : "#04121f" }} />}
        </button>
        <button onClick={onToggle} className="flex min-w-0 items-center gap-1 text-left">
          <span className="shrink-0" style={{ color: k.color }}>{k.icon}</span>
          <span className="min-w-0">
            <span className="block truncate text-[9px] font-bold">{f.title}</span>
            <span className={`block truncate text-[7px] ${s.muted}`}>{f.region} · {f.sector} · {f.horizon}</span>
          </span>
        </button>
        <span className="text-right text-[9px] font-black tabular-nums" style={{ color: g }}>{f.score}</span>
        {cols.includes("conf") && <span className={`text-right text-[8px] tabular-nums ${s.muted}`}>{f.confidence}</span>}
        {cols.includes("impact") && <span className={`text-right text-[8px] tabular-nums ${s.muted}`}>{f.impact}</span>}
        {cols.includes("effort") && <span className={`text-right text-[8px] tabular-nums ${s.muted}`}>{f.effort}</span>}
        {cols.includes("value") && <span className="truncate text-right text-[7.5px] font-bold">{f.value}</span>}
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-current/10">
            <div className="space-y-1 px-1.5 py-1.5">
              <div className="text-[8.5px] leading-snug">{f.summary}</div>
              <DrawLine series={f.trend} c1={g} c2={g} height={40} />
              <div className={`text-[7px] font-black uppercase tracking-wider ${s.muted}`}>Evidence chain</div>
              {f.evidence.map((e, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <Link2 className="h-2 w-2 shrink-0 opacity-50" />
                  <span className="min-w-0 flex-1 truncate text-[8px]">{e.text}</span>
                  <span className="w-8 shrink-0"><Bar v={e.weight * 200} color={g} chip={s.chip} /></span>
                  <span className={`w-6 shrink-0 text-right text-[7.5px] tabular-nums ${s.muted}`}>{Math.round(e.weight * 100)}%</span>
                </div>
              ))}
              <div className="flex flex-wrap gap-1 pt-0.5">
                {f.actions.map((a) => (
                  <button key={a} onClick={() => onAct(`Queued · ${a}`)}
                    className="rounded px-1 py-[2px] text-[7.5px] font-bold" style={{ background: alpha(g, 0.14), color: g }}>
                    + {a}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MindMap({ g, muted }: { g: string; muted: string }) {
  const srcs = V2_SOURCES.slice(0, 6);
  const finds = FINDINGS.slice(0, 5);
  return (
    <svg viewBox="0 0 240 150" className="h-[170px] w-full">
      {srcs.map((s2, i) => {
        const y = 14 + i * 24;
        return finds.map((f, j) => {
          if (!f.evidence.some((e) => e.src === s2.k)) return null;
          const fy = 22 + j * 28;
          return (
            <motion.path key={`${i}-${j}`} d={`M52,${y} C110,${y} 130,${fy} 176,${fy}`} fill="none"
              stroke={alpha(g, 0.35)} strokeWidth={0.8}
              initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1, delay: (i + j) * 0.05 }} />
          );
        });
      })}
      {srcs.map((s2, i) => (
        <g key={s2.k}>
          <circle cx={46} cy={14 + i * 24} r={4} fill={alpha(g, 0.8)} />
          <text x={40} y={17 + i * 24} textAnchor="end" fontSize="6" fill="currentColor" opacity={0.75}>{s2.label}</text>
        </g>
      ))}
      {finds.map((f, j) => (
        <g key={f.id}>
          <circle cx={180} cy={22 + j * 28} r={5 + f.score / 40} fill={alpha(KIND[f.kind].color, 0.75)} />
          <text x={190} y={24 + j * 28} fontSize="6" fill="currentColor" opacity={0.8}>{f.title.slice(0, 22)}</text>
        </g>
      ))}
    </svg>
  );
}
