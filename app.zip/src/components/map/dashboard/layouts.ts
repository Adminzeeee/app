/* Dashboard layouts — two design systems for the bottom pane. */

export interface LayoutSpec {
  id: number;
  name: string;
  blurb: string;
  /** whole-pane scale; bigger layouts read larger on phones */
  zoom: number;
  font: string;
  headFont: string;
  /** tab chrome */
  tabs: "pill" | "bar" | "underline" | "chip" | "rail" | "segment";
  tabPos: "top" | "bottom";
  radius: number;
  upper: boolean;
  tracking: string;
  /** surface tint over the theme background, 0 = none */
  tint: number;
  divider: boolean;
}

const MANROPE = "'Manrope', system-ui, sans-serif";
const SORA = "'Sora', system-ui, sans-serif";

export const LAYOUTS: LayoutSpec[] = [
  {
    id: 7, name: "Classic", blurb: "The original dense build (default)",
    zoom: 1, font: MANROPE, headFont: SORA, tabs: "chip", tabPos: "top",
    radius: 6, upper: false, tracking: "0", tint: 0, divider: false,
  },
  {
    id: 1, name: "Clean cards", blurb: "Roomy cards, calm spacing",
    zoom: 1.12, font: MANROPE, headFont: SORA, tabs: "pill", tabPos: "top",
    radius: 14, upper: false, tracking: "0", tint: 0.03, divider: false,
  },
];

export const LAYOUT_KEY = "bw.dashboard.layout.v2";
