import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Check, Coins, Flame, MessageSquare } from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Ring, Tap, useSkin } from "./ui";
import { useCoins } from "./coins";

const DAILY = 10;

const POOL: { q: string; options: string[] }[] = [
  { q: "How reliable was your water supply this week?", options: ["Very reliable", "Mostly fine", "Often out", "No supply"] },
  { q: "Did you experience a power cut in the last 7 days?", options: ["None", "Once", "2–3 times", "Almost daily"] },
  { q: "How easy was it to find work or a job lead?", options: ["Easy", "Some leads", "Very hard", "Not looking"] },
  { q: "How would you rate your nearest clinic?", options: ["Excellent", "Good", "Poor", "Never used"] },
  { q: "Are transport costs affecting your week?", options: ["Not at all", "A little", "A lot", "Can't travel"] },
  { q: "Is your local road in usable condition?", options: ["Good", "Passable", "Bad", "Impassable"] },
  { q: "How safe do you feel in your area at night?", options: ["Very safe", "Fairly safe", "Unsafe", "Very unsafe"] },
  { q: "Did food prices change for you this month?", options: ["Cheaper", "Same", "Higher", "Much higher"] },
  { q: "How is mobile network quality where you are?", options: ["Strong", "Patchy", "Weak", "None"] },
  { q: "What should leaders prioritise next quarter?", options: ["Water", "Jobs", "Health", "Roads"] },
  { q: "Have you used a government service online?", options: ["Yes, easy", "Yes, hard", "Tried, failed", "Never"] },
  { q: "How optimistic are you about the next 6 months?", options: ["Very", "Somewhat", "Not much", "Not at all"] },
];

const KEY = "bw-say-v1";
interface Saved { day: string; answered: number; streak: number; last: string }

function today() { return new Date().toISOString().slice(0, 10); }
function load(): Saved {
  if (typeof window === "undefined") return { day: today(), answered: 0, streak: 4, last: "" };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as Saved;
      if (p.day === today()) return p;
      const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
      return { day: today(), answered: 0, streak: p.day === y ? p.streak : 0, last: p.day };
    }
  } catch { /* ignore */ }
  return { day: today(), answered: 0, streak: 4, last: "" };
}

/** Have your say — 10 questions a day, 1 coin each, streak keeps building. */
export function SayTab({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const { balance, earn } = useCoins();
  const [state, setState] = useState<Saved>(load);
  const [picked, setPicked] = useState<string | null>(null);

  useEffect(() => {
    try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  }, [state]);

  const done = state.answered >= DAILY;
  const idx = (new Date().getDate() + state.answered) % POOL.length;
  const q = POOL[idx];

  const answer = (opt: string) => {
    if (done || picked) return;
    setPicked(opt);
    earn("Daily question answered", 1);
    window.setTimeout(() => {
      setPicked(null);
      setState((p) => {
        const answered = p.answered + 1;
        return { ...p, answered, streak: answered === DAILY ? p.streak + 1 : p.streak };
      });
    }, 380);
  };

  return (
    <div className="space-y-1.5">
      <div className={`flex items-center gap-2 rounded-lg border p-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.25), background: alpha(g, 0.05) }}>
        <Ring value={(state.answered / DAILY) * 100} color={g} size={40} label={`${state.answered}/${DAILY}`} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1">
            <MessageSquare className="h-3 w-3" style={{ color: g }} />
            <span className="truncate text-[10px] font-black">Today's questions</span>
          </div>
          <div className={`text-[7.5px] ${s.muted}`}>1 coin per answer · resets at midnight</div>
        </div>
        <div className="shrink-0 text-right">
          <div className="flex items-center gap-1 text-[10px] font-black" style={{ color: g }}>
            <Flame className="h-3 w-3" />{state.streak}d
          </div>
          <div className={`flex items-center justify-end gap-0.5 text-[8px] ${s.muted}`}>
            <Coins className="h-2.5 w-2.5" />{balance.toLocaleString()}
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!done ? (
          <motion.div key={state.answered} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className={`rounded-lg border p-2 ${s.card}`} style={{ borderColor: alpha(g, 0.22) }}>
            <div className={`mb-1 text-[7px] font-black uppercase tracking-[0.18em] ${s.muted}`}>
              Question {state.answered + 1} of {DAILY}
            </div>
            <div className="text-[11.5px] font-bold leading-snug">{q.q}</div>
            <div className="mt-1.5 grid gap-1">
              {q.options.map((o) => (
                <Tap key={o} color={g} effect="glow" onClick={() => answer(o)}
                  className="rounded-md px-2 py-1.5 text-[10px] font-semibold"
                  style={picked === o
                    ? { background: g, color: isLight ? "#fff" : "#04121f" }
                    : { background: alpha(g, 0.08) }}>
                  <span className="flex items-center gap-1">
                    {picked === o && <Check className="h-3 w-3" />}{o}
                  </span>
                </Tap>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div key="done" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className={`rounded-lg border p-2 text-center ${s.card}`} style={{ borderColor: alpha(g, 0.3) }}>
            <Check className="mx-auto h-5 w-5" style={{ color: g }} />
            <div className="mt-1 text-[11px] font-black">All 10 done — +10 coins</div>
            <div className={`text-[8px] ${s.muted}`}>Streak now {state.streak} days. Come back tomorrow for a new set.</div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: 7 }, (_, i) => {
          const on = i < Math.min(7, state.streak);
          return (
            <div key={i} className="grid h-6 place-items-center rounded-md text-[7.5px] font-black"
              style={{ background: on ? alpha(g, 0.22) : alpha(g, 0.06), color: on ? g : undefined }}>
              {["M", "T", "W", "T", "F", "S", "S"][i]}
            </div>
          );
        })}
      </div>
    </div>
  );
}
