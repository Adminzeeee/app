import { useMemo } from "react";
import engineHtml from "./verityEngine.html?raw";

/** Mobile-fit overrides injected into the sandboxed engine document. */
const MOBILE_CSS = `
<style>
@media (max-width: 760px) {
  :root { font-size: 15px }
  .top-bar { height: 40px; padding: 0 .5rem; gap: .4rem }
  .app-title { font-size: .52rem; letter-spacing: .14em }
  .top-actions {
    gap: .25rem;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
    max-width: calc(100% - 5.2rem);
  }
  .top-actions::-webkit-scrollbar { display: none }
  .action-btn { font-size: .46rem; padding: .3rem .5rem; border-radius: 6px }
  .toolbox { bottom: 3.6rem; gap: .3rem; padding: .35rem }
  .tool-btn { width: 34px; height: 30px; border-radius: 8px }
  .tool-btn svg { width: 16px; height: 12px }
  .tool-btn .tool-label { font-size: .34rem }
  .truth-panel { right: .4rem; left: .4rem; bottom: .4rem; width: auto; max-width: none }
  .truth-panel summary { font-size: .55rem; padding: .4rem .6rem }
  .truth-table-wrap { max-height: 150px; padding: .4rem }
  .truth-table { font-size: .48rem }
  .zoom-indicator { bottom: .4rem; font-size: .48rem; padding: .22rem .5rem }
  .undo-toast { bottom: 2.8rem; font-size: .52rem; padding: .4rem .7rem }
  .node-input { width: 74px; height: 60px }
  .node-gate { width: 96px; height: 66px }
  .node-output { width: 60px; height: 60px }
  .context-menu { min-width: 130px }
  .ctx-item { font-size: .55rem; padding: .35rem .6rem }
}
</style>
`;

/** v8 — Engine only: the Verity Engine circuit workspace, rendered exactly as designed. */
export function WorkspaceV8() {
  const doc = useMemo(() => engineHtml.replace("</head>", `${MOBILE_CSS}</head>`), []);

  return (
    <div
      className="overflow-hidden rounded-2xl"
      style={{ border: "1px solid rgba(0, 240, 255, 0.08)", background: "#0a0a12" }}
    >
      <iframe
        title="Verity Engine"
        srcDoc={doc}
        className="block h-[440px] w-full border-0 sm:h-[560px]"
        sandbox="allow-scripts allow-same-origin"
      />
    </div>
  );
}
