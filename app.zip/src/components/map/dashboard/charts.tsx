import { motion } from "framer-motion";
import { alpha } from "../color";
import type { ThemeSpec } from "../themes";

/** Self-drawing area/line chart. */
export function DrawLine({ series, c1, c2, height = 66 }: { series: number[]; c1: string; c2: string; height?: number }) {
  const w = 300, h = height;
  const min = Math.min(...series), max = Math.max(...series);
  const norm = (v: number) => (v - min) / Math.max(0.0001, max - min);
  const pts = series.map((v, i) => [(i / (series.length - 1)) * w, h - norm(v) * (h - 8) - 4] as const);
  const path = pts.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${path} L${w},${h} L0,${h} Z`;
  const id = `dl-${c1.replace(/[^a-z0-9]/gi, "")}-${series.length}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={c1} stopOpacity="0.45" />
          <stop offset="100%" stopColor={c1} stopOpacity="0" />
        </linearGradient>
      </defs>
      <motion.path d={area} fill={`url(#${id})`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.4 }} />
      <motion.path
        d={path} fill="none" stroke={c2} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"
        initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
        transition={{ duration: 1.3, ease: [0.22, 1, 0.36, 1] }}
        style={{ filter: `drop-shadow(0 0 4px ${alpha(c2, 0.55)})` }}
      />
    </svg>
  );
}

/** Self-drawing concentric donut rings. */
export function DrawDonut({
  sectors, theme, muted,
}: { sectors: { k: string; v: number }[]; theme: ThemeSpec; muted: string }) {
  const colors = [theme.markerCore.capital, theme.markerCore.city, theme.markerCore.park, theme.markerCore.landmark];
  return (
    <div className="flex items-center gap-2">
      <svg viewBox="0 0 76 76" className="h-[66px] w-[66px] shrink-0 -rotate-90">
        {sectors.map((s, i) => {
          const r = 33 - i * 7;
          const c = 2 * Math.PI * r;
          return (
            <g key={s.k}>
              <circle cx="38" cy="38" r={r} fill="none" stroke="currentColor" strokeWidth="4" opacity="0.08" />
              <motion.circle
                cx="38" cy="38" r={r} fill="none" stroke={colors[i % colors.length]} strokeWidth="4" strokeLinecap="round"
                strokeDasharray={c}
                initial={{ strokeDashoffset: c }}
                animate={{ strokeDashoffset: c * (1 - s.v / 60) }}
                transition={{ duration: 1.1, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                style={{ filter: `drop-shadow(0 0 3px ${alpha(colors[i % colors.length], 0.55)})` }}
              />
            </g>
          );
        })}
      </svg>
      <ul className="min-w-0 flex-1 space-y-[3px]">
        {sectors.map((s, i) => (
          <li key={s.k} className="flex items-center gap-1.5 text-[10.5px]">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: colors[i % colors.length] }} />
            <span className="truncate">{s.k}</span>
            <span className={`ml-auto font-semibold tabular-nums ${muted}`}>{s.v}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Self-drawing mindmap. */
export function MindMap({
  scope, theme, isLight, nodes,
}: {
  scope: string;
  theme: ThemeSpec;
  isLight: boolean;
  nodes?: { label: string; x: number; y: number; c: string }[];
}) {
  const ns = nodes ?? [
    { label: "Economy", x: 42, y: 16, c: theme.markerCore.capital },
    { label: "People", x: 200, y: 12, c: theme.markerCore.city },
    { label: "Nature", x: 250, y: 58, c: theme.markerCore.park },
    { label: "Trade", x: 30, y: 62, c: theme.markerCore.landmark },
    { label: "Jobs", x: 250, y: 96, c: theme.markerCore.village },
    { label: "Water", x: 44, y: 100, c: theme.markerCore.town },
  ];
  const cx = 148, cy = 58;
  return (
    <svg viewBox="0 0 300 116" className="h-[104px] w-full">
      {ns.map((n, i) => {
        const mx = (cx + n.x) / 2;
        return (
          <motion.path
            key={"e" + n.label}
            d={`M${cx},${cy} Q${mx},${n.y > cy ? cy + 28 : cy - 28} ${n.x + 14},${n.y + 7}`}
            fill="none" stroke={n.c} strokeWidth={1.1} strokeLinecap="round" opacity={0.75}
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
            transition={{ duration: 0.9, delay: 0.15 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
          />
        );
      })}
      <motion.circle
        cx={cx} cy={cy} r={17}
        fill={alpha(theme.glow, 0.13)} stroke={theme.glow} strokeWidth={1.2}
        initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 220, damping: 16 }}
        style={{ transformOrigin: `${cx}px ${cy}px`, filter: `drop-shadow(0 0 8px ${alpha(theme.glow, 0.55)})` }}
      />
      <text x={cx} y={cy + 3} textAnchor="middle" fontSize="8" fontWeight="800" fontFamily="'Sora',sans-serif" fill={isLight ? "#0f172a" : "#fff"}>
        {scope.length > 9 ? scope.slice(0, 8) + "…" : scope}
      </text>
      {ns.map((n, i) => (
        <motion.g
          key={n.label}
          initial={{ opacity: 0, scale: 0.7 }} animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 + i * 0.12, type: "spring", stiffness: 260, damping: 18 }}
          style={{ transformOrigin: `${n.x + 14}px ${n.y + 7}px` }}
        >
          <rect x={n.x} y={n.y} rx={7} height={14} width={n.label.length * 5.6 + 12} fill={alpha(n.c, 0.12)} stroke={n.c} strokeWidth={0.8} />
          <text x={n.x + 6} y={n.y + 10} fontSize="7.5" fontWeight="700" fontFamily="'Manrope',sans-serif" fill={isLight ? "#0f172a" : "#fff"}>
            {n.label}
          </text>
        </motion.g>
      ))}
    </svg>
  );
}

/** Animated horizontal column chart. */
export function Columns({ data, color }: { data: { k: string; v: number }[]; color: string }) {
  const max = Math.max(...data.map((d) => d.v), 1);
  return (
    <div className="flex h-[58px] items-end gap-1.5">
      {data.map((d, i) => (
        <div key={d.k} className="flex min-w-0 flex-1 flex-col items-center gap-1">
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: `${(d.v / max) * 44}px` }}
            transition={{ duration: 0.7, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
            className="w-full rounded-t-[3px]"
            style={{ background: `linear-gradient(180deg, ${color}, ${alpha(color, 0.25)})`, boxShadow: `0 0 8px ${alpha(color, 0.4)}` }}
          />
          <span className="w-full truncate text-center text-[8px] opacity-60">{d.k}</span>
        </div>
      ))}
    </div>
  );
}

/** Radar / spider chart. */
export function Radar({ data, color }: { data: { k: string; v: number }[]; color: string }) {
  const cx = 60, cy = 56, R = 42;
  const pts = data.map((d, i) => {
    const a = (i / data.length) * Math.PI * 2 - Math.PI / 2;
    const r = (d.v / 100) * R;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r] as const;
  });
  const poly = pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  return (
    <svg viewBox="0 0 120 112" className="h-[104px] w-full">
      {[1, 0.66, 0.33].map((f) => (
        <circle key={f} cx={cx} cy={cy} r={R * f} fill="none" stroke="currentColor" opacity={0.1} strokeWidth={0.6} />
      ))}
      {data.map((d, i) => {
        const a = (i / data.length) * Math.PI * 2 - Math.PI / 2;
        return (
          <g key={d.k}>
            <line x1={cx} y1={cy} x2={cx + Math.cos(a) * R} y2={cy + Math.sin(a) * R} stroke="currentColor" opacity={0.1} strokeWidth={0.6} />
            <text
              x={cx + Math.cos(a) * (R + 9)} y={cy + Math.sin(a) * (R + 9) + 2}
              textAnchor="middle" fontSize="6.5" fontWeight={700} fill="currentColor" opacity={0.6}
            >
              {d.k}
            </text>
          </g>
        );
      })}
      <motion.polygon
        points={poly}
        fill={alpha(color, 0.22)} stroke={color} strokeWidth={1.3}
        initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 180, damping: 18 }}
        style={{ transformOrigin: `${cx}px ${cy}px`, filter: `drop-shadow(0 0 5px ${alpha(color, 0.5)})` }}
      />
    </svg>
  );
}

/** Animated heat grid. */
export function HeatGrid({ seedRows, colors }: { seedRows: number[][]; colors: string[] }) {
  return (
    <div className="space-y-[3px]">
      {seedRows.map((row, r) => (
        <div key={r} className="flex gap-[3px]">
          {row.map((v, c) => (
            <motion.span
              key={c}
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: (r * row.length + c) * 0.012 }}
              className="h-[11px] flex-1 rounded-[2px]"
              style={{
                background: alpha(colors[Math.min(colors.length - 1, Math.floor((v / 100) * colors.length))], 0.25 + (v / 100) * 0.7),
              }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}
