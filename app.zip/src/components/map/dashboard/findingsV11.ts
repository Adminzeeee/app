/* Findings v11 — richer, plain-language findings with timestamps, money framing,
 * gaps and insights. Superset of the v2 Finding shape so the v2 table UI can
 * render it unchanged. */

export type V11Kind = "opportunity" | "gap" | "insight" | "risk";

export interface V11Finding {
  id: string;
  kind: V11Kind;
  /** Short label used in dense table rows. */
  title: string;
  /** Full plain-language headline: tells the user everything at a glance. */
  headline: string;
  region: string;
  sector: string;
  score: number;
  confidence: number;
  impact: number;
  effort: number;
  /** Money on the table, already framed for a decision. */
  value: string;
  /** Money detail: revenue, cost avoided, or payback. */
  money: { line: string; payback: string; upfront: string };
  horizon: string;
  detected: string;   // ISO
  updated: string;    // ISO
  owner: string;
  status: "new" | "reviewing" | "in motion" | "watch";
  summary: string;
  /** One sentence answering "why now". */
  whyNow: string;
  who: string;
  evidence: { src: string; text: string; weight: number }[];
  actions: string[];
  trend: number[];
}

const iso = (daysAgo: number, hour = 9, min = 12) => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, min, 0, 0);
  return d.toISOString();
};

export const V11_FINDINGS: V11Finding[] = [
  {
    id: "v1", kind: "opportunity", title: "Digital skills academy · Francistown",
    headline: "Open a 400-seat digital skills academy in Francistown — P41.2M of unmet tuition demand, zero competitors within 180km",
    region: "North-East", sector: "Education", score: 94, confidence: 88, impact: 84, effort: 46,
    value: "P41.2M / 3yr",
    money: { line: "P41.2M gross tuition over 3 years", payback: "19 months", upfront: "P7.4M fit-out + P1.1M/yr staff" },
    horizon: "12 months", detected: iso(11, 6, 40), updated: iso(0, 7, 5), owner: "T. Moeng", status: "in motion",
    summary: "5,120 youth survey responses name digital skills as the top employment pathway, while the directory shows no accredited training provider inside a 180km radius. Employer postings for data and web roles are up 48% in twelve weeks.",
    whyNow: "Two anchor employers have signed intent letters and the council annex lease expires in November — after that the site goes to open tender.",
    who: "Private training operators, TVET partners, district council",
    evidence: [
      { src: "surveys", text: "Youth employment wave 8 · digital skills demand +24% YoY (n=5,120)", weight: 0.31 },
      { src: "directory", text: "0 accredited digital training providers registered in North-East", weight: 0.27 },
      { src: "news", text: "3 press mentions of employer skills shortages in 30 days", weight: 0.18 },
      { src: "trade", text: "IT services imports up 12% — P18M/yr of spend leaving the district", weight: 0.14 },
      { src: "notes", text: "Field note: Francistown council offered a disused annex at P0 rent for 24 months", weight: 0.10 },
    ],
    actions: ["Scope a 400-seat academy", "Approach 2 anchor employers", "Model 3-year fee structure"],
    trend: [22, 30, 28, 41, 46, 52, 61, 68, 74, 82, 88, 94],
  },
  {
    id: "v2", kind: "opportunity", title: "Cold-chain depot · Ghanzi",
    headline: "Build a 600-pallet cold-chain depot in Ghanzi — 11% of perishable output is spoiling, worth P26.8M a year to recover",
    region: "Ghanzi", sector: "Agriculture", score: 88, confidence: 81, impact: 79, effort: 62,
    value: "P26.8M / yr recovered",
    money: { line: "P26.8M/yr spoilage recovered · P6.1M/yr storage fees", payback: "31 months", upfront: "P22.4M build + refrigeration" },
    horizon: "6 months", detected: iso(23, 11, 5), updated: iso(1, 16, 22), owner: "L. Serema", status: "reviewing",
    summary: "Agricultural output in Ghanzi rose 14% year on year while the directory still lists zero refrigerated depots in the district. Transit temperature telemetry puts spoilage at 9-13% of perishable volume.",
    whyNow: "The 2027 abattoir expansion doubles outbound volume; without cold storage the new throughput has nowhere to go.",
    who: "Agri-cooperatives, abattoir operators, reefer transporters",
    evidence: [
      { src: "directory", text: "0 cold-chain depots registered in Ghanzi district", weight: 0.34 },
      { src: "sensors", text: "Mean transit temperature exceeds 8°C on 61% of runs", weight: 0.26 },
      { src: "trade", text: "Perishable outbound volume +14% over 12 months", weight: 0.22 },
      { src: "weather", text: "Mean daytime max up 1.4°C vs 10-year baseline", weight: 0.18 },
    ],
    actions: ["Site survey 3 candidate plots", "Model 600-pallet capacity", "Test anchor tenant demand"],
    trend: [40, 42, 47, 44, 52, 58, 55, 63, 68, 71, 78, 88],
  },
  {
    id: "v3", kind: "opportunity", title: "Solar borehole retrofit · Kgalagadi",
    headline: "Retrofit 40 diesel boreholes to solar in Kgalagadi — cuts P9.6M a year in fuel and ends 62% of outage complaints",
    region: "Kgalagadi", sector: "Energy", score: 86, confidence: 84, impact: 88, effort: 55,
    value: "P9.6M / yr saved",
    money: { line: "P9.6M/yr diesel avoided across 40 sites", payback: "26 months", upfront: "P20.8M capital (P520k per site)" },
    horizon: "12 months", detected: iso(30, 8, 15), updated: iso(2, 10, 40), owner: "K. Dube", status: "in motion",
    summary: "Diesel pumping accounts for 71% of district water operating cost. Solar irradiance in Kgalagadi is in the top decile nationally and pump downtime clusters around fuel delivery gaps, not equipment failure.",
    whyNow: "A regional climate grant window closes in 41 days and covers up to 60% of retrofit capital.",
    who: "Water utility, district council, solar EPC contractors",
    evidence: [
      { src: "sensors", text: "Pump downtime 148 hours last quarter, 78% during fuel delivery gaps", weight: 0.3 },
      { src: "weather", text: "Top-decile national irradiance, 9.1 peak sun hours mean", weight: 0.24 },
      { src: "surveys", text: "62% of water complaints cite outages, not quality", weight: 0.24 },
      { src: "calendar", text: "Climate resilience grant window closes in 41 days", weight: 0.22 },
    ],
    actions: ["Shortlist 40 priority boreholes", "Draft grant submission", "Tender EPC package"],
    trend: [31, 36, 39, 44, 48, 51, 58, 64, 70, 76, 81, 86],
  },
  {
    id: "v4", kind: "opportunity", title: "Green-season lodging · Maun",
    headline: "Sell green-season Maun lodging packages — flood timing shifted three weeks early and 1,900 room-nights are still unsold",
    region: "North-West", sector: "Tourism", score: 79, confidence: 76, impact: 68, effort: 28,
    value: "P14.7M / season",
    money: { line: "1,900 room-nights × P7.7k average = P14.7M", payback: "Same season", upfront: "P1.2M marketing + channel fees" },
    horizon: "90 days", detected: iso(6, 13, 30), updated: iso(0, 12, 2), owner: "M. Kgosi", status: "new",
    summary: "Delta flood pulse arrived 19 days earlier than the ten-year mean, pulling peak wildlife viewing into a window operators still price as low season. Occupancy sits at 41% against 78% in the equivalent late window.",
    whyNow: "Booking lead time for this segment is 34 days — the sellable window closes in about five weeks.",
    who: "Lodges, tour operators, inbound agents",
    evidence: [
      { src: "sensors", text: "Flood gauge peak 19 days earlier than 10-year mean", weight: 0.33 },
      { src: "social", text: "Wildlife sighting posts up 61% for the early window", weight: 0.25 },
      { src: "directory", text: "Occupancy 41% vs 78% in the equivalent late window", weight: 0.24 },
      { src: "trade", text: "Inbound flight seats up 8% on the Maun route", weight: 0.18 },
    ],
    actions: ["Repackage green-season rates", "Brief 12 inbound agents", "Push a 5-week paid campaign"],
    trend: [18, 22, 26, 30, 38, 44, 49, 56, 62, 68, 74, 79],
  },
  {
    id: "v5", kind: "opportunity", title: "Reefer backhaul · A3 corridor",
    headline: "Sell reefer backhaul capacity on the A3 corridor — 44% of trucks run empty southbound, worth P12.6M a year",
    region: "Central", sector: "Logistics", score: 74, confidence: 79, impact: 61, effort: 33,
    value: "P12.6M / yr",
    money: { line: "P12.6M/yr in recovered backhaul revenue", payback: "8 months", upfront: "P1.9M booking platform + ops" },
    horizon: "6 months", detected: iso(17, 9, 50), updated: iso(3, 8, 12), owner: "Ops desk", status: "reviewing",
    summary: "Mobility traces show 44% of refrigerated southbound runs on the A3 return empty while three perishable shippers report waiting lists. A shared pre-booking pool closes the mismatch without new vehicles.",
    whyNow: "Fuel pass-through is squeezing hauler margins now, so operators are unusually open to a pooled model.",
    who: "Hauliers, perishable shippers, corridor freight association",
    evidence: [
      { src: "mobility", text: "44% of southbound reefer runs return empty", weight: 0.36 },
      { src: "directory", text: "3 shippers reporting perishable capacity waiting lists", weight: 0.26 },
      { src: "trade", text: "Cross-border perishable declarations +9% QoQ", weight: 0.21 },
      { src: "notes", text: "Field note: 2 hauliers already trialling informal pooling", weight: 0.17 },
    ],
    actions: ["Stand up a pre-booking pool", "Sign 4 anchor hauliers", "Price a per-pallet tariff"],
    trend: [28, 31, 33, 38, 42, 45, 51, 57, 62, 66, 70, 74],
  },
  {
    id: "v6", kind: "gap", title: "No paediatric cover · Kgalagadi South",
    headline: "Kgalagadi South has no paediatric coverage — 8,400 children sit more than 120km from the nearest clinician",
    region: "Kgalagadi", sector: "Health", score: 90, confidence: 92, impact: 91, effort: 68,
    value: "8,400 children affected",
    money: { line: "P4.1M/yr for a rotating clinic vs P11.3M/yr in referral transport", payback: "Immediate cost avoidance", upfront: "P2.6M vehicle + equipment" },
    horizon: "90 days", detected: iso(38, 7, 25), updated: iso(1, 9, 30), owner: "Health desk", status: "watch",
    summary: "The directory records no registered paediatric practitioner in the southern half of the district. Referral logs show families travelling a median 128km, and 31% of scheduled follow-ups are missed.",
    whyNow: "Missed-follow-up rate has risen for four straight quarters and now exceeds the national threshold for intervention.",
    who: "Ministry of Health, district health team, mobile clinic operators",
    evidence: [
      { src: "directory", text: "0 registered paediatric practitioners in Kgalagadi South", weight: 0.38 },
      { src: "surveys", text: "Median travel distance to child care: 128km", weight: 0.27 },
      { src: "sensors", text: "31% of scheduled paediatric follow-ups missed", weight: 0.21 },
      { src: "news", text: "2 district reports on child health access in 60 days", weight: 0.14 },
    ],
    actions: ["Cost a rotating clinic", "Map 6 candidate stop points", "Brief the district health team"],
    trend: [52, 56, 58, 63, 66, 70, 74, 79, 82, 85, 88, 90],
  },
  {
    id: "v7", kind: "gap", title: "Survey blind spot · Central rural",
    headline: "Nine rural wards in Central have not been surveyed in 14 months — every decision there is running on stale data",
    region: "Central", sector: "Digital", score: 71, confidence: 86, impact: 58, effort: 24,
    value: "9 wards · 61,000 people",
    money: { line: "P0.9M to close the gap; protects P140M of programme allocation", payback: "n/a — data quality", upfront: "P0.9M enumerator wave" },
    horizon: "90 days", detected: iso(44, 15, 10), updated: iso(4, 11, 45), owner: "Field team", status: "reviewing",
    summary: "Coverage mapping shows nine wards with no completed survey response since wave 6. Model confidence for those wards has fallen below 55%, and three active programmes allocate budget using those figures.",
    whyNow: "Wave 15 field planning locks in eleven days — adding these wards now costs a fraction of a standalone trip.",
    who: "Field enumeration team, planning unit",
    evidence: [
      { src: "surveys", text: "9 wards with zero responses since wave 6 (14 months)", weight: 0.4 },
      { src: "notes", text: "Enumerator roster short 6 people for Central rural", weight: 0.24 },
      { src: "directory", text: "Registration density 3.1× below national mean in those wards", weight: 0.2 },
      { src: "mobility", text: "Road access degraded on 4 of 9 approach routes", weight: 0.16 },
    ],
    actions: ["Add 9 wards to wave 15", "Recruit 6 enumerators", "Flag low-confidence outputs"],
    trend: [30, 34, 38, 41, 46, 50, 55, 58, 62, 66, 69, 71],
  },
  {
    id: "v8", kind: "gap", title: "Freight capacity · A3 corridor",
    headline: "A3 corridor freight capacity is 18% short of demand — 220 loads a week are being deferred or rerouted",
    region: "Central", sector: "Logistics", score: 76, confidence: 74, impact: 72, effort: 58,
    value: "220 loads / week deferred",
    money: { line: "P31M/yr of deferred freight value", payback: "22 months on new capacity", upfront: "P18M fleet or partner contracts" },
    horizon: "6 months", detected: iso(27, 10, 5), updated: iso(2, 14, 8), owner: "Ops desk", status: "watch",
    summary: "Declared tonnage has outrun registered corridor capacity for five consecutive months. Queue telemetry at the two main weighbridges shows dwell times up 41%.",
    whyNow: "Peak agricultural outbound season begins in ten weeks and will add a further 15% to demand.",
    who: "Hauliers, corridor authority, large shippers",
    evidence: [
      { src: "trade", text: "Declared tonnage exceeds registered capacity 5 months running", weight: 0.35 },
      { src: "mobility", text: "Weighbridge dwell time +41% vs baseline", weight: 0.28 },
      { src: "directory", text: "Registered corridor hauliers flat while demand +18%", weight: 0.22 },
      { src: "news", text: "4 shipper complaints reported in trade press", weight: 0.15 },
    ],
    actions: ["Quantify the capacity shortfall", "Open partner haulier talks", "Model a peak-season surcharge"],
    trend: [44, 47, 50, 54, 57, 60, 63, 67, 70, 72, 74, 76],
  },
  {
    id: "v9", kind: "insight", title: "Rain deficit predicts complaints",
    headline: "Rainfall deficit predicts water complaints 5 weeks ahead with r=0.82 — you can staff and message before the calls start",
    region: "All Botswana", sector: "Water", score: 83, confidence: 89, impact: 66, effort: 12,
    value: "5-week early warning",
    money: { line: "P3.4M/yr in avoided emergency callouts", payback: "Immediate", upfront: "P0.2M to wire the alert" },
    horizon: "30 days", detected: iso(9, 12, 0), updated: iso(0, 6, 55), owner: "Analysis desk", status: "new",
    summary: "Across eight survey waves, a rolling 30-day rainfall deficit leads water complaint volume by 34 days at r=0.82. The relationship holds in seven of nine districts and survives placebo testing.",
    whyNow: "Two districts crossed the deficit threshold last week, so the predicted complaint spike lands in early next month.",
    who: "Water utility ops, communications team",
    evidence: [
      { src: "weather", text: "Rolling 30-day rainfall deficit series, 24-month history", weight: 0.34 },
      { src: "surveys", text: "Complaint volume leads at 34 days, r=0.82", weight: 0.3 },
      { src: "sensors", text: "Reservoir drawdown confirms the same lag structure", weight: 0.2 },
      { src: "notes", text: "Granger + placebo tests pass at p<0.01", weight: 0.16 },
    ],
    actions: ["Wire a 5-week early alert", "Pre-stage tanker crews", "Draft the advance advisory"],
    trend: [40, 45, 49, 55, 58, 62, 67, 71, 75, 78, 81, 83],
  },
  {
    id: "v10", kind: "insight", title: "Directory growth tracks employment",
    headline: "Every 100 new business registrations track to 61 new jobs within two quarters — registration volume is your fastest employment proxy",
    region: "All Botswana", sector: "Digital", score: 77, confidence: 82, impact: 59, effort: 15,
    value: "0.61 jobs per registration",
    money: { line: "Each 1,000 registrations ≈ P22M of added wage base", payback: "n/a — forecasting", upfront: "P0.15M model wiring" },
    horizon: "6 months", detected: iso(15, 14, 20), updated: iso(3, 15, 5), owner: "Analysis desk", status: "reviewing",
    summary: "Directory registrations lead reported youth employment by two quarters at r=0.61, strongest in retail and services. That gives a monthly-refresh proxy for a figure otherwise published twice a year.",
    whyNow: "Registrations jumped 318 last week — the model implies an employment uptick worth flagging to planners now.",
    who: "Planning unit, economic development desk",
    evidence: [
      { src: "directory", text: "Registration series, 46,867 records, monthly refresh", weight: 0.36 },
      { src: "surveys", text: "Youth employment reported series, r=0.61 at 2-quarter lag", weight: 0.3 },
      { src: "trade", text: "Retail and services sub-sectors carry the effect", weight: 0.19 },
      { src: "social", text: "Hiring-intent mentions corroborate the direction", weight: 0.15 },
    ],
    actions: ["Publish a monthly employment nowcast", "Backtest across 3 districts", "Add to the planning brief"],
    trend: [35, 38, 42, 46, 50, 55, 59, 63, 67, 71, 74, 77],
  },
  {
    id: "v11", kind: "risk", title: "Water reliability sliding",
    headline: "Water reliability has fallen eight survey waves in a row — sentiment is down 23 points and now the steepest decline nationally",
    region: "Kgalagadi", sector: "Water", score: 91, confidence: 90, impact: 89, effort: 71,
    value: "23-point sentiment drop",
    money: { line: "P11.8M/yr in emergency response and tankering", payback: "n/a — loss avoidance", upfront: "P14M network remediation" },
    horizon: "30 days", detected: iso(48, 8, 0), updated: iso(0, 8, 45), owner: "Water desk", status: "in motion",
    summary: "Eight consecutive waves of decline, accelerating in the last three. Pump telemetry, complaint volume and tanker dispatch all point the same direction, and the decline now outpaces every other district.",
    whyNow: "The trend crosses the critical threshold within two waves at the current slope.",
    who: "Water utility, district leadership",
    evidence: [
      { src: "surveys", text: "Reliability sentiment −23 points across 8 waves", weight: 0.33 },
      { src: "sensors", text: "Pump downtime 148 hours last quarter, trending up", weight: 0.27 },
      { src: "social", text: "Outage mentions up 88% in 60 days", weight: 0.22 },
      { src: "weather", text: "Third consecutive below-mean rainfall season", weight: 0.18 },
    ],
    actions: ["Publish an outage transparency page", "Stand up a 30-day remediation sprint", "Escalate to district leadership"],
    trend: [78, 76, 74, 71, 68, 64, 60, 56, 51, 47, 44, 40],
  },
  {
    id: "v12", kind: "risk", title: "Fuel pass-through squeezing margins",
    headline: "Diesel pass-through is compressing freight margins to 6.1% — three of eleven corridor hauliers are inside the failure band",
    region: "All Botswana", sector: "Logistics", score: 80, confidence: 77, impact: 74, effort: 49,
    value: "3 of 11 hauliers at risk",
    money: { line: "P26M of corridor capacity at risk of exiting", payback: "n/a — loss avoidance", upfront: "P0.4M tariff renegotiation support" },
    horizon: "90 days", detected: iso(21, 16, 40), updated: iso(1, 17, 15), owner: "Ops desk", status: "watch",
    summary: "Diesel is up 11% while contracted haulage rates are fixed for another two quarters. Margin modelling puts three operators below the 7% band where corridor exits historically begin.",
    whyNow: "Rate renegotiation windows open in six weeks; after that operators are locked in for another two quarters.",
    who: "Hauliers, shippers, corridor authority",
    evidence: [
      { src: "trade", text: "Diesel index +11% while contract rates flat", weight: 0.34 },
      { src: "directory", text: "3 of 11 corridor hauliers below the 7% margin band", weight: 0.28 },
      { src: "mobility", text: "Trip frequency down 6% for the affected operators", weight: 0.2 },
      { src: "news", text: "2 operator statements on rate pressure", weight: 0.18 },
    ],
    actions: ["Model a fuel-indexed tariff", "Open renegotiation with 4 shippers", "Monitor exit risk weekly"],
    trend: [62, 64, 66, 69, 70, 72, 74, 76, 77, 78, 79, 80],
  },
  {
    id: "v13", kind: "risk", title: "Human–elephant conflict · Chobe",
    headline: "Human–elephant conflict incidents in Chobe are up 46% — crop losses now hit 1,240 households across four wards",
    region: "Chobe", sector: "Agriculture", score: 85, confidence: 83, impact: 81, effort: 57,
    value: "1,240 households",
    money: { line: "P6.2M/yr in crop losses and compensation", payback: "18 months on beehive fencing", upfront: "P6.2M fencing programme" },
    horizon: "6 months", detected: iso(34, 7, 55), updated: iso(2, 9, 5), owner: "Chobe unit", status: "reviewing",
    summary: "Incident reports rose 46% year on year, concentrated on four wards along the seasonal movement corridor. Beehive fencing trials elsewhere cut incidents by 61% at a fraction of compensation cost.",
    whyNow: "The next migration window opens in seven weeks — fencing must be in place before it.",
    who: "Wildlife department, ward committees, farming households",
    evidence: [
      { src: "events", text: "Incident reports +46% YoY, 4 wards carry 78% of them", weight: 0.32 },
      { src: "surveys", text: "1,240 households reporting crop loss", weight: 0.27 },
      { src: "satellite", text: "Corridor vegetation shift matches incident geography", weight: 0.23 },
      { src: "notes", text: "Beehive fence trial elsewhere cut incidents 61%", weight: 0.18 },
    ],
    actions: ["Deploy beehive fencing on 4 wards", "Pre-position response teams", "Brief ward committees"],
    trend: [48, 52, 55, 59, 63, 66, 70, 74, 77, 80, 83, 85],
  },
  {
    id: "v14", kind: "insight", title: "Grant windows drive project starts",
    headline: "Project starts cluster 18 days after grant windows open — shifting scoping earlier would add roughly 40 more starts a year",
    region: "All Botswana", sector: "Digital", score: 68, confidence: 80, impact: 52, effort: 18,
    value: "~40 extra starts / yr",
    money: { line: "P58M of additional programme spend actually deployed", payback: "n/a — throughput", upfront: "P0.3M planning change" },
    horizon: "12 months", detected: iso(19, 11, 35), updated: iso(5, 10, 25), owner: "Planning unit", status: "new",
    summary: "Across 24 months, project starts spike 18 days after each grant window opens and fall away sharply once it closes, implying preparation — not appetite — is the binding constraint.",
    whyNow: "Three windows open next quarter; scoping started now would land inside all three.",
    who: "Planning unit, programme leads",
    evidence: [
      { src: "calendar", text: "Grant window series vs project start dates, r=0.53", weight: 0.35 },
      { src: "notes", text: "Median scoping lead time 26 days vs 18-day window peak", weight: 0.27 },
      { src: "directory", text: "Application volume falls 64% after windows close", weight: 0.21 },
      { src: "news", text: "Two programmes cite preparation time as the blocker", weight: 0.17 },
    ],
    actions: ["Pre-scope against next quarter's windows", "Publish a rolling window calendar", "Set a 40-day scoping SLA"],
    trend: [30, 33, 36, 40, 44, 48, 52, 56, 59, 63, 66, 68],
  },
];

export const V11_KIND_META: Record<V11Kind, { label: string; color: string; blurb: string }> = {
  opportunity: { label: "Opportunity", color: "#22c55e", blurb: "Money to be made" },
  gap:         { label: "Gap",         color: "#f59e0b", blurb: "Something missing" },
  insight:     { label: "Insight",     color: "#38bdf8", blurb: "Pattern worth knowing" },
  risk:        { label: "Risk",        color: "#ef4444", blurb: "Loss to avoid" },
};

export function relStamp(isoStr: string) {
  const d = Date.now() - new Date(isoStr).getTime();
  const m = Math.round(d / 6e4);
  if (m < 60) return `${Math.max(1, m)}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.round(h / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.round(days / 30)}mo ago`;
}

export function stampTime(isoStr: string) {
  const d = new Date(isoStr);
  return `${d.toLocaleDateString(undefined, { day: "2-digit", month: "short" })} · ${d
    .toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", hour12: false })}`;
}
