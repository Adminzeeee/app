import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUp, Bookmark, Brain, Check, Coins, Cpu, Filter, Heart, Loader2, Play,
  Rss, Sparkles, Square, StickyNote, Trash2, Zap,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Panel, Tap, useSkin } from "./ui";
import { useCoins } from "./coins";
import { NOTES_SEED } from "./workspaceData";
import {
  ENGINE_FEATURES, ENGINE_MODES, SIGNAL_TAGS, V2_SOURCES, V2_STAGES,
} from "./workspaceV2Data";
import {
  FEED_CATEGORIES, KIND_GLYPH, relTime, useFeedStream,
  type FeedCategory, type FeedItem, type FeedKind,
} from "./feedData";

type View = "feed" | "saved" | "notes" | "engine";

const VIEWS: { k: View; label: string; icon: React.ReactNode }[] = [
  { k: "feed", label: "Findings", icon: <Rss className="h-2.5 w-2.5" /> },
  { k: "saved", label: "Saved", icon: <Bookmark className="h-2.5 w-2.5" /> },
  { k: "notes", label: "Notes", icon: <StickyNote className="h-2.5 w-2.5" /> },
  { k: "engine", label: "Engine", icon: <Brain className="h-2.5 w-2.5" /> },
];

type Sort = "latest" | "top" | "opportunity" | "risk" | "gap";
const SORTS: { k: Sort; label: string }[] = [
  { k: "latest", label: "Latest" },
  { k: "top", label: "Top" },
  { k: "opportunity", label: "Opportunities" },
  { k: "risk", label: "Risks" },
  { k: "gap", label: "Gaps" },
];

export function WorkspaceV6({
  theme, isLight, scope,
}: { theme: ThemeSpec; isLight: boolean; scope: string }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [view, setView] = useState<View>("feed");
  const [toast, setToast] = useState<string | null>(null);
  const say = useCallback((m: string) => {
    setToast(m);
    window.setTimeout(() => setToast((t) => (t === m ? null : t)), 1700);
  }, []);

  /* ---------------- feed ---------------- */
  const { items, pendingCount, reveal, bump } = useFeedStream();
  const [sort, setSort] = useState<Sort>("latest");
  const [cat, setCat] = useState<FeedCategory | null>(null);
  const [saved, setSaved] = useState<FeedItem[]>([]);
  const savedIds = useMemo(() => new Set(saved.map((x) => x.id)), [saved]);

  const feed = useMemo(() => {
    let out = items.slice();
    if (cat) out = out.filter((f) => f.category === cat);
    if (sort === "top") out = out.sort((a, b) => (b.reactions + b.watchers) - (a.reactions + a.watchers));
    else if (sort === "latest") out = out.sort((a, b) => b.createdAt - a.createdAt);
    else out = out.filter((f) => f.kind === sort).sort((a, b) => b.createdAt - a.createdAt);
    return out;
  }, [items, sort, cat]);

  const toggleSave = (f: FeedItem) => {
    setSaved((p) => (p.some((x) => x.id === f.id) ? p.filter((x) => x.id !== f.id) : [f, ...p]));
    say(savedIds.has(f.id) ? "Removed from saved" : "Saved");
  };

  /* ---------------- notes ---------------- */
  const [notes, setNotes] = useState(NOTES_SEED.map((n, i) => ({ id: "n" + i, ...n })));
  const [draft, setDraft] = useState("");
  const [tag, setTag] = useState(SIGNAL_TAGS[0]);

  /* ---------------- engine ---------------- */
  const { balance, spend } = useCoins();
  const [sources, setSources] = useState<string[]>(V2_SOURCES.slice(0, 8).map((x) => x.k));
  const [mode, setMode] = useState(ENGINE_MODES[1].k);
  const [feats, setFeats] = useState<string[]>(["chain", "calib"]);
  const modeDef = ENGINE_MODES.find((m) => m.k === mode)!;
  const stageCount = modeDef.stages;
  const secPerStage = 0.4 * modeDef.mult;
  const srcCost = V2_SOURCES.filter((x) => sources.includes(x.k)).reduce((a, b) => a + b.cost, 0);
  const featCost = ENGINE_FEATURES.filter((f) => feats.includes(f.k)).reduce((a, b) => a + b.cost, 0);
  const cost = Math.max(1, Math.round((srcCost + featCost) * modeDef.mult));

  const [running, setRunning] = useState(false);
  const [stage, setStage] = useState(0);
  const [trace, setTrace] = useState<string[]>([]);
  const timers = useRef<number[]>([]);
  const clearTimers = () => { timers.current.forEach(window.clearTimeout); timers.current = []; };
  useEffect(() => clearTimers, []);

  const run = useCallback(() => {
    if (running) { clearTimers(); setRunning(false); say("Run aborted"); return; }
    if (!sources.length) { say("Select at least one source"); return; }
    if (!spend(`Engine run · ${modeDef.label}`, cost)) { say(`Not enough coins — need ${cost}`); return; }
    clearTimers(); setRunning(true); setStage(0); setTrace([]);
    const lines = V2_STAGES.slice(0, stageCount);
    lines.forEach((line, i) => {
      timers.current.push(window.setTimeout(() => {
        setStage(i + 1);
        setTrace((t) => [...t, line]);
        if (i === lines.length - 1) { setRunning(false); say(`Run complete · ${cost} coins`); }
      }, secPerStage * 1000 * (i + 1)));
    });
  }, [running, sources.length, spend, cost, modeDef.label, stageCount, secPerStage, say]);

  const toggle = <T,>(arr: T[], v: T, set: (x: T[]) => void) =>
    set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const chip = (active: boolean) =>
    `rounded-full px-1.5 py-[3px] text-[8px] font-bold transition ${active ? s.solid : `${s.chip} ${s.muted}`}`;

  return (
    <div className="relative">
      <div className="-mx-0.5 mb-1.5 flex gap-1 overflow-x-auto pb-0.5" style={{ scrollbarWidth: "none" }}>
        {VIEWS.map((v) => (
          <Tap key={v.k} color={g} effect="squish" onClick={() => setView(v.k)}
            className={`flex shrink-0 items-center gap-1 rounded-md px-1.5 py-[4px] text-[8.5px] font-bold ${view === v.k ? s.solid : `${s.chip} ${s.muted}`}`}>
            {v.icon}{v.label}
            {v.k === "saved" && saved.length > 0 && <span className="tabular-nums opacity-70">{saved.length}</span>}
          </Tap>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={view} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.16 }} className="space-y-1.5">

          {/* ================= FEED ================= */}
          {view === "feed" && (
            <>
              <div className="flex flex-wrap items-center gap-1">
                {SORTS.map((o) => (
                  <Tap key={o.k} color={g} effect="squish" onClick={() => setSort(o.k)} className={chip(sort === o.k)}>
                    {o.label}
                  </Tap>
                ))}
              </div>
              <div className="-mx-0.5 flex gap-1 overflow-x-auto pb-0.5" style={{ scrollbarWidth: "none" }}>
                <Tap color={g} effect="squish" onClick={() => setCat(null)} className={chip(!cat)}>
                  <Filter className="mr-1 inline h-2 w-2" />All
                </Tap>
                {FEED_CATEGORIES.map((c) => (
                  <Tap key={c} color={g} effect="squish" onClick={() => setCat(c)} className={`shrink-0 ${chip(cat === c)}`}>{c}</Tap>
                ))}
              </div>

              <div className="relative">
                <AnimatePresence>
                  {pendingCount > 0 && (
                    <motion.button
                      initial={{ opacity: 0, y: -8, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8, scale: 0.9 }}
                      onClick={reveal}
                      className="absolute left-1/2 top-0 z-10 -translate-x-1/2 flex items-center gap-1 rounded-full px-2.5 py-1 text-[8.5px] font-black shadow-lg"
                      style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
                      <ArrowUp className="h-2.5 w-2.5" />{pendingCount} new
                    </motion.button>
                  )}
                </AnimatePresence>

                <div className="space-y-1 pt-1">
                  <AnimatePresence initial={false}>
                    {feed.map((f) => {
                      const k = KIND_GLYPH[f.kind];
                      const isSaved = savedIds.has(f.id);
                      return (
                        <motion.div
                          key={f.id}
                          layout
                          initial={{ opacity: 0, y: -10, scale: 0.98 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ type: "spring", stiffness: 380, damping: 32 }}
                          className={`rounded-md border px-1.5 py-1.5 ${s.card}`}
                        >
                          <div className="flex items-start gap-1.5">
                            <span
                              className="mt-[1px] grid h-4 w-4 shrink-0 place-items-center rounded-full text-[9px] font-black"
                              style={{ background: alpha(k.color, 0.18), color: k.color }}
                              title={k.word}
                            >
                              {k.glyph}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="text-[9.5px] font-bold leading-snug">{f.heading}</div>
                              <div className={`mt-[1px] text-[8px] leading-snug ${s.muted}`}>{f.detail}</div>
                              <div className={`mt-1 flex items-center gap-2 text-[7px] ${s.muted}`}>
                                <span>{f.region}</span>
                                <span>·</span>
                                <span>{relTime(f.createdAt)}</span>
                                <button onClick={() => bump(f.id, "reactions")} className="ml-auto flex items-center gap-[2px]">
                                  <Heart className="h-2.5 w-2.5" />{f.reactions}
                                </button>
                                <span className="flex items-center gap-[2px] opacity-80">
                                  {f.watchers} watching
                                </span>
                                <Tap color={g} effect="squish" onClick={() => toggleSave(f)}
                                  className="rounded-full p-[3px]" style={isSaved ? { background: alpha(g, 0.18), color: g } : undefined}>
                                  <Bookmark className="h-2.5 w-2.5" fill={isSaved ? "currentColor" : "none"} />
                                </Tap>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                  {!feed.length && (
                    <div className={`rounded-md border p-3 text-center text-[9px] ${s.card} ${s.muted}`}>Nothing here yet.</div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* ================= SAVED ================= */}
          {view === "saved" && (
            <>
              {saved.map((f) => {
                const k = KIND_GLYPH[f.kind];
                return (
                  <div key={f.id} className={`rounded-md border px-1.5 py-1 ${s.card}`}>
                    <div className="flex items-center gap-1.5">
                      <span className="grid h-4 w-4 shrink-0 place-items-center rounded-full text-[9px] font-black"
                        style={{ background: alpha(k.color, 0.18), color: k.color }}>{k.glyph}</span>
                      <span className="min-w-0 flex-1 truncate text-[9.5px] font-bold">{f.heading}</span>
                      <button onClick={() => setSaved((p) => p.filter((x) => x.id !== f.id))} className={`shrink-0 ${s.muted}`}>
                        <Trash2 className="h-2.5 w-2.5" />
                      </button>
                    </div>
                    <div className={`mt-[1px] truncate text-[7.5px] ${s.muted}`}>{f.region} · {relTime(f.createdAt)}</div>
                  </div>
                );
              })}
              {!saved.length && (
                <div className={`rounded-md border p-3 text-center text-[9px] ${s.card} ${s.muted}`}>
                  Nothing saved yet — bookmark items from Findings.
                </div>
              )}
            </>
          )}

          {/* ================= NOTES ================= */}
          {view === "notes" && (
            <>
              <div className={`rounded-md border p-1.5 ${s.card}`}>
                <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={2}
                  placeholder="Capture a field note, rumour, or observation…"
                  className="w-full resize-none bg-transparent text-[9px] outline-none placeholder:opacity-40" />
                <div className="flex items-center gap-1">
                  <select value={tag} onChange={(e) => setTag(e.target.value)}
                    className={`rounded px-1 py-[3px] text-[8px] font-bold outline-none ${s.chip}`}>
                    {SIGNAL_TAGS.map((t) => <option key={t} className="bg-slate-900 text-white">{t}</option>)}
                  </select>
                  <Tap color={g} effect="glow"
                    onClick={() => {
                      if (!draft.trim()) return;
                      setNotes((p) => [{ id: "n" + Date.now(), t: draft.trim(), when: "just now", tag }, ...p]);
                      setDraft(""); say("Note added");
                    }}
                    className="ml-auto rounded px-2 py-[4px] text-[8.5px] font-black"
                    style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>Add</Tap>
                </div>
              </div>
              {notes.map((n) => (
                <motion.div key={n.id} initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }}
                  className={`rounded-md border px-1.5 py-1 ${s.card}`}>
                  <div className="flex items-center gap-1">
                    <StickyNote className="h-2.5 w-2.5 shrink-0" style={{ color: theme.markerCore.landmark }} />
                    <span className="rounded-full px-1 text-[7px] font-bold" style={{ background: alpha(g, 0.14), color: g }}>{n.tag}</span>
                    <span className={`ml-auto shrink-0 text-[7px] ${s.muted}`}>{n.when}</span>
                  </div>
                  <p className="mt-[2px] text-[9px] leading-snug">{n.t}</p>
                </motion.div>
              ))}
            </>
          )}

          {/* ================= ENGINE ================= */}
          {view === "engine" && (
            <>
              <div className={`rounded-md border p-1.5 ${s.card}`} style={{ background: alpha(g, 0.05) }}>
                <div className="flex items-center gap-1.5">
                  <div className="grid h-6 w-6 place-items-center rounded-md" style={{ background: alpha(g, 0.18) }}>
                    <Cpu className="h-3 w-3" style={{ color: g }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[10px] font-extrabold">Insight engine</div>
                    <div className={`text-[8px] ${s.muted}`}>{sources.length} sources · {feats.length} modules · {scope}</div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-[11px] font-black tabular-nums" style={{ color: g }}>
                      <Coins className="h-2.5 w-2.5" />{cost}
                    </div>
                    <div className={`text-[7.5px] ${s.muted}`}>bal {balance}</div>
                  </div>
                </div>

                <Tap color={g} effect="glow" onClick={run}
                  className="mt-1.5 flex w-full items-center justify-center gap-1.5 rounded-md py-[7px] text-[10px] font-black"
                  style={{ background: running ? alpha("#ef4444", 0.9) : g, color: isLight ? "#fff" : "#04121f" }}>
                  {running ? <><Square className="h-3 w-3" />Abort · stage {stage}/{stageCount}</> : <><Play className="h-3 w-3" />Run engine · {cost} coins</>}
                </Tap>

                {(running || trace.length > 0) && (
                  <div className="mt-1.5">
                    <div className="h-[3px] w-full overflow-hidden rounded-full" style={{ background: alpha(g, 0.15) }}>
                      <motion.div className="h-full rounded-full" style={{ background: g }}
                        animate={{ width: `${(stage / stageCount) * 100}%` }} transition={{ duration: 0.3 }} />
                    </div>
                    <div className="mt-1 max-h-[104px] space-y-[2px] overflow-y-auto rounded bg-current/[0.03] p-1 font-mono text-[7.5px]">
                      {trace.map((t, i) => (
                        <motion.div key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} className="flex gap-1">
                          <span style={{ color: g }}>▸</span><span className="min-w-0 flex-1 truncate">{t}</span>
                        </motion.div>
                      ))}
                      {running && (
                        <div className="flex items-center gap-1 opacity-70">
                          <Loader2 className="h-2.5 w-2.5 animate-spin" style={{ color: g }} /><span>working…</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <Panel title="Depth" muted={s.muted} className={s.card}>
                <div className="grid grid-cols-2 gap-1">
                  {ENGINE_MODES.map((m) => (
                    <Tap key={m.k} color={g} effect="squish" onClick={() => setMode(m.k)}
                      className={`rounded-md border px-1.5 py-1 ${s.card}`}
                      style={mode === m.k ? { borderColor: g, background: alpha(g, 0.1) } : undefined}>
                      <div className="text-[9px] font-bold">{m.label}</div>
                      <div className={`truncate text-[7.5px] ${s.muted}`}>{m.blurb}</div>
                    </Tap>
                  ))}
                </div>
              </Panel>

              <Panel title={`Data sources · ${sources.length}/${V2_SOURCES.length}`} muted={s.muted} className={s.card}
                right={
                  <button onClick={() => setSources(sources.length === V2_SOURCES.length ? [] : V2_SOURCES.map((x) => x.k))}
                    className="text-[8px] font-bold" style={{ color: g }}>
                    {sources.length === V2_SOURCES.length ? "none" : "all"}
                  </button>
                }>
                <div className="space-y-[3px]">
                  {V2_SOURCES.map((src) => {
                    const on = sources.includes(src.k);
                    return (
                      <Tap key={src.k} color={g} effect="squish" onClick={() => toggle(sources, src.k, setSources)}
                        className={`flex w-full items-center gap-1.5 rounded border px-1.5 py-[4px] ${s.card}`}
                        style={on ? { borderColor: alpha(g, 0.5), background: alpha(g, 0.07) } : { opacity: 0.55 }}>
                        <span className="grid h-3 w-3 shrink-0 place-items-center rounded-[3px]"
                          style={{ background: on ? g : "transparent", border: `1px solid ${on ? g : "currentColor"}` }}>
                          {on && <Check className="h-2 w-2" style={{ color: isLight ? "#fff" : "#04121f" }} />}
                        </span>
                        <span className="min-w-0 flex-1 truncate text-[9px] font-bold">{src.label}</span>
                        <span className="shrink-0 text-[8px] font-black tabular-nums" style={{ color: g }}>{src.cost}c</span>
                      </Tap>
                    );
                  })}
                </div>
              </Panel>

              <Panel title={`Engine modules · ${feats.length}`} muted={s.muted} className={s.card}>
                <div className="grid grid-cols-2 gap-1">
                  {ENGINE_FEATURES.map((f) => {
                    const on = feats.includes(f.k);
                    return (
                      <Tap key={f.k} color={g} effect="squish" onClick={() => toggle(feats, f.k, setFeats)}
                        className={`rounded border px-1.5 py-1 ${s.card}`}
                        style={on ? { borderColor: g, background: alpha(g, 0.08) } : { opacity: 0.6 }}>
                        <div className="flex items-center gap-1">
                          <Zap className="h-2.5 w-2.5 shrink-0" style={{ color: on ? g : "currentColor" }} />
                          <span className="truncate text-[8.5px] font-bold">{f.label}</span>
                          <span className="ml-auto text-[7.5px] font-black" style={{ color: g }}>{f.cost}c</span>
                        </div>
                      </Tap>
                    );
                  })}
                </div>
              </Panel>
            </>
          )}
        </motion.div>
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-20 left-1/2 z-[80] -translate-x-1/2 rounded-full px-2.5 py-1 text-[10px] font-bold text-black"
            style={{ background: g, boxShadow: `0 8px 24px -6px ${g}` }}>
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
