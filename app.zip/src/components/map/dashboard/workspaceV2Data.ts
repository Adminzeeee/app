/* Workspace v2 — richer engine, tables, scenarios, ops data. */

export interface SourceMeta {
  k: string;
  label: string;
  records: number;
  fresh: string;
  health: number;      // 0-100 connector health
  latency: number;     // ms
  cost: number;        // coins per scan
  tier: "core" | "premium" | "beta";
  trend: number[];
}

export const V2_SOURCES: SourceMeta[] = [
  { k: "news", label: "News & press", records: 12_840, fresh: "4m", health: 96, latency: 210, cost: 4, tier: "core", trend: [4, 6, 5, 8, 7, 9, 11, 10] },
  { k: "surveys", label: "Survey waves", records: 15_492, fresh: "1h", health: 99, latency: 140, cost: 6, tier: "core", trend: [9, 10, 12, 11, 14, 15, 15, 16] },
  { k: "directory", label: "Directory graph", records: 46_867, fresh: "9m", health: 94, latency: 320, cost: 5, tier: "core", trend: [30, 33, 36, 38, 41, 43, 45, 47] },
  { k: "weather", label: "Weather API", records: 88_120, fresh: "2m", health: 91, latency: 95, cost: 3, tier: "core", trend: [70, 74, 78, 80, 82, 85, 86, 88] },
  { k: "calendar", label: "Calendar & grants", records: 1_204, fresh: "18m", health: 88, latency: 180, cost: 2, tier: "core", trend: [0.8, 0.9, 1, 1, 1.1, 1.1, 1.2, 1.2] },
  { k: "events", label: "Public events", records: 3_318, fresh: "31m", health: 84, latency: 260, cost: 2, tier: "core", trend: [2, 2.2, 2.5, 2.6, 2.9, 3, 3.2, 3.3] },
  { k: "notes", label: "Custom notes", records: 214, fresh: "just now", health: 100, latency: 20, cost: 1, tier: "core", trend: [0.1, 0.12, 0.14, 0.15, 0.17, 0.19, 0.2, 0.21] },
  { k: "trade", label: "Trade & customs", records: 22_006, fresh: "1h", health: 79, latency: 640, cost: 7, tier: "premium", trend: [14, 15, 17, 18, 19, 20, 21, 22] },
  { k: "sensors", label: "Sensor mesh", records: 190_442, fresh: "12s", health: 97, latency: 60, cost: 9, tier: "premium", trend: [120, 135, 148, 158, 168, 178, 185, 190] },
  { k: "social", label: "Social listening", records: 61_775, fresh: "7m", health: 86, latency: 410, cost: 8, tier: "premium", trend: [40, 44, 48, 51, 55, 57, 59, 62] },
  { k: "satellite", label: "Satellite imagery", records: 9_402, fresh: "3h", health: 72, latency: 1_240, cost: 12, tier: "beta", trend: [5, 5.5, 6, 6.8, 7.4, 8.1, 8.9, 9.4] },
  { k: "mobility", label: "Mobility traces", records: 128_910, fresh: "5m", health: 81, latency: 380, cost: 11, tier: "beta", trend: [80, 89, 96, 104, 112, 118, 124, 129] },
];

export const ENGINE_MODES = [
  { k: "sweep", label: "Fast sweep", mult: 0.6, stages: 7, blurb: "Shallow pass, headline signals only" },
  { k: "standard", label: "Standard", mult: 1, stages: 11, blurb: "Balanced depth and runtime" },
  { k: "deep", label: "Deep analysis", mult: 1.8, stages: 15, blurb: "Full entity resolution + causal tests" },
  { k: "exhaustive", label: "Exhaustive", mult: 2.8, stages: 19, blurb: "Everything, including counterfactuals" },
];

export const V2_STAGES = [
  "Handshake · authenticating source connectors",
  "Streaming records · parallel fetch workers",
  "Schema normalisation · 412 field mappings",
  "Entity resolution · fuzzy match + dedupe",
  "Geo-join · district & ward boundaries",
  "Temporal alignment · resampling to weekly grid",
  "Feature synthesis · 1,884 derived features",
  "Baseline modelling · 24-month seasonal fit",
  "Anomaly detection · robust z-scores",
  "Cross-source correlation · weather × supply",
  "Causal screening · Granger + placebo tests",
  "Opportunity clustering · HDBSCAN",
  "Risk register stress test",
  "Counterfactual sweep · 400 draws",
  "Impact × effort scoring",
  "Confidence calibration · isotonic",
  "Evidence chain assembly",
  "Narrative drafting · executive tone",
  "Final ranking & handoff",
];

export interface AlertRule {
  id: string;
  name: string;
  when: string;
  channel: string;
  active: boolean;
  fired: number;
}

export const ALERT_RULES: AlertRule[] = [
  { id: "a1", name: "Critical risk appears", when: "severity = critical AND score > 80", channel: "Push + email", active: true, fired: 4 },
  { id: "a2", name: "Water sentiment drop", when: "surveys.water_sentiment falls 2 waves", channel: "Push", active: true, fired: 9 },
  { id: "a3", name: "Grant window < 30 days", when: "calendar.grant_deadline < 30d", channel: "Email digest", active: false, fired: 1 },
  { id: "a4", name: "New cold-chain listing", when: "directory.category = cold-chain", channel: "In-app", active: true, fired: 0 },
];

export interface PipelineItem {
  id: string;
  title: string;
  owner: string;
  stage: "backlog" | "scoping" | "active" | "done";
  due: string;
  value: string;
}

export const PIPELINE: PipelineItem[] = [
  { id: "p1", title: "Scope 400-seat digital academy", owner: "T. Moeng", stage: "scoping", due: "12 Sep", value: "P41.2M" },
  { id: "p2", title: "Shortlist 40 priority boreholes", owner: "K. Dube", stage: "active", due: "28 Aug", value: "P18.4M" },
  { id: "p3", title: "Cold-chain site survey · Ghanzi", owner: "L. Serema", stage: "backlog", due: "04 Oct", value: "P26.8M" },
  { id: "p4", title: "Outage transparency dashboard", owner: "Ops desk", stage: "active", due: "19 Aug", value: "P31M exp." },
  { id: "p5", title: "Reefer pre-booking · A3", owner: "M. Kgosi", stage: "done", due: "02 Aug", value: "P12.6M" },
  { id: "p6", title: "Enumerator recruitment · Central", owner: "Field team", stage: "scoping", due: "15 Sep", value: "9 wards" },
  { id: "p7", title: "Beehive fence deployment", owner: "Chobe unit", stage: "backlog", due: "20 Nov", value: "P6.2M" },
];

export const TIMELINE = [
  { t: "Sensor mesh flagged pump downtime spike", when: "12m ago", kind: "risk", src: "sensors" },
  { t: "Survey wave 14 ingested · 2,104 responses", when: "1h ago", kind: "data", src: "surveys" },
  { t: "Engine run #482 completed · 12 findings", when: "3h ago", kind: "engine", src: "engine" },
  { t: "Report shared with district ops", when: "5h ago", kind: "report", src: "reports" },
  { t: "New directory registrations +318", when: "9h ago", kind: "data", src: "directory" },
  { t: "Grant deadline moved forward 6 days", when: "1d ago", kind: "risk", src: "calendar" },
  { t: "Scenario 'Aggressive' saved by T. Moeng", when: "1d ago", kind: "sim", src: "sim" },
  { t: "Satellite tile refresh · Ghanzi", when: "2d ago", kind: "data", src: "satellite" },
];

export const GEO_HEAT = [
  { region: "Kgalagadi", risk: 91, opp: 54, gap: 78, pop: "51k" },
  { region: "North-East", risk: 38, opp: 88, gap: 42, pop: "232k" },
  { region: "North-West", risk: 57, opp: 71, gap: 66, pop: "175k" },
  { region: "South-East", risk: 62, opp: 64, gap: 40, pop: "421k" },
  { region: "Ghanzi", risk: 44, opp: 76, gap: 58, pop: "48k" },
  { region: "Chobe", risk: 66, opp: 49, gap: 35, pop: "28k" },
  { region: "Central", risk: 41, opp: 58, gap: 63, pop: "612k" },
  { region: "Kweneng", risk: 36, opp: 61, gap: 47, pop: "398k" },
  { region: "Southern", risk: 39, opp: 55, gap: 44, pop: "212k" },
];

export const CORRELATIONS = [
  { a: "Rainfall deficit", b: "Water complaints", r: 0.82 },
  { a: "Diesel price", b: "Freight margin", r: -0.74 },
  { a: "Directory growth", b: "Youth employment", r: 0.61 },
  { a: "Flood pulse timing", b: "Lodge occupancy", r: 0.69 },
  { a: "Grant windows", b: "Project starts", r: 0.53 },
  { a: "Sensor downtime", b: "Sentiment drop", r: -0.78 },
];

export const REPORT_SECTIONS = [
  "Executive summary", "Method & sources", "Findings table", "Evidence chains",
  "Scenario outcomes", "Risk register", "Recommended actions", "Appendix · raw metrics",
];

export const REPORT_TEMPLATES = [
  { k: "exec", label: "Executive brief", pages: 3, sections: ["Executive summary", "Findings table", "Recommended actions"] },
  { k: "board", label: "Board pack", pages: 12, sections: REPORT_SECTIONS },
  { k: "funder", label: "Funder submission", pages: 8, sections: ["Executive summary", "Method & sources", "Evidence chains", "Scenario outcomes", "Recommended actions"] },
  { k: "ops", label: "Field ops sheet", pages: 2, sections: ["Findings table", "Recommended actions"] },
];

export const SIM_PRESETS = [
  { k: "base", label: "Base case", mods: { budget: 18, speed: 100, partners: 4, adoption: 55, risk: 45 } },
  { k: "aggressive", label: "Aggressive", mods: { budget: 42, speed: 165, partners: 9, adoption: 78, risk: 80 } },
  { k: "lean", label: "Lean pilot", mods: { budget: 6, speed: 80, partners: 2, adoption: 34, risk: 25 } },
  { k: "drought", label: "Drought shock", mods: { budget: 22, speed: 70, partners: 5, adoption: 40, risk: 90 } },
  { k: "boom", label: "Tourism boom", mods: { budget: 30, speed: 140, partners: 7, adoption: 84, risk: 55 } },
  { k: "austerity", label: "Austerity", mods: { budget: 8, speed: 60, partners: 3, adoption: 38, risk: 30 } },
];

export const SIGNAL_TAGS = ["Education", "Water", "Energy", "Logistics", "Tourism", "Health", "Housing", "Digital", "Agriculture"];

export const ENGINE_FEATURES = [
  { k: "causal", label: "Causal screening", blurb: "Granger + placebo tests on every candidate", cost: 6 },
  { k: "counter", label: "Counterfactual sweep", blurb: "400 synthetic control draws", cost: 8 },
  { k: "calib", label: "Confidence calibration", blurb: "Isotonic recalibration on backtests", cost: 4 },
  { k: "chain", label: "Evidence chains", blurb: "Trace every claim to a source record", cost: 3 },
  { k: "narr", label: "Narrative drafting", blurb: "Executive-tone written summary", cost: 5 },
  { k: "geo", label: "Geo decomposition", blurb: "Ward-level attribution of each signal", cost: 7 },
  { k: "peer", label: "Peer benchmarking", blurb: "Compare against 6 SADC baselines", cost: 6 },
  { k: "watch", label: "Continuous watch", blurb: "Re-run automatically when sources move", cost: 10 },
  { k: "anom", label: "Anomaly amplifier", blurb: "Boost weak but rare signals", cost: 4 },
  { k: "dedupe", label: "Entity resolution+", blurb: "Cross-source identity graph", cost: 5 },
  { k: "cost", label: "Cost-benefit modelling", blurb: "Attach P-value ranges to each action", cost: 7 },
  { k: "bias", label: "Bias audit", blurb: "Coverage-gap correction on survey weights", cost: 4 },
];
