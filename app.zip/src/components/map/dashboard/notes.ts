/* User-written signals (notes) — local, persisted. */

import { useCallback, useEffect, useState } from "react";

export interface Note {
  id: string;
  text: string;
  tag: string;
  when: number;
  pinned: boolean;
}

const KEY = "bw.signals.notes.v1";

function read(): Note[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Note[];
  } catch {
    return [];
  }
}

function write(n: Note[]) {
  try { window.localStorage.setItem(KEY, JSON.stringify(n)); } catch { /* ignore */ }
}

const subs = new Set<(n: Note[]) => void>();
let cache: Note[] | null = null;

function all() {
  if (cache == null) cache = read();
  return cache;
}
function commit(n: Note[]) {
  cache = n;
  write(n);
  subs.forEach((f) => f(n));
}

export const NOTE_TAGS = ["Idea", "Watch", "Question", "Action", "Contact"];

export function useNotes() {
  const [notes, setNotes] = useState<Note[]>([]);
  useEffect(() => {
    setNotes(all());
    subs.add(setNotes);
    return () => { subs.delete(setNotes); };
  }, []);

  const add = useCallback((text: string, tag: string) => {
    if (!text.trim()) return;
    commit([{ id: `n${Date.now()}`, text: text.trim(), tag, when: Date.now(), pinned: false }, ...all()]);
  }, []);
  const remove = useCallback((id: string) => commit(all().filter((n) => n.id !== id)), []);
  const pin = useCallback((id: string) =>
    commit(all().map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n))), []);

  return { notes, add, remove, pin };
}
