import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Check, Coins, Flame, Sparkles } from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { useSkin, Tap } from "./ui";
import { useCoins } from "./coins";
import { DAILY, POOL, loadSay, saveSay, type SayState } from "./sayData";

/** v2 — rich daily survey: picture cards, mood faces, sliders and scenarios. */
export function SayV2({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const { balance, earn } = useCoins();
  const [state, setState] = useState<SayState>(loadSay);
  const [picked, setPicked] = useState<string | null>(null);
  const [slide, setSlide] = useState(50);
  const [burst, setBurst] = useState(0);

  useEffect(() => { saveSay(state); }, [state]);

  const done = state.answered >= DAILY;
  const q = POOL[(new Date().getDate() + state.answered) % POOL.length];
  const kind = q.kind ?? "choice";

  const commit = (label: string) => {
    if (done || picked) return;
    setPicked(label);
    setBurst((b) => b + 1);
    earn("Daily question answered", 1);
    window.setTimeout(() => {
      setPicked(null);
      setSlide(50);
      setState((p) => {
        const answered = p.answered + 1;
        return { ...p, answered, streak: answered === DAILY ? p.streak + 1 : p.streak };
      });
    }, 420);
  };

  return (
    <div className="space-y-2">
      {/* header */}
      <div className="relative overflow-hidden rounded-2xl border p-3" style={{ borderColor: alpha(g, 0.18), background: alpha(g, 0.04) }}>
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">
            <div className="text-[14px] font-extrabold leading-tight" style={{ fontFamily: "'Sora', sans-serif" }}>
              Have your say
            </div>
            <div className={`text-[9px] ${s.muted}`}>{DAILY} questions a day · 1 coin each</div>
          </div>
          <div className="shrink-0 text-right">
            <div className="flex items-center justify-end gap-1 text-[12px] font-black" style={{ color: g }}>
              <Flame className="h-3.5 w-3.5" />{state.streak}d
            </div>
            <div className={`flex items-center justify-end gap-1 text-[9px] ${s.muted}`}>
              <Coins className="h-3 w-3" />{balance.toLocaleString()}
            </div>
          </div>
        </div>

        <div className="mt-2 flex gap-[3px]">
          {Array.from({ length: DAILY }).map((_, i) => (
            <motion.div key={i} className="h-[5px] flex-1 rounded-full"
              animate={{ background: i < state.answered ? g : alpha(g, 0.14) }} />
          ))}
        </div>

        {/* coin burst */}
        <AnimatePresence>
          {burst > 0 && picked && (
            <motion.div
              key={burst}
              initial={{ opacity: 0, y: 8, scale: 0.7 }}
              animate={{ opacity: 1, y: -10, scale: 1 }}
              exit={{ opacity: 0, y: -22 }}
              className="pointer-events-none absolute right-3 top-8 flex items-center gap-1 text-[11px] font-black"
              style={{ color: g }}
            >
              <Sparkles className="h-3 w-3" /> +1
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence mode="wait">
        {!done ? (
          <motion.div
            key={state.answered}
            initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden rounded-2xl border"
            style={{ borderColor: alpha(g, 0.16) }}
          >
            {/* artwork */}
            {kind === "picture" && q.art && (
              <div className="relative h-[74px] w-full overflow-hidden"
                style={{ background: `linear-gradient(135deg, ${q.art[0]}, ${q.art[1]})` }}>
                <motion.div
                  className="absolute inset-0 opacity-30"
                  style={{ background: "radial-gradient(circle at 30% 40%, #fff, transparent 60%)" }}
                  animate={{ x: [-20, 20, -20] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                />
                <motion.div
                  className="absolute bottom-2 left-3 text-[34px] leading-none"
                  animate={{ y: [0, -4, 0], rotate: [0, 3, 0] }}
                  transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
                >
                  {q.glyph}
                </motion.div>
              </div>
            )}

            <div className="p-3">
              <div className={`text-[8px] font-black uppercase tracking-[0.2em] ${s.muted}`}>
                Question {state.answered + 1} of {DAILY} · {kind}
              </div>

              {kind === "scenario" && q.scene && (
                <div className="mt-1.5 rounded-xl px-2.5 py-2 text-[10px] italic leading-snug"
                  style={{ background: alpha(g, 0.07) }}>
                  {q.scene}
                </div>
              )}

              <div className="mt-1.5 text-[14px] font-bold leading-snug" style={{ fontFamily: "'Sora', sans-serif" }}>
                {q.q}
              </div>

              {/* mood faces */}
              {kind === "mood" && q.moods && (
                <div className="mt-3 flex items-end justify-between">
                  {q.moods.map((m, i) => {
                    const label = q.options[i] ?? m;
                    const on = picked === label;
                    return (
                      <motion.button
                        key={m} onClick={() => commit(label)} whileTap={{ scale: 0.85 }}
                        whileHover={{ scale: 1.12, y: -3 }}
                        className="grid place-items-center rounded-2xl px-2 py-1.5"
                        style={on ? { background: alpha(g, 0.18) } : undefined}
                      >
                        <span className="text-[26px] leading-none">{m}</span>
                        <span className={`mt-1 text-[7px] font-bold ${on ? "" : s.muted}`} style={on ? { color: g } : undefined}>
                          {label}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>
              )}

              {/* slider */}
              {kind === "slider" && (
                <div className="mt-3">
                  <div className="flex items-baseline justify-between">
                    <span className={`text-[7.5px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{q.scale?.[0]}</span>
                    <motion.span key={slide} initial={{ scale: 1.25 }} animate={{ scale: 1 }}
                      className="text-[20px] font-black tabular-nums" style={{ color: g, fontFamily: "'Sora', sans-serif" }}>
                      {slide}{q.unit}
                    </motion.span>
                    <span className={`text-[7.5px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{q.scale?.[1]}</span>
                  </div>
                  <input
                    type="range" min={0} max={100} value={slide}
                    onChange={(e) => setSlide(Number(e.target.value))}
                    className="mt-2 h-1.5 w-full appearance-none rounded-full outline-none"
                    style={{ background: `linear-gradient(90deg, ${g} ${slide}%, ${alpha(g, 0.14)} ${slide}%)`, accentColor: g }}
                  />
                  <Tap color={g} effect="glow" onClick={() => commit(`${slide}${q.unit ?? ""}`)}
                    className="mt-3 w-full rounded-xl py-2 text-center text-[12px] font-black"
                    style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
                    Submit answer
                  </Tap>
                </div>
              )}

              {/* choice / picture / scenario options */}
              {(kind === "choice" || kind === "picture" || kind === "scenario") && (
                <div className="mt-2 grid gap-1.5">
                  {q.options.map((o) => (
                    <Tap key={o} color={g} effect="glow" onClick={() => commit(o)}
                      className="flex items-center gap-2 rounded-xl border px-3 py-2 text-[12px] font-semibold"
                      style={picked === o
                        ? { background: g, color: isLight ? "#fff" : "#04121f", borderColor: g }
                        : { borderColor: alpha(g, 0.18) }}>
                      {picked === o
                        ? <Check className="h-3.5 w-3.5" />
                        : <span className="h-2 w-2 rounded-full" style={{ background: alpha(g, 0.4) }} />}
                      {o}
                    </Tap>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div key="done" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="relative overflow-hidden rounded-2xl border p-4 text-center" style={{ borderColor: alpha(g, 0.3) }}>
            {Array.from({ length: 14 }).map((_, i) => (
              <motion.span key={i} className="absolute h-1.5 w-1.5 rounded-full"
                style={{ background: g, left: `${(i * 37) % 100}%`, top: 0 }}
                animate={{ y: [0, 120], opacity: [1, 0], rotate: 180 }}
                transition={{ duration: 2 + (i % 4) * 0.4, repeat: Infinity, delay: i * 0.15 }} />
            ))}
            <Check className="mx-auto h-7 w-7" style={{ color: g }} />
            <div className="mt-1.5 text-[14px] font-black" style={{ fontFamily: "'Sora', sans-serif" }}>
              All {DAILY} done — +{DAILY} coins
            </div>
            <div className={`text-[10px] ${s.muted}`}>Streak now {state.streak} days. Come back tomorrow.</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
