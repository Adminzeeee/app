import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  ArrowLeft, ArrowUpRight, BarChart3, ChevronDown, Eye, EyeOff, MapPin,
  Pencil, Plus, Search, SlidersHorizontal, Trash2, X,
} from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData, Place } from "../types";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Tap, useSkin } from "./ui";
import { BIZ_TYPES, LISTING_TYPES, MY_LISTINGS, PEOPLE_TYPES, groupsOf, type Cat, type MyListing } from "./exploreCats";

const DATA = raw as unknown as BotswanaData;

type Lens = "overview" | "people" | "business" | "listings" | "mine";
type MainTab = "overview" | "mine";

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}
const metric = (scope: string, salt: number, min: number, max: number) =>
  min + ((hash(scope + salt) % 1000) / 1000) * (max - min);

/** Scale the national category counts down to the selected place. */
function scaled(cats: Cat[], scope: string, salt: number) {
  const f = 0.06 + ((hash(scope + salt) % 1000) / 1000) * 0.9;
  return cats.map((c) => ({ ...c, n: Math.max(1, Math.round(c.n * f)) }));
}

const noscroll = "[&::-webkit-scrollbar]:hidden" as const;

/** Explore v6 — v1's counters-as-tabs, restyled: minimal tabs, swipeable category rails,
 *  unified card styling across every category surface, no "new today" noise. */
export function ExploreV6({
  theme, isLight, place, onSelectPlace,
}: {
  theme: ThemeSpec;
  isLight: boolean;
  place: Place | null;
  onSelectPlace?: (p: Place | null) => void;
}) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [tab, setTab] = useState<MainTab>("overview");
  const [lens, setLens] = useState<Lens>("overview");
  const [picker, setPicker] = useState(false);
  const [pq, setPq] = useState("");

  const scope = place?.name ?? "All Botswana";

  const people = useMemo(() => scaled(PEOPLE_TYPES, scope, 1), [scope]);
  const biz = useMemo(() => scaled(BIZ_TYPES, scope, 2), [scope]);
  const listings = useMemo(() => scaled(LISTING_TYPES, scope, 3), [scope]);

  const placeList = useMemo(() => {
    const all = DATA.places;
    if (!pq.trim()) return all.slice(0, 40);
    return all.filter((p) => p.name.toLowerCase().includes(pq.toLowerCase())).slice(0, 40);
  }, [pq]);

  const backToOverview = () => { setLens("overview"); setTab("overview"); };
  const goto = (l: Lens) => setLens(l);

  return (
    <div>
      {/* scope header */}
      <button onClick={() => setPicker((v) => !v)} className="flex w-full items-center gap-1.5 text-left">
        <MapPin className="h-3 w-3 shrink-0" style={{ color: g }} />
        <span className="min-w-0 truncate text-[16px] font-black leading-none">{scope}</span>
        <motion.span animate={{ rotate: picker ? 180 : 0 }} className="shrink-0 opacity-50">
          <ChevronDown className="h-3 w-3" />
        </motion.span>
        {place && (
          <span className="ml-auto shrink-0 rounded-full px-1.5 py-[1px] text-[6.5px] font-black uppercase tracking-[0.14em]"
            style={{ background: alpha(g, 0.12), color: g }}>
            {place.type}
          </span>
        )}
      </button>

      <AnimatePresence>
        {picker && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className={`mt-1.5 rounded-xl border p-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
              <div className="mb-1 flex items-center gap-1.5">
                <Search className="h-2.5 w-2.5 shrink-0 opacity-50" />
                <input value={pq} onChange={(e) => setPq(e.target.value)} autoFocus placeholder="Find a place"
                  className="min-w-0 flex-1 bg-transparent text-[9px] font-semibold outline-none placeholder:opacity-35" />
              </div>
              <button onClick={() => { onSelectPlace?.(null); setPicker(false); }}
                className="mb-[2px] block w-full rounded-md px-1.5 py-[4px] text-left text-[8.5px] font-black"
                style={!place ? { background: alpha(g, 0.14), color: g } : undefined}>
                All Botswana
              </button>
              <div className="max-h-[168px] overflow-y-auto">
                {placeList.map((p) => (
                  <button key={p.name} onClick={() => { onSelectPlace?.(p); setPicker(false); }}
                    className="flex w-full items-center gap-1 rounded-md px-1.5 py-[4px] text-left"
                    style={place?.name === p.name ? { background: alpha(g, 0.14) } : undefined}>
                    <span className="min-w-0 flex-1 truncate text-[8.5px] font-semibold">{p.name}</span>
                    <span className={`shrink-0 text-[6.5px] uppercase tracking-[0.14em] ${s.muted}`}>{p.type}</span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* minimal main tabs — thin single-line separator, no pills */}
      <div className="mt-2 flex" style={{ borderBottom: `1px solid ${alpha(g, 0.14)}` }}>
        {([{ k: "overview", label: "Overview" }, { k: "mine", label: "My listings" }] as { k: MainTab; label: string }[]).map((t) => {
          const on = tab === t.k;
          return (
            <button key={t.k}
              onClick={() => { setTab(t.k); setLens(t.k === "mine" ? "mine" : "overview"); }}
              className="relative flex-1 py-1.5 text-center text-[9.5px] font-black uppercase tracking-[0.1em]"
              style={{ color: on ? g : undefined, opacity: on ? 1 : 0.45 }}>
              {t.label}
              {on && (
                <motion.div layoutId="v6-underline" className="absolute inset-x-3 -bottom-px h-[1.5px] rounded-full"
                  style={{ background: g }} transition={{ type: "spring", stiffness: 500, damping: 40 }} />
              )}
            </button>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={lens} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.14 }} className="mt-2">
          {lens === "overview" && (
            <Overview scope={scope} g={g} s={s} people={people} biz={biz} listings={listings} goto={goto} />
          )}
          {lens === "people" && <Catalog cats={people} g={g} s={s} isLight={isLight} noun="people" title="Who is here" scope={scope} onBack={backToOverview} />}
          {lens === "business" && <Catalog cats={biz} g={g} s={s} isLight={isLight} noun="businesses" title="Business types" scope={scope} onBack={backToOverview} />}
          {lens === "listings" && <Catalog cats={listings} g={g} s={s} isLight={isLight} noun="listings" title="Most posted" scope={scope} onBack={backToOverview} />}
          {lens === "mine" && <Mine g={g} s={s} isLight={isLight} />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

/* ---------------- shared category card (used everywhere types+counts show up) ---------------- */

function CategoryCard({ c, g, s, max, onClick }: { c: Cat; g: string; s: ReturnType<typeof useSkin>; max: number; onClick?: () => void }) {
  return (
    <Tap color={g} effect="squish" onClick={onClick}
      className="relative min-w-[104px] shrink-0 snap-start overflow-hidden rounded-xl border px-2 py-1.5 text-left"
      style={{ borderColor: alpha(g, 0.13) }}>
      <motion.div layout className="absolute inset-y-0 left-0" style={{ width: `${(c.n / max) * 100}%`, background: alpha(g, 0.07) }} />
      <div className="relative truncate text-[9px] font-black leading-tight">{c.k}</div>
      <div className="relative mt-[2px] text-[13px] font-black leading-none tabular-nums" style={{ color: g }}>{c.n.toLocaleString()}</div>
      <div className={`relative mt-[2px] truncate text-[6px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{c.group}</div>
    </Tap>
  );
}

/** Horizontally swipeable rail of category cards, all sharing the same visual language. */
function CategoryRail({
  title, g, s, cats, onSeeAll,
}: { title: string; g: string; s: ReturnType<typeof useSkin>; cats: Cat[]; onSeeAll: () => void }) {
  const top = useMemo(() => [...cats].sort((a, b) => b.n - a.n).slice(0, 10), [cats]);
  const max = Math.max(...top.map((c) => c.n), 1);
  return (
    <div>
      <div className="mb-1 flex items-center">
        <span className="text-[6.5px] font-black uppercase tracking-[0.22em]" style={{ color: alpha(g, 0.8) }}>{title}</span>
        <button onClick={onSeeAll} className={`ml-auto flex items-center gap-[2px] text-[7px] font-bold ${s.muted}`}>
          See all <ArrowUpRight className="h-2 w-2" />
        </button>
      </div>
      <motion.div layout className={`-mx-0.5 flex snap-x snap-mandatory gap-1.5 overflow-x-auto px-0.5 pb-1 ${noscroll}`}
        style={{ scrollbarWidth: "none" }}>
        {top.map((c) => (
          <CategoryCard key={c.k} c={c} g={g} s={s} max={max} onClick={onSeeAll} />
        ))}
      </motion.div>
    </div>
  );
}

/* ---------------- overview: minimal, no charts, unified category rails ---------------- */

function Overview({
  scope, g, s, people, biz, listings, goto,
}: {
  scope: string; g: string; s: ReturnType<typeof useSkin>;
  people: Cat[]; biz: Cat[]; listings: Cat[];
  goto: (l: Lens) => void;
}) {
  const facts: [string, string][] = [
    ["Verified", `${Math.round(metric(scope, 7, 42, 92))}%`],
    ["Active now", Math.round(metric(scope, 5, 40, 980)).toLocaleString()],
    ["Replies < 1h", `${Math.round(metric(scope, 8, 38, 86))}%`],
  ];

  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-3 gap-1">
        {facts.map(([k, v]) => (
          <div key={k} className="rounded-lg px-1.5 py-1" style={{ background: alpha(g, 0.07) }}>
            <div className="truncate text-[10px] font-black leading-none tabular-nums" style={{ color: g }}>{v}</div>
            <div className={`mt-[3px] truncate text-[6px] font-bold uppercase tracking-[0.12em] ${s.muted}`}>{k}</div>
          </div>
        ))}
      </div>

      <CategoryRail title="Who is here" g={g} s={s} cats={people} onSeeAll={() => goto("people")} />
      <CategoryRail title="Business types" g={g} s={s} cats={biz} onSeeAll={() => goto("business")} />
      <CategoryRail title="Most posted" g={g} s={s} cats={listings} onSeeAll={() => goto("listings")} />
    </div>
  );
}

/* ---------------- catalog: types + how many (navigated to, not tabbed) ---------------- */

function Catalog({
  cats, g, s, isLight, noun, title, scope, onBack,
}: {
  cats: Cat[]; g: string; s: ReturnType<typeof useSkin>; isLight: boolean; noun: string; title: string; scope: string; onBack: () => void;
}) {
  const [q, setQ] = useState("");
  const [group, setGroup] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const groups = useMemo(() => groupsOf(cats), [cats]);

  const shown = useMemo(() => {
    let list = cats;
    if (group) list = list.filter((c) => c.group === group);
    if (q.trim()) list = list.filter((c) => (c.k + c.group).toLowerCase().includes(q.toLowerCase()));
    return [...list].sort((a, b) => b.n - a.n);
  }, [cats, group, q]);

  const max = Math.max(...shown.map((c) => c.n), 1);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-1.5">
        <Tap color={g} effect="squish" onClick={onBack} className="shrink-0 rounded-full p-1" style={{ background: alpha(g, 0.1) }}>
          <ArrowLeft className="h-3 w-3" style={{ color: g }} />
        </Tap>
        <span className="truncate text-[11px] font-black">{title}</span>
        <span className={`ml-auto shrink-0 text-[7px] ${s.muted}`}>{scope}</span>
      </div>

      <div className="flex items-center gap-1.5 rounded-lg px-2 py-1" style={{ background: alpha(g, 0.06) }}>
        <Search className="h-2.5 w-2.5 shrink-0 opacity-50" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${noun} in ${scope}`}
          className="min-w-0 flex-1 bg-transparent text-[9px] font-semibold outline-none placeholder:opacity-35" />
        {q && <button onClick={() => setQ("")} className="shrink-0 opacity-50"><X className="h-2.5 w-2.5" /></button>}
      </div>

      <div className="flex items-center gap-1">
        <SlidersHorizontal className="h-2.5 w-2.5 shrink-0 opacity-40" />
        <div className={`flex min-w-0 flex-1 gap-[3px] overflow-x-auto ${noscroll}`} style={{ scrollbarWidth: "none" }}>
          {groups.map((x) => (
            <button key={x} onClick={() => setGroup(group === x ? null : x)}
              className="shrink-0 rounded-full px-2 py-[2px] text-[7px] font-bold"
              style={group === x ? { background: alpha(g, 0.22), color: g } : { background: alpha(g, 0.06) }}>
              {x}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-1">
        {shown.map((c) => {
          const on = open === c.k;
          return (
            <Tap key={c.k} color={g} effect="squish" onClick={() => setOpen(on ? null : c.k)}
              className="relative overflow-hidden rounded-xl border px-2 py-1.5 text-left"
              style={{ borderColor: on ? alpha(g, 0.5) : alpha(g, 0.13), background: on ? alpha(g, 0.1) : "transparent" }}>
              <div className="absolute inset-y-0 left-0" style={{ width: `${(c.n / max) * 100}%`, background: alpha(g, 0.06) }} />
              <div className="relative truncate text-[9px] font-black leading-tight">{c.k}</div>
              <div className="relative mt-[2px] text-[13px] font-black leading-none tabular-nums" style={{ color: g }}>
                {c.n.toLocaleString()}
              </div>
              <div className={`relative mt-[2px] truncate text-[6px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{c.group}</div>
              <AnimatePresence>
                {on && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                    className="relative overflow-hidden">
                    <div className="mt-1 flex items-center gap-1">
                      <span className="rounded-md px-1.5 py-[3px] text-[7px] font-black"
                        style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
                        Browse
                      </span>
                      <span className="rounded-md px-1.5 py-[3px] text-[7px] font-bold" style={{ background: alpha(g, 0.12), color: g }}>
                        Alert me
                      </span>
                      <ArrowUpRight className="ml-auto h-2.5 w-2.5" style={{ color: g }} />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Tap>
          );
        })}
      </div>

      {shown.length === 0 && <div className={`py-4 text-center text-[8px] ${s.muted}`}>Nothing matches that filter.</div>}
    </div>
  );
}

/* ---------------- my listings — ported from ExploreV5's owner-console treatment ---------------- */

const STATUS: Record<string, string> = { live: "#22c55e", paused: "#f59e0b", draft: "#94a3b8", sold: "#38bdf8" };

function Mine({ g, s, isLight }: { g: string; s: ReturnType<typeof useSkin>; isLight: boolean }) {
  const [entries, setEntries] = useState<MyListing[]>(MY_LISTINGS);
  const totals = entries.reduce(
    (a, e) => ({ views: a.views + e.views, saves: a.saves + e.saves, msgs: a.msgs + e.msgs, live: a.live + (e.status === "live" ? 1 : 0) }),
    { views: 0, saves: 0, msgs: 0, live: 0 },
  );

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-3 gap-1.5">
        {([["Views", totals.views], ["Saves", totals.saves], ["Messages", totals.msgs]] as [string, number][]).map(([k, v]) => (
          <div key={k} className="rounded-2xl border p-2" style={{ borderColor: alpha(g, 0.14) }}>
            <BarChart3 className="h-3 w-3" style={{ color: g }} />
            <div className="mt-1 text-[13px] font-black leading-none tabular-nums">{v.toLocaleString()}</div>
            <div className={`mt-[2px] text-[7px] font-bold uppercase tracking-[0.16em] ${s.muted}`}>{k}</div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border" style={{ borderColor: alpha(g, 0.14) }}>
        {entries.length === 0 && (
          <div className={`px-2 py-4 text-center text-[9px] ${s.muted}`}>Nothing listed yet.</div>
        )}
        {entries.map((m) => (
          <div key={m.id} className="flex items-center gap-2 border-b px-2 py-[8px] last:border-0" style={{ borderColor: alpha(g, 0.08) }}>
            <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg" style={{ background: alpha(g, 0.12) }}>
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: STATUS[m.status], boxShadow: `0 0 6px ${STATUS[m.status]}` }} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-1">
                <span className="truncate text-[10.5px] font-bold">{m.title}</span>
                <span className="shrink-0 text-[8.5px] font-black" style={{ color: g }}>{m.price}</span>
              </span>
              <span className={`block truncate text-[7.5px] ${s.muted}`}>
                {m.type} · {m.views.toLocaleString()} views · {m.saves} saves · {m.msgs} msgs · {m.when}
              </span>
            </span>
            <Tap color={g} effect="squish"
              onClick={() => setEntries((p) => p.map((x) => x.id === m.id ? { ...x, status: x.status === "live" ? "paused" : "live" } : x))}
              className="shrink-0 rounded-lg p-1" style={{ background: alpha(g, 0.08) }}>
              {m.status === "live" ? <Eye className="h-3 w-3" style={{ color: g }} /> : <EyeOff className="h-3 w-3 opacity-60" />}
            </Tap>
            <Tap color={g} effect="squish" className="shrink-0 rounded-lg p-1" style={{ background: alpha(g, 0.08) }}>
              <Pencil className="h-3 w-3" style={{ color: g }} />
            </Tap>
            <Tap color={g} effect="squish" onClick={() => setEntries((p) => p.filter((x) => x.id !== m.id))}
              className="shrink-0 rounded-lg p-1" style={{ background: alpha(g, 0.08) }}>
              <Trash2 className="h-3 w-3 opacity-70" />
            </Tap>
          </div>
        ))}
      </div>

      <Tap color={g} effect="lift" className="flex w-full items-center justify-center gap-1 rounded-xl border py-2 text-[8.5px] font-black"
        style={{ borderColor: alpha(g, 0.2) }}>
        <Plus className="h-3 w-3" style={{ color: g }} />
        New listing
      </Tap>
    </div>
  );
}
