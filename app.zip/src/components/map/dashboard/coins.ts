import { useCallback, useEffect, useState } from "react";

const KEY = "bw-coins-v1";

type Ledger = { balance: number; history: { t: string; amt: number; when: number }[] };

const DEFAULT: Ledger = {
  balance: 1240,
  history: [
    { t: "Signup bonus", amt: 500, when: Date.now() - 864e5 * 12 },
    { t: "Housing survey completed", amt: 320, when: Date.now() - 864e5 * 4 },
    { t: "Referral · Naledi O.", amt: 250, when: Date.now() - 864e5 * 2 },
    { t: "Daily streak · 7 days", amt: 170, when: Date.now() - 3600e3 * 9 },
  ],
};

let mem: Ledger | null = null;
const subs = new Set<(l: Ledger) => void>();

function read(): Ledger {
  if (mem) return mem;
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) { mem = JSON.parse(raw) as Ledger; return mem; }
    } catch { /* ignore */ }
  }
  mem = DEFAULT;
  return mem;
}

function write(next: Ledger) {
  mem = next;
  try { window.localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* ignore */ }
  subs.forEach((f) => f(next));
}

/** Shared coin wallet across the dashboard. */
export function useCoins() {
  const [ledger, setLedger] = useState<Ledger>(read);

  useEffect(() => {
    subs.add(setLedger);
    setLedger(read());
    return () => { subs.delete(setLedger); };
  }, []);

  const earn = useCallback((t: string, amt: number) => {
    const cur = read();
    write({
      balance: cur.balance + amt,
      history: [{ t, amt, when: Date.now() }, ...cur.history].slice(0, 30),
    });
  }, []);

  const spend = useCallback((t: string, amt: number) => {
    const cur = read();
    if (cur.balance < amt) return false;
    write({
      balance: cur.balance - amt,
      history: [{ t, amt: -amt, when: Date.now() }, ...cur.history].slice(0, 30),
    });
    return true;
  }, []);

  return { balance: ledger.balance, history: ledger.history, earn, spend };
}
