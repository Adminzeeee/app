import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Check, Coins } from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { useSkin, Tap, Ring } from "./ui";
import { useCoins } from "./coins";
import { DAILY, POOL, choiceOptions, loadSay, saveSay, type SayState } from "./sayData";

const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, monospace";

/** v3 — console: monospace ballot, keyed options, tight streak ledger. */
export function SayV3({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const { balance, earn } = useCoins();
  const [state, setState] = useState<SayState>(loadSay);
  const [picked, setPicked] = useState<string | null>(null);

  useEffect(() => { saveSay(state); }, [state]);

  const done = state.answered >= DAILY;
  const q = POOL[(new Date().getDate() + state.answered) % POOL.length];

  const answer = (opt: string) => {
    if (done || picked) return;
    setPicked(opt);
    earn("Daily question answered", 1);
    window.setTimeout(() => {
      setPicked(null);
      setState((p) => {
        const answered = p.answered + 1;
        return { ...p, answered, streak: answered === DAILY ? p.streak + 1 : p.streak };
      });
    }, 340);
  };

  return (
    <div className="space-y-2" style={{ fontFamily: MONO }}>
      <div className="flex items-center gap-2.5 rounded-2xl border px-3 py-2"
        style={{ borderColor: alpha(g, 0.18), background: alpha(g, 0.05) }}>
        <Ring value={(state.answered / DAILY) * 100} color={g} size={46} label={`${state.answered}/${DAILY}`} />
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-bold uppercase tracking-[0.18em]" style={{ color: g }}>daily ballot</div>
          <div className={`text-[9px] ${s.muted}`}>streak {state.streak}d · resets midnight</div>
        </div>
        <div className={`flex shrink-0 items-center gap-1 text-[11px] font-bold ${s.muted}`}>
          <Coins className="h-3.5 w-3.5" style={{ color: g }} />{balance.toLocaleString()}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!done ? (
          <motion.div key={state.answered}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22 }}
            className="rounded-2xl border p-3" style={{ borderColor: alpha(g, 0.16) }}>
            <div className={`text-[8.5px] uppercase tracking-[0.2em] ${s.muted}`}>
              q{String(state.answered + 1).padStart(2, "0")}/{DAILY}
            </div>
            <div className="mt-1 text-[13px] font-bold leading-snug">{q.q}</div>
            <div className="mt-2 space-y-1">
              {choiceOptions(q).map((o, i) => (
                <Tap key={o} color={g} effect="glow" onClick={() => answer(o)}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[11.5px]"
                  style={picked === o
                    ? { background: g, color: isLight ? "#fff" : "#04121f" }
                    : { background: alpha(g, 0.07) }}>
                  <span className="grid h-4 w-4 shrink-0 place-items-center rounded text-[8.5px] font-bold"
                    style={{ background: alpha(g, picked === o ? 0.35 : 0.18), color: picked === o ? "inherit" : g }}>
                    {picked === o ? <Check className="h-2.5 w-2.5" /> : String.fromCharCode(65 + i)}
                  </span>
                  <span className="truncate">{o}</span>
                </Tap>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div key="done" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="rounded-2xl border p-4 text-center" style={{ borderColor: alpha(g, 0.3) }}>
            <div className="text-[13px] font-bold" style={{ color: g }}>ballot complete · +{DAILY} coins</div>
            <div className={`mt-1 text-[10px] ${s.muted}`}>streak {state.streak}d — next set at midnight</div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: 7 }, (_, i) => {
          const on = i < Math.min(7, state.streak);
          return (
            <div key={i} className="grid h-7 place-items-center rounded-lg text-[9px] font-bold"
              style={{ background: on ? alpha(g, 0.22) : alpha(g, 0.06), color: on ? g : undefined }}>
              {["m", "t", "w", "t", "f", "s", "s"][i]}
            </div>
          );
        })}
      </div>
    </div>
  );
}
