/* Rich dummy data for the Botswana command-center dashboard. */

export interface Review {
  by: string;
  stars: number;
  text: string;
  when: string;
}

export interface Freelancer {
  id: string;
  name: string;
  role: string;
  city: string;
  rate: string;
  rating: number;
  jobs: number;
  success: number;
  responseHrs: number;
  available: "now" | "week" | "booked";
  photo: string;
  cover: string;
  bio: string;
  skills: { k: string; v: number }[];
  langs: string[];
  portfolio: { title: string; img: string }[];
  reviews: Review[];
  earnings: number[];
}

export interface Product {
  name: string;
  price: number;
  was?: number;
  stock: number;
  img: string;
}

export interface Business {
  id: string;
  name: string;
  role: string;
  city: string;
  staff: string;
  rating: number;
  reviewsCount: number;
  photo: string;
  cover: string;
  about: string;
  phone: string;
  hours: { d: string; h: string }[];
  openNow: boolean;
  products: Product[];
  campaign: { title: string; sub: string; endsInMin: number };
  updates: { when: string; text: string }[];
  reviews: Review[];
  traffic: number[];
}

const U = (id: string, w = 400) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70`;

export const FREELANCERS: Freelancer[] = [
  {
    id: "neo",
    name: "Neo Kgosi",
    role: "Brand & Product Designer",
    city: "Gaborone",
    rate: "P420/hr",
    rating: 4.9,
    jobs: 87,
    success: 98,
    responseHrs: 1,
    available: "now",
    photo: U("photo-1500648767791-00dcc994a43e", 200),
    cover: U("photo-1517841905240-472988babdf9"),
    bio: "Nine years designing identity systems and product UI for Southern African fintech, tourism and public-sector teams.",
    skills: [
      { k: "Figma", v: 96 },
      { k: "Design systems", v: 91 },
      { k: "Motion", v: 78 },
      { k: "Webflow", v: 70 },
    ],
    langs: ["Setswana", "English"],
    portfolio: [
      { title: "Kalahari Bank rebrand", img: U("photo-1558655146-9f40138edfeb", 300) },
      { title: "Delta booking app", img: U("photo-1512941937669-90a1b58e7e9c", 300) },
      { title: "Census dashboard", img: U("photo-1551288049-bebda4e38f71", 300) },
    ],
    reviews: [
      { by: "Delta Safari Co.", stars: 5, text: "Delivered a full identity in 11 days. Ridiculous quality.", when: "2w ago" },
      { by: "Gabs Digital", stars: 5, text: "Best design partner we've worked with in Gaborone.", when: "1mo ago" },
      { by: "BW Health", stars: 4, text: "Great work, timelines slipped by two days.", when: "3mo ago" },
    ],
    earnings: [22, 28, 26, 34, 31, 42, 39, 48, 52, 47, 58, 61],
  },
  {
    id: "lesedi",
    name: "Lesedi Moeng",
    role: "Data & GIS Analyst",
    city: "Francistown",
    rate: "P380/hr",
    rating: 4.8,
    jobs: 54,
    success: 96,
    responseHrs: 3,
    available: "week",
    photo: U("photo-1494790108377-be9c29b29330", 200),
    cover: U("photo-1451187580459-43490279c0fa"),
    bio: "Spatial analytics for mining logistics, water monitoring and district-level census modelling.",
    skills: [
      { k: "PostGIS", v: 94 },
      { k: "Python", v: 89 },
      { k: "QGIS", v: 92 },
      { k: "Power BI", v: 74 },
    ],
    langs: ["English", "Setswana", "Kalanga"],
    portfolio: [
      { title: "Okavango flood model", img: U("photo-1446776877081-d282a0f896e2", 300) },
      { title: "Haulage route optimiser", img: U("photo-1519003722824-194d4455a60c", 300) },
    ],
    reviews: [
      { by: "Kalahari Logistics", stars: 5, text: "Cut our empty-run kilometres by 18%.", when: "5d ago" },
      { by: "Water Utilities", stars: 5, text: "Clear models, clear reporting.", when: "2mo ago" },
    ],
    earnings: [15, 19, 24, 21, 30, 28, 35, 33, 40, 44, 41, 49],
  },
  {
    id: "tumelo",
    name: "Tumelo Baruti",
    role: "Solar & Off-grid Engineer",
    city: "Maun",
    rate: "P290/hr",
    rating: 4.7,
    jobs: 132,
    success: 94,
    responseHrs: 6,
    available: "now",
    photo: U("photo-1507003211169-0a1dd7228f2d", 200),
    cover: U("photo-1509391366360-2e959784a276"),
    bio: "Designs and installs off-grid PV for lodges, clinics and boreholes across Ngamiland.",
    skills: [
      { k: "PV sizing", v: 95 },
      { k: "Battery banks", v: 88 },
      { k: "Boreholes", v: 82 },
    ],
    langs: ["Setswana", "English"],
    portfolio: [{ title: "Lodge microgrid", img: U("photo-1466611653911-95081537e5b7", 300) }],
    reviews: [{ by: "Chobe Fresh", stars: 5, text: "Zero downtime since commissioning.", when: "3w ago" }],
    earnings: [30, 26, 33, 38, 35, 41, 44, 39, 47, 51, 55, 52],
  },
  {
    id: "kefilwe",
    name: "Kefilwe Rantao",
    role: "Field Surveyor",
    city: "Kasane",
    rate: "P250/hr",
    rating: 5,
    jobs: 41,
    success: 100,
    responseHrs: 2,
    available: "booked",
    photo: U("photo-1438761681033-6461ffad8d80", 200),
    cover: U("photo-1516426122078-c23e76319801"),
    bio: "Household and enterprise survey fieldwork, enumerator training, mobile data capture.",
    skills: [
      { k: "ODK / Kobo", v: 93 },
      { k: "Sampling", v: 86 },
      { k: "Team lead", v: 90 },
    ],
    langs: ["Setswana", "English", "Subiya"],
    portfolio: [{ title: "Chobe enterprise census", img: U("photo-1454165804606-c3d57bc86b40", 300) }],
    reviews: [{ by: "Stats Botswana", stars: 5, text: "Flawless field discipline.", when: "1w ago" }],
    earnings: [10, 14, 12, 18, 22, 19, 25, 27, 24, 31, 29, 35],
  },
  {
    id: "kagiso",
    name: "Kagiso Phiri",
    role: "Drone & LiDAR Mapper",
    city: "Ghanzi",
    rate: "P520/hr",
    rating: 4.9,
    jobs: 33,
    success: 97,
    responseHrs: 4,
    available: "week",
    photo: U("photo-1519085360753-af0119f7cbe7", 200),
    cover: U("photo-1473968512647-3e447244af8f"),
    bio: "Aerial survey, orthomosaics and volumetrics for mining, ranching and conservation.",
    skills: [
      { k: "LiDAR", v: 92 },
      { k: "Photogrammetry", v: 90 },
      { k: "CAA permits", v: 85 },
    ],
    langs: ["English", "Setswana", "Afrikaans"],
    portfolio: [{ title: "Ranch boundary survey", img: U("photo-1500534314209-a25ddb2bd429", 300) }],
    reviews: [{ by: "Orapa Tooling", stars: 5, text: "Stockpile volumes within 1.2%.", when: "6d ago" }],
    earnings: [8, 12, 18, 15, 22, 28, 25, 33, 38, 35, 44, 47],
  },
  {
    id: "boitumelo",
    name: "Boitumelo Seru",
    role: "Setswana Content Lead",
    city: "Palapye",
    rate: "P180/hr",
    rating: 4.6,
    jobs: 210,
    success: 92,
    responseHrs: 8,
    available: "now",
    photo: U("photo-1544005313-94ddf0286df2", 200),
    cover: U("photo-1499346030926-9a72daac6c63"),
    bio: "Bilingual copy, localisation and public-health messaging at national scale.",
    skills: [
      { k: "Localisation", v: 94 },
      { k: "Copywriting", v: 88 },
      { k: "Radio scripts", v: 80 },
    ],
    langs: ["Setswana", "English"],
    portfolio: [{ title: "National health campaign", img: U("photo-1543269865-cbf427effbad", 300) }],
    reviews: [{ by: "Ministry of Health", stars: 5, text: "Reached rural audiences properly.", when: "1mo ago" }],
    earnings: [18, 20, 24, 22, 26, 30, 28, 32, 30, 36, 34, 39],
  },
];

export const BUSINESSES: Business[] = [
  {
    id: "kalahari-log",
    name: "Kalahari Logistics",
    role: "Freight & haulage",
    city: "Lobatse",
    staff: "120 staff",
    rating: 4.6,
    reviewsCount: 212,
    photo: U("photo-1519003722824-194d4455a60c", 200),
    cover: U("photo-1601584115197-04ecc0da31d7"),
    about: "Cross-border haulage between Botswana, South Africa and Namibia. 64-truck fleet with live tracking.",
    phone: "+267 533 1180",
    hours: [
      { d: "Mon–Fri", h: "06:00 – 18:00" },
      { d: "Sat", h: "07:00 – 13:00" },
      { d: "Sun", h: "Closed" },
    ],
    openNow: true,
    products: [
      { name: "Full truckload · GAB→JNB", price: 12400, was: 14200, stock: 6, img: U("photo-1591768575198-88dac53fbd0a", 300) },
      { name: "Cold chain pallet", price: 2100, stock: 22, img: U("photo-1553413077-190dd305871c", 300) },
      { name: "Bonded warehousing / m²", price: 85, was: 110, stock: 340, img: U("photo-1586528116311-ad8dd3c8310d", 300) },
    ],
    campaign: { title: "Rainy-season freight", sub: "12% off northbound loads", endsInMin: 184 },
    updates: [
      { when: "2h", text: "Kazungula border clearing in under 40 min." },
      { when: "1d", text: "Two new refrigerated units on the Maun route." },
    ],
    reviews: [
      { by: "Chobe Fresh", stars: 5, text: "Never lost a cold chain load with them.", when: "1w ago" },
      { by: "Boteti AgriWorks", stars: 4, text: "Reliable, invoicing could be faster.", when: "1mo ago" },
    ],
    traffic: [40, 52, 47, 61, 58, 72, 66, 80, 74, 88, 82, 95],
  },
  {
    id: "delta-safari",
    name: "Delta Safari Co.",
    role: "Eco tourism operator",
    city: "Maun",
    staff: "48 staff",
    rating: 4.9,
    reviewsCount: 1043,
    photo: U("photo-1547471080-7cc2caa01a7e", 200),
    cover: U("photo-1516426122078-c23e76319801"),
    about: "Mobile and lodge-based safaris across the Okavango, Moremi and Chobe with community-owned camps.",
    phone: "+267 686 0421",
    hours: [
      { d: "Mon–Sat", h: "07:00 – 19:00" },
      { d: "Sun", h: "09:00 – 15:00" },
    ],
    openNow: true,
    products: [
      { name: "4-night mobile safari", price: 18900, was: 22500, stock: 4, img: U("photo-1534177616072-ef7dc120449d", 300) },
      { name: "Mokoro day trip", price: 850, stock: 30, img: U("photo-1502581827181-9cf3c3ee0106", 300) },
      { name: "Scenic delta flight", price: 2400, was: 2900, stock: 9, img: U("photo-1436491865332-7a61a109cc05", 300) },
    ],
    campaign: { title: "Green season flash sale", sub: "Up to 16% off · 4 seats left", endsInMin: 47 },
    updates: [
      { when: "3h", text: "Flood pulse reached Boro channel — mokoro routes open." },
      { when: "2d", text: "New solar camp opened at Xakanaxa." },
    ],
    reviews: [
      { by: "A. Mokoena", stars: 5, text: "Guides knew every bird call by name.", when: "4d ago" },
      { by: "J. Peters", stars: 5, text: "Worth every pula.", when: "3w ago" },
    ],
    traffic: [62, 70, 68, 84, 92, 88, 96, 90, 102, 118, 110, 129],
  },
  {
    id: "gabs-digital",
    name: "Gabs Digital",
    role: "Software studio",
    city: "Gaborone",
    staff: "26 staff",
    rating: 4.8,
    reviewsCount: 96,
    photo: U("photo-1551434678-e076c223a692", 200),
    cover: U("photo-1522071820081-009f0129c71c"),
    about: "Product engineering for banking, logistics and government digital services.",
    phone: "+267 391 7742",
    hours: [
      { d: "Mon–Fri", h: "08:00 – 17:30" },
      { d: "Sat–Sun", h: "Closed" },
    ],
    openNow: false,
    products: [
      { name: "Discovery sprint (2 wks)", price: 68000, stock: 2, img: U("photo-1517245386807-bb43f82c33c4", 300) },
      { name: "Mobile app retainer / mo", price: 42000, was: 48000, stock: 3, img: U("photo-1512941937669-90a1b58e7e9c", 300) },
    ],
    campaign: { title: "Q3 build slots", sub: "2 engineering slots remaining", endsInMin: 620 },
    updates: [{ when: "5h", text: "Shipped offline-first sync for the census app." }],
    reviews: [{ by: "Kalahari Bank", stars: 5, text: "Shipped ahead of schedule twice.", when: "2w ago" }],
    traffic: [30, 34, 31, 40, 44, 41, 49, 52, 48, 57, 61, 58],
  },
  {
    id: "chobe-fresh",
    name: "Chobe Fresh",
    role: "Cold chain foods",
    city: "Kasane",
    staff: "64 staff",
    rating: 4.5,
    reviewsCount: 318,
    photo: U("photo-1542838132-92c53300491e", 200),
    cover: U("photo-1488459716781-31db52582fe9"),
    about: "Fresh produce, dairy and frozen distribution to lodges and retailers across the north.",
    phone: "+267 625 0099",
    hours: [
      { d: "Mon–Sat", h: "05:30 – 17:00" },
      { d: "Sun", h: "06:00 – 11:00" },
    ],
    openNow: true,
    products: [
      { name: "Produce crate (20kg)", price: 640, was: 780, stock: 48, img: U("photo-1542838132-92c53300491e", 300) },
      { name: "Dairy pallet", price: 3200, stock: 12, img: U("photo-1550583724-b2692b85b150", 300) },
      { name: "Frozen protein box", price: 1450, was: 1620, stock: 27, img: U("photo-1607623814075-e51df1bdc82f", 300) },
    ],
    campaign: { title: "Lodge restock special", sub: "Free delivery over P5 000", endsInMin: 96 },
    updates: [{ when: "1d", text: "New 12-tonne reefer added to the Kasane route." }],
    reviews: [{ by: "Delta Safari Co.", stars: 4, text: "Consistent, occasionally short on greens.", when: "10d ago" }],
    traffic: [55, 58, 62, 59, 66, 71, 68, 75, 79, 74, 83, 88],
  },
];

/* ---------------- surveys ---------------- */

export interface SurveyItem {
  id: string;
  title: string;
  category: "Economy" | "Social" | "Infrastructure" | "Environment";
  responses: number;
  target: number;
  sentiment: number;
  trend: number[];
  topAnswer: string;
  regions: { r: string; v: number }[];
}

export const SURVEYS: SurveyItem[] = [
  {
    id: "housing",
    title: "Housing needs & affordability",
    category: "Social",
    responses: 2841,
    target: 3200,
    sentiment: 46,
    trend: [30, 34, 32, 40, 44, 41, 49, 52],
    topAnswer: "Serviced plots are the #1 blocker (38%)",
    regions: [{ r: "South-East", v: 74 }, { r: "Central", v: 52 }, { r: "North-West", v: 41 }],
  },
  {
    id: "youth",
    title: "Youth employment pathways",
    category: "Economy",
    responses: 5120,
    target: 5000,
    sentiment: 58,
    trend: [40, 44, 47, 45, 52, 58, 61, 66],
    topAnswer: "Digital skills demand up 24% YoY",
    regions: [{ r: "South-East", v: 88 }, { r: "North-East", v: 63 }, { r: "Ghanzi", v: 29 }],
  },
  {
    id: "water",
    title: "Water access & reliability",
    category: "Infrastructure",
    responses: 1904,
    target: 2500,
    sentiment: 39,
    trend: [50, 46, 44, 40, 38, 36, 35, 33],
    topAnswer: "Outage frequency worst in Kgalagadi",
    regions: [{ r: "Kgalagadi", v: 81 }, { r: "Ghanzi", v: 66 }, { r: "Central", v: 44 }],
  },
  {
    id: "confidence",
    title: "Business confidence index",
    category: "Economy",
    responses: 762,
    target: 900,
    sentiment: 71,
    trend: [55, 58, 62, 60, 66, 69, 72, 75],
    topAnswer: "SMEs expect hiring growth in Q4",
    regions: [{ r: "South-East", v: 79 }, { r: "North-East", v: 61 }, { r: "Chobe", v: 57 }],
  },
  {
    id: "conservation",
    title: "Wildlife & conservation attitudes",
    category: "Environment",
    responses: 3388,
    target: 3000,
    sentiment: 66,
    trend: [60, 62, 65, 63, 68, 70, 69, 73],
    topAnswer: "Human-elephant conflict tops concerns",
    regions: [{ r: "Chobe", v: 92 }, { r: "North-West", v: 77 }, { r: "Central", v: 38 }],
  },
  {
    id: "transport",
    title: "Transport & road safety",
    category: "Infrastructure",
    responses: 1477,
    target: 2000,
    sentiment: 51,
    trend: [44, 47, 45, 50, 48, 53, 51, 55],
    topAnswer: "A1 corridor lighting is the top ask",
    regions: [{ r: "Central", v: 68 }, { r: "South-East", v: 62 }, { r: "Southern", v: 49 }],
  },
];

export const OPPORTUNITIES = [
  { t: "Digital skills academy · Francistown", v: 92, note: "5.1k youth responses, no local provider" },
  { t: "Cold-chain hub · Ghanzi", v: 78, note: "Agri output up, 0 refrigerated depots" },
  { t: "Solar borehole retrofit · Kgalagadi", v: 71, note: "81% report outages, grants available" },
  { t: "Community tourism · Tsodilo", v: 64, note: "Visitor intent up 18% YoY" },
];

export const RISKS = [
  { t: "Water reliability decline", sev: "high", v: 82, note: "8-wave downward sentiment trend" },
  { t: "Housing affordability gap", sev: "high", v: 76, note: "Serviced land supply lagging demand" },
  { t: "Human–elephant conflict", sev: "medium", v: 58, note: "Chobe incident reports +11%" },
  { t: "Fuel price pass-through", sev: "medium", v: 47, note: "Freight margins compressing" },
  { t: "Survey fatigue · Central", sev: "low", v: 24, note: "Response rate down 6pts" },
];

export const AI_REPORT_LINES = [
  "Synthesising 15,492 responses across 6 active instruments…",
  "Weighting by district population and response recency…",
  "Cross-referencing economic indicators and rainfall anomalies…",
  "Detecting 4 opportunity clusters and 5 material risks…",
  "Drafting executive summary and recommended actions…",
];

/* ---------------- overview ---------------- */

export const LIVE_PHOTOS = [
  { img: U("photo-1516426122078-c23e76319801"), cap: "Okavango · dawn flight" },
  { img: U("photo-1547471080-7cc2caa01a7e"), cap: "Chobe · elephant transit" },
  { img: U("photo-1534177616072-ef7dc120449d"), cap: "Kalahari · dune ridge" },
  { img: U("photo-1502581827181-9cf3c3ee0106"), cap: "Makgadikgadi · salt pan" },
  { img: U("photo-1518709268805-4e9042af9f23"), cap: "Gaborone · CBD" },
];

export const POLLS = [
  {
    q: "What should Botswana invest in first?",
    opts: [
      { k: "Renewable energy", v: 38 },
      { k: "Digital skills", v: 31 },
      { k: "Water security", v: 22 },
      { k: "Tourism roads", v: 9 },
    ],
  },
  {
    q: "Best season to visit the Delta?",
    opts: [
      { k: "Jun – Aug", v: 52 },
      { k: "Sep – Oct", v: 27 },
      { k: "Nov – Jan", v: 12 },
      { k: "Feb – May", v: 9 },
    ],
  },
];

export const BROADCASTS = [
  { tag: "LIVE", text: "Okavango flood pulse briefing · Maun ops room", watchers: 1284 },
  { tag: "LIVE", text: "Kalahari sensor mesh telemetry feed", watchers: 372 },
  { tag: "REPLAY", text: "Q3 tourism board press conference", watchers: 5610 },
];

export const SECTOR_TABLE = [
  { s: "Mining", gdp: 24.6, jobs: 12400, yoy: 1.8 },
  { s: "Tourism", gdp: 13.2, jobs: 38900, yoy: 8.4 },
  { s: "Agriculture", gdp: 6.1, jobs: 52100, yoy: -1.2 },
  { s: "Services", gdp: 41.7, jobs: 141000, yoy: 3.6 },
  { s: "Manufacturing", gdp: 9.4, jobs: 27600, yoy: 2.1 },
  { s: "Energy", gdp: 5.0, jobs: 6300, yoy: 6.9 },
];

/* ---------------- calendar ---------------- */

export const WEATHER_KINDS = ["sun", "cloud", "rain", "storm", "haze"] as const;
export type WeatherKind = (typeof WEATHER_KINDS)[number];

export interface DayEvent {
  time: string;
  title: string;
  kind: "survey" | "civic" | "business" | "field";
  where: string;
  owner: string;
}

export const EVENT_POOL: DayEvent[] = [
  { time: "06:30", title: "Enumerator muster & kit check", kind: "field", where: "Mogoditshane Ward 7", owner: "Stats Botswana field unit" },
  { time: "08:00", title: "Household survey wave", kind: "survey", where: "Tlokweng Ward 3", owner: "Stats Botswana" },
  { time: "08:30", title: "District data review", kind: "civic", where: "Gaborone City Council", owner: "Ministry of Local Government" },
  { time: "09:30", title: "Kgotla feedback session", kind: "civic", where: "Kanye Main Kgotla", owner: "Ngwaketse District Council" },
  { time: "10:15", title: "Water reliability spot-checks", kind: "field", where: "Kgalagadi South", owner: "Water Utilities Corporation" },
  { time: "11:00", title: "Cold-chain depot audit", kind: "business", where: "Kasane Depot 2", owner: "Chobe Fresh Logistics" },
  { time: "12:00", title: "Youth digital-skills intake", kind: "civic", where: "Palapye Youth Centre", owner: "Ministry of Youth & Gender Affairs" },
  { time: "13:00", title: "Borehole telemetry sweep", kind: "field", where: "Ghanzi Farms Block 9", owner: "Dept. of Water Affairs" },
  { time: "13:45", title: "SME confidence interviews", kind: "survey", where: "Francistown CBD", owner: "Stats Botswana" },
  { time: "14:30", title: "Tourism operators forum", kind: "business", where: "Maun Old Airstrip Hall", owner: "Botswana Tourism Organisation" },
  { time: "15:15", title: "Health post supply count", kind: "field", where: "Mahalapye Clinic", owner: "Ministry of Health" },
  { time: "16:00", title: "Youth employment kgotla", kind: "civic", where: "Selebi-Phikwe Ward 11", owner: "Ministry of Local Government" },
  { time: "16:45", title: "Market vendor licensing drive", kind: "business", where: "Lobatse Open Market", owner: "Lobatse Town Council" },
  { time: "17:30", title: "Drone mapping window", kind: "field", where: "Ghanzi conservancy edge", owner: "Land Administration Unit" },
  { time: "18:15", title: "Evening enumerator debrief", kind: "survey", where: "Serowe field office", owner: "Stats Botswana field unit" },
];

export const AGENDA_OWNERS_NOTE = "Field agenda synced from district ops rooms · updates every 15 min";

export const ATTENDEE_POOL = [
  "Kabo M.", "Thato S.", "Lesego K.", "Onalenna P.", "Boitumelo R.", "Tumelo B.",
  "Refilwe N.", "Kagiso T.", "Neo D.", "Lorato W.", "Kefilwe M.", "Gomolemo S.",
];

export const WARDS = [
  "Ward 3 · Tlokweng", "Ward 7 · Mogoditshane", "Ward 11 · Selebi-Phikwe",
  "Ward 14 · Gaborone North", "Ward 5 · Kanye", "Ward 9 · Serowe",
];
