import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Building2, Megaphone, Radio, Users } from "lucide-react";
import { alpha } from "../color";
import { useSkin, Tap } from "./ui";
import { DIR_PEOPLE, DIR_BIZ, ADS } from "./directoryData";
import type { ExploreProps } from "./ExploreShell";

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}
const val = (scope: string, salt: number, min: number, max: number) =>
  Math.round(min + ((hash(scope + salt) % 1000) / 1000) * (max - min));

type Kind = "person" | "business" | "listing" | "signal";
interface Row { id: number; kind: Kind; title: string; sub: string; at: number }

const SIGNALS = [
  "Water tanker dispatched to the ward",
  "New clinic hours published",
  "Road grading crew reported on site",
  "Fuel price update posted",
  "Network outage cleared",
  "Council meeting minutes released",
];

const ICON: Record<Kind, typeof Users> = {
  person: Users, business: Building2, listing: Megaphone, signal: Radio,
};

/** v4 — Live feed: everything happening in the selected place, as it lands. */
export function ExploreV4({ theme, isLight, place }: ExploreProps) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const scope = place?.name ?? "All Botswana";
  const [filter, setFilter] = useState<Kind | "all">("all");
  const [rows, setRows] = useState<Row[]>([]);
  const n = useRef(0);

  const make = useMemo(() => {
    return (): Row => {
      const i = n.current++;
      const k: Kind = (["person", "business", "listing", "signal"] as Kind[])[(i + hash(scope)) % 4];
      const now = Date.now();
      if (k === "person") {
        const p = DIR_PEOPLE[(i * 7 + hash(scope)) % DIR_PEOPLE.length];
        return { id: i, kind: k, title: p.name, sub: `${p.role} joined · ${scope}`, at: now };
      }
      if (k === "business") {
        const b = DIR_BIZ[(i * 5 + hash(scope)) % DIR_BIZ.length] as unknown as Record<string, string>;
        return { id: i, kind: k, title: String(b.name ?? "Business"), sub: `registered · ${scope}`, at: now };
      }
      if (k === "listing") {
        const a = ADS[(i * 3 + hash(scope)) % ADS.length];
        return { id: i, kind: k, title: a.title, sub: `${a.price} · ${scope}`, at: now };
      }
      return { id: i, kind: k, title: SIGNALS[i % SIGNALS.length], sub: `signal · ${scope}`, at: now };
    };
  }, [scope]);

  useEffect(() => {
    n.current = 0;
    setRows(Array.from({ length: 8 }, () => make()));
    const id = window.setInterval(() => setRows((p) => [make(), ...p].slice(0, 40)), 4200);
    return () => window.clearInterval(id);
  }, [make]);

  const shown = filter === "all" ? rows : rows.filter((r) => r.kind === filter);
  const ago = (t: number) => {
    const sdiff = Math.max(1, Math.round((Date.now() - t) / 1000));
    return sdiff < 60 ? `${sdiff}s` : `${Math.round(sdiff / 60)}m`;
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline gap-2">
        <span className="min-w-0 truncate text-[15px] font-black leading-none">{scope}</span>
        <span className="ml-auto flex items-center gap-1 text-[8px] font-bold" style={{ color: g }}>
          <motion.span className="h-1.5 w-1.5 rounded-full" style={{ background: g }}
            animate={{ opacity: [1, 0.2, 1] }} transition={{ duration: 1.4, repeat: Infinity }} />
          live feed
        </span>
      </div>

      <div className="grid grid-cols-4 gap-1">
        {[["People", 1], ["Business", 2], ["Listings", 3], ["Signals", 4]].map(([k, salt]) => (
          <div key={String(k)} className="rounded-lg px-1.5 py-1" style={{ background: alpha(g, 0.06) }}>
            <div className="text-[11px] font-black leading-none tabular-nums" style={{ color: g }}>
              {val(scope, Number(salt), 40, 4200).toLocaleString()}
            </div>
            <div className={`mt-[2px] truncate text-[6.5px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{k}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-1 overflow-x-auto pb-[2px]">
        {(["all", "person", "business", "listing", "signal"] as const).map((k) => (
          <Tap key={k} color={g} effect="squish" onClick={() => setFilter(k)}
            className="shrink-0 rounded-full px-2 py-[3px] text-[7.5px] font-black uppercase tracking-[0.12em]"
            style={filter === k ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.07) }}>
            {k}
          </Tap>
        ))}
      </div>

      <div className="max-h-[300px] overflow-y-auto pr-0.5">
        <AnimatePresence initial={false}>
          {shown.map((r) => {
            const Icon = ICON[r.kind];
            return (
              <motion.div key={r.id} layout
                initial={{ opacity: 0, y: -8, height: 0 }}
                animate={{ opacity: 1, y: 0, height: "auto" }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-2 border-b py-[6px]" style={{ borderColor: alpha(g, 0.09) }}>
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg" style={{ background: alpha(g, 0.1) }}>
                  <Icon className="h-3 w-3" style={{ color: g }} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[9.5px] font-bold leading-tight">{r.title}</span>
                  <span className={`block truncate text-[7px] uppercase tracking-[0.1em] ${s.muted}`}>{r.sub}</span>
                </span>
                <span className={`shrink-0 text-[7.5px] tabular-nums ${s.muted}`}>{ago(r.at)}</span>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
