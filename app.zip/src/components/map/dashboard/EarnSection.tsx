import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { Check, Coins, Flame, Gift, History, Trophy } from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Panel, Tap } from "./ui";
import { useCoins } from "./coins";

interface PaidSurvey {
  id: string; title: string; coins: number; mins: number; cat: string;
  qs: { q: string; a: string[] }[];
}

export const PAID_SURVEYS: PaidSurvey[] = [
  {
    id: "ps1", title: "Water reliability in your ward", coins: 180, mins: 3, cat: "Infrastructure",
    qs: [
      { q: "How many days last week did you have running water?", a: ["Every day", "4–6 days", "1–3 days", "None"] },
      { q: "What is your main backup source?", a: ["Borehole", "Water tank", "Neighbour", "Bought water", "None"] },
      { q: "How would you rate municipal response time?", a: ["Fast", "Acceptable", "Slow", "No response"] },
    ],
  },
  {
    id: "ps2", title: "Small business cost pressure", coins: 240, mins: 4, cat: "Economy",
    qs: [
      { q: "Which cost rose most this quarter?", a: ["Fuel", "Stock", "Rent", "Wages", "Electricity"] },
      { q: "Are you hiring in the next 90 days?", a: ["Yes, more than 3", "Yes, 1–2", "No", "Reducing staff"] },
      { q: "Main barrier to growth?", a: ["Access to credit", "Demand", "Skills", "Logistics", "Regulation"] },
    ],
  },
  {
    id: "ps3", title: "Youth skills and training demand", coins: 150, mins: 2, cat: "Social",
    qs: [
      { q: "What training would you pay for?", a: ["Solar install", "Coding", "Welding", "Logistics", "Hospitality"] },
      { q: "Preferred format?", a: ["In person", "Hybrid", "Fully online"] },
    ],
  },
  {
    id: "ps4", title: "Tourism spend and season shape", coins: 300, mins: 5, cat: "Tourism",
    qs: [
      { q: "Peak month for your bookings?", a: ["Jun", "Jul", "Aug", "Sep", "Oct"] },
      { q: "Average nights per booking?", a: ["1–2", "3–4", "5–7", "8+"] },
      { q: "Biggest operational constraint?", a: ["Road access", "Staff", "Fuel", "Connectivity"] },
    ],
  },
  {
    id: "ps5", title: "Transport and commuting patterns", coins: 120, mins: 2, cat: "Mobility",
    qs: [
      { q: "Daily one-way commute time?", a: ["<15 min", "15–30 min", "30–60 min", "60+ min"] },
      { q: "Primary mode?", a: ["Combi", "Own car", "Walk", "Lift club", "Bike"] },
    ],
  },
  {
    id: "ps6", title: "Food prices in your nearest town", coins: 200, mins: 3, cat: "Economy",
    qs: [
      { q: "Maize meal price change this month?", a: ["Down", "Flat", "Up a little", "Up sharply"] },
      { q: "Where do you shop most?", a: ["Supermarket", "Tuckshop", "Market", "Direct from farm"] },
    ],
  },
];

const REWARDS = [
  { k: "P20 airtime", cost: 800, icon: "📱" },
  { k: "Directory boost · 7d", cost: 1500, icon: "🚀" },
  { k: "Verified badge", cost: 2400, icon: "✅" },
  { k: "P50 data bundle", cost: 1900, icon: "🌐" },
  { k: "Featured ad · 3d", cost: 1200, icon: "📢" },
  { k: "Report export pack", cost: 900, icon: "📊" },
];

const LEADERS = [
  { n: "Naledi O.", c: 8420 }, { n: "Tebogo M.", c: 7310 }, { n: "Kagiso S.", c: 6905 },
  { n: "You", c: 0 }, { n: "Boitumelo K.", c: 5140 }, { n: "Lesego T.", c: 4870 },
];

export function EarnSection({ theme, isLight, s }: { theme: ThemeSpec; isLight: boolean; s: any }) {
  const { balance, history, earn, spend } = useCoins();
  const [done, setDone] = useState<Record<string, boolean>>({});
  const [active, setActive] = useState<PaidSurvey | null>(null);
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<Record<number, string>>({});
  const [toast, setToast] = useState<string | null>(null);

  const flash = (m: string) => { setToast(m); window.setTimeout(() => setToast(null), 1800); };

  const answer = (a: string) => {
    if (!active) return;
    const next = { ...picked, [step]: a };
    setPicked(next);
    if (step + 1 < active.qs.length) { setStep(step + 1); return; }
    earn(active.title, active.coins);
    setDone((d) => ({ ...d, [active.id]: true }));
    flash(`+${active.coins} coins earned`);
    setActive(null); setStep(0); setPicked({});
  };

  const streak = 7;
  const dailyGoal = 500;
  const earnedToday = history.filter((h) => Date.now() - h.when < 864e5 && h.amt > 0).reduce((a, b) => a + b.amt, 0);
  const leaders = [...LEADERS.map((l) => (l.n === "You" ? { ...l, c: balance } : l))].sort((a, b) => b.c - a.c);

  return (
    <div className="space-y-1.5">
      {/* wallet */}
      <div className={`flex items-center gap-2 rounded-lg border px-2 py-1.5 ${s.card}`}
        style={{ background: `linear-gradient(100deg, ${alpha(theme.glow, 0.16)}, transparent)` }}>
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg" style={{ background: alpha(theme.glow, 0.2) }}>
          <Coins className="h-4 w-4" style={{ color: theme.glow }} />
        </span>
        <div className="min-w-0 flex-1">
          <div className={`text-[7.5px] font-black uppercase tracking-[0.2em] ${s.muted}`}>Coin balance</div>
          <motion.div key={balance} initial={{ scale: 1.15 }} animate={{ scale: 1 }}
            className="text-[18px] font-black leading-none tabular-nums" style={{ color: theme.glow }}>
            {balance.toLocaleString()}
          </motion.div>
        </div>
        <div className="shrink-0 text-right">
          <div className={`flex items-center justify-end gap-0.5 text-[8px] font-bold ${s.muted}`}>
            <Flame className="h-2.5 w-2.5" style={{ color: "#f59e0b" }} />{streak}-day streak
          </div>
          <div className="w-[74px]"><Bar v={Math.min(100, (earnedToday / dailyGoal) * 100)} color={theme.markerCore.park} chip={s.chip} /></div>
          <div className={`text-[7px] tabular-nums ${s.muted}`}>{earnedToday}/{dailyGoal} today</div>
        </div>
      </div>

      {/* paid surveys */}
      <Panel title="Earn coins · paid surveys" dense className={s.card} muted={s.muted}
        right={<span className={`text-[7.5px] ${s.muted}`}>{PAID_SURVEYS.length} open</span>}>
        <div className="space-y-1">
          {PAID_SURVEYS.map((p) => (
            <Tap key={p.id} color={theme.glow} effect="squish"
              onClick={() => { if (!done[p.id]) { setActive(p); setStep(0); setPicked({}); } }}
              className={`flex w-full items-center gap-1.5 rounded border px-1.5 py-1 ${s.card} ${done[p.id] ? "opacity-55" : ""}`}>
              <div className="min-w-0 flex-1 text-left">
                <div className="truncate text-[9px] font-bold">{p.title}</div>
                <div className={`truncate text-[7px] ${s.muted}`}>{p.cat} · {p.mins} min · {p.qs.length} questions</div>
              </div>
              {done[p.id] ? (
                <span className="flex shrink-0 items-center gap-0.5 text-[8px] font-black" style={{ color: "#22c55e" }}>
                  <Check className="h-2.5 w-2.5" />Done
                </span>
              ) : (
                <span className="shrink-0 rounded-full px-1.5 py-[1px] text-[8.5px] font-black"
                  style={{ background: alpha(theme.glow, 0.18), color: theme.glow }}>+{p.coins}</span>
              )}
            </Tap>
          ))}
        </div>
      </Panel>

      {/* rewards */}
      <Panel title="Redeem" dense className={s.card} muted={s.muted} right={<Gift className="h-2.5 w-2.5" style={{ color: theme.glow }} />}>
        <div className="grid grid-cols-2 gap-1 sm:grid-cols-3">
          {REWARDS.map((r) => {
            const can = balance >= r.cost;
            return (
              <Tap key={r.k} color={theme.markerCore.park} effect="squish"
                onClick={() => { if (spend(r.k, r.cost)) flash(`Redeemed ${r.k}`); else flash("Not enough coins"); }}
                className={`w-full rounded border px-1 py-[3px] text-left ${s.card} ${can ? "" : "opacity-45"}`}>
                <div className="truncate text-[8px] font-bold">{r.icon} {r.k}</div>
                <div className="text-[9px] font-black tabular-nums" style={{ color: can ? theme.glow : undefined }}>{r.cost.toLocaleString()}</div>
              </Tap>
            );
          })}
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
        <Panel title="Leaderboard" dense className={s.card} muted={s.muted} right={<Trophy className="h-2.5 w-2.5" style={{ color: "#f59e0b" }} />}>
          <div className="space-y-[2px]">
            {leaders.map((l, i) => (
              <div key={l.n} className={`flex items-center gap-1 rounded px-1 py-[1px] ${l.n === "You" ? s.chip : ""}`}>
                <span className={`w-3 shrink-0 text-[8px] font-black ${s.muted}`}>{i + 1}</span>
                <span className="min-w-0 flex-1 truncate text-[8.5px] font-semibold">{l.n}</span>
                <span className="shrink-0 text-[8.5px] font-black tabular-nums" style={{ color: theme.glow }}>{l.c.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Coin history" dense className={s.card} muted={s.muted} right={<History className="h-2.5 w-2.5" />}>
          <div className="max-h-[104px] space-y-[2px] overflow-y-auto">
            {history.map((h, i) => (
              <div key={i} className="flex items-center gap-1">
                <span className="min-w-0 flex-1 truncate text-[8px]">{h.t}</span>
                <span className="shrink-0 text-[8px] font-black tabular-nums"
                  style={{ color: h.amt > 0 ? "#22c55e" : "#ef4444" }}>{h.amt > 0 ? "+" : ""}{h.amt}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* survey runner */}
      <AnimatePresence>
        {active && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] grid place-items-center p-4"
            style={{ background: "rgba(2,4,10,0.62)" }} onClick={() => setActive(null)}>
            <motion.div initial={{ y: 18, scale: 0.97 }} animate={{ y: 0, scale: 1 }} exit={{ y: 12, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className={`w-full max-w-[320px] rounded-xl border p-2 ${s.card}`}
              style={{ background: isLight ? "#fff" : "#0a0e1a" }}>
              <div className="flex items-center gap-1">
                <span className="min-w-0 flex-1 truncate text-[10px] font-black">{active.title}</span>
                <span className="shrink-0 rounded-full px-1.5 text-[8px] font-black"
                  style={{ background: alpha(theme.glow, 0.18), color: theme.glow }}>+{active.coins}</span>
              </div>
              <div className="my-1 flex gap-[2px]">
                {active.qs.map((_, i) => (
                  <div key={i} className="h-[2px] flex-1 rounded-full"
                    style={{ background: i <= step ? theme.glow : alpha(theme.glow, 0.18) }} />
                ))}
              </div>
              <div className={`mb-1 text-[7px] font-black uppercase tracking-[0.2em] ${s.muted}`}>
                Question {step + 1} of {active.qs.length}
              </div>
              <AnimatePresence mode="wait">
                <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}
                  transition={{ duration: 0.18 }}>
                  <p className="mb-1.5 text-[11px] font-bold leading-snug">{active.qs[step].q}</p>
                  <div className="space-y-1">
                    {active.qs[step].a.map((a) => (
                      <Tap key={a} color={theme.glow} effect="squish" onClick={() => answer(a)}
                        className={`block w-full rounded border px-1.5 py-1 text-left text-[9.5px] font-semibold ${s.card}`}>
                        {a}
                      </Tap>
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
            className="fixed bottom-4 left-1/2 z-[90] -translate-x-1/2 rounded-full px-3 py-1 text-[10px] font-black"
            style={{ background: theme.glow, color: "#04060d" }}>
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
