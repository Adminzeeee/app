import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity, AlertTriangle, Bookmark, Brain, ChevronRight, Cpu, Download, FlaskConical,
  Layers, Lightbulb, Play, RotateCcw, Save, Search, Settings2, Sliders, Sparkles, StickyNote,
  Target, Trash2, TrendingUp, X, Zap,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Panel, Ring, Tap, useSkin } from "./ui";
import { DrawLine } from "./charts";
import {
  DEPTHS, FINDINGS, HORIZONS, LEVERS, NOTES_SEED, REGIONS, SCAN_STAGES, SCENARIO_PRESETS,
  SECTORS, SOURCES, type Finding, type FindingKind,
} from "./workspaceData";

type View = "scan" | "results" | "reports" | "sim" | "notes";

const VIEWS: { k: View; label: string; icon: React.ReactNode }[] = [
  { k: "scan", label: "Engine", icon: <Brain className="h-2.5 w-2.5" /> },
  { k: "results", label: "Findings", icon: <Target className="h-2.5 w-2.5" /> },
  { k: "reports", label: "Reports", icon: <Bookmark className="h-2.5 w-2.5" /> },
  { k: "sim", label: "Simulate", icon: <FlaskConical className="h-2.5 w-2.5" /> },
  { k: "notes", label: "Notes", icon: <StickyNote className="h-2.5 w-2.5" /> },
];

const KIND_META: Record<FindingKind, { label: string; color: string; icon: React.ReactNode }> = {
  opportunity: { label: "Opportunity", color: "#22c55e", icon: <Lightbulb className="h-2.5 w-2.5" /> },
  gap: { label: "Gap", color: "#38bdf8", icon: <Layers className="h-2.5 w-2.5" /> },
  risk: { label: "Risk", color: "#ef4444", icon: <AlertTriangle className="h-2.5 w-2.5" /> },
};

interface SavedReport {
  id: string;
  name: string;
  when: string;
  count: number;
  filters: string;
  findings: string[];
  avg: number;
}

export function WorkspaceTab({
  theme, isLight, scope,
}: { theme: ThemeSpec; isLight: boolean; scope: string }) {
  const s = useSkin(isLight);
  const [view, setView] = useState<View>("scan");

  /* ---- filters ---- */
  const [sources, setSources] = useState<string[]>(SOURCES.map((x) => x.k));
  const [kinds, setKinds] = useState<FindingKind[]>(["opportunity", "gap", "risk"]);
  const [region, setRegion] = useState(REGIONS[0]);
  const [sector, setSector] = useState(SECTORS[0]);
  const [horizon, setHorizon] = useState(HORIZONS[2]);
  const [depth, setDepth] = useState(DEPTHS[1]);
  const [minScore, setMinScore] = useState(45);
  const [minConf, setMinConf] = useState(60);
  const [maxEffort, setMaxEffort] = useState(100);
  const [q, setQ] = useState("");

  /* ---- scan ---- */
  const [stage, setStage] = useState(-1);
  const [scanning, setScanning] = useState(false);
  const [done, setDone] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const timers = useRef<number[]>([]);

  const clearTimers = () => { timers.current.forEach(window.clearTimeout); timers.current = []; };
  useEffect(() => clearTimers, []);

  const results = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return FINDINGS.filter((f) =>
      kinds.includes(f.kind) &&
      (region === REGIONS[0] || f.region === region || f.region === "All Botswana") &&
      (sector === SECTORS[0] || f.sector === sector) &&
      f.score >= minScore && f.confidence >= minConf && f.effort <= maxEffort &&
      f.evidence.some((e) => sources.includes(e.src)) &&
      (!ql || (f.title + f.summary + f.sector + f.region).toLowerCase().includes(ql)),
    ).sort((a, b) => b.score - a.score);
  }, [kinds, region, sector, minScore, minConf, maxEffort, sources, q]);

  const runScan = useCallback(() => {
    clearTimers();
    setScanning(true); setDone(false); setStage(0); setLog([]);
    const step = depth === "Fast sweep" ? 190 : depth === "Standard" ? 320 : depth === "Deep analysis" ? 460 : 620;
    SCAN_STAGES.forEach((line, i) => {
      timers.current.push(window.setTimeout(() => {
        setStage(i + 1);
        setLog((l) => [...l, `${line} · ${(Math.random() * 900 + 60).toFixed(0)}ms`]);
        if (i === SCAN_STAGES.length - 1) {
          setScanning(false); setDone(true);
          timers.current.push(window.setTimeout(() => setView("results"), 500));
        }
      }, step * (i + 1)));
    });
  }, [depth]);

  /* ---- reports ---- */
  const [reports, setReports] = useState<SavedReport[]>([
    {
      id: "r0", name: "Q3 national opportunity sweep", when: "3d ago", count: 9,
      filters: "All Botswana · All sectors · 6 months", findings: FINDINGS.slice(0, 9).map((f) => f.id), avg: 71,
    },
    {
      id: "r1", name: "Kgalagadi water risk deep-dive", when: "1w ago", count: 3,
      filters: "Kgalagadi · Water · 90 days", findings: ["f8", "f3", "f5"], avg: 81,
    },
  ]);
  const [toast, setToast] = useState<string | null>(null);
  const say = (m: string) => { setToast(m); window.setTimeout(() => setToast(null), 1900); };

  const saveReport = () => {
    if (!results.length) { say("Run a scan first"); return; }
    const r: SavedReport = {
      id: "r" + Date.now(),
      name: `${region} · ${sector} · ${new Date().toLocaleDateString()}`,
      when: "just now",
      count: results.length,
      filters: `${region} · ${sector} · ${horizon}`,
      findings: results.map((f) => f.id),
      avg: Math.round(results.reduce((a, b) => a + b.score, 0) / results.length),
    };
    setReports((p) => [r, ...p]);
    say("Report saved");
  };

  /* ---- detail ---- */
  const [open, setOpen] = useState<Finding | null>(null);

  /* ---- notes ---- */
  const [notes, setNotes] = useState(NOTES_SEED);
  const [draft, setDraft] = useState("");

  const counts = useMemo(() => ({
    opportunity: results.filter((f) => f.kind === "opportunity").length,
    gap: results.filter((f) => f.kind === "gap").length,
    risk: results.filter((f) => f.kind === "risk").length,
  }), [results]);

  return (
    <div className="space-y-1.5">
      {/* header strip */}
      <div className={`flex items-center gap-1.5 rounded-md border px-1.5 py-1 ${s.card}`}>
        <span className="grid h-5 w-5 shrink-0 place-items-center rounded-md" style={{ background: alpha(theme.glow, 0.16) }}>
          <Cpu className="h-3 w-3" style={{ color: theme.glow }} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[9.5px] font-bold leading-tight">Signal Engine · {scope}</div>
          <div className={`truncate text-[7.5px] ${s.muted}`}>
            {sources.length}/{SOURCES.length} sources · {SOURCES.reduce((a, b) => a + b.records, 0).toLocaleString()} records
          </div>
        </div>
        <span className="shrink-0 rounded-full px-1.5 py-[1px] text-[7px] font-black uppercase tracking-[0.14em]"
          style={{ background: alpha(done ? "#22c55e" : theme.glow, 0.16), color: done ? "#22c55e" : theme.glow }}>
          {scanning ? "scanning" : done ? "ready" : "idle"}
        </span>
      </div>

      {/* view tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
        {VIEWS.map((v) => (
          <Tap key={v.k} color={theme.glow} effect="squish" onClick={() => setView(v.k)}
            className={`flex shrink-0 items-center gap-1 rounded px-1.5 py-[2px] text-[8.5px] font-bold ${view === v.k ? s.solid : `${s.chip} ${s.muted}`}`}>
            {v.icon}{v.label}
            {v.k === "results" && <span className="tabular-nums opacity-70">{results.length}</span>}
            {v.k === "reports" && <span className="tabular-nums opacity-70">{reports.length}</span>}
          </Tap>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={view} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.16 }} className="space-y-1.5">

          {/* ============ ENGINE ============ */}
          {view === "scan" && (
            <>
              <Panel title="Data sources" className={s.card} muted={s.muted} dense
                right={
                  <button onClick={() => setSources(sources.length === SOURCES.length ? [] : SOURCES.map((x) => x.k))}
                    className={`text-[7.5px] font-bold uppercase tracking-wider ${s.muted}`}>
                    {sources.length === SOURCES.length ? "none" : "all"}
                  </button>
                }>
                <div className="grid grid-cols-2 gap-[3px] sm:grid-cols-3">
                  {SOURCES.map((src) => {
                    const on = sources.includes(src.k);
                    return (
                      <Tap key={src.k} color={theme.glow} effect="squish"
                        onClick={() => setSources((p) => on ? p.filter((x) => x !== src.k) : [...p, src.k])}
                        className={`flex w-full items-center gap-1 rounded border px-1 py-[2px] ${on ? "border-current/40" : "border-current/10 opacity-45"}`}>
                        <span className="h-1 w-1 shrink-0 rounded-full" style={{ background: on ? theme.glow : "currentColor" }} />
                        <span className="min-w-0 flex-1 truncate text-[8px] font-semibold">{src.label}</span>
                        <span className={`shrink-0 text-[6.5px] tabular-nums ${s.muted}`}>{src.fresh}</span>
                      </Tap>
                    );
                  })}
                </div>
              </Panel>

              <Panel title="Scope filters" className={s.card} muted={s.muted} dense>
                <div className="grid grid-cols-2 gap-1">
                  <Select label="Region" value={region} opts={REGIONS} onChange={setRegion} s={s} />
                  <Select label="Sector" value={sector} opts={SECTORS} onChange={setSector} s={s} />
                  <Select label="Horizon" value={horizon} opts={HORIZONS} onChange={setHorizon} s={s} />
                  <Select label="Depth" value={depth} opts={DEPTHS} onChange={setDepth} s={s} />
                </div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {(Object.keys(KIND_META) as FindingKind[]).map((k) => {
                    const on = kinds.includes(k);
                    return (
                      <Tap key={k} color={KIND_META[k].color} effect="squish"
                        onClick={() => setKinds((p) => on ? p.filter((x) => x !== k) : [...p, k])}
                        className="flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[8px] font-bold"
                        style={{ background: alpha(KIND_META[k].color, on ? 0.2 : 0.06), color: on ? KIND_META[k].color : undefined, opacity: on ? 1 : 0.5 }}>
                        {KIND_META[k].icon}{KIND_META[k].label}
                      </Tap>
                    );
                  })}
                </div>
                <div className="mt-1 space-y-[2px]">
                  <Slide label="Min score" v={minScore} set={setMinScore} s={s} color={theme.glow} />
                  <Slide label="Min confidence" v={minConf} set={setMinConf} s={s} color={theme.markerCore.city} />
                  <Slide label="Max effort" v={maxEffort} set={setMaxEffort} s={s} color={theme.markerCore.landmark} />
                </div>
              </Panel>

              <Tap color={theme.glow} effect="glow" onClick={runScan}
                className="flex w-full items-center justify-center gap-1.5 rounded-md py-1.5 text-[10px] font-black"
                style={{ background: theme.glow, color: "#04060d" }}>
                {scanning ? <Activity className="h-3 w-3 animate-pulse" /> : <Sparkles className="h-3 w-3" />}
                {scanning ? "Analysing…" : `Run ${depth.toLowerCase()}`}
              </Tap>

              {stage >= 0 && (
                <Panel title="Engine trace" className={s.card} muted={s.muted} dense>
                  <div className="mb-1 flex items-center gap-1.5">
                    <div className="min-w-0 flex-1">
                      <Bar v={(stage / SCAN_STAGES.length) * 100} color={theme.glow} chip={s.chip} />
                    </div>
                    <span className={`shrink-0 text-[7.5px] tabular-nums ${s.muted}`}>{stage}/{SCAN_STAGES.length}</span>
                  </div>
                  <div className="max-h-[104px] space-y-[1px] overflow-y-auto font-mono">
                    {log.map((l, i) => (
                      <motion.div key={i} initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }}
                        className={`flex items-start gap-1 text-[7.5px] leading-tight ${s.muted}`}>
                        <span style={{ color: theme.glow }}>›</span>
                        <span className="min-w-0 flex-1">{l}</span>
                      </motion.div>
                    ))}
                    {scanning && (
                      <div className="flex items-center gap-1 text-[7.5px]" style={{ color: theme.glow }}>
                        <span className="inline-block h-1 w-1 animate-ping rounded-full" style={{ background: theme.glow }} />
                        working…
                      </div>
                    )}
                  </div>
                  {done && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                      className="mt-1 grid grid-cols-3 gap-1">
                      {(Object.keys(KIND_META) as FindingKind[]).map((k) => (
                        <div key={k} className={`rounded border px-1 py-[2px] ${s.card}`}>
                          <div className={`text-[6.5px] font-bold uppercase tracking-wider ${s.muted}`}>{KIND_META[k].label}</div>
                          <div className="text-[11px] font-black tabular-nums" style={{ color: KIND_META[k].color }}>{counts[k]}</div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </Panel>
              )}
            </>
          )}

          {/* ============ FINDINGS ============ */}
          {view === "results" && (
            <>
              <div className={`flex items-center gap-1 rounded-full px-2 py-[3px] ${s.chip}`}>
                <Search className={`h-2.5 w-2.5 shrink-0 ${s.muted}`} />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filter findings…"
                  className="min-w-0 flex-1 bg-transparent text-[9px] outline-none placeholder:opacity-50" />
                <span className={`shrink-0 text-[8px] tabular-nums ${s.muted}`}>{results.length}</span>
              </div>

              <div className="flex gap-1">
                <Tap color={theme.glow} effect="squish" onClick={saveReport}
                  className={`flex flex-1 items-center justify-center gap-1 rounded border py-[3px] text-[8.5px] font-bold ${s.card}`}>
                  <Save className="h-2.5 w-2.5" />Save as report
                </Tap>
                <Tap color={theme.glow} effect="squish" onClick={() => { setView("sim"); }}
                  className={`flex flex-1 items-center justify-center gap-1 rounded border py-[3px] text-[8.5px] font-bold ${s.card}`}>
                  <FlaskConical className="h-2.5 w-2.5" />Simulate
                </Tap>
                <Tap color={theme.glow} effect="squish" onClick={() => say("Exported findings.csv")}
                  className={`flex items-center justify-center gap-1 rounded border px-2 py-[3px] text-[8.5px] font-bold ${s.card}`}>
                  <Download className="h-2.5 w-2.5" />
                </Tap>
              </div>

              {results.length === 0 && (
                <div className={`rounded-md border p-3 text-center text-[9px] ${s.card} ${s.muted}`}>
                  No findings match these filters. Loosen the score or effort thresholds.
                </div>
              )}

              {results.map((f, i) => {
                const m = KIND_META[f.kind];
                const isOpen = open?.id === f.id;
                return (
                  <div key={f.id}>
                    <Tap color={m.color} effect="ripple" onClick={() => setOpen(isOpen ? null : f)}
                      className={`block w-full rounded-md border px-1.5 py-1 ${s.card}`}>
                      <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.02 }}>
                        <div className="flex items-center gap-1">
                          <span className="shrink-0" style={{ color: m.color }}>{m.icon}</span>
                          <span className="min-w-0 flex-1 truncate text-[9.5px] font-bold">{f.title}</span>
                          <span className="shrink-0 rounded-full px-1 text-[7px] font-black tabular-nums"
                            style={{ background: alpha(m.color, 0.16), color: m.color }}>{f.score}</span>
                        </div>
                        <div className={`mt-[1px] flex items-center gap-1 text-[7.5px] ${s.muted}`}>
                          <span className="truncate">{f.region} · {f.sector} · {f.horizon}</span>
                          <span className="ml-auto shrink-0 font-bold" style={{ color: theme.glow }}>{f.value}</span>
                        </div>
                        <div className="mt-[3px] flex items-center gap-1">
                          <div className="min-w-0 flex-1"><Bar v={f.score} color={m.color} chip={s.chip} /></div>
                          <span className={`shrink-0 text-[7px] tabular-nums ${s.muted}`}>c{f.confidence} · e{f.effort}</span>
                          <ChevronRight className={`h-2.5 w-2.5 shrink-0 transition ${isOpen ? "rotate-90" : ""} ${s.muted}`} />
                        </div>
                      </motion.div>
                    </Tap>
                    <AnimatePresence>
                      {isOpen && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden">
                          <FindingDetail f={f} theme={theme} s={s} say={say} onSim={() => setView("sim")} />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </>
          )}

          {/* ============ REPORTS ============ */}
          {view === "reports" && (
            <>
              {reports.map((r) => (
                <div key={r.id} className={`rounded-md border px-1.5 py-1 ${s.card}`}>
                  <div className="flex items-center gap-1">
                    <Bookmark className="h-2.5 w-2.5 shrink-0" style={{ color: theme.glow }} />
                    <span className="min-w-0 flex-1 truncate text-[9.5px] font-bold">{r.name}</span>
                    <button onClick={() => setReports((p) => p.filter((x) => x.id !== r.id))}
                      className={`shrink-0 ${s.muted}`} aria-label="Delete">
                      <Trash2 className="h-2.5 w-2.5" />
                    </button>
                  </div>
                  <div className={`truncate text-[7.5px] ${s.muted}`}>{r.filters} · {r.when}</div>
                  <div className="mt-[3px] flex items-center gap-1">
                    <span className="rounded-full px-1 text-[7px] font-black tabular-nums"
                      style={{ background: alpha(theme.glow, 0.15), color: theme.glow }}>{r.count} findings</span>
                    <span className={`text-[7px] tabular-nums ${s.muted}`}>avg score {r.avg}</span>
                    <Tap color={theme.glow} effect="squish" onClick={() => { setView("sim"); say("Loaded into simulator"); }}
                      className={`ml-auto rounded px-1.5 py-[1px] text-[7.5px] font-bold ${s.chip}`}>Run scenario</Tap>
                  </div>
                </div>
              ))}
              {!reports.length && (
                <div className={`rounded-md border p-3 text-center text-[9px] ${s.card} ${s.muted}`}>No saved reports yet.</div>
              )}
            </>
          )}

          {/* ============ SIMULATE ============ */}
          {view === "sim" && <Simulator theme={theme} s={s} findings={results.length ? results : FINDINGS} say={say} />}

          {/* ============ NOTES ============ */}
          {view === "notes" && (
            <>
              <div className={`flex items-center gap-1 rounded-md border px-1.5 py-1 ${s.card}`}>
                <input value={draft} onChange={(e) => setDraft(e.target.value)}
                  placeholder="Add a field note the engine will ingest…"
                  className="min-w-0 flex-1 bg-transparent text-[9px] outline-none placeholder:opacity-50" />
                <Tap color={theme.glow} effect="squish"
                  onClick={() => { if (!draft.trim()) return; setNotes((p) => [{ t: draft.trim(), when: "just now", tag: sector }, ...p]); setDraft(""); say("Note added to corpus"); }}
                  className="shrink-0 rounded px-1.5 py-[1px] text-[8px] font-black" style={{ background: theme.glow, color: "#04060d" }}>
                  Add
                </Tap>
              </div>
              {notes.map((n, i) => (
                <motion.div key={n.t + i} initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }}
                  className={`rounded-md border px-1.5 py-1 ${s.card}`}>
                  <div className="flex items-center gap-1">
                    <StickyNote className="h-2.5 w-2.5 shrink-0" style={{ color: theme.markerCore.landmark }} />
                    <span className="rounded-full px-1 text-[7px] font-bold" style={{ background: alpha(theme.glow, 0.14), color: theme.glow }}>{n.tag}</span>
                    <span className={`ml-auto shrink-0 text-[7px] ${s.muted}`}>{n.when}</span>
                  </div>
                  <p className="mt-[2px] text-[9px] leading-snug">{n.t}</p>
                </motion.div>
              ))}
            </>
          )}
        </motion.div>
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-20 left-1/2 z-[80] -translate-x-1/2 rounded-full px-2.5 py-1 text-[10px] font-bold text-black"
            style={{ background: theme.glow, boxShadow: `0 8px 24px -6px ${theme.glow}` }}>
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ---------- detail ---------- */

function FindingDetail({
  f, theme, s, say, onSim,
}: { f: Finding; theme: ThemeSpec; s: any; say: (m: string) => void; onSim: () => void }) {
  const m = KIND_META[f.kind];
  return (
    <div className={`mt-1 space-y-1 rounded-md border p-1.5 ${s.card}`}>
      <p className="text-[9px] leading-snug">{f.summary}</p>

      <div className="grid grid-cols-4 gap-1">
        {[
          ["Score", f.score, m.color], ["Confidence", f.confidence, theme.markerCore.city],
          ["Impact", f.impact, theme.markerCore.park], ["Effort", f.effort, theme.markerCore.landmark],
        ].map(([l, v, c]) => (
          <div key={l as string} className="flex flex-col items-center gap-[1px]">
            <Ring value={v as number} color={c as string} size={26} />
            <span className={`text-[6.5px] font-bold uppercase tracking-wider ${s.muted}`}>{l as string}</span>
          </div>
        ))}
      </div>

      <Panel title="Signal attribution" dense className={s.card} muted={s.muted}>
        <div className="space-y-[2px]">
          {f.evidence.map((e) => (
            <div key={e.text} className="flex items-center gap-1">
              <span className="w-[46px] shrink-0 truncate text-[7px] font-black uppercase tracking-wider" style={{ color: theme.glow }}>{e.src}</span>
              <span className="min-w-0 flex-1 truncate text-[8px]">{e.text}</span>
              <div className="w-8 shrink-0"><Bar v={e.weight * 100 * 2.4} color={m.color} chip={s.chip} /></div>
              <span className={`w-5 shrink-0 text-right text-[7px] tabular-nums ${s.muted}`}>{Math.round(e.weight * 100)}%</span>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-1">
        <Panel title="12-mo signal" dense className={s.card} muted={s.muted}>
          <DrawLine series={f.trend} c1={m.color} c2={theme.glow} height={28} />
        </Panel>
        <Panel title="Recommended actions" dense className={s.card} muted={s.muted}>
          <ul className="space-y-[1px]">
            {f.actions.map((a) => (
              <li key={a} className="flex items-start gap-1 text-[8px] leading-tight">
                <span className="mt-[3px] h-1 w-1 shrink-0 rounded-full" style={{ background: m.color }} />{a}
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="flex gap-1">
        <Tap color={theme.glow} effect="squish" onClick={() => say("Pinned to workspace")}
          className={`flex-1 rounded border py-[2px] text-center text-[8px] font-bold ${s.card}`}>Pin</Tap>
        <Tap color={theme.glow} effect="squish" onClick={onSim}
          className={`flex-1 rounded border py-[2px] text-center text-[8px] font-bold ${s.card}`}>Simulate</Tap>
        <Tap color={theme.glow} effect="squish" onClick={() => say("Assigned to district ops")}
          className={`flex-1 rounded border py-[2px] text-center text-[8px] font-bold ${s.card}`}>Assign</Tap>
      </div>
    </div>
  );
}

/* ---------- simulator ---------- */

function Simulator({
  theme, s, findings, say,
}: { theme: ThemeSpec; s: any; findings: Finding[]; say: (m: string) => void }) {
  const [target, setTarget] = useState(findings[0]?.id ?? "");
  const [vals, setVals] = useState<Record<string, number>>(
    Object.fromEntries(LEVERS.map((l) => [l.k, l.def])),
  );
  const [runs, setRuns] = useState<{ name: string; roi: number; risk: number; months: number }[]>([]);

  const f = findings.find((x) => x.id === target) ?? findings[0];

  const model = useMemo(() => {
    const base = f?.score ?? 60;
    const b = vals.budget ?? 18, sp = vals.speed ?? 100, pt = vals.partners ?? 4;
    const ad = vals.adoption ?? 55, rk = vals.risk ?? 45;
    const roi = Math.max(-40, Math.round((base * 0.6 + b * 1.9 + ad * 0.7 + pt * 2.2) * (sp / 130) - 42));
    const months = Math.max(2, Math.round(30 - b * 0.28 - pt * 0.9 - (sp - 100) * 0.06));
    const risk = Math.min(99, Math.max(4, Math.round(rk * 0.55 + (60 - b) * 0.35 + (100 - ad) * 0.28)));
    const success = Math.min(98, Math.max(6, Math.round(ad * 0.6 + (f?.confidence ?? 70) * 0.35 + pt * 1.1 - rk * 0.12)));
    const curve = Array.from({ length: 12 }, (_, i) =>
      Math.max(0, roi * (1 / (1 + Math.exp(-(i - months / 2.2) * 0.55))) + (i * b) / 22),
    );
    return { roi, months, risk, success, curve };
  }, [vals, f]);

  return (
    <div className="space-y-1.5">
      <Panel title="Scenario target" dense className={s.card} muted={s.muted}>
        <select value={target} onChange={(e) => setTarget(e.target.value)}
          className={`w-full rounded px-1 py-[2px] text-[8.5px] font-semibold outline-none ${s.chip}`}
          style={{ background: "transparent" }}>
          {findings.map((x) => <option key={x.id} value={x.id} style={{ color: "#0f172a" }}>{x.title}</option>)}
        </select>
        <div className="mt-1 flex flex-wrap gap-1">
          {SCENARIO_PRESETS.map((p) => (
            <Tap key={p.k} color={theme.glow} effect="squish" onClick={() => setVals({ ...p.mods })}
              className={`rounded-full px-1.5 py-[1px] text-[8px] font-bold ${s.chip}`}>{p.label}</Tap>
          ))}
          <Tap color={theme.glow} effect="squish" onClick={() => setVals(Object.fromEntries(LEVERS.map((l) => [l.k, l.def])))}
            className={`flex items-center gap-1 rounded-full px-1.5 py-[1px] text-[8px] font-bold ${s.chip}`}>
            <RotateCcw className="h-2 w-2" />Reset
          </Tap>
        </div>
      </Panel>

      <Panel title="Levers" dense className={s.card} muted={s.muted}>
        {LEVERS.map((l) => (
          <div key={l.k} className="mb-[2px] flex items-center gap-1.5">
            <span className="w-[58px] shrink-0 truncate text-[7.5px] font-semibold">{l.label}</span>
            <input type="range" min={l.min} max={l.max} value={vals[l.k]}
              onChange={(e) => setVals((v) => ({ ...v, [l.k]: Number(e.target.value) }))}
              className="h-1 min-w-0 flex-1 accent-current" />
            <span className={`w-[42px] shrink-0 text-right text-[7px] tabular-nums ${s.muted}`}>{vals[l.k]}{l.unit === "%" ? "%" : ` ${l.unit}`}</span>
          </div>
        ))}
      </Panel>

      <div className="grid grid-cols-4 gap-1">
        {[
          ["ROI", `${model.roi}%`, model.roi >= 0 ? "#22c55e" : "#ef4444"],
          ["Payback", `${model.months}mo`, theme.markerCore.city],
          ["Risk", `${model.risk}`, model.risk > 60 ? "#ef4444" : "#f59e0b"],
          ["Success", `${model.success}%`, theme.markerCore.park],
        ].map(([l, v, c]) => (
          <div key={l as string} className={`rounded border px-1 py-[2px] ${s.card}`}>
            <div className={`truncate text-[6.5px] font-bold uppercase tracking-wider ${s.muted}`}>{l as string}</div>
            <motion.div key={v as string} initial={{ opacity: 0, y: -3 }} animate={{ opacity: 1, y: 0 }}
              className="text-[11px] font-black tabular-nums" style={{ color: c as string }}>{v as string}</motion.div>
          </div>
        ))}
      </div>

      <Panel title="Modelled 12-month return curve" dense className={s.card} muted={s.muted}>
        <DrawLine series={model.curve} c1={theme.markerCore.park} c2={theme.glow} height={40} />
      </Panel>

      <div className="flex gap-1">
        <Tap color={theme.glow} effect="glow"
          onClick={() => { setRuns((p) => [{ name: `Run ${p.length + 1}`, roi: model.roi, risk: model.risk, months: model.months }, ...p].slice(0, 6)); say("Scenario recorded"); }}
          className="flex flex-1 items-center justify-center gap-1 rounded py-1 text-[9px] font-black"
          style={{ background: theme.glow, color: "#04060d" }}>
          <Play className="h-2.5 w-2.5" />Record run
        </Tap>
        <Tap color={theme.glow} effect="squish" onClick={() => say("Scenario saved to report")}
          className={`flex items-center gap-1 rounded border px-2 py-1 text-[9px] font-bold ${s.card}`}>
          <Save className="h-2.5 w-2.5" />
        </Tap>
      </div>

      {runs.length > 0 && (
        <Panel title="Run comparison" dense className={s.card} muted={s.muted}>
          {runs.map((r) => (
            <div key={r.name} className="flex items-center gap-1 py-[1px]">
              <span className="w-[36px] shrink-0 text-[7.5px] font-bold">{r.name}</span>
              <div className="min-w-0 flex-1"><Bar v={Math.max(0, r.roi)} color={r.roi >= 0 ? "#22c55e" : "#ef4444"} chip={s.chip} /></div>
              <span className={`w-[58px] shrink-0 text-right text-[7px] tabular-nums ${s.muted}`}>{r.roi}% · {r.months}mo · r{r.risk}</span>
            </div>
          ))}
        </Panel>
      )}
    </div>
  );
}

/* ---------- tiny controls ---------- */

function Select({
  label, value, opts, onChange, s,
}: { label: string; value: string; opts: string[]; onChange: (v: string) => void; s: any }) {
  return (
    <label className="min-w-0">
      <span className={`block text-[6.5px] font-bold uppercase tracking-wider ${s.muted}`}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className={`w-full rounded px-1 py-[2px] text-[8.5px] font-semibold outline-none ${s.chip}`}>
        {opts.map((o) => <option key={o} value={o} style={{ color: "#0f172a" }}>{o}</option>)}
      </select>
    </label>
  );
}

function Slide({
  label, v, set, s, color,
}: { label: string; v: number; set: (n: number) => void; s: any; color: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-[62px] shrink-0 text-[7.5px] font-semibold">{label}</span>
      <input type="range" min={0} max={100} value={v} onChange={(e) => set(Number(e.target.value))}
        className="h-1 min-w-0 flex-1" style={{ accentColor: color }} />
      <span className={`w-4 shrink-0 text-right text-[7px] tabular-nums ${s.muted}`}>{v}</span>
    </div>
  );
}
