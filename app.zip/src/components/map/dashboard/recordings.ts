import { useCallback, useEffect, useState } from "react";

export interface Recording {
  id: string;
  title: string;
  channel: string;
  category: string;
  seconds: number;
  when: number;
  scheduled?: boolean;
  at?: string;
}

const KEY = "bw-recordings-v1";

const DEFAULT: Recording[] = [
  { id: "rec1", title: "Water reliability · morning brief", channel: "Health & Water", category: "Metrics", seconds: 412, when: Date.now() - 36e5 * 5 },
  { id: "rec2", title: "Economy pulse · midday", channel: "Economy Live", category: "Metrics", seconds: 265, when: Date.now() - 36e5 * 26 },
  { id: "rec3", title: "Kalahari Sessions · ep 12", channel: "Local Entertainment", category: "Culture", seconds: 1840, when: Date.now() - 36e5 * 50 },
  { id: "rec4", title: "Evening insight digest", channel: "Insight Desk", category: "Insights", seconds: 0, when: Date.now() + 36e5 * 6, scheduled: true, at: "18:00" },
];

let mem: Recording[] | null = null;
const subs = new Set<(r: Recording[]) => void>();

function read(): Recording[] {
  if (mem) return mem;
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) { mem = JSON.parse(raw) as Recording[]; return mem; }
    } catch { /* ignore */ }
  }
  mem = DEFAULT;
  return mem;
}

function write(next: Recording[]) {
  mem = next;
  try { window.localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* ignore */ }
  subs.forEach((f) => f(next));
}

/** Shared recordings folder — written by the radio, read by the workspace. */
export function useRecordings() {
  const [items, setItems] = useState<Recording[]>(read);
  useEffect(() => {
    subs.add(setItems);
    setItems(read());
    return () => { subs.delete(setItems); };
  }, []);

  const add = useCallback((r: Omit<Recording, "id" | "when">) => {
    write([{ ...r, id: "rec" + Date.now(), when: Date.now() }, ...read()].slice(0, 60));
  }, []);
  const remove = useCallback((id: string) => write(read().filter((r) => r.id !== id)), []);

  return { items, add, remove };
}
