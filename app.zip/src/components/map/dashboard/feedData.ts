/* Shared "Feed" data for WorkspaceV6 / WorkspaceV7 — plain-language, glyph-first,
   social-feed style opportunity/risk/gap stream. */

import { useEffect, useRef, useState } from "react";

export type FeedKind = "opportunity" | "risk" | "gap";

export const FEED_CATEGORIES = [
  "Water", "Energy", "Health", "Housing", "Education", "Tourism",
  "Trade", "Digital", "Agriculture", "Logistics",
] as const;
export type FeedCategory = (typeof FEED_CATEGORIES)[number];

/** Symbol glyphs used instead of word tags — kept intentionally terse. */
export const KIND_GLYPH: Record<FeedKind, { glyph: string; color: string; word: string }> = {
  opportunity: { glyph: "▲", color: "#22c55e", word: "Opportunity" },
  risk: { glyph: "●", color: "#ef4444", word: "Risk" },
  gap: { glyph: "◆", color: "#38bdf8", word: "Gap" },
};

export interface FeedItem {
  id: string;
  kind: FeedKind;
  category: FeedCategory;
  heading: string;   // plain-language nutshell
  detail: string;    // one extra line, still plain
  region: string;
  reactions: number;
  watchers: number;
  createdAt: number; // ms epoch
}

const REGIONS = [
  "South-East", "North-West", "Central", "Ghanzi", "Kgalagadi",
  "Chobe", "Kweneng", "North-East", "Southern", "Maun", "Gaborone", "Francistown",
];

/* Plain-language nutshells — no jargon, no scores, just "what it means for you". */
const RAW: [FeedKind, FeedCategory, string, string][] = [
  ["opportunity", "Education", "Nobody nearby teaches digital skills — and young people want it", "A training centre here could fill a gap employers keep complaining about."],
  ["risk", "Water", "Water keeps cutting out in the same three villages", "People have been complaining for months and it isn't getting fixed."],
  ["opportunity", "Agriculture", "Farmers have nowhere cold to store their produce", "Crops are rotting before they reach the market — a cold-storage site would pay for itself."],
  ["gap", "Health", "No child doctor for 36,000 people", "The nearest one is a four-hour drive away."],
  ["opportunity", "Energy", "Sun-powered water pumps could end the diesel headaches", "A grant that pays for this closes in under three months."],
  ["risk", "Logistics", "Trucks are backing up at the border again", "Queues are the longest they've been all year — deliveries will slip."],
  ["opportunity", "Tourism", "Flood season is arriving early this year", "Lodges are still charging dry-season prices — a quick reprice could capture extra bookings."],
  ["gap", "Digital", "Nine villages barely show up in any survey", "Decisions are being made without hearing from these communities at all."],
  ["risk", "Housing", "New homes are being built slower than families are forming", "Waiting lists are only going to get longer from here."],
  ["opportunity", "Trade", "Local welders are losing work to bigger towns", "A shared workshop nearby could keep that income local."],
  ["risk", "Health", "A vaccine fridge is losing temperature", "Stock could spoil within two days if it isn't fixed."],
  ["opportunity", "Digital", "Drone pilots are in short supply", "Councils need aerial surveys and can't find enough licensed people to do them."],
  ["gap", "Trade", "Customs clearance is taking a fifth longer than usual", "Small traders are the ones feeling it most."],
  ["risk", "Agriculture", "It hasn't rained here in over two weeks", "Grazing land is under real strain and herds are moving."],
  ["opportunity", "Housing", "A stalled land project could restart with one signature", "Three tenders are ready to go but are stuck waiting on approval."],
  ["gap", "Education", "Teachers are leaving faster than they're being replaced", "One district is especially exposed heading into next term."],
  ["opportunity", "Water", "Forty boreholes are due for repair — and there's money for it", "A grant window is open, but someone needs to shortlist the sites."],
  ["risk", "Energy", "The power grid hiccupped twice this week on the same line", "It's the second time in seven days — worth a look before it happens again."],
  ["opportunity", "Tourism", "Visitor interest in heritage sites is climbing fast", "Bed space nearby hasn't grown to match it in five years."],
  ["gap", "Water", "One district reports the worst service satisfaction in the country", "And there's no outreach scheduled to address it in the next three months."],
  ["risk", "Trade", "Fuel costs are eating into delivery margins", "Smaller operators are the ones most exposed to this squeeze."],
  ["opportunity", "Agriculture", "A grain co-op could unlock a bulk discount", "Prices just dipped and there's unmet demand for twenty tonnes."],
  ["risk", "Housing", "Building material costs jumped again this year", "Projects already underway may need to be re-budgeted."],
  ["opportunity", "Digital", "New business sign-ups are up sharply this month", "Especially in solar — installers are now in more demand than plumbers."],
  ["gap", "Logistics", "Cold-chain trucks can't cover the season's peak demand", "There aren't enough refrigerated trucks booked for what's coming."],
  ["risk", "Agriculture", "More conflict between farms and wildlife is being reported", "Herds are moving closer to farmland as the dry season bites."],
  ["opportunity", "Health", "Telehealth could bridge the gap while a permanent clinic is planned", "It's a fast, cheap way to reach people right now."],
  ["gap", "Tourism", "There aren't enough trained guides for the busy season", "Bookings are coming in faster than staff can be hired."],
  ["risk", "Digital", "A backlog of unverified business listings is growing", "Trust in the directory could slip if this isn't cleared soon."],
  ["opportunity", "Energy", "Three new solar installers just registered", "That's a sign this market is finally starting to move."],
  ["risk", "Water", "A pump has failed the same way for the third time", "Something structural is likely wrong, not just bad luck."],
  ["opportunity", "Trade", "A quiet fibre corridor could support cheaper logistics", "Maintenance is scheduled — a good moment to plan around it."],
  ["gap", "Housing", "Two servicing tenders have stalled with no clear reason", "Land is ready but nothing is moving on either one."],
  ["opportunity", "Tourism", "Community-run camps are being overlooked by big operators", "Bundling a few of them into one circuit could unlock new bookings."],
  ["risk", "Education", "Attendance is dropping in wards with recent outages", "The two problems appear to be linked — worth checking directly."],
];

let counter = 0;
function makeItem(offsetMs: number): FeedItem {
  const i = counter++;
  const [kind, category, heading, detail] = RAW[i % RAW.length];
  return {
    id: `feed-${i}-${Math.random().toString(36).slice(2, 7)}`,
    kind, category, heading, detail,
    region: REGIONS[(i * 3) % REGIONS.length],
    reactions: 4 + ((i * 13) % 180),
    watchers: 2 + ((i * 7) % 64),
    createdAt: Date.now() - offsetMs,
  };
}

/** Initial seed — many entries, staggered ages so the feed feels lived-in. */
export const FEED_SEED: FeedItem[] = Array.from({ length: RAW.length }, (_, i) =>
  makeItem(i * 1000 * 60 * (3 + (i % 11))),
);

export function relTime(ts: number): string {
  const d = Math.max(0, Date.now() - ts);
  if (d < 20_000) return "just now";
  if (d < 60_000) return `${Math.floor(d / 1000)}s`;
  if (d < 3.6e6) return `${Math.floor(d / 60_000)}m`;
  if (d < 8.64e7) return `${Math.floor(d / 3.6e6)}h`;
  return `${Math.floor(d / 8.64e7)}d`;
}

/** Live-streaming feed hook shared by both v6 and v7 feed layouts.
 *  New items accumulate silently until `reveal()` is called, showing a "N new" pill. */
export function useFeedStream(intervalMs = 5200) {
  const [items, setItems] = useState<FeedItem[]>(FEED_SEED);
  const pending = useRef<FeedItem[]>([]);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => {
      const item = makeItem(0);
      pending.current = [item, ...pending.current];
      setPendingCount(pending.current.length);
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);

  const reveal = () => {
    if (!pending.current.length) return;
    setItems((p) => [...pending.current, ...p]);
    pending.current = [];
    setPendingCount(0);
  };

  const bump = (id: string, kind: "reactions" | "watchers") =>
    setItems((p) => p.map((it) => (it.id === id ? { ...it, [kind]: it[kind] + 1 } : it)));

  return { items, pendingCount, reveal, bump };
}
