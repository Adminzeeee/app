/* Granular category counts for the Explore lenses — the "what and how many" view. */

export interface Cat {
  k: string;
  n: number;
  today: number;
  group: string;
}

export const PEOPLE_TYPES: Cat[] = [
  { k: "Hairdressers", n: 1240, today: 18, group: "Personal care" },
  { k: "Plumbers", n: 892, today: 12, group: "Trades" },
  { k: "Electricians", n: 774, today: 9, group: "Trades" },
  { k: "Bricklayers", n: 2044, today: 24, group: "Trades" },
  { k: "Welders", n: 655, today: 7, group: "Trades" },
  { k: "Solar installers", n: 412, today: 21, group: "Trades" },
  { k: "Long-haul drivers", n: 2610, today: 31, group: "Drivers" },
  { k: "Taxi & combi drivers", n: 1880, today: 26, group: "Drivers" },
  { k: "Delivery riders", n: 640, today: 14, group: "Drivers" },
  { k: "Nurses", n: 1290, today: 6, group: "Health" },
  { k: "Care workers", n: 520, today: 4, group: "Health" },
  { k: "Safari guides", n: 1440, today: 16, group: "Tourism" },
  { k: "Chefs & cooks", n: 980, today: 11, group: "Tourism" },
  { k: "Waiters", n: 1105, today: 19, group: "Tourism" },
  { k: "Tutors", n: 803, today: 8, group: "Education" },
  { k: "Software developers", n: 612, today: 13, group: "Tech" },
  { k: "Graphic designers", n: 448, today: 10, group: "Creative" },
  { k: "Photographers", n: 366, today: 5, group: "Creative" },
  { k: "Drone pilots", n: 288, today: 9, group: "Tech" },
  { k: "Security guards", n: 900, today: 3, group: "Security" },
  { k: "Farm hands", n: 1320, today: 7, group: "Agriculture" },
  { k: "Herders", n: 945, today: 2, group: "Agriculture" },
];

export const BIZ_TYPES: Cat[] = [
  { k: "Car washes", n: 204, today: 3, group: "Auto" },
  { k: "Panel beaters", n: 96, today: 1, group: "Auto" },
  { k: "Spare-part shops", n: 188, today: 2, group: "Auto" },
  { k: "Salons & barbers", n: 612, today: 9, group: "Personal care" },
  { k: "Tuck shops", n: 1420, today: 14, group: "Retail" },
  { k: "Supermarkets", n: 236, today: 2, group: "Retail" },
  { k: "Clothing stores", n: 318, today: 4, group: "Retail" },
  { k: "Restaurants", n: 486, today: 6, group: "Food" },
  { k: "Takeaways", n: 704, today: 11, group: "Food" },
  { k: "Bakeries", n: 162, today: 1, group: "Food" },
  { k: "Guest houses", n: 388, today: 5, group: "Tourism" },
  { k: "Lodges & camps", n: 244, today: 3, group: "Tourism" },
  { k: "Tour operators", n: 176, today: 2, group: "Tourism" },
  { k: "Transport & freight", n: 512, today: 6, group: "Logistics" },
  { k: "Hardware stores", n: 268, today: 2, group: "Construction" },
  { k: "Building contractors", n: 442, today: 5, group: "Construction" },
  { k: "Printing shops", n: 154, today: 2, group: "Services" },
  { k: "Accountants", n: 208, today: 1, group: "Services" },
  { k: "Law firms", n: 118, today: 1, group: "Services" },
  { k: "IT & software", n: 162, today: 4, group: "Tech" },
  { k: "Farms & feedlots", n: 596, today: 3, group: "Agriculture" },
  { k: "Butcheries", n: 232, today: 2, group: "Food" },
];

export const LISTING_TYPES: Cat[] = [
  { k: "Houses for rent", n: 1502, today: 46, group: "Property" },
  { k: "Houses for sale", n: 688, today: 17, group: "Property" },
  { k: "Rooms & flats", n: 1144, today: 38, group: "Property" },
  { k: "Plots & land", n: 522, today: 12, group: "Property" },
  { k: "Cars for sale", n: 1866, today: 62, group: "Vehicles" },
  { k: "Bakkies & trucks", n: 704, today: 21, group: "Vehicles" },
  { k: "Car hire", n: 288, today: 8, group: "Vehicles" },
  { k: "Furniture", n: 940, today: 27, group: "Home" },
  { k: "Appliances", n: 612, today: 19, group: "Home" },
  { k: "Phones & laptops", n: 1388, today: 55, group: "Electronics" },
  { k: "Building material", n: 466, today: 9, group: "Trade" },
  { k: "Tools for hire", n: 342, today: 11, group: "Trade" },
  { k: "Livestock", n: 826, today: 15, group: "Agriculture" },
  { k: "Farm equipment", n: 254, today: 4, group: "Agriculture" },
  { k: "Jobs offered", n: 1032, today: 41, group: "Work" },
  { k: "Looking for work", n: 1874, today: 58, group: "Work" },
  { k: "Services offered", n: 1134, today: 33, group: "Work" },
  { k: "Events & tickets", n: 186, today: 6, group: "Social" },
  { k: "Lost & found", n: 92, today: 3, group: "Social" },
];

export interface MyListing {
  id: string;
  title: string;
  type: string;
  price: string;
  status: "live" | "paused" | "draft" | "sold";
  views: number;
  saves: number;
  msgs: number;
  when: string;
}

export const MY_LISTINGS: MyListing[] = [
  { id: "m1", title: "2-bed house, Block 8", type: "Houses for rent", price: "P4,200 / mo", status: "live", views: 1240, saves: 86, msgs: 12, when: "2d ago" },
  { id: "m2", title: "Toyota Hilux 2016 D4D", type: "Bakkies & trucks", price: "P189,000", status: "live", views: 3480, saves: 214, msgs: 31, when: "5d ago" },
  { id: "m3", title: "Mobile car wash — weekends", type: "Services offered", price: "From P120", status: "paused", views: 412, saves: 19, msgs: 4, when: "1w ago" },
  { id: "m4", title: "Office desk + chair set", type: "Furniture", price: "P1,450", status: "sold", views: 902, saves: 41, msgs: 9, when: "3w ago" },
  { id: "m5", title: "Solar geyser installation", type: "Services offered", price: "Quote", status: "draft", views: 0, saves: 0, msgs: 0, when: "just now" },
];

export const groupsOf = (cats: Cat[]) => Array.from(new Set(cats.map((c) => c.group)));
