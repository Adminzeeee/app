import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { alpha } from "../color";

/* ---------- theme-derived class helpers ---------- */

export function useSkin(isLight: boolean) {
  return {
    muted: isLight ? "text-slate-500" : "text-white/50",
    card: isLight ? "border-slate-900/10 bg-transparent" : "border-white/10 bg-transparent",
    chip: isLight ? "bg-slate-900/[0.05]" : "bg-white/[0.06]",
    solid: isLight ? "bg-slate-900 text-white" : "bg-white text-slate-900",
    line: isLight ? "border-slate-900/10" : "border-white/10",
  };
}

/* ---------- tap effects ---------- */

type TapStyle = "ripple" | "squish" | "glow" | "lift";

interface TapProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  color: string;
  effect?: TapStyle;
  as?: "div" | "button";
  style?: React.CSSProperties;
  title?: string;
}

/** Clickable surface with per-variant touch feedback. */
export function Tap({
  children, onClick, className = "", color, effect = "ripple", style, title,
}: TapProps) {
  const [rips, setRips] = useState<{ id: number; x: number; y: number }[]>([]);
  const n = useRef(0);

  const handle = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (effect === "ripple" || effect === "glow") {
      const r = e.currentTarget.getBoundingClientRect();
      const id = n.current++;
      setRips((p) => [...p, { id, x: e.clientX - r.left, y: e.clientY - r.top }]);
      window.setTimeout(() => setRips((p) => p.filter((q) => q.id !== id)), 620);
    }
  };

  const anim =
    effect === "squish"
      ? { scale: 0.95 }
      : effect === "lift"
        ? { y: 1, scale: 0.995 }
        : { scale: 0.985 };

  return (
    <motion.button
      type="button"
      title={title}
      onPointerDown={handle}
      onClick={onClick}
      whileTap={anim}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      className={`relative overflow-hidden text-left ${className}`}
      style={{ WebkitTapHighlightColor: "transparent", ...style }}
    >
      {children}
      <span className="pointer-events-none absolute inset-0">
        {rips.map((r) => (
          <motion.span
            key={r.id}
            initial={{ opacity: 0.5, scale: 0 }}
            animate={{ opacity: 0, scale: 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute rounded-full"
            style={{
              left: r.x - 90,
              top: r.y - 90,
              height: 180,
              width: 180,
              background:
                effect === "glow"
                  ? `radial-gradient(circle, ${alpha(color, 0.55)}, transparent 65%)`
                  : `radial-gradient(circle, ${alpha(color, 0.32)}, transparent 70%)`,
            }}
          />
        ))}
      </span>
    </motion.button>
  );
}

/* ---------- panels ---------- */

export function Panel({
  title, right, children, className, muted, dense,
}: {
  title?: string;
  right?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  muted: string;
  dense?: boolean;
}) {
  return (
    <div className={`rounded-md border ${dense ? "p-1" : "p-1.5"} ${className ?? ""}`}>
      {title && (
        <div className="mb-0.5 flex items-center gap-2">
          <div className={`text-[8.5px] font-semibold uppercase tracking-[0.2em] ${muted}`}>{title}</div>
          {right && <div className="ml-auto">{right}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

export function Kpi({
  label, value, suffix, color, card, muted, spark, onClick,
}: {
  label: string;
  value: string;
  suffix?: string;
  color: string;
  card: string;
  muted: string;
  spark?: number[];
  onClick?: () => void;
}) {
  return (
    <Tap color={color} effect="glow" onClick={onClick} className={`min-w-0 rounded-md border px-1.5 py-1 ${card}`}>
      <div className={`truncate text-[7px] font-semibold uppercase tracking-[0.12em] ${muted}`}>{label}</div>
      <div
        className="mt-[2px] text-[12px] font-extrabold leading-none tabular-nums"
        style={{ fontFamily: "'Sora',sans-serif", color }}
      >
        {value}
        {suffix && <span className={`ml-0.5 text-[7px] font-semibold ${muted}`}>{suffix}</span>}
      </div>
      {spark && <MiniSpark series={spark} color={color} />}
    </Tap>
  );
}

export function MiniSpark({ series, color }: { series: number[]; color: string }) {
  const w = 60, h = 14;
  const min = Math.min(...series), max = Math.max(...series);
  const d = series
    .map((v, i) => {
      const x = (i / (series.length - 1)) * w;
      const y = h - ((v - min) / Math.max(1, max - min)) * h;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="mt-0.5 h-[9px] w-full" preserveAspectRatio="none">
      <motion.path
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={1.4}
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
      />
    </svg>
  );
}

export function Bar({ v, color, chip }: { v: number; color: string; chip: string }) {
  return (
    <div className={`h-1 w-full overflow-hidden rounded-full ${chip}`}>
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${Math.min(100, v)}%` }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="h-full rounded-full"
        style={{ background: color, boxShadow: `0 0 6px ${alpha(color, 0.7)}` }}
      />
    </div>
  );
}

export function Ring({
  value, color, size = 44, label,
}: { value: number; color: string; size?: number; label?: string }) {
  const r = size / 2 - 4;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ height: size, width: size }}>
      <svg viewBox={`0 0 ${size} ${size}`} className="-rotate-90" width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" opacity={0.12} strokeWidth="3.5" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={color} strokeWidth="3.5" strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - value / 100) }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          style={{ filter: `drop-shadow(0 0 4px ${alpha(color, 0.7)})` }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-[9.5px] font-extrabold tabular-nums">
        {label ?? Math.round(value)}
      </div>
    </div>
  );
}

/* ---------- sheet / detail modal ---------- */

export function Sheet({
  open, onClose, children, isLight, title,
}: {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  isLight: boolean;
  title?: string;
}) {
  return (
    <AnimatePresence>
      {open && (
          <motion.section
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22 }}
             className={`mt-2 overflow-hidden rounded-md border ${
              isLight ? "border-slate-900/10 bg-slate-900/[0.03] text-slate-900" : "border-white/12 bg-white/[0.035] text-white"
            }`}
            style={{ fontFamily: "'Manrope', system-ui, sans-serif" }}
          >
            <div className="flex items-center gap-2 border-b border-current/10 px-2 py-1">
              <span className="truncate text-[10.5px] font-bold" style={{ fontFamily: "'Sora',sans-serif" }}>
                {title}
              </span>
              <button
                onClick={onClose}
                aria-label="Close"
                className="ml-auto grid h-5 w-5 place-items-center rounded-md bg-current/10"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
            <div>{children}</div>
          </motion.section>
      )}
    </AnimatePresence>
  );
}

/* ---------- misc ---------- */

export function Stars({ n, color }: { n: number; color: string }) {
  return (
    <span className="inline-flex items-center gap-[1px]">
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 24 24" className="h-2.5 w-2.5" fill={i < Math.round(n) ? color : "currentColor"} opacity={i < Math.round(n) ? 1 : 0.2}>
          <path d="M12 2l3 6.5 7 .9-5 4.8 1.3 7-6.3-3.4L5.7 21 7 14.2 2 9.4l7-.9L12 2z" />
        </svg>
      ))}
    </span>
  );
}

export function useCountdown(minutes: number) {
  const [left, setLeft] = useState(minutes * 60);
  useEffect(() => {
    setLeft(minutes * 60);
    const id = window.setInterval(() => setLeft((v) => (v > 0 ? v - 1 : 0)), 1000);
    return () => window.clearInterval(id);
  }, [minutes]);
  const h = Math.floor(left / 3600);
  const m = Math.floor((left % 3600) / 60);
  const s = left % 60;
  return `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
}

export function hash(str: string) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}
export function rand(seed: string, min: number, max: number) {
  return min + ((hash(seed) % 1000) / 1000) * (max - min);
}

/** Live-ticking number that drifts around a base value. */
export function useLive(base: number, jitter = 3, ms = 2200) {
  const [v, setV] = useState(base);
  useEffect(() => {
    setV(base);
    const id = window.setInterval(() => {
      setV((x) => Math.max(0, Math.round((x + (Math.random() - 0.45) * jitter) * 10) / 10));
    }, ms);
    return () => window.clearInterval(id);
  }, [base, jitter, ms]);
  return v;
}

export function useTabScroll() {
  const ref = useRef<HTMLDivElement>(null);
  const scrollTop = useCallback(() => ref.current?.scrollTo({ top: 0, behavior: "smooth" }), []);
  return { ref, scrollTop };
}

/* ---------- zoomable chart surface ---------- */

/** Pinch / wheel zoom + drag pan wrapper for inline charts. */
export function Zoomable({
  children, className = "", muted,
}: { children: React.ReactNode; className?: string; muted: string }) {
  const box = useRef<HTMLDivElement>(null);
  const [z, setZ] = useState(1);
  const [off, setOff] = useState({ x: 0, y: 0 });
  const state = useRef({ z: 1, x: 0, y: 0 });
  state.current = { z, x: off.x, y: off.y };

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1);
      const cur = state.current;
      const next = Math.min(6, Math.max(1, cur.z * Math.exp(-dy * 0.0018)));
      const r = el.getBoundingClientRect();
      const px = e.clientX - r.left, py = e.clientY - r.top;
      const k = next / cur.z;
      setZ(next);
      setOff({ x: px - (px - cur.x) * k, y: py - (py - cur.y) * k });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const pts = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef({ d: 0, z: 1 });

  const down = (e: React.PointerEvent) => {
    pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.current.size === 2) {
      const [a, b] = Array.from(pts.current.values());
      pinch.current = { d: Math.hypot(b.x - a.x, b.y - a.y), z: state.current.z };
    }
  };
  const move = (e: React.PointerEvent) => {
    if (!pts.current.has(e.pointerId)) return;
    const prev = pts.current.get(e.pointerId)!;
    pts.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.current.size === 2) {
      const [a, b] = Array.from(pts.current.values());
      const d = Math.hypot(b.x - a.x, b.y - a.y);
      setZ(Math.min(6, Math.max(1, pinch.current.z * (d / (pinch.current.d || d)))));
    } else if (state.current.z > 1) {
      setOff((o) => ({ x: o.x + (e.clientX - prev.x), y: o.y + (e.clientY - prev.y) }));
    }
  };
  const up = (e: React.PointerEvent) => { pts.current.delete(e.pointerId); };

  return (
    <div className={`relative ${className}`}>
      <div
        ref={box}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
        className="relative overflow-hidden rounded-md"
        style={{ touchAction: "none", cursor: z > 1 ? "grab" : "default" }}
      >
        <div style={{ transform: `translate3d(${off.x}px, ${off.y}px, 0) scale(${z})`, transformOrigin: "0 0", willChange: "transform" }}>
          {children}
        </div>
      </div>
      <div className="absolute right-1 top-1 flex items-center gap-1">
        <span className={`rounded px-1 text-[8px] tabular-nums ${muted}`}>{z.toFixed(1)}×</span>
        {z !== 1 && (
          <button
            onClick={() => { setZ(1); setOff({ x: 0, y: 0 }); }}
            className={`rounded px-1 text-[8px] font-bold ${muted}`}
          >
            reset
          </button>
        )}
      </div>
    </div>
  );
}
