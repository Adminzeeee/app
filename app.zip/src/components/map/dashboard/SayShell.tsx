import { useState } from "react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Tap } from "./ui";
import { SayTab } from "./SayTab";
import { SayV2 } from "./SayV2";
import { SayV3 } from "./SayV3";

/** Version switcher across the Have your say builds. */
export function SayShell({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const [v, setV] = useState<1 | 2 | 3>(2);
  
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1">
        <div className="ml-auto flex items-center gap-[2px] rounded-full p-[2px]" style={{ background: alpha(theme.glow, 0.12) }}>
          {([1, 2, 3] as const).map((n) => (
            <Tap
              key={n} color={theme.glow} effect="squish" onClick={() => setV(n)}
              className="rounded-full px-2 py-[2px] text-[8px] font-black"
              style={v === n
                ? { background: theme.glow, color: isLight ? "#fff" : "#04121f" }
                : { color: "inherit", opacity: 0.6 }}
            >
              v{n}
            </Tap>
          ))}
        </div>
      </div>
      {v === 1 && <SayTab theme={theme} isLight={isLight} />}
      {v === 2 && <SayV2 theme={theme} isLight={isLight} />}
      {v === 3 && <SayV3 theme={theme} isLight={isLight} />}
    </div>
  );
}
