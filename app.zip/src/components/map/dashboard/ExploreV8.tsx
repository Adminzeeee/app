import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { ChevronDown, MapPin, Search } from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData, Place } from "../types";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { useSkin } from "./ui";
import { BIZ_TYPES, LISTING_TYPES, PEOPLE_TYPES, type Cat } from "./exploreCats";

const DATA = raw as unknown as BotswanaData;

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}

/** Scale the national category counts down to the selected place. */
function scaled(cats: Cat[], scope: string, salt: number) {
  const f = 0.06 + ((hash(scope + salt) % 1000) / 1000) * 0.9;
  return cats.map((c) => ({ ...c, n: Math.max(1, Math.round(c.n * f)), today: 0 }));
}

/** Explore v8 — v7 with the lens tabs and verification strip stripped out.
 *  Pure "what is here, and how many" at a glance. */
export function ExploreV8({
  theme, isLight, place, onSelectPlace,
}: {
  theme: ThemeSpec;
  isLight: boolean;
  place: Place | null;
  onSelectPlace?: (p: Place | null) => void;
}) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [picker, setPicker] = useState(false);
  const [pq, setPq] = useState("");

  const scope = place?.name ?? "All Botswana";

  const people = useMemo(() => scaled(PEOPLE_TYPES, scope, 1), [scope]);
  const biz = useMemo(() => scaled(BIZ_TYPES, scope, 2), [scope]);
  const listings = useMemo(() => scaled(LISTING_TYPES, scope, 3), [scope]);

  const placeList = useMemo(() => {
    const all = DATA.places;
    if (!pq.trim()) return all.slice(0, 40);
    return all.filter((p) => p.name.toLowerCase().includes(pq.toLowerCase())).slice(0, 40);
  }, [pq]);

  const top = (c: Cat[]) => [...c].sort((a, b) => b.n - a.n).slice(0, 8);

  return (
    <div>
      {/* scope header */}
      <button onClick={() => setPicker((v) => !v)} className="flex w-full items-center gap-1.5 text-left">
        <MapPin className="h-3 w-3 shrink-0" style={{ color: g }} />
        <span className="min-w-0 truncate text-[16px] font-black leading-none">{scope}</span>
        <motion.span animate={{ rotate: picker ? 180 : 0 }} className="shrink-0 opacity-50">
          <ChevronDown className="h-3 w-3" />
        </motion.span>
        {place && (
          <span className="ml-auto shrink-0 rounded-full px-1.5 py-[1px] text-[6.5px] font-black uppercase tracking-[0.14em]"
            style={{ background: alpha(g, 0.12), color: g }}>
            {place.type}
          </span>
        )}
      </button>

      <AnimatePresence>
        {picker && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className={`mt-1.5 rounded-xl border p-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
              <div className="mb-1 flex items-center gap-1.5">
                <Search className="h-2.5 w-2.5 shrink-0 opacity-50" />
                <input value={pq} onChange={(e) => setPq(e.target.value)} placeholder="Find a place"
                  className="min-w-0 flex-1 bg-transparent text-[9px] font-semibold outline-none placeholder:opacity-35" />
              </div>
              <button onClick={() => { onSelectPlace?.(null); setPicker(false); }}
                className="mb-[2px] block w-full rounded-md px-1.5 py-[4px] text-left text-[8.5px] font-black"
                style={!place ? { background: alpha(g, 0.14), color: g } : undefined}>
                All Botswana
              </button>
              <div className="max-h-[168px] overflow-y-auto">
                {placeList.map((p) => (
                  <button key={p.name} onClick={() => { onSelectPlace?.(p); setPicker(false); }}
                    className="flex w-full items-center gap-1 rounded-md px-1.5 py-[4px] text-left"
                    style={place?.name === p.name ? { background: alpha(g, 0.14) } : undefined}>
                    <span className="min-w-0 flex-1 truncate text-[8.5px] font-semibold">{p.name}</span>
                    <span className={`shrink-0 text-[6.5px] uppercase tracking-[0.14em] ${s.muted}`}>{p.type}</span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-2.5 space-y-2.5">
        <Group title="Who is here" g={g} s={s} cats={top(people)} />
        <Group title="Busiest business types" g={g} s={s} cats={top(biz)} />
        <Group title="Most posted right now" g={g} s={s} cats={top(listings)} />
      </div>
    </div>
  );
}

function Group({ title, g, s, cats }: { title: string; g: string; s: ReturnType<typeof useSkin>; cats: Cat[] }) {
  return (
    <div>
      <div className={`mb-1 text-[6.5px] font-black uppercase tracking-[0.22em] ${s.muted}`} style={{ color: alpha(g, 0.8) }}>{title}</div>
      <div className="flex flex-wrap gap-1">
        {cats.map((c) => (
          <span key={c.k} className="rounded-full px-2 py-[3px] text-[8px] font-bold" style={{ background: alpha(g, 0.08) }}>
            {c.k} <b className="tabular-nums" style={{ color: g }}>{c.n.toLocaleString()}</b>
          </span>
        ))}
      </div>
    </div>
  );
}
