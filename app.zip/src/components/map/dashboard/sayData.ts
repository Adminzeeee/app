/* Shared state + question pool for the "Have your say" versions. */

export const DAILY = 10;

export type QKind = "choice" | "mood" | "slider" | "scenario" | "picture";

export interface SayQuestion {
  q: string;
  options: string[];
  kind?: QKind;
  /** short scenario paragraph shown above the options */
  scene?: string;
  /** emoji set for mood questions */
  moods?: string[];
  /** slider end labels + unit */
  scale?: [string, string];
  unit?: string;
  /** decorative gradient stops for picture cards */
  art?: [string, string];
  /** emoji illustration for picture cards */
  glyph?: string;
}

export const POOL: SayQuestion[] = [
  {
    q: "How reliable was your water supply this week?",
    options: ["Very reliable", "Mostly fine", "Often out", "No supply"],
    kind: "picture", glyph: "💧", art: ["#0ea5e9", "#22d3ee"],
  },
  {
    q: "How did this week feel overall?",
    options: ["Rough", "Heavy", "Okay", "Good", "Great"],
    kind: "mood", moods: ["😖", "😕", "😐", "🙂", "🤩"],
  },
  {
    q: "Did you experience a power cut in the last 7 days?",
    options: ["None", "Once", "2–3 times", "Almost daily"],
    kind: "picture", glyph: "⚡", art: ["#f59e0b", "#f97316"],
  },
  {
    q: "How many hours did you spend travelling this week?",
    options: [], kind: "slider", scale: ["0 h", "20 h+"], unit: "h",
  },
  {
    q: "Your clinic has one nurse and a queue of forty people at 7am.",
    options: ["Wait it out", "Go to a private clinic", "Try another village", "Give up for today"],
    kind: "scenario",
    scene: "Picture your nearest clinic on a busy Monday. What would you actually do?",
  },
  {
    q: "How easy was it to find work or a job lead?",
    options: ["Easy", "Some leads", "Very hard", "Not looking"],
    kind: "picture", glyph: "🛠️", art: ["#8b5cf6", "#6366f1"],
  },
  {
    q: "Rate the condition of your local road.",
    options: [], kind: "slider", scale: ["Impassable", "Perfect"], unit: "/100",
  },
  {
    q: "A new lodge opens nearby and hires 40 people from outside the village.",
    options: ["Great for the area", "Mixed feelings", "Locals should come first", "Bad for us"],
    kind: "scenario",
    scene: "Jobs arrive, but not for everyone. Where do you land?",
  },
  {
    q: "How safe do you feel in your area at night?",
    options: ["Very safe", "Fairly safe", "Unsafe", "Very unsafe"],
    kind: "picture", glyph: "🌙", art: ["#334155", "#0f172a"],
  },
  {
    q: "Did food prices change for you this month?",
    options: ["Cheaper", "Same", "Higher", "Much higher"],
    kind: "picture", glyph: "🧺", art: ["#16a34a", "#65a30d"],
  },
  {
    q: "How is mobile network quality where you are?",
    options: ["Strong", "Patchy", "Weak", "None"],
    kind: "picture", glyph: "📶", art: ["#0891b2", "#0ea5e9"],
  },
  {
    q: "How hopeful do you feel about the next six months?",
    options: ["Not at all", "A little", "Neutral", "Hopeful", "Very hopeful"],
    kind: "mood", moods: ["🌧️", "🌥️", "⛅", "🌤️", "☀️"],
  },
  {
    q: "What should leaders prioritise next quarter?",
    options: ["Water", "Jobs", "Health", "Roads"],
    kind: "picture", glyph: "🏛️", art: ["#e11d48", "#f43f5e"],
  },
  {
    q: "How much of your income went to transport this month?",
    options: [], kind: "slider", scale: ["0%", "50%+"], unit: "%",
  },
];

const KEY = "bw-say-v1";

export interface SayState { day: string; answered: number; streak: number; last: string }

export function today() { return new Date().toISOString().slice(0, 10); }

export function loadSay(): SayState {
  if (typeof window === "undefined") return { day: today(), answered: 0, streak: 4, last: "" };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as SayState;
      if (p.day === today()) return p;
      const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
      return { day: today(), answered: 0, streak: p.day === y ? p.streak : 0, last: p.day };
    }
  } catch { /* ignore */ }
  return { day: today(), answered: 0, streak: 4, last: "" };
}

export function saveSay(s: SayState) {
  try { window.localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* ignore */ }
}

/** Fallback options so simple builds can render slider questions too. */
export function choiceOptions(q: SayQuestion): string[] {
  return q.options.length ? q.options : ["Low", "Medium", "High", "Very high"];
}
