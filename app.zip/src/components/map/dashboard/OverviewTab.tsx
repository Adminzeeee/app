import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import {
  Activity, Camera, ChevronDown, Radio, TrendingDown, TrendingUp, Users, Vote, Zap,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Kpi, Panel, Ring, Sheet, Tap, Zoomable, hash, rand, useLive, useSkin } from "./ui";
import { Columns, DrawDonut, DrawLine, HeatGrid, MindMap, Radar } from "./charts";
import { BROADCASTS, LIVE_PHOTOS, POLLS, SECTOR_TABLE } from "./data";

export function OverviewTab({
  theme, isLight, scope, seed,
}: { theme: ThemeSpec; isLight: boolean; scope: string; seed: string }) {
  const s = useSkin(isLight);
  const [photo, setPhoto] = useState<number | null>(null);
  const [sector, setSector] = useState<(typeof SECTOR_TABLE)[number] | null>(null);
  const [pollI, setPollI] = useState(0);
  const [vote, setVote] = useState<Record<number, string>>({});
  const [gallery, setGallery] = useState(0);
  const [cast, setCast] = useState<number | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => setGallery((v) => (v + 1) % LIVE_PHOTOS.length), 4200);
    return () => window.clearInterval(id);
  }, []);

  const gdp = useMemo(() => rand(seed + "gdp", -1.5, 6.5).toFixed(1), [seed]);
  const mood = useMemo(() => Math.round(rand(seed + "mood", 45, 92)), [seed]);
  const surveys = useMemo(() => Math.round(rand(seed + "sv", 3, 320)), [seed]);
  const visitors = useLive(Math.round(rand(seed + "vis", 900, 4200)), 40, 1800);
  const uplink = useLive(96, 1.4, 1500);

  const series = useMemo(
    () => Array.from({ length: 18 }, (_, i) => 0.28 + ((hash(seed + i) % 1000) / 1000) * 0.7),
    [seed],
  );
  const sectors = useMemo(
    () => ["Mining", "Tourism", "Agri", "Services"].map((k) => ({ k, v: Math.round(rand(seed + k, 12, 48)) })),
    [seed],
  );
  const radar = useMemo(
    () => ["Econ", "Health", "Infra", "Env", "Edu", "Digital"].map((k) => ({ k, v: Math.round(rand(seed + "r" + k, 35, 96)) })),
    [seed],
  );
  const heat = useMemo(
    () => Array.from({ length: 5 }, (_, r) => Array.from({ length: 18 }, (_, c) => hash(seed + r + "x" + c) % 100)),
    [seed],
  );
  const cols = useMemo(
    () => ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((k) => ({ k, v: Math.round(rand(seed + "c" + k, 20, 100)) })),
    [seed],
  );

  const poll = POLLS[pollI];
  const voted = vote[pollI];
  const total = poll.opts.reduce((a, b) => a + b.v, 0);

  return (
    <div className="space-y-2">
      {/* KPI strip */}
      <div className="grid grid-cols-5 gap-1">
        <Kpi label="GDP growth" value={`${Number(gdp) >= 0 ? "+" : ""}${gdp}%`} color={theme.markerCore.park} card={s.card} muted={s.muted} spark={series.slice(0, 8)} />
        <Kpi label="Sentiment" value={String(mood)} suffix="/100" color={theme.markerCore.city} card={s.card} muted={s.muted} spark={series.slice(4, 12)} />
        <Kpi label="Live visitors" value={String(Math.round(visitors))} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
        <Kpi label="Surveys" value={String(surveys)} color={theme.markerCore.landmark} card={s.card} muted={s.muted} spark={series.slice(6, 14)} />
        <Kpi label="Uplink" value={`${uplink.toFixed(1)}%`} color={theme.glow} card={s.card} muted={s.muted} />
      </div>

      {/* live broadcast + gallery */}
      <div className="grid grid-cols-5 gap-1.5">
        <Panel title="Live broadcast · tap for detail" className={`col-span-3 ${s.card}`} muted={s.muted}>
          <div className="space-y-1">
            {BROADCASTS.map((b, bi) => {
              const openB = cast === bi;
              const viewers = Math.round(b.watchers * (0.94 + ((bi * 37) % 12) / 100));
              return (
                <div key={b.text}>
                  <Tap color={theme.glow} effect="lift" onClick={() => setCast(openB ? null : bi)} className={`flex w-full items-center gap-2 rounded-lg px-1.5 py-1 ${s.chip}`}>
                    <span
                      className="flex items-center gap-1 rounded-full px-1.5 py-[1px] text-[8px] font-black tracking-[0.14em]"
                      style={{ background: b.tag === "LIVE" ? alpha("#ef4444", 0.18) : alpha(theme.glow, 0.16), color: b.tag === "LIVE" ? "#ef4444" : theme.glow }}
                    >
                      <motion.span
                        animate={{ opacity: [1, 0.2, 1] }} transition={{ duration: 1.4, repeat: Infinity }}
                        className="h-1 w-1 rounded-full" style={{ background: "currentColor" }}
                      />
                      {b.tag}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[10.5px] font-semibold">{b.text}</span>
                    <span className={`flex shrink-0 items-center gap-0.5 text-[9px] tabular-nums ${s.muted}`}>
                      <Users className="h-2.5 w-2.5" />
                      {b.watchers.toLocaleString()}
                    </span>
                    <ChevronDown className={`h-3 w-3 shrink-0 transition-transform ${s.muted} ${openB ? "rotate-180" : ""}`} />
                  </Tap>
                  <AnimatePresence initial={false}>
                    {openB && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }} className="overflow-hidden"
                      >
                        <div className={`mt-1 rounded-lg border p-1.5 ${s.card}`}>
                          <div className="grid grid-cols-4 gap-1">
                            <Kpi label="Viewers" value={viewers.toLocaleString()} color={theme.markerCore.city} card={s.card} muted={s.muted} />
                            <Kpi label="Peak" value={(viewers + 480).toLocaleString()} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
                            <Kpi label="Bitrate" value={`${(3 + (bi % 3) * 0.7).toFixed(1)}M`} color={theme.markerCore.park} card={s.card} muted={s.muted} />
                            <Kpi label="Uptime" value={`${8 + bi * 3}h`} color={theme.glow} card={s.card} muted={s.muted} />
                          </div>
                          <div className="mt-1 grid grid-cols-5 gap-1.5">
                            <div className="col-span-3">
                              <DrawLine series={series.slice(bi, bi + 10)} c1={theme.markerCore.city} c2={theme.glow} height={30} />
                            </div>
                            <div className="col-span-2 space-y-[3px]">
                              {[["Mesh nodes", 92], ["Sentiment", 78], ["Retention", 64]].map(([k, v]) => (
                                <div key={k as string} className="flex items-center gap-1">
                                  <span className={`w-[52px] shrink-0 truncate text-[8.5px] ${s.muted}`}>{k}</span>
                                  <div className="min-w-0 flex-1"><Bar v={v as number} color={theme.glow} chip={s.chip} /></div>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className={`mt-1 text-[9px] leading-snug ${s.muted}`}>
                            Feed relayed from the {scope} mesh gateway · auto-transcribed · archived for 30 days.
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel title="Field gallery" className={`col-span-2 ${s.card}`} muted={s.muted}
          right={<span className={`text-[9px] tabular-nums ${s.muted}`}>{gallery + 1}/{LIVE_PHOTOS.length}</span>}
        >
          <div className="grid grid-cols-3 gap-1">
            {LIVE_PHOTOS.slice(0, 3).map((p, i) => (
              <Tap key={p.cap} color={theme.glow} effect="glow" onClick={() => setPhoto(i)} className="relative overflow-hidden rounded-lg">
                <img src={p.img} alt={p.cap} className="h-10 w-full object-cover" loading="lazy" decoding="async" />
                <span className="absolute inset-x-0 bottom-0 truncate bg-black/45 px-1 py-[1px] text-[7px] font-bold text-white">{p.cap}</span>
              </Tap>
            ))}
          </div>
          <div className="mt-1 flex items-center gap-1">
            <Camera className="h-2.5 w-2.5" style={{ color: theme.glow }} />
            <span className={`truncate text-[9px] ${s.muted}`}>{LIVE_PHOTOS[gallery].cap}</span>
          </div>
        </Panel>
      </div>

      {/* charts row — half width each, always one line */}
      <div className="grid grid-cols-2 gap-1.5">
        <Panel title={`Activity · 18 mo · ${scope}`} dense className={s.card} muted={s.muted}>
          <DrawLine series={series} c1={theme.markerCore.city} c2={theme.markerCore.park} height={30} />
        </Panel>
        <Panel title="Economy mix" dense className={s.card} muted={s.muted}>
          <DrawDonut sectors={sectors} theme={theme} muted={s.muted} />
        </Panel>
      </div>


      {/* sector table */}
      <Panel title="Sector engine · tap a row" className={s.card} muted={s.muted}>
        <div className="space-y-[3px]">
          {SECTOR_TABLE.map((r) => (
            <Tap key={r.s} color={theme.markerCore.city} effect="ripple" onClick={() => setSector(r)} className={`flex w-full items-center gap-2 rounded-lg px-1.5 py-1 ${s.chip}`}>
              <span className="w-[70px] shrink-0 truncate text-[11px] font-bold">{r.s}</span>
              <div className="min-w-0 flex-1"><Bar v={r.gdp * 2.2} color={theme.markerCore.city} chip={s.chip} /></div>
              <span className={`w-[38px] shrink-0 text-right text-[10px] tabular-nums ${s.muted}`}>{r.gdp}%</span>
              <span className={`w-[46px] shrink-0 text-right text-[10px] font-bold tabular-nums ${r.yoy >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                {r.yoy >= 0 ? "+" : ""}{r.yoy}%
              </span>
            </Tap>
          ))}
        </div>
      </Panel>

      {/* poll */}
      <Panel title="Live poll" className={s.card} muted={s.muted}
        right={
          <Tap color={theme.glow} effect="squish" onClick={() => setPollI((v) => (v + 1) % POLLS.length)} className={`rounded-full px-1.5 py-[2px] text-[9px] font-bold ${s.chip}`}>
            next
          </Tap>
        }
      >
        <div className="flex items-center gap-1.5 text-[11px] font-bold">
          <Vote className="h-3 w-3" style={{ color: theme.glow }} />
          {poll.q}
        </div>
        <div className="mt-1 grid grid-cols-2 gap-1">
          {poll.opts.map((o) => {
            const pct = Math.round((o.v / total) * 100);
            const mine = voted === o.k;
            return (
              <Tap
                key={o.k}
                color={theme.markerCore.capital}
                effect="glow"
                onClick={() => setVote((v) => ({ ...v, [pollI]: o.k }))}
                className={`w-full rounded-lg px-1.5 py-1 ${s.chip}`}
                style={mine ? { boxShadow: `inset 0 0 0 1px ${alpha(theme.glow, 0.7)}` } : undefined}
              >
                <div className="flex items-center gap-1.5">
                  <span className="truncate text-[10px] font-semibold">{o.k}</span>
                  <span className={`ml-auto text-[9.5px] font-bold tabular-nums ${voted ? "" : "opacity-40"}`}>{voted ? `${pct}%` : "vote"}</span>
                </div>
                {voted && <div className="mt-0.5"><Bar v={pct} color={mine ? theme.glow : theme.markerCore.city} chip={s.chip} /></div>}
              </Tap>
            );
          })}
        </div>
      </Panel>

      {/* radar + signal map — half each, pinch/scroll to zoom */}
      <div className="grid grid-cols-2 gap-1.5">
        <Panel title="Development radar · zoom" dense className={s.card} muted={s.muted}>
          <Zoomable muted={s.muted}>
            <Radar data={radar} color={theme.glow} />
          </Zoomable>
        </Panel>
        <Panel title="Signal map · zoom" dense className={s.card} muted={s.muted}>
          <Zoomable muted={s.muted}>
            <MindMap scope={scope} theme={theme} isLight={isLight} />
          </Zoomable>
        </Panel>
      </div>

      {/* weekly footfall + sensor mesh — half each */}
      <div className="grid grid-cols-2 gap-1.5">
        <Panel title="Weekly footfall" dense className={s.card} muted={s.muted}>
          <Columns data={cols} color={theme.markerCore.capital} />
        </Panel>
        <Panel title="Sensor mesh · 90d" dense className={s.card} muted={s.muted}
          right={<span className={`flex items-center gap-1 text-[8.5px] ${s.muted}`}><Zap className="h-2.5 w-2.5" />live</span>}
        >
          <HeatGrid seedRows={heat} colors={[theme.markerCore.city, theme.markerCore.park, theme.glow]} />
        </Panel>
      </div>


      {/* photo sheet */}
      <Sheet open={photo !== null} onClose={() => setPhoto(null)} isLight={isLight} title={photo !== null ? LIVE_PHOTOS[photo].cap : ""}>
        {photo !== null && (
          <div>
            <img src={LIVE_PHOTOS[photo].img} alt={LIVE_PHOTOS[photo].cap} className="h-56 w-full object-cover" />
            <div className="space-y-2 p-3">
              <div className="flex items-center gap-1.5 text-[11px]">
                <Radio className="h-3 w-3" style={{ color: theme.glow }} />
                Captured by field mesh camera · {scope}
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {LIVE_PHOTOS.map((p, i) => (
                  <Tap key={p.cap} color={theme.glow} effect="ripple" onClick={() => setPhoto(i)} className="overflow-hidden rounded-lg">
                    <img src={p.img} alt={p.cap} className="h-14 w-full object-cover" loading="lazy" />
                  </Tap>
                ))}
              </div>
            </div>
          </div>
        )}
      </Sheet>

      {/* sector sheet */}
      <Sheet open={!!sector} onClose={() => setSector(null)} isLight={isLight} title={sector ? `${sector.s} · sector brief` : ""}>
        {sector && (
          <div className="space-y-2 p-3">
            <div className="grid grid-cols-3 gap-1.5">
              <Kpi label="GDP share" value={`${sector.gdp}%`} color={theme.markerCore.city} card={s.card} muted={s.muted} />
              <Kpi label="Jobs" value={sector.jobs.toLocaleString()} color={theme.markerCore.park} card={s.card} muted={s.muted} />
              <Kpi label="YoY" value={`${sector.yoy >= 0 ? "+" : ""}${sector.yoy}%`} color={sector.yoy >= 0 ? theme.markerCore.park : theme.markerCore.landmark} card={s.card} muted={s.muted} />
            </div>
            <Panel title="Output trend" className={s.card} muted={s.muted}>
              <DrawLine series={series.slice(0, 12)} c1={theme.markerCore.capital} c2={theme.glow} />
            </Panel>
            <Panel title="Health ring" className={s.card} muted={s.muted}>
              <div className="flex items-center gap-3">
                <Ring value={Math.min(99, sector.gdp * 3)} color={theme.glow} size={54} />
                <p className="text-[11px] leading-snug">
                  {sector.s} contributes {sector.gdp}% of national output with {sector.jobs.toLocaleString()} recorded jobs.
                  Momentum is {sector.yoy >= 0 ? "positive" : "negative"} at {sector.yoy}% year on year.
                </p>
              </div>
            </Panel>
          </div>
        )}
      </Sheet>

      <div className={`flex items-center gap-1.5 pt-1 text-[9px] uppercase tracking-[0.2em] ${s.muted}`}>
        <Activity className="h-2.5 w-2.5" />
        streaming · {scope}
        <AnimatePresence>
          <motion.span key={Math.round(visitors)} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="ml-auto inline-flex items-center gap-1">
            {uplink > 96 ? <TrendingUp className="h-2.5 w-2.5 text-emerald-400" /> : <TrendingDown className="h-2.5 w-2.5 text-rose-400" />}
            mesh {uplink.toFixed(1)}%
          </motion.span>
        </AnimatePresence>
      </div>
    </div>
  );
}
