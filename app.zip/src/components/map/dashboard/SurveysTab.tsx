import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  AlertTriangle, Brain, Coins, FileText, Filter, Lightbulb, Sparkles, Target, Users,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Kpi, Panel, Ring, Sheet, Tap, useSkin } from "./ui";
import { Columns, DrawLine, Radar } from "./charts";
import { EarnSection } from "./EarnSection";
import { AI_REPORT_LINES, OPPORTUNITIES, RISKS, SURVEYS, type SurveyItem } from "./data";

const CATS = ["All", "Economy", "Social", "Infrastructure", "Environment"] as const;
type Cat = (typeof CATS)[number];
type Section = "earn" | "instruments" | "insights" | "opportunities" | "risks";

const SECTIONS: { k: Section; label: string; icon: React.ReactNode }[] = [
  { k: "earn", label: "Earn", icon: <Coins className="h-3 w-3" /> },
  { k: "instruments", label: "Instruments", icon: <Users className="h-3 w-3" /> },
  { k: "insights", label: "Insights", icon: <Lightbulb className="h-3 w-3" /> },
  { k: "opportunities", label: "Opportunity", icon: <Target className="h-3 w-3" /> },
  { k: "risks", label: "Risk scan", icon: <AlertTriangle className="h-3 w-3" /> },
];


export function SurveysTab({ theme, isLight, scope }: { theme: ThemeSpec; isLight: boolean; scope: string }) {
  const s = useSkin(isLight);
  const [cat, setCat] = useState<Cat>("All");
  const [section, setSection] = useState<Section>("earn");
  const [detail, setDetail] = useState<SurveyItem | null>(null);
  const [report, setReport] = useState<{ step: number; done: boolean } | null>(null);

  const rows = useMemo(() => (cat === "All" ? SURVEYS : SURVEYS.filter((x) => x.category === cat)), [cat]);
  const totalResp = SURVEYS.reduce((a, b) => a + b.responses, 0);
  const avgSent = Math.round(SURVEYS.reduce((a, b) => a + b.sentiment, 0) / SURVEYS.length);

  const runReport = () => {
    setReport({ step: 0, done: false });
    AI_REPORT_LINES.forEach((_, i) => {
      window.setTimeout(() => setReport({ step: i + 1, done: i === AI_REPORT_LINES.length - 1 }), 650 * (i + 1));
    });
  };

  return (
    <div className="space-y-1.5">
      <div className="grid grid-cols-4 gap-1">
        <Kpi label="Responses" value={totalResp.toLocaleString()} color={theme.markerCore.city} card={s.card} muted={s.muted} />
        <Kpi label="Instruments" value={String(SURVEYS.length)} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
        <Kpi label="Sentiment" value={String(avgSent)} suffix="/100" color={theme.markerCore.park} card={s.card} muted={s.muted} />
        <Kpi label="Risks" value={String(RISKS.length)} color={theme.markerCore.landmark} card={s.card} muted={s.muted} />
      </div>

      {/* section tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
        {SECTIONS.map((sec) => (
          <Tap
            key={sec.k} color={theme.glow} effect="squish" onClick={() => setSection(sec.k)}
            className={`flex shrink-0 items-center gap-1 rounded-md px-2 py-[3px] text-[9.5px] font-bold ${section === sec.k ? s.solid : `${s.chip} ${s.muted}`}`}
          >
            {sec.icon}{sec.label}
          </Tap>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={section} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.18 }} className="space-y-1.5">
          {section === "earn" && <EarnSection theme={theme} isLight={isLight} s={s} />}

          {section === "instruments" && (

            <>
              <div className="flex items-center gap-1 overflow-x-auto">
                <Filter className={`h-3 w-3 shrink-0 ${s.muted}`} />
                {CATS.map((c) => (
                  <Tap key={c} color={theme.markerCore.city} effect="squish" onClick={() => setCat(c)}
                    className={`shrink-0 rounded-full px-2 py-[3px] text-[10px] font-semibold ${cat === c ? s.solid : `${s.chip} ${s.muted}`}`}>
                    {c}
                  </Tap>
                ))}
                <span className={`ml-auto shrink-0 text-[9.5px] ${s.muted}`}>{rows.length} shown</span>
              </div>

              {rows.map((r, i) => {
                const pct = Math.round((r.responses / r.target) * 100);
                const open = detail?.id === r.id;
                return (
                  <div key={r.id}>
                    <Tap color={theme.markerCore.city} effect="ripple" onClick={() => setDetail(open ? null : r)} className={`block w-full rounded-md border px-1.5 py-[5px] ${s.card}`}>
                      <motion.div initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i, 6) * 0.02 }}>
                        <div className="flex items-center gap-1.5">
                          <span className="truncate text-[10px] font-bold">{r.title}</span>
                          <span className="shrink-0 rounded-full px-1 py-[1px] text-[8px] font-bold" style={{ background: alpha(theme.glow, 0.15), color: theme.glow }}>
                            {r.category}
                          </span>
                          <span className={`ml-auto shrink-0 text-[9.5px] tabular-nums ${s.muted}`}>{r.responses.toLocaleString()}</span>
                        </div>
                        <div className="mt-[3px] flex items-center gap-1.5">
                          <div className="min-w-0 flex-1"><Bar v={pct} color={pct >= 100 ? theme.markerCore.park : theme.markerCore.city} chip={s.chip} /></div>
                          <span className={`shrink-0 text-[8.5px] tabular-nums ${s.muted}`}>{pct}%</span>
                        </div>
                      </motion.div>
                    </Tap>
                    <Sheet open={open} onClose={() => setDetail(null)} isLight={isLight} title={r.title}>
                      {open && <SurveyDetail d={r} theme={theme} s={s} />}
                    </Sheet>
                  </div>
                );
              })}

            </>
          )}

          {section === "insights" && (
            <>
              <Panel title="AI report engine" className={s.card} muted={s.muted}>
                <div className="flex items-center gap-2">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl" style={{ background: alpha(theme.glow, 0.15) }}>
                    <Brain className="h-4 w-4" style={{ color: theme.glow }} />
                  </span>
                  <p className="min-w-0 flex-1 text-[11px] leading-snug">
                    Generate a weighted executive brief across all instruments for <b>{scope}</b>.
                  </p>
                  <Tap color={theme.glow} effect="glow" onClick={runReport} className="shrink-0 rounded-lg px-2.5 py-1 text-[10.5px] font-bold" style={{ background: theme.glow, color: "#04060d" }}>
                    <span className="inline-flex items-center gap-1"><Sparkles className="h-3 w-3" />Generate</span>
                  </Tap>
                </div>
                {report && (
                  <div className="mt-2 space-y-1">
                    {AI_REPORT_LINES.slice(0, report.step).map((l) => (
                      <motion.div key={l} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} className={`flex items-center gap-1.5 text-[10px] ${s.muted}`}>
                        <span className="h-1 w-1 rounded-full" style={{ background: theme.glow }} />{l}
                      </motion.div>
                    ))}
                    {report.done && (
                      <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={`mt-1 rounded-lg border p-2 text-[11px] leading-snug ${s.card}`}>
                        <div className="mb-1 flex items-center gap-1 text-[10px] font-black uppercase tracking-[0.18em]" style={{ color: theme.glow }}>
                          <FileText className="h-3 w-3" />Executive brief
                        </div>
                        Sentiment across {scope} sits at {avgSent}/100. Economy instruments are strengthening (business confidence +75)
                        while infrastructure instruments — particularly water reliability — continue an eight-wave decline.
                        Priority action: fund solar borehole retrofits in Kgalagadi and stand up a digital skills academy in Francistown.
                      </motion.div>
                    )}
                  </div>
                )}
              </Panel>

              <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                <Panel title="Sentiment by instrument" className={s.card} muted={s.muted}>
                  <Columns data={SURVEYS.map((x) => ({ k: x.title.split(" ")[0], v: x.sentiment }))} color={theme.markerCore.city} />
                </Panel>
                <Panel title="Theme radar" className={s.card} muted={s.muted}>
                  <Radar data={SURVEYS.slice(0, 6).map((x) => ({ k: x.category.slice(0, 4), v: x.sentiment }))} color={theme.glow} />
                </Panel>
              </div>
            </>
          )}

          {section === "opportunities" && OPPORTUNITIES.map((o, i) => (
            <Tap key={o.t} color={theme.markerCore.park} effect="lift" className={`block w-full rounded-lg border px-1.5 py-1 ${s.card}`}>
              <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 6) * 0.03 }} className="flex items-center gap-1.5">
                <Ring value={o.v} color={theme.markerCore.park} size={26} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[10px] font-bold">{o.t}</div>
                  <div className={`truncate text-[9px] ${s.muted}`}>{o.note}</div>
                </div>
                <span className="shrink-0 rounded-full px-1.5 py-[1px] text-[8px] font-black" style={{ background: alpha(theme.markerCore.park, 0.16), color: theme.markerCore.park }}>
                  {o.v}
                </span>
              </motion.div>
            </Tap>
          ))}

          {section === "risks" && RISKS.map((r, i) => {
            const c = r.sev === "high" ? "#ef4444" : r.sev === "medium" ? "#f59e0b" : theme.markerCore.city;
            return (
              <Tap key={r.t} color={c} effect="ripple" className={`block w-full rounded-lg border px-1.5 py-1 ${s.card}`}>
                <motion.div initial={{ opacity: 0, x: 6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i, 6) * 0.03 }}>
                  <div className="flex items-center gap-1.5">
                    <AlertTriangle className="h-3 w-3 shrink-0" style={{ color: c }} />
                    <span className="truncate text-[10px] font-bold">{r.t}</span>
                    <span className="ml-auto shrink-0 rounded-full px-1 py-[1px] text-[8px] font-black uppercase" style={{ background: alpha(c, 0.16), color: c }}>
                      {r.sev}
                    </span>
                  </div>
                  <div className="mt-[3px] flex items-center gap-1.5">
                    <div className="min-w-0 flex-1"><Bar v={r.v} color={c} chip={s.chip} /></div>
                    <span className={`truncate text-[8.5px] ${s.muted}`}>{r.note}</span>
                  </div>
                </motion.div>
              </Tap>
            );
          })}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

/** Inline detail body for one survey — rendered directly under its row. */
function SurveyDetail({ d, theme, s }: { d: any; theme: any; s: any }) {
  return (
    <div className="space-y-1.5 p-2">
      <div className="grid grid-cols-3 gap-1">
        <Kpi label="Responses" value={d.responses.toLocaleString()} color={theme.markerCore.city} card={s.card} muted={s.muted} />
        <Kpi label="Target" value={d.target.toLocaleString()} color={theme.markerCore.capital} card={s.card} muted={s.muted} />
        <Kpi label="Sentiment" value={String(d.sentiment)} suffix="/100" color={theme.markerCore.park} card={s.card} muted={s.muted} />
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        <Panel title="Wave trend" dense className={s.card} muted={s.muted}>
          <DrawLine series={d.trend} c1={theme.markerCore.city} c2={theme.glow} height={30} />
        </Panel>
        <Panel title="Regional intensity" dense className={s.card} muted={s.muted}>
          <div className="space-y-[3px]">
            {d.regions.map((r: any) => (
              <div key={r.r} className="flex items-center gap-1">
                <span className="w-[58px] shrink-0 truncate text-[8.5px] font-semibold">{r.r}</span>
                <div className="min-w-0 flex-1"><Bar v={r.v} color={theme.markerCore.capital} chip={s.chip} /></div>
                <span className={`w-5 shrink-0 text-right text-[8.5px] tabular-nums ${s.muted}`}>{r.v}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
      <Panel title="Headline finding" dense className={s.card} muted={s.muted}>
        <p className="text-[10px] font-semibold leading-snug">{d.topAnswer}</p>
      </Panel>
    </div>
  );
}

