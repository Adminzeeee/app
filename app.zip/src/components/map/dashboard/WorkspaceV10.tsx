import { useEffect, useMemo, useRef, useState } from "react";
import { STATE_LABEL, ago, mutateFinding, removeFinding, uptime, useEngine, type LiveFinding } from "./engineLive";

/* ── palettes: #1 is the original Verity cyan, the rest are bright / mono ── */
export interface Palette {
  id: number;
  name: string;
  vars: Record<string, string>;
}

const PALETTES: Palette[] = [
  {
    id: 1, name: "Verity",
    vars: {
      "--bg-primary": "#0a0a12", "--bg-secondary": "#12121e", "--bg-glass": "rgba(18,18,30,.75)",
      "--border-glass": "rgba(0,240,255,.08)", "--accent": "#00f0ff", "--accent-2": "#7b61ff",
      "--danger": "#ff4466", "--text": "#e0e0e8", "--dim": "#5a5a72",
      "--node": "#16162a", "--node-border": "#2a2a44", "--on-accent": "#04121f",
      "--glow": "0 0 20px rgba(0,240,255,.35), 0 0 60px rgba(0,240,255,.08)",
      "--dots": "rgba(0,240,255,.025)",
    },
  },
  {
    id: 2, name: "Paper",
    vars: {
      "--bg-primary": "#ffffff", "--bg-secondary": "#f4f5f7", "--bg-glass": "rgba(255,255,255,.82)",
      "--border-glass": "rgba(15,23,42,.10)", "--accent": "#0f172a", "--accent-2": "#475569",
      "--danger": "#dc2626", "--text": "#0f172a", "--dim": "#64748b",
      "--node": "#f8fafc", "--node-border": "#e2e8f0", "--on-accent": "#ffffff",
      "--glow": "0 2px 14px rgba(15,23,42,.08)", "--dots": "rgba(15,23,42,.05)",
    },
  },
  {
    id: 3, name: "Ink",
    vars: {
      "--bg-primary": "#000000", "--bg-secondary": "#0b0b0b", "--bg-glass": "rgba(14,14,14,.8)",
      "--border-glass": "rgba(255,255,255,.12)", "--accent": "#ffffff", "--accent-2": "#a3a3a3",
      "--danger": "#ff5f56", "--text": "#f5f5f5", "--dim": "#8a8a8a",
      "--node": "#111111", "--node-border": "#262626", "--on-accent": "#000000",
      "--glow": "0 0 18px rgba(255,255,255,.18)", "--dots": "rgba(255,255,255,.05)",
    },
  },
  {
    id: 4, name: "Citrus",
    vars: {
      "--bg-primary": "#fffdf6", "--bg-secondary": "#fff7e0", "--bg-glass": "rgba(255,253,246,.85)",
      "--border-glass": "rgba(234,88,12,.16)", "--accent": "#ea580c", "--accent-2": "#f59e0b",
      "--danger": "#b91c1c", "--text": "#1c1917", "--dim": "#8a7a68",
      "--node": "#fffaf0", "--node-border": "#f4ddb4", "--on-accent": "#ffffff",
      "--glow": "0 0 16px rgba(234,88,12,.18)", "--dots": "rgba(234,88,12,.06)",
    },
  },
  {
    id: 5, name: "Signal",
    vars: {
      "--bg-primary": "#f6fbff", "--bg-secondary": "#e8f3ff", "--bg-glass": "rgba(246,251,255,.86)",
      "--border-glass": "rgba(29,78,216,.16)", "--accent": "#1d4ed8", "--accent-2": "#0ea5e9",
      "--danger": "#e11d48", "--text": "#0b1b33", "--dim": "#5c7392",
      "--node": "#ffffff", "--node-border": "#cfe2f7", "--on-accent": "#ffffff",
      "--glow": "0 0 16px rgba(29,78,216,.18)", "--dots": "rgba(29,78,216,.06)",
    },
  },
  {
    id: 6, name: "Lime",
    vars: {
      "--bg-primary": "#0c1108", "--bg-secondary": "#131c0e", "--bg-glass": "rgba(19,28,14,.78)",
      "--border-glass": "rgba(183,227,75,.14)", "--accent": "#b7e34b", "--accent-2": "#4ade80",
      "--danger": "#fb7185", "--text": "#eaf3dc", "--dim": "#7e8c68",
      "--node": "#16210f", "--node-border": "#2c3a1d", "--on-accent": "#0c1108",
      "--glow": "0 0 20px rgba(183,227,75,.25)", "--dots": "rgba(183,227,75,.05)",
    },
  },
];

const CSS = `
.v10{font-family:'JetBrains Mono','Fira Code','SF Mono',monospace;
  background:var(--bg-primary);color:var(--text);border:1px solid var(--border-glass);
  border-radius:14px;overflow:hidden;user-select:none;display:flex;flex-direction:column;min-height:100%}
.v10 *{box-sizing:border-box}
.v10 .bar{display:flex;align-items:center;gap:.4rem;height:38px;padding:0 .55rem;
  border-bottom:1px solid var(--border-glass);background:var(--bg-secondary)}
.v10 .title{font-size:.5rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;opacity:.45;white-space:nowrap}
.v10 .acts{display:flex;gap:.25rem;overflow-x:auto;scrollbar-width:none;margin-left:auto}
.v10 .acts::-webkit-scrollbar{display:none}
.v10 .btn{font:inherit;font-size:.5rem;font-weight:600;letter-spacing:.08em;text-transform:uppercase;
  color:var(--dim);background:var(--bg-glass);border:1px solid var(--border-glass);border-radius:8px;
  padding:.3rem .55rem;cursor:pointer;white-space:nowrap;transition:all .25s cubic-bezier(.16,1,.3,1)}
.v10 .btn:hover{color:var(--accent);border-color:var(--accent)}
.v10 .btn.on{color:var(--on-accent);background:var(--accent);border-color:var(--accent);box-shadow:var(--glow)}
.v10 .swatches{display:flex;gap:.25rem;padding:.35rem .55rem;border-bottom:1px solid var(--border-glass);
  background:var(--bg-secondary);overflow-x:auto;scrollbar-width:none}
.v10 .sw{display:flex;align-items:center;gap:.3rem;border:1px solid var(--border-glass);border-radius:20px;
  padding:.2rem .5rem;font-size:.45rem;text-transform:uppercase;letter-spacing:.1em;color:var(--dim);
  background:transparent;cursor:pointer;white-space:nowrap}
.v10 .sw.on{color:var(--accent);border-color:var(--accent)}
.v10 .sw i{width:8px;height:8px;border-radius:50%;display:block}
.v10 .world{position:relative;padding:.55rem;flex:1;display:flex;flex-direction:column;min-height:0;
  background-image:radial-gradient(circle at 1px 1px,var(--dots) 1px,transparent 1px);background-size:40px 40px}
.v10 .vitals{display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.45rem}
.v10 .chip{display:flex;align-items:center;gap:.3rem;background:var(--bg-glass);border:1px solid var(--border-glass);
  border-radius:8px;padding:.24rem .45rem;font-size:.47rem;color:var(--dim)}
.v10 .chip b{color:var(--accent);font-weight:700;font-variant-numeric:tabular-nums}
.v10 .led{width:6px;height:6px;border-radius:50%;background:var(--accent);animation:v10p 2s ease-in-out infinite}
.v10 .led.dim{background:var(--dim);animation:none}
@keyframes v10p{0%,100%{opacity:1}50%{opacity:.25}}
.v10 .surface{background:var(--bg-glass);border:1px solid var(--border-glass);border-radius:12px;padding:.5rem;
  flex:1;min-height:44vh;max-height:60vh;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--node-border) transparent}
.v10 .surface::-webkit-scrollbar{width:4px}
.v10 .surface::-webkit-scrollbar-thumb{background:var(--node-border);border-radius:2px}
.v10 .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:.4rem}
.v10 .node{background:var(--node);border:1.5px solid var(--node-border);border-radius:12px;padding:.45rem;
  display:flex;flex-direction:column;gap:2px;transition:all .3s cubic-bezier(.16,1,.3,1)}
.v10 .node.hot{border-color:var(--accent);box-shadow:var(--glow)}
.v10 .node .nm{font-size:.5rem;font-weight:700;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.v10 .node.hot .nm{color:var(--accent)}
.v10 .node .sub{font-size:.4rem;letter-spacing:.1em;text-transform:uppercase;color:var(--dim)}
.v10 .line{display:flex;gap:.4rem;padding:3px 2px;font-size:.48rem;color:var(--dim);
  border-bottom:1px solid var(--border-glass);animation:v10in .3s ease}
@keyframes v10in{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:none}}
.v10 .line .who{color:var(--accent);flex:0 0 auto;font-weight:700}
.v10 .line .txt{color:var(--text);min-width:0;flex:1}
.v10 .line .t{flex:0 0 auto;opacity:.5;font-size:.42rem}
.v10 .tools{display:flex;gap:.25rem;margin-bottom:.4rem;overflow-x:auto;scrollbar-width:none;align-items:center}
.v10 .tools::-webkit-scrollbar{display:none}
.v10 input.q{font:inherit;font-size:.48rem;color:var(--text);background:var(--node);border:1px solid var(--border-glass);
  border-radius:8px;padding:.26rem .45rem;min-width:90px;flex:1;outline:none}
.v10 .f{font:inherit;font-size:.44rem;text-transform:uppercase;letter-spacing:.08em;color:var(--dim);
  background:transparent;border:1px solid var(--border-glass);border-radius:20px;padding:.2rem .45rem;cursor:pointer;white-space:nowrap}
.v10 .f.on{color:var(--on-accent);background:var(--accent);border-color:var(--accent)}
.v10 .fnd{border:1px solid var(--border-glass);border-radius:10px;padding:.4rem .45rem;margin-bottom:.3rem;
  background:var(--node);cursor:pointer;transition:border-color .25s}
.v10 .fnd.sel{border-color:var(--accent);box-shadow:var(--glow)}
.v10 .fnd .h{display:flex;align-items:baseline;gap:.35rem}
.v10 .fnd .ttl{font-size:.54rem;font-weight:700;color:var(--text);flex:1;min-width:0;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.v10 .fnd.unread .ttl::before{content:"";display:inline-block;width:5px;height:5px;border-radius:50%;
  background:var(--accent);margin-right:5px;vertical-align:middle}
.v10 .fnd .sc{font-size:.55rem;font-weight:700;color:var(--accent);font-variant-numeric:tabular-nums}
.v10 .fnd .meta{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:3px;font-size:.42rem;letter-spacing:.08em;
  text-transform:uppercase;color:var(--dim)}
.v10 .tag{border:1px solid var(--border-glass);border-radius:20px;padding:0 .35rem}
.v10 .tag.risk{color:var(--danger);border-color:var(--danger)}
.v10 .tag.opp{color:var(--accent);border-color:var(--accent)}
.v10 .barline{height:3px;border-radius:2px;background:var(--node-border);margin-top:4px;overflow:hidden}
.v10 .barline i{display:block;height:100%;background:var(--accent);transition:width .5s cubic-bezier(.16,1,.3,1)}
.v10 .insp{margin-top:.45rem;background:var(--bg-glass);border:1px solid var(--border-glass);border-radius:12px;
  padding:.5rem .6rem;font-size:.48rem;color:var(--dim);max-height:34vh;overflow-y:auto}
.v10 .insp .ttl{font-size:.44rem;text-transform:uppercase;letter-spacing:.14em;margin-bottom:.3rem;color:var(--accent)}
.v10 .row{display:flex;justify-content:space-between;gap:.5rem;padding:1px 0}
.v10 .row .val{color:var(--text);font-weight:600;text-align:right}
.v10 .chain{margin-top:.35rem;border-left:1px solid var(--border-glass);padding-left:.45rem}
.v10 .chain div{padding:1px 0;font-size:.44rem}
.v10 .chain b{color:var(--accent);font-weight:700}
.v10 .acts2{display:flex;gap:.25rem;margin-top:.45rem;flex-wrap:wrap}
.v10 .empty{text-align:center;padding:1.2rem 0;color:var(--dim);font-size:.52rem;font-style:italic}
@media(max-width:760px){
  .v10 .grid{grid-template-columns:repeat(auto-fill,minmax(84px,1fr))}
  .v10 .surface{min-height:38vh;max-height:52vh}
}
`;

type Tab = "agents" | "reason" | "feed" | "findings";
const TABS: { k: Tab; label: string }[] = [
  { k: "agents", label: "Agents" },
  { k: "reason", label: "Reason" },
  { k: "feed", label: "Feed" },
  { k: "findings", label: "Findings" },
];

const clock = (t: number) =>
  new Date(t).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

type Kind = "all" | "opportunity" | "risk" | "starred" | "saved" | "unread";
type Sort = "score" | "new" | "confidence" | "az";

const KINDS: { k: Kind; label: string }[] = [
  { k: "all", label: "All" },
  { k: "opportunity", label: "Opps" },
  { k: "risk", label: "Risks" },
  { k: "starred", label: "Starred" },
  { k: "saved", label: "Saved" },
  { k: "unread", label: "Unread" },
];
const SORTS: { k: Sort; label: string }[] = [
  { k: "score", label: "Score" },
  { k: "new", label: "Newest" },
  { k: "confidence", label: "Conf" },
  { k: "az", label: "A–Z" },
];

const PAL_KEY = "bw.v10.palette";

/** v10 — the engine at full power: themable, faster feed, deep findings desk. */
export function WorkspaceV10() {
  const e = useEngine();
  const [tab, setTab] = useState<Tab>("findings");
  const [palId, setPalId] = useState(1);
  const [sel, setSel] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [kind, setKind] = useState<Kind>("all");
  const [sort, setSort] = useState<Sort>("score");
  const [paused, setPaused] = useState(false);
  const frozen = useRef<typeof e.feed>([]);

  useEffect(() => {
    const saved = Number(window.localStorage.getItem(PAL_KEY));
    if (PALETTES.some((p) => p.id === saved)) setPalId(saved);
  }, []);
  useEffect(() => {
    try { window.localStorage.setItem(PAL_KEY, String(palId)); } catch { /* ignore */ }
  }, [palId]);

  const pal = PALETTES.find((p) => p.id === palId)!;

  if (!paused) frozen.current = e.feed;
  const feed = paused ? frozen.current : e.feed;

  const active = useMemo(() => new Set(e.thoughts.slice(0, 6).map((t) => t.agent.id)), [e.thoughts]);
  const agents = useMemo(() => Object.keys(e.states).slice(0, e.agentCount), [e.states, e.agentCount]);
  const agentById = useMemo(() => new Map(e.thoughts.map((t) => [t.agent.id, t.agent])), [e.thoughts]);

  const findings = useMemo(() => {
    let list = e.findings;
    if (kind === "opportunity" || kind === "risk") list = list.filter((f) => f.kind === kind);
    if (kind === "starred") list = list.filter((f) => f.fav);
    if (kind === "saved") list = list.filter((f) => f.saved);
    if (kind === "unread") list = list.filter((f) => !f.read);
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter((f) => (f.title + f.detail + f.region + f.sector).toLowerCase().includes(s));
    }
    const by: Record<Sort, (a: LiveFinding, b: LiveFinding) => number> = {
      score: (a, b) => b.score - a.score,
      new: (a, b) => b.when - a.when,
      confidence: (a, b) => b.confidence - a.confidence,
      az: (a, b) => a.title.localeCompare(b.title),
    };
    return [...list].sort(by[sort]);
  }, [e.findings, kind, q, sort]);

  const inspected = e.findings.find((f) => f.id === sel) ?? findings[0];
  const unread = e.findings.filter((f) => !f.read).length;
  const risks = e.findings.filter((f) => f.kind === "risk").length;
  const avgConf = Math.round(e.findings.reduce((a, b) => a + b.confidence, 0) / Math.max(1, e.findings.length));

  const open = (f: LiveFinding) => {
    setSel(f.id);
    if (!f.read) mutateFinding(f.id, { read: true });
  };

  const style = pal.vars as unknown as React.CSSProperties;

  return (
    <div className="v10" style={style}>
      <style>{CSS}</style>

      <div className="bar">
        <span className="title">Verity Engine · v10</span>
        <div className="acts">
          {TABS.map((t) => (
            <button key={t.k} className={`btn${tab === t.k ? " on" : ""}`} onClick={() => setTab(t.k)}>
              {t.label}{t.k === "findings" && unread > 0 ? ` ${unread}` : ""}
            </button>
          ))}
        </div>
      </div>

      <div className="swatches">
        {PALETTES.map((p) => (
          <button key={p.id} className={`sw${p.id === palId ? " on" : ""}`} onClick={() => setPalId(p.id)}>
            <i style={{ background: p.vars["--accent"], boxShadow: `0 0 6px ${p.vars["--accent"]}` }} />
            {p.id}. {p.name}
          </button>
        ))}
      </div>

      <div className="world">
        <div className="vitals">
          <span className="chip"><span className="led" /><b>{uptime(e.runtimeMs)}</b></span>
          <span className="chip">agents <b>{e.agentCount}</b></span>
          <span className="chip">ops <b>{e.ops.toLocaleString()}</b></span>
          <span className="chip">findings <b>{e.findings.length}</b></span>
          <span className="chip">risks <b>{risks}</b></span>
          <span className="chip">avg conf <b>{avgConf}%</b></span>
          <span className="chip">packets <b>{e.feed.length}</b></span>
        </div>

        <div className="surface">
          {tab === "agents" && (
            <div className="grid">
              {agents.map((id) => {
                const a = agentById.get(id);
                const st = e.states[id];
                const hot = active.has(id);
                return (
                  <div key={id} className={`node${hot ? " hot" : ""}`}>
                    <span className={`led${hot ? "" : " dim"}`} />
                    <span className="nm">{a?.name ?? id.toUpperCase()}</span>
                    <span className="sub">{st ? STATE_LABEL[st] : "idle"}</span>
                  </div>
                );
              })}
            </div>
          )}

          {tab === "reason" && (e.thoughts.length === 0 ? (
            <div className="empty">awaiting first reasoning trace…</div>
          ) : e.thoughts.slice(0, 60).map((t) => (
            <div key={t.id} className="line">
              <span className="who">{t.agent.name}</span>
              <span className="txt">{t.text}</span>
              <span className="t">{clock(t.when)}</span>
            </div>
          )))}

          {tab === "feed" && (
            <>
              <div className="tools">
                <button className={`f${paused ? " on" : ""}`} onClick={() => setPaused((v) => !v)}>
                  {paused ? "Resume" : "Pause"}
                </button>
                <span className="f">{feed.length} packets buffered</span>
              </div>
              {feed.length === 0 ? <div className="empty">no packets received yet…</div> : feed.slice(0, 90).map((f) => (
                <div key={f.id} className="line">
                  <span className="who">{f.src.kind.toUpperCase()}</span>
                  <span className="txt">{f.text}</span>
                  <span className="t">{clock(f.when)}</span>
                </div>
              ))}
            </>
          )}

          {tab === "findings" && (
            <>
              <div className="tools">
                <input className="q" value={q} onChange={(ev) => setQ(ev.target.value)} placeholder="search findings, regions, sectors" />
                {SORTS.map((x) => (
                  <button key={x.k} className={`f${sort === x.k ? " on" : ""}`} onClick={() => setSort(x.k)}>{x.label}</button>
                ))}
              </div>
              <div className="tools">
                {KINDS.map((x) => (
                  <button key={x.k} className={`f${kind === x.k ? " on" : ""}`} onClick={() => setKind(x.k)}>{x.label}</button>
                ))}
              </div>
              {findings.length === 0 ? <div className="empty">nothing matches that filter…</div> : findings.map((f) => (
                <div key={f.id} className={`fnd${f.id === inspected?.id ? " sel" : ""}${f.read ? "" : " unread"}`} onClick={() => open(f)}>
                  <div className="h">
                    <span className="ttl">{f.title}</span>
                    <span className="sc">{f.score}</span>
                  </div>
                  <div className="meta">
                    <span className={`tag ${f.kind === "risk" ? "risk" : "opp"}`}>{f.kind}</span>
                    <span className="tag">{f.region}</span>
                    <span className="tag">{f.sector}</span>
                    <span className="tag">{f.value}</span>
                    <span>{ago(f.when)}</span>
                    {f.fav && <span className="tag">★</span>}
                    {f.saved && <span className="tag">saved</span>}
                  </div>
                  <div className="barline"><i style={{ width: `${f.confidence}%` }} /></div>
                </div>
              ))}
            </>
          )}
        </div>

        {tab === "findings" && inspected && (
          <div className="insp">
            <div className="ttl">Inspector · {inspected.kind}</div>
            <div className="row"><span>{inspected.title}</span></div>
            <div className="row"><span>detail</span><span className="val">{inspected.detail}</span></div>
            <div className="row"><span>region / sector</span><span className="val">{inspected.region} · {inspected.sector}</span></div>
            <div className="row"><span>score</span><span className="val">{inspected.score}/100</span></div>
            <div className="row"><span>confidence</span><span className="val">{inspected.confidence}%</span></div>
            <div className="row"><span>value</span><span className="val">{inspected.value}</span></div>
            <div className="row"><span>lead agent</span><span className="val">{inspected.agent}</span></div>
            <div className="row"><span>first seen</span><span className="val">{ago(inspected.when)}</span></div>

            <div className="chain">
              <div><b>evidence</b> 3 corroborating sources · 1 disputed</div>
              <div><b>chain</b> sensor mesh → directory delta → survey wave 15</div>
              <div><b>method</b> HDBSCAN cluster + synthetic control (n=400)</div>
              <div><b>next check</b> in {5 + (inspected.score % 20)} minutes</div>
              <div><b>owner</b> unassigned · SLA {inspected.kind === "risk" ? "24h" : "7d"}</div>
            </div>

            <div className="acts2">
              <button className={`btn${inspected.fav ? " on" : ""}`} onClick={() => mutateFinding(inspected.id, { fav: !inspected.fav })}>★ Star</button>
              <button className={`btn${inspected.saved ? " on" : ""}`} onClick={() => mutateFinding(inspected.id, { saved: !inspected.saved })}>Save</button>
              <button className="btn" onClick={() => mutateFinding(inspected.id, { score: Math.min(100, inspected.score + 5) })}>Escalate</button>
              <button className="btn" onClick={() => navigator.clipboard?.writeText(`${inspected.title} — ${inspected.detail}`)}>Copy</button>
              <button className="btn" onClick={() => { removeFinding(inspected.id); setSel(null); }}>Dismiss</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
