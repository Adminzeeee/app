import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  BadgeCheck, ChevronRight, Eye, Flame, Heart, MapPin, Megaphone, Search, Store,
  TrendingUp, Users,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Bar, Panel, Stars, Tap, useSkin } from "./ui";
import { DrawLine } from "./charts";
import {
  ADS, AD_KINDS, AD_TOTAL, BIZ_CATS, BIZ_TOTAL, DIR_BIZ, DIR_PEOPLE, PEOPLE_CATS,
  PEOPLE_TOTAL, TRENDING_BIZ, TRENDING_SKILLS, type Ad, type DirBiz, type DirPerson,
} from "./directoryData";

type Kind = "people" | "businesses" | "ads";

export function DirectoryTab({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSkin(isLight);
  const [kind, setKind] = useState<Kind>("people");
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);

  const totals: Record<Kind, number> = { people: PEOPLE_TOTAL, businesses: BIZ_TOTAL, ads: AD_TOTAL };
  const icons: Record<Kind, React.ReactNode> = {
    people: <Users className="h-2.5 w-2.5" />,
    businesses: <Store className="h-2.5 w-2.5" />,
    ads: <Megaphone className="h-2.5 w-2.5" />,
  };

  const people = useMemo(() => DIR_PEOPLE.filter((p) =>
    (!cat || p.cat === cat) && (p.name + p.role + p.city + p.cat).toLowerCase().includes(q.toLowerCase())), [q, cat]);
  const biz = useMemo(() => DIR_BIZ.filter((b) =>
    (!cat || b.cat === cat) && (b.name + b.cat + b.city).toLowerCase().includes(q.toLowerCase())), [q, cat]);
  const ads = useMemo(() => ADS.filter((a) =>
    (!cat || a.kind === cat) && (a.title + a.city + a.cat + a.by).toLowerCase().includes(q.toLowerCase())), [q, cat]);

  const shown = kind === "people" ? people.length : kind === "businesses" ? biz.length : ads.length;

  return (
    <div className="space-y-1.5">
      {/* top switcher with live counts */}
      <div className="grid grid-cols-3 gap-1">
        {(["people", "businesses", "ads"] as const).map((k) => (
          <Tap key={k} color={theme.glow} effect="squish"
            onClick={() => { setKind(k); setCat(null); setOpenId(null); }}
            className={`flex min-w-0 items-center gap-1 rounded px-1.5 py-[3px] ${kind === k ? s.solid : `${s.chip}`}`}>
            <span className="shrink-0">{icons[k]}</span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[8px] font-bold capitalize leading-none">{k}</span>
              <span className="block text-[9.5px] font-black tabular-nums leading-tight">{totals[k].toLocaleString()}</span>
            </span>
          </Tap>
        ))}
      </div>

      {/* search */}
      <div className={`flex items-center gap-1 rounded-full px-2 py-[3px] ${s.chip}`}>
        <Search className={`h-2.5 w-2.5 shrink-0 ${s.muted}`} />
        <input value={q} onChange={(e) => setQ(e.target.value)}
          placeholder={kind === "ads" ? "Search ads, price, town…" : "Search name, skill, town…"}
          className="min-w-0 flex-1 bg-transparent text-[9px] outline-none placeholder:opacity-50" />
        {cat && (
          <button onClick={() => setCat(null)} className="shrink-0 rounded-full px-1 text-[7.5px] font-bold"
            style={{ background: alpha(theme.glow, 0.18), color: theme.glow }}>{cat} ×</button>
        )}
        <span className={`shrink-0 text-[8px] tabular-nums ${s.muted}`}>{shown}</span>
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={kind} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.16 }} className="space-y-1.5">

          {/* ---------------- PEOPLE ---------------- */}
          {kind === "people" && (
            <>
              <Panel title="Categories" dense className={s.card} muted={s.muted}>
                <div className="grid grid-cols-2 gap-[3px] sm:grid-cols-3">
                  {PEOPLE_CATS.map((c) => (
                    <Tap key={c.k} color={theme.markerCore.city} effect="squish"
                      onClick={() => setCat(cat === c.k ? null : c.k)}
                      className={`w-full rounded border px-1 py-[2px] ${cat === c.k ? "border-current/50" : "border-current/10"}`}>
                      <div className="truncate text-[7.5px] font-bold leading-tight">{c.k}</div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-[10px] font-black tabular-nums" style={{ color: theme.markerCore.city }}>
                          {c.count.toLocaleString()}
                        </span>
                        <span className="text-[6.5px] font-bold tabular-nums" style={{ color: c.growth >= 0 ? "#22c55e" : "#ef4444" }}>
                          {c.growth >= 0 ? "+" : ""}{c.growth}%
                        </span>
                      </div>
                      <div className={`truncate text-[6.5px] ${s.muted}`}>+{c.today} today</div>
                    </Tap>
                  ))}
                </div>
              </Panel>

              <Panel title="Trending skills · registered today" dense className={s.card} muted={s.muted}
                right={<Flame className="h-2.5 w-2.5" style={{ color: "#f59e0b" }} />}>
                <div className="space-y-[2px]">
                  {TRENDING_SKILLS.map((t) => (
                    <div key={t.k} className="flex items-center gap-1">
                      <span className="w-[62px] shrink-0 truncate text-[8px] font-semibold">{t.k}</span>
                      <span className="w-6 shrink-0 text-[8.5px] font-black tabular-nums" style={{ color: theme.glow }}>{t.today}</span>
                      <div className="min-w-0 flex-1"><Bar v={(t.today / 240) * 100} color={theme.markerCore.city} chip={s.chip} /></div>
                      <span className={`w-[52px] shrink-0 text-right text-[6.5px] tabular-nums ${s.muted}`}>
                        {t.total.toLocaleString()} · +{t.delta}%
                      </span>
                    </div>
                  ))}
                </div>
              </Panel>

              {people.map((p, i) => (
                <PersonRow key={p.id} p={p} i={i} theme={theme} s={s} isLight={isLight}
                  open={openId === p.id} onToggle={() => setOpenId(openId === p.id ? null : p.id)} />
              ))}
            </>
          )}

          {/* ---------------- BUSINESSES ---------------- */}
          {kind === "businesses" && (
            <>
              <Panel title="Sectors" dense className={s.card} muted={s.muted}>
                <div className="grid grid-cols-2 gap-[3px] sm:grid-cols-3">
                  {BIZ_CATS.map((c) => (
                    <Tap key={c.k} color={theme.markerCore.capital} effect="squish"
                      onClick={() => setCat(cat === c.k ? null : c.k)}
                      className={`w-full rounded border px-1 py-[2px] ${cat === c.k ? "border-current/50" : "border-current/10"}`}>
                      <div className="truncate text-[7.5px] font-bold leading-tight">{c.k}</div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-[10px] font-black tabular-nums" style={{ color: theme.markerCore.capital }}>
                          {c.count.toLocaleString()}
                        </span>
                        <span className="text-[6.5px] font-bold" style={{ color: c.growth >= 0 ? "#22c55e" : "#ef4444" }}>+{c.growth}%</span>
                      </div>
                      <div className={`truncate text-[6.5px] ${s.muted}`}>+{c.today} today</div>
                    </Tap>
                  ))}
                </div>
              </Panel>

              <Panel title="Fastest growing types" dense className={s.card} muted={s.muted}
                right={<TrendingUp className="h-2.5 w-2.5" style={{ color: "#22c55e" }} />}>
                <div className="space-y-[2px]">
                  {TRENDING_BIZ.map((t) => (
                    <div key={t.k} className="flex items-center gap-1">
                      <span className="w-[62px] shrink-0 truncate text-[8px] font-semibold">{t.k}</span>
                      <span className="w-5 shrink-0 text-[8.5px] font-black tabular-nums" style={{ color: theme.glow }}>{t.today}</span>
                      <div className="min-w-0 flex-1"><Bar v={t.delta} color={theme.markerCore.capital} chip={s.chip} /></div>
                      <span className={`w-[52px] shrink-0 text-right text-[6.5px] tabular-nums ${s.muted}`}>
                        {t.total.toLocaleString()} · +{t.delta}%
                      </span>
                    </div>
                  ))}
                </div>
              </Panel>

              {biz.map((b, i) => (
                <BizRow key={b.id} b={b} i={i} theme={theme} s={s}
                  open={openId === b.id} onToggle={() => setOpenId(openId === b.id ? null : b.id)} />
              ))}
            </>
          )}

          {/* ---------------- ADS ---------------- */}
          {kind === "ads" && (
            <>
              <div className="grid grid-cols-3 gap-1">
                {AD_KINDS.map((a) => (
                  <Tap key={a.k} color={a.color} effect="squish" onClick={() => setCat(cat === a.k ? null : a.k)}
                    className={`w-full rounded border px-1 py-[2px] ${cat === a.k ? "border-current/50" : "border-current/10"}`}
                    style={{ background: cat === a.k ? alpha(a.color, 0.14) : undefined }}>
                    <div className="truncate text-[7.5px] font-bold leading-tight">{a.k}</div>
                    <div className="text-[10px] font-black tabular-nums" style={{ color: a.color }}>{a.count.toLocaleString()}</div>
                    <div className={`truncate text-[6.5px] ${s.muted}`}>+{a.today} today</div>
                  </Tap>
                ))}
              </div>

              <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                {ads.slice(0, 30).map((a, i) => (
                  <AdCard key={a.id} a={a} i={i} theme={theme} s={s}
                    open={openId === a.id} onToggle={() => setOpenId(openId === a.id ? null : a.id)} />
                ))}
              </div>
            </>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

/* ---------- rows ---------- */

function PersonRow({
  p, i, theme, s, isLight, open, onToggle,
}: { p: DirPerson; i: number; theme: ThemeSpec; s: any; isLight: boolean; open: boolean; onToggle: () => void }) {
  return (
    <div>
      <Tap color={theme.markerCore.city} effect="lift" onClick={onToggle}
        className={`block w-full rounded-md border px-1.5 py-1 ${s.card}`}>
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.02 }}
          className="flex items-center gap-1.5">
          <div className="relative shrink-0">
            <img src={p.photo} alt={p.name} className="h-6 w-6 rounded-md object-cover" loading="lazy" decoding="async" />
            <span className="absolute -bottom-0.5 -right-0.5 h-1.5 w-1.5 rounded-full border"
              style={{
                background: p.available === "now" ? "#22c55e" : p.available === "week" ? "#f59e0b" : "#64748b",
                borderColor: isLight ? "#fff" : "#0a0e1a",
              }} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1">
              <span className="truncate text-[9px] font-bold">{p.name}</span>
              {p.verified && <BadgeCheck className="h-2 w-2 shrink-0" style={{ color: theme.markerCore.park }} />}
            </div>
            <div className={`truncate text-[7.5px] ${s.muted}`}>{p.role} · {p.city}</div>
          </div>
          <div className="shrink-0 text-right">
            <div className="text-[8.5px] font-black" style={{ color: theme.glow }}>{p.rate}</div>
            <div className={`flex items-center justify-end gap-0.5 text-[6.5px] tabular-nums ${s.muted}`}>
              <Stars n={p.rating} color={theme.markerCore.landmark} />{p.jobs}j
            </div>
          </div>
          <ChevronRight className={`h-2.5 w-2.5 shrink-0 transition ${open ? "rotate-90" : ""} ${s.muted}`} />
        </motion.div>
      </Tap>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden">
            <div className={`mt-1 space-y-1 rounded-md border p-1.5 ${s.card}`}>
              <p className="text-[8.5px] leading-snug">{p.bio}</p>
              <div className="space-y-[2px]">
                {p.skills.map((k) => (
                  <div key={k.k} className="flex items-center gap-1">
                    <span className="w-[56px] shrink-0 truncate text-[7.5px] font-semibold">{k.k}</span>
                    <div className="min-w-0 flex-1"><Bar v={k.v} color={theme.markerCore.city} chip={s.chip} /></div>
                    <span className={`w-4 shrink-0 text-right text-[7px] tabular-nums ${s.muted}`}>{k.v}</span>
                  </div>
                ))}
              </div>
              <div className={`flex items-center gap-1 text-[7px] ${s.muted}`}>
                <span className={`rounded-full px-1 ${s.chip}`}>{p.cat}</span>
                <span className={`rounded-full px-1 ${s.chip}`}>joined {p.joined}</span>
                <span className={`ml-auto rounded-full px-1 ${s.chip}`}>{p.available}</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function BizRow({
  b, i, theme, s, open, onToggle,
}: { b: DirBiz; i: number; theme: ThemeSpec; s: any; open: boolean; onToggle: () => void }) {
  return (
    <div>
      <Tap color={theme.markerCore.capital} effect="lift" onClick={onToggle}
        className={`block w-full rounded-md border px-1.5 py-1 ${s.card}`}>
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.02 }}
          className="flex items-center gap-1.5">
          <img src={b.photo} alt="" className="h-6 w-6 shrink-0 rounded-md object-cover" loading="lazy" decoding="async" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1">
              <span className="truncate text-[9px] font-bold">{b.name}</span>
              {b.verified && <BadgeCheck className="h-2 w-2 shrink-0" style={{ color: theme.markerCore.park }} />}
            </div>
            <div className={`truncate text-[7.5px] ${s.muted}`}>{b.cat} · {b.city} · {b.staff} staff</div>
          </div>
          <span className="shrink-0 rounded-full px-1 text-[6.5px] font-black"
            style={{ background: b.openNow ? alpha("#22c55e", 0.18) : alpha("#64748b", 0.2), color: b.openNow ? "#22c55e" : "#94a3b8" }}>
            {b.openNow ? "OPEN" : "SHUT"}
          </span>
          <ChevronRight className={`h-2.5 w-2.5 shrink-0 transition ${open ? "rotate-90" : ""} ${s.muted}`} />
        </motion.div>
      </Tap>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden">
            <div className={`mt-1 space-y-1 rounded-md border p-1.5 ${s.card}`}>
              <div className="flex items-center gap-1">
                <Stars n={b.rating} color={theme.markerCore.landmark} />
                <span className={`text-[7.5px] tabular-nums ${s.muted}`}>{b.reviews} reviews</span>
                <span className="ml-auto truncate rounded-full px-1 text-[7px] font-bold"
                  style={{ background: alpha(theme.glow, 0.15), color: theme.glow }}>{b.offer}</span>
              </div>
              <DrawLine series={[40, 46, 43, 52, 58, 55, 63, 68, 65, 74, 78, 84]} c1={theme.markerCore.capital} c2={theme.glow} height={28} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AdCard({
  a, i, theme, s, open, onToggle,
}: { a: Ad; i: number; theme: ThemeSpec; s: any; open: boolean; onToggle: () => void }) {
  const color = AD_KINDS.find((k) => k.k === a.kind)?.color ?? theme.glow;
  return (
    <div>
      <Tap color={color} effect="lift" onClick={onToggle} className={`block w-full overflow-hidden rounded-md border ${s.card}`}>
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.02 }}
          className="flex items-stretch gap-1.5">
          <img src={a.img} alt="" className="h-[42px] w-[52px] shrink-0 object-cover" loading="lazy" decoding="async" />
          <div className="min-w-0 flex-1 py-[3px] pr-1.5">
            <div className="flex items-center gap-1">
              <span className="shrink-0 rounded-full px-1 text-[6.5px] font-black uppercase"
                style={{ background: alpha(color, 0.18), color }}>{a.kind}</span>
              {a.urgent && <span className="shrink-0 rounded-full px-1 text-[6.5px] font-black"
                style={{ background: alpha("#ef4444", 0.18), color: "#ef4444" }}>URGENT</span>}
              <span className={`ml-auto shrink-0 text-[6.5px] ${s.muted}`}>{a.when}</span>
            </div>
            <div className="truncate text-[8.5px] font-bold leading-tight">{a.title}</div>
            <div className="flex items-center gap-1">
              <span className="text-[9px] font-black" style={{ color: theme.glow }}>{a.price}</span>
              <span className={`flex items-center gap-0.5 truncate text-[6.5px] ${s.muted}`}>
                <MapPin className="h-2 w-2" />{a.city}
              </span>
              <span className={`ml-auto flex shrink-0 items-center gap-1 text-[6.5px] tabular-nums ${s.muted}`}>
                <Eye className="h-2 w-2" />{a.views}<Heart className="h-2 w-2" />{a.saved}
              </span>
            </div>
          </div>
        </motion.div>
      </Tap>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden">
            <div className={`mt-1 space-y-1 rounded-md border p-1.5 ${s.card}`}>
              <p className="text-[8.5px] leading-snug">{a.desc}</p>
              <div className={`flex items-center gap-1 text-[7px] ${s.muted}`}>
                <span className={`rounded-full px-1 ${s.chip}`}>{a.cat}</span>
                <span className={`truncate rounded-full px-1 ${s.chip}`}>{a.by}</span>
              </div>
              <div className="flex gap-1">
                <span className="flex-1 rounded py-[2px] text-center text-[8px] font-black"
                  style={{ background: theme.glow, color: "#04060d" }}>Contact</span>
                <span className={`flex-1 rounded border py-[2px] text-center text-[8px] font-bold ${s.card}`}>Save</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
