import { useState } from "react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Tap } from "./ui";
import { WorkspaceTab } from "./WorkspaceTab";
import { WorkspaceV2 } from "./WorkspaceV2";
import { WorkspaceV6 } from "./WorkspaceV6";
import { WorkspaceV7 } from "./WorkspaceV7";
import { WorkspaceV8 } from "./WorkspaceV8";
import { WorkspaceV9 } from "./WorkspaceV9";
import { WorkspaceV10 } from "./WorkspaceV10";
import { WorkspaceV11 } from "./WorkspaceV11";

/** Version switcher across the workspace builds. */
export function WorkspaceShell({
  theme, isLight, scope,
}: { theme: ThemeSpec; isLight: boolean; scope: string }) {
  const [v, setV] = useState<1 | 2 | 6 | 7 | 8 | 9 | 10 | 11>(11);

  return (
    <div>
      <div className="mb-1.5 flex items-center">
        <div className="ml-auto flex items-center gap-[2px] rounded-full p-[2px]" style={{ background: alpha(theme.glow, 0.12) }}>
          {([1, 2, 6, 7, 8, 9, 10, 11] as const).map((n) => (
            <Tap
              key={n} color={theme.glow} effect="squish" onClick={() => setV(n)}
              className="rounded-full px-[6px] py-[2px] text-[8px] font-black"
              style={v === n
                ? { background: theme.glow, color: isLight ? "#fff" : "#04121f" }
                : { color: "inherit", opacity: 0.6 }}
            >
              v{n}
            </Tap>
          ))}
        </div>
      </div>
      {v === 1 && <WorkspaceTab theme={theme} isLight={isLight} scope={scope} />}
      {v === 2 && <WorkspaceV2 theme={theme} isLight={isLight} scope={scope} />}
      {v === 6 && <WorkspaceV6 theme={theme} isLight={isLight} scope={scope} />}
      {v === 7 && <WorkspaceV7 theme={theme} isLight={isLight} scope={scope} />}
      {v === 8 && <WorkspaceV8 />}
      {v === 9 && <WorkspaceV9 />}
      {v === 10 && <WorkspaceV10 />}
      {v === 11 && <WorkspaceV11 theme={theme} isLight={isLight} scope={scope} />}
    </div>
  );
}
