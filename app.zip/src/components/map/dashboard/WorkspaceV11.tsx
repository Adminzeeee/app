/* Workspace v11 — three purpose-built Findings designs.
 * A · Table   : the v2 findings table, filters and tabs removed, timestamps added.
 * B · Money   : opportunity-first cards written for people who need the number.
 * C · Briefing: an editorial digest grouped by what the user should do about it. */
import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  AlertTriangle, ArrowRight, Banknote, Check, ChevronDown, Clock,
  Lightbulb, Search, Sparkles, Target, TrendingUp, Users,
} from "lucide-react";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Panel, Tap, useSkin } from "./ui";
import { DrawLine } from "./charts";
import { V11_FINDINGS, V11_KIND_META, relStamp, stampTime, type V11Finding, type V11Kind } from "./findingsV11";

const KIND_ICON: Record<V11Kind, React.ReactNode> = {
  opportunity: <Sparkles className="h-2.5 w-2.5" />,
  gap: <Target className="h-2.5 w-2.5" />,
  insight: <Lightbulb className="h-2.5 w-2.5" />,
  risk: <AlertTriangle className="h-2.5 w-2.5" />,
};

const LAYOUTS = [
  { k: "table", label: "Table" },
  { k: "money", label: "Money" },
  { k: "brief", label: "Briefing" },
] as const;
type LayoutKey = (typeof LAYOUTS)[number]["k"];

export function WorkspaceV11({ theme, isLight }: { theme: ThemeSpec; isLight: boolean; scope?: string }) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [layout, setLayout] = useState<LayoutKey>("table");

  return (
    <div className="space-y-1.5 pb-6">
      <div className="flex items-center gap-1">
        <div className="min-w-0">
          <div className="text-[12.5px] font-black leading-none" style={{ fontFamily: "'Sora',sans-serif" }}>Findings</div>
          <div className={`mt-[2px] text-[7.5px] ${s.muted}`}>
            {V11_FINDINGS.length} live · last refresh {relStamp(V11_FINDINGS[0].updated)}
          </div>
        </div>
        <div className="ml-auto flex items-center gap-[2px] rounded-full p-[2px]" style={{ background: alpha(g, 0.12) }}>
          {LAYOUTS.map((l) => (
            <Tap key={l.k} color={g} effect="squish" onClick={() => setLayout(l.k)}
              className="rounded-full px-[7px] py-[2px] text-[8px] font-black"
              style={layout === l.k ? { background: g, color: isLight ? "#fff" : "#04121f" } : { opacity: 0.6 }}>
              {l.label}
            </Tap>
          ))}
        </div>
      </div>

      {layout === "table" && <TableLayout g={g} s={s} isLight={isLight} />}
      {layout === "money" && <MoneyLayout g={g} s={s} />}
      {layout === "brief" && <BriefLayout g={g} s={s} />}
    </div>
  );
}

/* ================= A · TABLE (v2 UI, no filters, with timestamps) ============ */

function TableLayout({ g, s, isLight }: { g: string; s: ReturnType<typeof useSkin>; isLight: boolean }) {
  const [sel, setSel] = useState<string[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const rows = useMemo(() => [...V11_FINDINGS].sort((a, b) => b.score - a.score), []);
  const toggleSel = (id: string) => setSel((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  return (
    <>
      <div className={`flex items-center gap-1 rounded-md border px-1.5 py-[4px] text-[8px] ${s.card}`}>
        <button onClick={() => setSel(sel.length === rows.length ? [] : rows.map((r) => r.id))} className="font-bold" style={{ color: g }}>
          {sel.length === rows.length && rows.length > 0 ? "deselect all" : "select all"}
        </button>
        <span className={s.muted}>{sel.length} selected · {rows.length} rows</span>
        <span className={`ml-auto flex items-center gap-1 ${s.muted}`}>
          <Clock className="h-2.5 w-2.5" />updated {relStamp(rows[0].updated)}
        </span>
      </div>

      <div className={`grid items-center gap-1 rounded-t border-b px-1.5 py-[3px] text-[7px] font-black uppercase tracking-wider ${s.muted} ${s.line}`}
        style={{ gridTemplateColumns: "12px 1fr 26px 26px 26px 46px" }}>
        <span />
        <span>Finding</span>
        <span className="text-right">Sc</span>
        <span className="text-right">Cf</span>
        <span className="text-right">Im</span>
        <span className="text-right">Value</span>
      </div>

      <div className="space-y-[2px]">
        {rows.map((f) => (
          <V11Row key={f.id} f={f} g={g} s={s} isLight={isLight}
            selected={sel.includes(f.id)} onSelect={() => toggleSel(f.id)}
            expanded={open === f.id} onToggle={() => setOpen(open === f.id ? null : f.id)} />
        ))}
      </div>
    </>
  );
}

function V11Row({
  f, g, s, isLight, selected, onSelect, expanded, onToggle,
}: {
  f: V11Finding; g: string; s: ReturnType<typeof useSkin>; isLight: boolean;
  selected: boolean; onSelect: () => void; expanded: boolean; onToggle: () => void;
}) {
  const k = V11_KIND_META[f.kind];
  return (
    <div className={`rounded border ${s.card}`} style={selected ? { borderColor: alpha(g, 0.6), background: alpha(g, 0.05) } : undefined}>
      <div className="grid items-center gap-1 px-1.5 py-[4px]" style={{ gridTemplateColumns: "12px 1fr 26px 26px 26px 46px" }}>
        <button onClick={onSelect} className="grid h-3 w-3 place-items-center rounded-[3px]"
          style={{ background: selected ? g : "transparent", border: `1px solid ${selected ? g : "currentColor"}` }}>
          {selected && <Check className="h-2 w-2" style={{ color: isLight ? "#fff" : "#04121f" }} />}
        </button>
        <button onClick={onToggle} className="flex min-w-0 items-center gap-1 text-left">
          <span className="shrink-0" style={{ color: k.color }}>{KIND_ICON[f.kind]}</span>
          <span className="min-w-0">
            <span className="block truncate text-[9px] font-bold">{f.title}</span>
            <span className={`block truncate text-[7px] ${s.muted}`}>
              {f.region} · {f.sector} · {f.horizon} · {relStamp(f.updated)}
            </span>
          </span>
        </button>
        <span className="text-right text-[9px] font-black tabular-nums" style={{ color: g }}>{f.score}</span>
        <span className={`text-right text-[8px] tabular-nums ${s.muted}`}>{f.confidence}</span>
        <span className={`text-right text-[8px] tabular-nums ${s.muted}`}>{f.impact}</span>
        <span className="truncate text-right text-[7.5px] font-bold">{f.value}</span>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-current/10">
            <div className="space-y-1 px-1.5 py-1.5">
              <div className="text-[9px] font-bold leading-snug">{f.headline}</div>
              <div className={`flex flex-wrap items-center gap-x-2 gap-y-[2px] text-[7px] ${s.muted}`}>
                <span>Detected {stampTime(f.detected)}</span>
                <span>Updated {stampTime(f.updated)}</span>
                <span>Owner {f.owner}</span>
                <span className="rounded-full px-1 py-[1px] font-black uppercase tracking-wider" style={{ background: alpha(k.color, 0.16), color: k.color }}>
                  {f.status}
                </span>
              </div>
              <div className="text-[8.5px] leading-snug">{f.summary}</div>
              <div className={`rounded border-l-2 px-1.5 py-1 text-[8px] leading-snug ${s.chip}`} style={{ borderColor: k.color }}>
                <b>Why now · </b>{f.whyNow}
              </div>
              <DrawLine series={f.trend} c1={g} c2={k.color} height={46} />
              <div className="grid grid-cols-3 gap-1">
                {[["Money", f.money.line], ["Payback", f.money.payback], ["Upfront", f.money.upfront]].map(([a, b]) => (
                  <div key={a} className={`rounded px-1.5 py-1 ${s.chip}`}>
                    <div className={`text-[6.5px] font-black uppercase tracking-wider ${s.muted}`}>{a}</div>
                    <div className="text-[8px] font-bold leading-tight">{b}</div>
                  </div>
                ))}
              </div>
              <div className="space-y-[2px]">
                {f.evidence.map((e, i) => (
                  <div key={i} className="flex items-center gap-1 text-[7.5px]">
                    <span className="shrink-0 rounded px-1 py-[1px] font-black uppercase tracking-wider" style={{ background: alpha(g, 0.12), color: g }}>{e.src}</span>
                    <span className="min-w-0 flex-1 truncate">{e.text}</span>
                    <span className={`tabular-nums ${s.muted}`}>{Math.round(e.weight * 100)}%</span>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-1">
                {f.actions.map((a) => (
                  <span key={a} className="rounded-full px-1.5 py-[2px] text-[7.5px] font-bold" style={{ background: alpha(g, 0.12), color: g }}>{a}</span>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================= B · MONEY ================= */

function MoneyLayout({ g, s }: { g: string; s: ReturnType<typeof useSkin> }) {
  const [tab, setTab] = useState<V11Kind>("opportunity");
  const rows = useMemo(() => V11_FINDINGS.filter((f) => f.kind === tab).sort((a, b) => b.score - a.score), [tab]);
  const [open, setOpen] = useState<string | null>(null);

  return (
    <>
      <div className="grid grid-cols-4 gap-1">
        {(Object.keys(V11_KIND_META) as V11Kind[]).map((k) => {
          const meta = V11_KIND_META[k];
          const n = V11_FINDINGS.filter((f) => f.kind === k).length;
          const on = tab === k;
          return (
            <Tap key={k} color={meta.color} effect="squish" onClick={() => setTab(k)}
              className={`rounded-lg border px-1.5 py-1 text-left ${s.card}`}
              style={on ? { borderColor: meta.color, background: alpha(meta.color, 0.1) } : undefined}>
              <div className="flex items-center gap-1" style={{ color: meta.color }}>
                {KIND_ICON[k]}<span className="text-[9px] font-black tabular-nums">{n}</span>
              </div>
              <div className="mt-[1px] truncate text-[7.5px] font-bold">{meta.label}</div>
              <div className={`truncate text-[6.5px] ${s.muted}`}>{meta.blurb}</div>
            </Tap>
          );
        })}
      </div>

      <div className="space-y-1.5">
        {rows.map((f) => {
          const meta = V11_KIND_META[f.kind];
          const isOpen = open === f.id;
          return (
            <div key={f.id} className={`overflow-hidden rounded-xl border ${s.card}`} style={{ borderColor: alpha(meta.color, 0.28) }}>
              <div className="px-2 py-1.5">
                <div className={`flex items-center gap-1 text-[6.5px] font-black uppercase tracking-[0.16em] ${s.muted}`}>
                  <span style={{ color: meta.color }}>{KIND_ICON[f.kind]}</span>
                  <span style={{ color: meta.color }}>{meta.label}</span>
                  <span>· {f.region} · {f.sector}</span>
                  <span className="ml-auto normal-case tracking-normal">{relStamp(f.updated)}</span>
                </div>

                <div className="mt-1 text-[11px] font-black leading-[1.25]" style={{ fontFamily: "'Sora',sans-serif" }}>
                  {f.headline}
                </div>

                <div className="mt-1.5 flex items-stretch gap-1">
                  <div className="min-w-0 flex-1 rounded-lg px-2 py-1.5" style={{ background: alpha(meta.color, 0.12) }}>
                    <div className="flex items-center gap-1 text-[6.5px] font-black uppercase tracking-[0.16em]" style={{ color: meta.color }}>
                      <Banknote className="h-2.5 w-2.5" />On the table
                    </div>
                    <div className="mt-[2px] text-[13px] font-black leading-none tabular-nums">{f.value}</div>
                    <div className={`mt-[2px] text-[7.5px] ${s.muted}`}>{f.money.line}</div>
                  </div>
                  <div className="w-[86px] shrink-0 space-y-1">
                    <Mini label="Payback" v={f.money.payback} s={s} />
                    <Mini label="Upfront" v={f.money.upfront} s={s} />
                  </div>
                </div>

                <div className={`mt-1.5 rounded-lg border-l-2 px-1.5 py-1 text-[8.5px] leading-snug ${s.chip}`} style={{ borderColor: meta.color }}>
                  <b>Why now · </b>{f.whyNow}
                </div>

                <div className="mt-1.5 grid grid-cols-3 gap-1">
                  <Score label="Score" v={f.score} c={g} s={s} />
                  <Score label="Confidence" v={f.confidence} c={g} s={s} />
                  <Score label="Effort" v={f.effort} c={g} s={s} />
                </div>

                <div className="mt-1.5 flex flex-wrap items-center gap-1">
                  {f.actions.slice(0, 2).map((a) => (
                    <span key={a} className="flex items-center gap-1 rounded-full px-2 py-[3px] text-[8px] font-bold"
                      style={{ background: alpha(meta.color, 0.14), color: meta.color }}>
                      <ArrowRight className="h-2.5 w-2.5" />{a}
                    </span>
                  ))}
                  <Tap color={g} effect="squish" onClick={() => setOpen(isOpen ? null : f.id)}
                    className={`ml-auto flex items-center gap-1 rounded-full px-2 py-[3px] text-[8px] font-bold ${s.chip}`}>
                    {isOpen ? "less" : "detail"}
                    <motion.span animate={{ rotate: isOpen ? 180 : 0 }}><ChevronDown className="h-2.5 w-2.5" /></motion.span>
                  </Tap>
                </div>
              </div>

              <AnimatePresence>
                {isOpen && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-current/10">
                    <div className="space-y-1.5 px-2 py-1.5">
                      <div className="text-[8.5px] leading-snug">{f.summary}</div>
                      <div className={`flex items-center gap-1 text-[7.5px] ${s.muted}`}>
                        <Users className="h-2.5 w-2.5" />{f.who}
                      </div>
                      <DrawLine series={f.trend} c1={g} c2={meta.color} height={52} />
                      <div className="space-y-[2px]">
                        {f.evidence.map((e, i) => (
                          <div key={i} className="flex items-center gap-1 text-[7.5px]">
                            <span className="shrink-0 rounded px-1 py-[1px] font-black uppercase tracking-wider" style={{ background: alpha(g, 0.12), color: g }}>{e.src}</span>
                            <span className="min-w-0 flex-1">{e.text}</span>
                          </div>
                        ))}
                      </div>
                      <div className={`flex flex-wrap gap-x-2 text-[7px] ${s.muted}`}>
                        <span>Detected {stampTime(f.detected)}</span>
                        <span>Updated {stampTime(f.updated)}</span>
                        <span>Owner {f.owner}</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </>
  );
}

function Mini({ label, v, s }: { label: string; v: string; s: ReturnType<typeof useSkin> }) {
  return (
    <div className={`rounded-lg px-1.5 py-1 ${s.chip}`}>
      <div className={`text-[6px] font-black uppercase tracking-[0.14em] ${s.muted}`}>{label}</div>
      <div className="text-[7.5px] font-bold leading-tight">{v}</div>
    </div>
  );
}

function Score({ label, v, c, s }: { label: string; v: number; c: string; s: ReturnType<typeof useSkin> }) {
  return (
    <div className={`rounded-lg px-1.5 py-1 ${s.chip}`}>
      <div className="flex items-baseline gap-1">
        <span className="text-[11px] font-black tabular-nums" style={{ color: c }}>{v}</span>
        <span className={`text-[6.5px] font-black uppercase tracking-wider ${s.muted}`}>{label}</span>
      </div>
      <div className="mt-[3px] h-[3px] w-full overflow-hidden rounded-full" style={{ background: alpha(c, 0.15) }}>
        <motion.div initial={{ width: 0 }} animate={{ width: `${v}%` }} className="h-full rounded-full" style={{ background: c }} />
      </div>
    </div>
  );
}

/* ================= C · BRIEFING ================= */

const BUCKETS = [
  { k: "act", label: "Act this week", test: (f: V11Finding) => f.horizon === "30 days" || f.horizon === "90 days" },
  { k: "plan", label: "Plan this quarter", test: (f: V11Finding) => f.horizon === "6 months" },
  { k: "watch", label: "Keep watching", test: (f: V11Finding) => f.horizon === "12 months" },
] as const;

function BriefLayout({ g, s }: { g: string; s: ReturnType<typeof useSkin> }) {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? V11_FINDINGS.filter((f) => (f.headline + f.region + f.sector).toLowerCase().includes(t)) : V11_FINDINGS;
  }, [q]);

  const money = V11_FINDINGS.filter((f) => f.kind === "opportunity").length;

  return (
    <>
      <Panel title="Today's briefing" muted={s.muted} className={s.card}>
        <div className="text-[9.5px] leading-snug">
          <b style={{ color: g }}>{money} money-making opportunities</b> are open right now, the largest worth{" "}
          <b>P41.2M</b> over three years. Two risks crossed their warning line this week and one insight gives you a{" "}
          <b>five-week head start</b> on water complaints.
        </div>
        <div className="mt-1.5 grid grid-cols-4 gap-1">
          {(Object.keys(V11_KIND_META) as V11Kind[]).map((k) => {
            const meta = V11_KIND_META[k];
            return (
              <div key={k} className={`rounded-lg px-1.5 py-1 ${s.chip}`}>
                <div className="flex items-center gap-1" style={{ color: meta.color }}>
                  {KIND_ICON[k]}<span className="text-[10px] font-black tabular-nums">{V11_FINDINGS.filter((f) => f.kind === k).length}</span>
                </div>
                <div className={`truncate text-[6.5px] font-bold ${s.muted}`}>{meta.label}</div>
              </div>
            );
          })}
        </div>
      </Panel>

      <div className={`flex items-center gap-1 rounded-md px-1.5 py-[4px] ${s.chip}`}>
        <Search className="h-2.5 w-2.5 shrink-0 opacity-60" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search findings"
          className="min-w-0 flex-1 bg-transparent text-[9px] outline-none placeholder:opacity-40" />
      </div>

      {BUCKETS.map((b) => {
        const rows = list.filter(b.test).sort((x, y) => y.score - x.score);
        if (!rows.length) return null;
        return (
          <div key={b.k}>
            <div className="mb-1 flex items-center gap-1.5">
              <span className="h-[2px] w-4 rounded-full" style={{ background: g }} />
              <span className="text-[7px] font-black uppercase tracking-[0.2em]" style={{ color: g }}>{b.label}</span>
              <span className={`text-[7px] ${s.muted}`}>{rows.length}</span>
            </div>
            <div className="space-y-1">
              {rows.map((f) => {
                const meta = V11_KIND_META[f.kind];
                return (
                  <article key={f.id} className={`rounded-lg border p-1.5 ${s.card}`}>
                    <div className="flex items-start gap-1.5">
                      <span className="mt-[2px] grid h-5 w-5 shrink-0 place-items-center rounded-lg"
                        style={{ background: alpha(meta.color, 0.14), color: meta.color }}>
                        {KIND_ICON[f.kind]}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="text-[10px] font-black leading-[1.3]">{f.headline}</div>
                        <div className={`mt-[3px] flex flex-wrap items-center gap-x-1.5 text-[7px] ${s.muted}`}>
                          <span className="font-black uppercase tracking-wider" style={{ color: meta.color }}>{meta.label}</span>
                          <span>{f.region}</span><span>·</span><span>{f.sector}</span>
                          <span>·</span><span>{f.owner}</span>
                          <span className="ml-auto">{relStamp(f.updated)}</span>
                        </div>
                        <div className="mt-1 text-[8.5px] leading-snug">{f.whyNow}</div>
                        <div className="mt-1 flex flex-wrap items-center gap-1">
                          <span className="flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[8px] font-black"
                            style={{ background: alpha(meta.color, 0.13), color: meta.color }}>
                            <Banknote className="h-2.5 w-2.5" />{f.value}
                          </span>
                          <span className={`flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[7.5px] font-bold ${s.chip}`}>
                            <TrendingUp className="h-2.5 w-2.5" />score {f.score}
                          </span>
                          <span className={`flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[7.5px] font-bold ${s.chip}`}>
                            <Clock className="h-2.5 w-2.5" />{f.horizon}
                          </span>
                        </div>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {f.actions.map((a) => (
                            <span key={a} className="rounded px-1.5 py-[2px] text-[7.5px] font-bold" style={{ background: alpha(g, 0.1), color: g }}>{a}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        );
      })}
    </>
  );
}
