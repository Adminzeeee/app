/* Directory dummy data — People, Businesses, Ads. */

const U = (id: string, w = 400) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70`;

/* ---------------- people ---------------- */

export interface PersonCat {
  k: string;
  count: number;
  today: number;
  growth: number;
  icon: string;
}

export const PEOPLE_TOTAL = 24_318;

export const PEOPLE_CATS: PersonCat[] = [
  { k: "Trades & Construction", count: 5842, today: 234, growth: 12.4, icon: "hammer" },
  { k: "Drivers & Logistics", count: 3971, today: 118, growth: 8.1, icon: "truck" },
  { k: "Tech & Digital", count: 2884, today: 96, growth: 26.7, icon: "cpu" },
  { k: "Health & Care", count: 2410, today: 61, growth: 5.2, icon: "heart" },
  { k: "Hospitality & Tourism", count: 3120, today: 142, growth: 14.9, icon: "palm" },
  { k: "Agriculture & Livestock", count: 2265, today: 74, growth: 3.4, icon: "leaf" },
  { k: "Education & Training", count: 1508, today: 38, growth: 6.6, icon: "book" },
  { k: "Creative & Media", count: 1418, today: 52, growth: 18.3, icon: "camera" },
  { k: "Security & Facilities", count: 900, today: 27, growth: -2.1, icon: "shield" },
];

export const TRENDING_SKILLS = [
  { k: "Plumbers", today: 234, total: 1892, delta: 31 },
  { k: "Solar installers", today: 187, total: 1204, delta: 62 },
  { k: "Long-haul drivers", today: 118, total: 2610, delta: 9 },
  { k: "Safari guides", today: 96, total: 1440, delta: 24 },
  { k: "Welders", today: 88, total: 1655, delta: 11 },
  { k: "React developers", today: 74, total: 612, delta: 48 },
  { k: "Bricklayers", today: 71, total: 2044, delta: 4 },
  { k: "Enumerators", today: 66, total: 803, delta: 55 },
  { k: "Nurses", today: 52, total: 1290, delta: 7 },
  { k: "Drone pilots", today: 41, total: 288, delta: 73 },
];

export interface DirPerson {
  id: string;
  name: string;
  role: string;
  cat: string;
  city: string;
  rate: string;
  rating: number;
  jobs: number;
  verified: boolean;
  available: "now" | "week" | "booked";
  photo: string;
  bio: string;
  skills: { k: string; v: number }[];
  joined: string;
}

const NAMES = [
  "Neo Kgosi", "Lesedi Moeng", "Tumelo Baruti", "Kefilwe Rantao", "Kagiso Phiri",
  "Boitumelo Seru", "Thabo Mmusi", "Naledi Oitsile", "Mpho Sekgoma", "Gorata Dube",
  "Onalenna Tau", "Kabo Ramotswe", "Tshepo Molefe", "Amantle Sechele", "Bonolo Kgomotso",
  "Katlego Ntsima", "Refilwe Sebina", "Oratile Motsumi", "Goitseone Pule", "Warona Mabiletsa",
];
const ROLES: [string, string][] = [
  ["Master Plumber", "Trades & Construction"],
  ["Solar & Off-grid Engineer", "Trades & Construction"],
  ["Long-haul Driver", "Drivers & Logistics"],
  ["Fleet Coordinator", "Drivers & Logistics"],
  ["React Developer", "Tech & Digital"],
  ["Data & GIS Analyst", "Tech & Digital"],
  ["Registered Nurse", "Health & Care"],
  ["Community Health Worker", "Health & Care"],
  ["Safari Guide", "Hospitality & Tourism"],
  ["Lodge Manager", "Hospitality & Tourism"],
  ["Cattle Agronomist", "Agriculture & Livestock"],
  ["Irrigation Technician", "Agriculture & Livestock"],
  ["Maths Tutor", "Education & Training"],
  ["Enumerator Trainer", "Education & Training"],
  ["Drone & LiDAR Mapper", "Creative & Media"],
  ["Setswana Content Lead", "Creative & Media"],
  ["Site Security Lead", "Security & Facilities"],
  ["Welder / Fabricator", "Trades & Construction"],
  ["Bricklayer", "Trades & Construction"],
  ["Field Surveyor", "Tech & Digital"],
];
const CITIES = ["Gaborone", "Francistown", "Maun", "Kasane", "Ghanzi", "Palapye", "Lobatse", "Serowe", "Jwaneng", "Molepolole"];
const FACES = [
  "photo-1500648767791-00dcc994a43e", "photo-1494790108377-be9c29b29330",
  "photo-1507003211169-0a1dd7228f2d", "photo-1438761681033-6461ffad8d80",
  "photo-1519085360753-af0119f7cbe7", "photo-1544005313-94ddf0286df2",
  "photo-1534528741775-53994a69daeb", "photo-1552374196-c4e7ffc6e126",
  "photo-1487412720507-e7ab37603c6f", "photo-1489424731084-a5d8b219a5bb",
];
const SKILLPOOL = ["Site safety", "Estimating", "Client comms", "Tooling", "Scheduling", "Compliance", "Field QA", "Reporting"];

function seeded(i: number, salt: number) {
  return ((i * 9301 + salt * 49297) % 233280) / 233280;
}

export const DIR_PEOPLE: DirPerson[] = Array.from({ length: 42 }, (_, i) => {
  const [role, cat] = ROLES[i % ROLES.length];
  return {
    id: `p${i}`,
    name: NAMES[i % NAMES.length] + (i >= NAMES.length ? ` ${["Jr.", "II", "Sr."][i % 3]}` : ""),
    role,
    cat,
    city: CITIES[Math.floor(seeded(i, 3) * CITIES.length)],
    rate: `P${Math.round(120 + seeded(i, 7) * 480)}/hr`,
    rating: Math.round((3.9 + seeded(i, 11) * 1.1) * 10) / 10,
    jobs: Math.round(6 + seeded(i, 13) * 240),
    verified: seeded(i, 17) > 0.28,
    available: (["now", "week", "booked"] as const)[Math.floor(seeded(i, 19) * 3)],
    photo: U(FACES[i % FACES.length], 200),
    bio: `${role} operating out of ${CITIES[Math.floor(seeded(i, 3) * CITIES.length)]}. Registered on the national skills directory with verified references.`,
    skills: SKILLPOOL.slice(i % 3, (i % 3) + 4).map((k, j) => ({ k, v: Math.round(58 + seeded(i + j, 23) * 40) })),
    joined: ["today", "2d ago", "1w ago", "3w ago", "2mo ago"][Math.floor(seeded(i, 29) * 5)],
  };
});

/* ---------------- businesses ---------------- */

export const BIZ_TOTAL = 8_642;

export const BIZ_CATS = [
  { k: "Retail & Wholesale", count: 2104, today: 41, growth: 6.1 },
  { k: "Transport & Freight", count: 1288, today: 22, growth: 9.4 },
  { k: "Tourism & Lodging", count: 1512, today: 35, growth: 15.8 },
  { k: "Construction", count: 1096, today: 18, growth: 4.2 },
  { k: "Food & Agri-processing", count: 902, today: 14, growth: 7.7 },
  { k: "Professional Services", count: 866, today: 20, growth: 11.2 },
  { k: "Manufacturing", count: 512, today: 6, growth: 2.3 },
  { k: "Tech & Software", count: 362, today: 11, growth: 29.6 },
];

export const TRENDING_BIZ = [
  { k: "Guest houses", today: 35, total: 1512, delta: 22 },
  { k: "Hardware stores", today: 28, total: 744, delta: 14 },
  { k: "Cold-chain depots", today: 9, total: 96, delta: 68 },
  { k: "Software studios", today: 11, total: 362, delta: 30 },
  { k: "Bakeries", today: 17, total: 588, delta: 8 },
  { k: "Solar installers", today: 21, total: 244, delta: 57 },
];

export interface DirBiz {
  id: string;
  name: string;
  cat: string;
  role: string;
  city: string;
  staff: number;
  rating: number;
  reviews: number;
  openNow: boolean;
  photo: string;
  cover: string;
  verified: boolean;
  offer: string;
}

const BIZ_NAMES = [
  "Kalahari Logistics", "Delta Safari Co.", "Gabs Digital", "Chobe Fresh", "Tsodilo Hardware",
  "Boteti AgriWorks", "Okavango Guest House", "Serowe Steelworks", "Jwaneng Auto Spares",
  "Maun Cold Store", "Palapye Bakery", "Ghanzi Ranch Supply", "Kazungula Clearing",
  "Molepolole Motors", "Lobatse Print House", "Selebi Solar", "Kanye Textiles", "Orapa Tooling",
];
const COVERS = [
  "photo-1601584115197-04ecc0da31d7", "photo-1516426122078-c23e76319801",
  "photo-1522071820081-009f0129c71c", "photo-1488459716781-31db52582fe9",
  "photo-1581092160562-40aa08e78837", "photo-1500534314209-a25ddb2bd429",
];

export const DIR_BIZ: DirBiz[] = Array.from({ length: 24 }, (_, i) => {
  const cat = BIZ_CATS[i % BIZ_CATS.length];
  return {
    id: `b${i}`,
    name: BIZ_NAMES[i % BIZ_NAMES.length] + (i >= BIZ_NAMES.length ? ` ${["North", "South", "West"][i % 3]}` : ""),
    cat: cat.k,
    role: cat.k,
    city: CITIES[Math.floor(seeded(i, 5) * CITIES.length)],
    staff: Math.round(3 + seeded(i, 31) * 180),
    rating: Math.round((3.8 + seeded(i, 37) * 1.2) * 10) / 10,
    reviews: Math.round(8 + seeded(i, 41) * 900),
    openNow: seeded(i, 43) > 0.35,
    photo: U(COVERS[i % COVERS.length], 200),
    cover: U(COVERS[(i + 2) % COVERS.length]),
    verified: seeded(i, 47) > 0.4,
    offer: ["12% off this week", "Free delivery over P5 000", "2 slots left", "New stock arrived", "Bulk pricing available"][i % 5],
  };
});

/* ---------------- ads ---------------- */

export type AdKind = "For sale" | "For rent" | "For hire" | "Wanted" | "Looking for" | "Services";

export const AD_TOTAL = 13_907;

export const AD_KINDS: { k: AdKind; count: number; today: number; color: string }[] = [
  { k: "For sale", count: 5104, today: 312, color: "#22c55e" },
  { k: "For rent", count: 2871, today: 148, color: "#38bdf8" },
  { k: "For hire", count: 1966, today: 96, color: "#a78bfa" },
  { k: "Wanted", count: 1544, today: 71, color: "#f59e0b" },
  { k: "Looking for", count: 1288, today: 64, color: "#f472b6" },
  { k: "Services", count: 1134, today: 55, color: "#2dd4bf" },
];

export interface Ad {
  id: string;
  kind: AdKind;
  title: string;
  price: string;
  city: string;
  when: string;
  views: number;
  saved: number;
  img: string;
  by: string;
  cat: string;
  urgent: boolean;
  desc: string;
}

const AD_SEED: { kind: AdKind; title: string; price: string; cat: string; img: string }[] = [
  { kind: "For sale", title: "Toyota Hilux 2.8 GD-6 (2021)", price: "P385 000", cat: "Vehicles", img: "photo-1533473359331-0135ef1b58bf" },
  { kind: "For sale", title: "3-bed house · Block 8", price: "P1 250 000", cat: "Property", img: "photo-1568605114967-8130f3a36994" },
  { kind: "For sale", title: "Nguni cattle · herd of 24", price: "P168 000", cat: "Livestock", img: "photo-1500595046743-cd271d694d30" },
  { kind: "For sale", title: "Solar inverter 5kW + batteries", price: "P42 500", cat: "Energy", img: "photo-1509391366360-2e959784a276" },
  { kind: "For rent", title: "2-bed flat · Extension 12", price: "P4 800/mo", cat: "Property", img: "photo-1502672260266-1c1ef2d93688" },
  { kind: "For rent", title: "Warehouse 640m² · Lobatse", price: "P28 000/mo", cat: "Commercial", img: "photo-1586528116311-ad8dd3c8310d" },
  { kind: "For rent", title: "Tipper truck · daily hire", price: "P2 100/day", cat: "Equipment", img: "photo-1591768575198-88dac53fbd0a" },
  { kind: "For hire", title: "Certified electrician · same day", price: "P350/hr", cat: "Trades", img: "photo-1621905251189-08b45d6a269e" },
  { kind: "For hire", title: "Event photographer + drone", price: "P2 400/day", cat: "Creative", img: "photo-1452587925148-ce544e77e70d" },
  { kind: "For hire", title: "Mobile welding crew", price: "P4 900/day", cat: "Trades", img: "photo-1504328345606-18bbc8c9d7d1" },
  { kind: "Wanted", title: "Wanted: second-hand water tanks", price: "Negotiable", cat: "Equipment", img: "photo-1541888946425-d81bb19240f5" },
  { kind: "Wanted", title: "Wanted: 20t of maize (bulk)", price: "Market rate", cat: "Agri", img: "photo-1574323347407-f5e1ad6d020b" },
  { kind: "Looking for", title: "Looking for: shared office desk", price: "P900/mo", cat: "Commercial", img: "photo-1497366216548-37526070297c" },
  { kind: "Looking for", title: "Looking for: Setswana translator", price: "P180/hr", cat: "Services", img: "photo-1543269865-cbf427effbad" },
  { kind: "Services", title: "Borehole drilling & testing", price: "From P22 000", cat: "Trades", img: "photo-1466611653911-95081537e5b7" },
  { kind: "Services", title: "Cross-border freight clearing", price: "Quote", cat: "Logistics", img: "photo-1601584115197-04ecc0da31d7" },
];

export const ADS: Ad[] = Array.from({ length: 48 }, (_, i) => {
  const s = AD_SEED[i % AD_SEED.length];
  return {
    id: `a${i}`,
    kind: s.kind,
    title: s.title,
    price: s.price,
    cat: s.cat,
    city: CITIES[Math.floor(seeded(i, 53) * CITIES.length)],
    when: ["12m ago", "1h ago", "4h ago", "today", "2d ago", "5d ago"][Math.floor(seeded(i, 59) * 6)],
    views: Math.round(20 + seeded(i, 61) * 4800),
    saved: Math.round(seeded(i, 67) * 240),
    img: U(s.img, 400),
    by: BIZ_NAMES[i % BIZ_NAMES.length],
    urgent: seeded(i, 71) > 0.78,
    desc: `${s.title} listed in ${CITIES[Math.floor(seeded(i, 53) * CITIES.length)]}. Verified seller, inspection welcome, delivery can be arranged nationwide.`,
  };
});
