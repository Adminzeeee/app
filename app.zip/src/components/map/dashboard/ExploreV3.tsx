import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeftRight, Search } from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData } from "../types";
import { alpha } from "../color";
import { Tap, useSkin } from "./ui";
import type { ExploreProps } from "./ExploreShell";

const DATA = raw as unknown as BotswanaData;

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}
const val = (scope: string, salt: number, min: number, max: number) =>
  Math.round(min + ((hash(scope + salt) % 1000) / 1000) * (max - min));

const METRICS = [
  "Opportunity", "Services", "Talent", "Demand", "Connectivity", "Safety", "Cost of living",
];

/** v3 — Compare: put two places head to head, metric by metric. */
export function ExploreV3({ theme, isLight, place, onSelectPlace }: ExploreProps) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const left = place?.name ?? "Gaborone";
  const [right, setRight] = useState("Maun");
  const [q, setQ] = useState("");
  const [picking, setPicking] = useState(false);

  const options = useMemo(() => {
    const all = DATA.places.map((p) => p.name);
    return (q.trim() ? all.filter((n) => n.toLowerCase().includes(q.toLowerCase())) : all).slice(0, 30);
  }, [q]);

  const swap = () => {
    const p = DATA.places.find((x) => x.name === right);
    if (p) { onSelectPlace?.(p); setRight(left); }
  };

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-1.5">
        <div className="rounded-xl border px-2 py-1.5" style={{ borderColor: alpha(g, 0.2), background: alpha(g, 0.06) }}>
          <div className={`text-[6.5px] font-black uppercase tracking-[0.18em] ${s.muted}`}>selected on map</div>
          <div className="truncate text-[12px] font-black leading-tight">{left}</div>
        </div>
        <Tap color={g} effect="squish" onClick={swap} className="grid h-7 w-7 place-items-center rounded-full" style={{ background: alpha(g, 0.14) }}>
          <ArrowLeftRight className="h-3 w-3" style={{ color: g }} />
        </Tap>
        <Tap color={g} effect="squish" onClick={() => setPicking((v) => !v)}
          className="rounded-xl border px-2 py-1.5" style={{ borderColor: alpha(g, 0.2) }}>
          <div className={`text-[6.5px] font-black uppercase tracking-[0.18em] ${s.muted}`}>compare with</div>
          <div className="truncate text-[12px] font-black leading-tight" style={{ color: g }}>{right}</div>
        </Tap>
      </div>

      {picking && (
        <div className="rounded-xl border p-1.5" style={{ borderColor: alpha(g, 0.16) }}>
          <div className="mb-1 flex items-center gap-1.5">
            <Search className="h-2.5 w-2.5 opacity-50" />
            <input value={q} onChange={(e) => setQ(e.target.value)} autoFocus placeholder="Find a place"
              className="min-w-0 flex-1 bg-transparent text-[9px] font-semibold outline-none placeholder:opacity-35" />
          </div>
          <div className="grid max-h-[140px] grid-cols-2 gap-[2px] overflow-y-auto">
            {options.map((n) => (
              <button key={n} onClick={() => { setRight(n); setPicking(false); }}
                className="truncate rounded-md px-1.5 py-[3px] text-left text-[8.5px] font-semibold"
                style={right === n ? { background: alpha(g, 0.14), color: g } : undefined}>
                {n}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-1.5">
        {METRICS.map((m, i) => {
          const a = val(left, 20 + i, 25, 98);
          const b = val(right, 20 + i, 25, 98);
          return (
            <div key={m}>
              <div className={`mb-[2px] flex items-center justify-between text-[7px] uppercase tracking-[0.14em] ${s.muted}`}>
                <span className="tabular-nums font-black" style={{ color: a >= b ? g : undefined }}>{a}</span>
                <span>{m}</span>
                <span className="tabular-nums font-black" style={{ color: b > a ? g : undefined }}>{b}</span>
              </div>
              <div className="flex items-center gap-[3px]">
                <div className="flex h-[6px] flex-1 justify-end overflow-hidden rounded-full" style={{ background: alpha(g, 0.08) }}>
                  <motion.div className="h-full rounded-full" style={{ background: g, opacity: 0.9 }}
                    initial={{ width: 0 }} animate={{ width: `${a}%` }} transition={{ duration: 0.6, delay: i * 0.03 }} />
                </div>
                <div className="flex h-[6px] flex-1 overflow-hidden rounded-full" style={{ background: alpha(g, 0.08) }}>
                  <motion.div className="h-full rounded-full" style={{ background: g, opacity: 0.45 }}
                    initial={{ width: 0 }} animate={{ width: `${b}%` }} transition={{ duration: 0.6, delay: i * 0.03 }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="rounded-xl border p-2" style={{ borderColor: alpha(g, 0.14) }}>
        <div className={`mb-1 text-[6.5px] font-black uppercase tracking-[0.2em] ${s.muted}`}>verdict</div>
        <div className="text-[10px] font-bold leading-snug">
          {left} leads on {METRICS.filter((m, i) => val(left, 20 + i, 25, 98) >= val(right, 20 + i, 25, 98)).length} of {METRICS.length} measures.
          Strongest gap: {METRICS[hash(left + right) % METRICS.length]}.
        </div>
      </div>
    </div>
  );
}
