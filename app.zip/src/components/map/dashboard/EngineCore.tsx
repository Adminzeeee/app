import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import {
  AlertTriangle, ArrowUpRight, Bookmark, Check, Download, FileText, Filter,
  Pin, Plus, Rss, Satellite, Trash2, Waves,
} from "lucide-react";
import { alpha } from "../color";
import { useSkin, Tap, Bar } from "./ui";
import {
  AGENT_POOL, FEEDS, STATE_LABEL, ago, mutateFinding, removeFinding,
  setAgentCount, uptime, useEngine, type LiveFinding,
} from "./engineLive";
import { NOTE_TAGS, useNotes } from "./notes";

type Common = { theme: { glow: string }; isLight: boolean };

/* ------------------------------------------------------------------ */
/* Shared shell                                                        */
/* ------------------------------------------------------------------ */

function Panel({
  title, right, children, g, isLight, pad = true,
}: { title: string; right?: React.ReactNode; children: React.ReactNode; g: string; isLight: boolean; pad?: boolean }) {
  const s = useSkin(isLight);
  return (
    <section className={`overflow-hidden rounded-xl border ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
      <header className="flex items-center gap-1 px-2 py-[5px]">
        <span className={`text-[7px] font-black uppercase tracking-[0.22em] ${s.muted}`}>{title}</span>
        <span className="ml-auto flex items-center gap-1">{right}</span>
      </header>
      <div className={pad ? "px-2 pb-2" : ""}>{children}</div>
    </section>
  );
}

function Dot({ g, on = true }: { g: string; on?: boolean }) {
  return (
    <motion.span
      className="h-[5px] w-[5px] rounded-full"
      style={{ background: on ? g : alpha(g, 0.3) }}
      animate={on ? { opacity: [1, 0.2, 1] } : { opacity: 0.4 }}
      transition={{ duration: 1.6, repeat: Infinity }}
    />
  );
}

/* ------------------------------------------------------------------ */
/* Engine header                                                       */
/* ------------------------------------------------------------------ */

export function EngineHeader({ theme, isLight, compact }: Common & { compact?: boolean }) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  return (
    <div className={`rounded-xl border px-2 py-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
      <div className="flex items-baseline gap-1.5">
        <Dot g={g} />
        <span className="text-[8px] font-black uppercase tracking-[0.22em]">Always on</span>
        <span className="ml-auto text-[9px] font-black tabular-nums" style={{ color: g }}>{uptime(e.runtimeMs)}</span>
      </div>
      {!compact && (
        <div className="mt-1.5 flex items-end gap-3">
          <Stat label="agents" v={`${e.agentCount}`} g={g} muted={s.muted} />
          <Stat label="ops" v={e.ops.toLocaleString()} g={g} muted={s.muted} />
          <Stat label="findings" v={`${e.findings.length}`} g={g} muted={s.muted} />
          <Stat label="sources" v={`${FEEDS.length}`} g={g} muted={s.muted} />
        </div>
      )}
    </div>
  );
}

function Stat({ label, v, g, muted }: { label: string; v: string; g: string; muted: string }) {
  return (
    <div className="min-w-0">
      <div className="truncate text-[12px] font-black leading-none tabular-nums" style={{ color: g }}>{v}</div>
      <div className={`mt-[2px] truncate text-[6.5px] font-bold uppercase tracking-[0.2em] ${muted}`}>{label}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Agent roster — calm, typographic, no confetti                       */
/* ------------------------------------------------------------------ */

export function AgentRoster({ theme, isLight, height = 150 }: Common & { height?: number }) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  const agents = AGENT_POOL.slice(0, e.agentCount);
  const busy = agents.filter((a) => e.states[a.id] !== "waiting").length;

  return (
    <Panel
      title="Agents"
      g={g}
      isLight={isLight}
      pad={false}
      right={<span className={`text-[7px] tabular-nums ${s.muted}`}>{busy}/{agents.length} active</span>}
    >
      <div className="overflow-y-auto" style={{ height }}>
        {agents.map((a) => {
          const st = e.states[a.id];
          const idle = st === "waiting";
          return (
            <div key={a.id} className="flex items-center gap-1.5 px-2 py-[3px]">
              <span
                className="h-[4px] w-[4px] shrink-0 rounded-full"
                style={{ background: idle ? alpha(g, 0.25) : g }}
              />
              <span className="w-[52px] shrink-0 truncate text-[8px] font-black tracking-[0.08em]">{a.name}</span>
              <span className={`min-w-0 flex-1 truncate text-[7.5px] ${s.muted}`}>{a.focus}</span>
              <span
                className="w-[46px] shrink-0 text-right text-[7px] font-bold lowercase"
                style={{ color: idle ? undefined : g, opacity: idle ? 0.45 : 1 }}
              >
                {STATE_LABEL[st]}
              </span>
              <span className="relative h-[2px] w-8 shrink-0 overflow-hidden rounded-full" style={{ background: alpha(g, 0.12) }}>
                {!idle && (
                  <motion.span
                    className="absolute inset-y-0 w-1/3 rounded-full"
                    style={{ background: g }}
                    animate={{ x: ["-40%", "180%"] }}
                    transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                  />
                )}
              </span>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* Reasoning stream                                                    */
/* ------------------------------------------------------------------ */

export function ThoughtStream({ theme, isLight, height = 150 }: Common & { height?: number }) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  const [head, ...rest] = e.thoughts;

  return (
    <Panel
      title="Reasoning"
      g={g}
      isLight={isLight}
      pad={false}
      right={<Dot g={g} />}
    >
      <div className="px-2 pb-1">
        <div className="text-[7px] font-bold uppercase tracking-[0.2em]" style={{ color: g }}>
          {head ? head.agent.name : "booting"}
        </div>
        <div className="text-[9px] font-semibold leading-snug">
          {head ? head.text : "warming up"}
          <motion.span
            className="ml-[2px] inline-block h-[9px] w-[4px] translate-y-[1px]"
            style={{ background: g }}
            animate={{ opacity: [1, 0, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
          />
        </div>
      </div>
      <div className="relative overflow-y-auto px-2 pb-1.5" style={{ height }}>
        <span className="absolute bottom-1 left-[9px] top-0 w-px" style={{ background: alpha(g, 0.15) }} />
        <AnimatePresence initial={false}>
          {rest.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative flex gap-1.5 py-[2px] pl-3"
            >
              <span className="absolute left-[6px] top-[7px] h-[3px] w-[3px] rounded-full" style={{ background: alpha(g, 0.5) }} />
              <span className={`w-[46px] shrink-0 truncate text-[6.5px] font-black uppercase tracking-[0.12em] ${s.muted}`}>
                {t.agent.name}
              </span>
              <span className="min-w-0 flex-1 text-[7.5px] leading-snug opacity-75">{t.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* Live feeds                                                          */
/* ------------------------------------------------------------------ */

function feedIcon(k: string) {
  return k === "rss" ? <Rss className="h-2 w-2" />
    : k === "api" ? <Satellite className="h-2 w-2" />
      : k === "sensor" ? <Waves className="h-2 w-2" /> : <Rss className="h-2 w-2" />;
}

export function FeedPanel({ theme, isLight, height = 150 }: Common & { height?: number }) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  return (
    <Panel
      title="Incoming"
      g={g}
      isLight={isLight}
      pad={false}
      right={<span className={`text-[7px] ${s.muted}`}>{FEEDS.length} sources</span>}
    >
      <div className="overflow-y-auto px-2 pb-1.5" style={{ height }}>
        <AnimatePresence initial={false}>
          {e.feed.map((f) => (
            <motion.div key={f.id} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="flex items-start gap-1.5 py-[3px]">
              <span className="mt-[2px] shrink-0 opacity-60" style={{ color: g }}>{feedIcon(f.src.kind)}</span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[8px] font-semibold leading-snug">{f.text}</span>
                <span className={`block truncate text-[6.5px] uppercase tracking-[0.12em] ${s.muted}`}>
                  {f.src.label.split(" · ")[0]} · {ago(f.when)}
                </span>
              </span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Panel>
  );
}

/** Compact strip of every source and whether it is receiving right now. */
export function SourceGrid({ theme, isLight }: Common) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  return (
    <Panel title="Sources" g={g} isLight={isLight}>
      <div className="grid grid-cols-2 gap-x-2 gap-y-[3px]">
        {FEEDS.map((f, i) => {
          const live = (Math.floor(e.runtimeMs / 1000) + i) % Math.max(3, Math.round(f.cadence / 2)) === 0;
          return (
            <div key={f.k} className="flex min-w-0 items-center gap-1">
              <span className="h-[4px] w-[4px] shrink-0 rounded-full" style={{ background: live ? g : alpha(g, 0.22) }} />
              <span className="min-w-0 flex-1 truncate text-[7.5px] font-semibold">{f.label.split(" · ")[0]}</span>
              <span className={`shrink-0 text-[6.5px] uppercase tracking-[0.14em] ${s.muted}`}>
                {live ? "in" : "idle"}
              </span>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------------ */
/* Fine-tuning                                                         */
/* ------------------------------------------------------------------ */

export function EngineTuning({ theme, isLight }: Common) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  const [depth, setDepth] = useState(2);
  const [risk, setRisk] = useState(55);
  const DEPTHS = ["Sweep", "Standard", "Deep", "Exhaustive"];

  return (
    <Panel title="Tuning" g={g} isLight={isLight}>
      <div className="mb-1.5">
        <div className={`mb-[3px] flex justify-between text-[7px] ${s.muted}`}>
          <span className="uppercase tracking-[0.16em]">Agents</span>
          <span className="tabular-nums" style={{ color: g }}>{e.agentCount}</span>
        </div>
        <input type="range" min={8} max={20} step={1} value={e.agentCount}
          onChange={(ev) => setAgentCount(Number(ev.target.value))}
          className="w-full" style={{ accentColor: g }} />
      </div>

      <div className="mb-1.5 grid grid-cols-4 gap-1">
        {DEPTHS.map((d, i) => (
          <Tap key={d} color={g} effect="squish" onClick={() => setDepth(i)}
            className="rounded-md py-[3px] text-center text-[7px] font-black uppercase tracking-[0.1em]"
            style={depth === i
              ? { background: g, color: isLight ? "#fff" : "#04121f" }
              : { background: alpha(g, 0.08) }}>
            {d}
          </Tap>
        ))}
      </div>

      <div className="mb-1.5">
        <div className={`mb-[3px] flex justify-between text-[7px] ${s.muted}`}>
          <span className="uppercase tracking-[0.16em]">Risk sensitivity</span>
          <span className="tabular-nums" style={{ color: g }}>{risk}</span>
        </div>
        <input type="range" min={0} max={100} value={risk}
          onChange={(ev) => setRisk(Number(ev.target.value))} className="w-full" style={{ accentColor: g }} />
      </div>

      <div className="grid grid-cols-2 gap-2">
        <MetricBar label="Throughput" v={62 + (e.agentCount - 8) * 3} color={g} chip={s.chip} muted={s.muted} />
        <MetricBar label="Confidence" v={54 + depth * 11} color={g} chip={s.chip} muted={s.muted} />
      </div>
    </Panel>
  );
}

function MetricBar({ label, v, color, chip, muted }: { label: string; v: number; color: string; chip: string; muted: string }) {
  return (
    <div>
      <div className={`mb-[2px] flex justify-between text-[6.5px] uppercase tracking-[0.14em] ${muted}`}>
        <span>{label}</span><span className="tabular-nums">{Math.min(100, v)}%</span>
      </div>
      <Bar v={Math.min(100, v)} color={color} chip={chip} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Findings — monochrome, opportunities above risks                    */
/* ------------------------------------------------------------------ */

type SortKey = "new" | "score" | "confidence" | "region";
const SORTS: { k: SortKey; label: string }[] = [
  { k: "new", label: "Newest" },
  { k: "score", label: "Score" },
  { k: "confidence", label: "Conf." },
  { k: "region", label: "Region" },
];

export function FindingsBoard({ theme, isLight }: Common) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  const [sort, setSort] = useState<SortKey>("new");
  const [view, setView] = useState<"opportunity" | "risk">("opportunity");
  const [filter, setFilter] = useState<"all" | "unread" | "pinned">("all");
  const [open, setOpen] = useState<string | null>(null);
  const [sortOpen, setSortOpen] = useState(false);

  const sortFn = (a: LiveFinding, b: LiveFinding) =>
    sort === "new" ? b.when - a.when
      : sort === "score" ? b.score - a.score
        : sort === "confidence" ? b.confidence - a.confidence
          : a.region.localeCompare(b.region);

  const counts = useMemo(() => ({
    opportunity: e.findings.filter((f) => f.kind === "opportunity").length,
    risk: e.findings.filter((f) => f.kind === "risk").length,
    unread: e.findings.filter((f) => !f.read).length,
  }), [e.findings]);

  const list = useMemo(
    () => e.findings
      .filter((f) => f.kind === view)
      .filter((f) => filter === "all" || (filter === "unread" ? !f.read : f.fav))
      .sort(sortFn),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [e.findings, view, filter, sort],
  );

  return (
    <div>
      {/* opportunity / risk switch */}
      <div className="mb-1.5 flex rounded-lg p-[2px]" style={{ background: alpha(g, 0.07) }}>
        {([["opportunity", "Opportunities", counts.opportunity], ["risk", "Risks", counts.risk]] as const).map(([k, label, n]) => (
          <Tap key={k} color={g} effect="squish" onClick={() => { setView(k); setOpen(null); }}
            className="flex flex-1 items-center justify-center gap-1 rounded-md py-[5px] text-[9px] font-black"
            style={view === k
              ? { background: g, color: isLight ? "#fff" : "#04121f" }
              : { opacity: 0.55 }}>
            {k === "risk" ? <AlertTriangle className="h-2.5 w-2.5" /> : <ArrowUpRight className="h-2.5 w-2.5" />}
            {label}
            <span className="tabular-nums opacity-70">{n}</span>
          </Tap>
        ))}
      </div>

      {/* filter + sort */}
      <div className="mb-1 flex items-center gap-1">
        {(["all", "unread", "pinned"] as const).map((k) => (
          <button key={k} onClick={() => setFilter(k)}
            className="rounded-full px-2 py-[2px] text-[7.5px] font-bold capitalize"
            style={filter === k ? { background: alpha(g, 0.18), color: g } : { opacity: 0.5 }}>
            {k}{k === "unread" && counts.unread ? ` ${counts.unread}` : ""}
          </button>
        ))}
        <div className="relative ml-auto">
          <button onClick={() => setSortOpen((v) => !v)}
            className="flex items-center gap-1 rounded-full px-2 py-[2px] text-[7.5px] font-bold"
            style={{ background: alpha(g, 0.1), color: g }}>
            <Filter className="h-2.5 w-2.5" />
            {SORTS.find((x) => x.k === sort)!.label}
          </button>
          <AnimatePresence>
            {sortOpen && (
              <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
                className={`absolute right-0 top-5 z-20 w-[96px] overflow-hidden rounded-lg border ${isLight ? "border-slate-900/10 bg-white" : "border-white/12 bg-[#0a1020]"}`}>
                {SORTS.map((o) => (
                  <button key={o.k} onClick={() => { setSort(o.k); setSortOpen(false); }}
                    className="block w-full px-2 py-1 text-left text-[8px] font-bold"
                    style={{ color: sort === o.k ? g : undefined, opacity: sort === o.k ? 1 : 0.65 }}>
                    {o.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className={`mb-1 text-[6.5px] uppercase tracking-[0.14em] ${s.muted}`}>
        tap to read · swipe left dismiss · swipe right save
      </div>

      <div className="max-h-[360px] overflow-y-auto pr-0.5">
        <AnimatePresence initial={false}>
          {list.map((f) => (
            <FindingRow key={f.id} f={f} g={g} isLight={isLight} open={open === f.id}
              onOpen={() => { mutateFinding(f.id, { read: true }); setOpen(open === f.id ? null : f.id); }} />
          ))}
        </AnimatePresence>
        {list.length === 0 && (
          <div className={`rounded-lg border px-3 py-5 text-center text-[8px] ${s.card} ${s.muted}`} style={{ borderColor: alpha(g, 0.14) }}>
            Nothing here yet — the engine is still working.
          </div>
        )}
      </div>
    </div>
  );
}

function Group({ label, count, icon, g, muted }: { label: string; count: number; icon: React.ReactNode; g: string; muted: string }) {
  return (
    <div className="mb-1 flex items-center gap-1">
      <span style={{ color: g }}>{icon}</span>
      <span className="text-[7px] font-black uppercase tracking-[0.22em]">{label}</span>
      <span className={`text-[7px] tabular-nums ${muted}`}>{count}</span>
      <span className="ml-1 h-px flex-1" style={{ background: alpha(g, 0.12) }} />
    </div>
  );
}

function FindingRow({
  f, g, isLight, open, onOpen,
}: { f: LiveFinding; g: string; isLight: boolean; open: boolean; onOpen: () => void }) {
  const s = useSkin(isLight);
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0, marginBottom: 0 }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.3}
      onDragEnd={(_, info) => {
        if (info.offset.x < -90) removeFinding(f.id);
        else if (info.offset.x > 90) mutateFinding(f.id, { saved: true, read: true });
      }}
      className={`relative mb-1 overflow-hidden rounded-lg border ${s.card}`}
      style={{
        borderColor: f.fav ? alpha(g, 0.55) : alpha(g, 0.14),
        background: f.fav ? alpha(g, 0.07) : "transparent",
        opacity: f.read && !f.fav ? 0.72 : 1,
      }}
    >
      <button onClick={onOpen} className="w-full px-2 py-[6px] text-left">
        <div className="flex items-center gap-1">
          {!f.read && <span className="h-[4px] w-[4px] shrink-0 rounded-full" style={{ background: g }} />}
          <span className={`min-w-0 flex-1 truncate text-[9.5px] ${f.read ? "font-semibold" : "font-black"}`}>{f.title}</span>
          <span className="shrink-0 text-[8px] font-black tabular-nums" style={{ color: g }}>{f.score}</span>
        </div>
        <div className={`mt-[2px] flex items-center gap-1 text-[6.5px] uppercase tracking-[0.12em] ${s.muted}`}>
          <span className="truncate">{f.region} · {f.sector}</span>
          <span className="ml-auto shrink-0 tabular-nums">{ago(f.when)}</span>
          {f.saved && <Bookmark className="h-2 w-2" style={{ color: g }} />}
          {f.read && <Check className="h-2 w-2 opacity-50" />}
        </div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden px-2 pb-1.5">
            <div className="text-[8.5px] leading-snug opacity-80">{f.detail}</div>
            <div className={`mt-1 text-[6.5px] uppercase tracking-[0.12em] ${s.muted}`}>
              {f.agent} · confidence {f.confidence}% · {f.value}
            </div>
            <div className="mt-1 flex gap-1">
              <button onClick={() => mutateFinding(f.id, { saved: !f.saved })}
                className="flex-1 rounded-md py-[4px] text-center text-[8px] font-black"
                style={{ background: f.saved ? alpha(g, 0.16) : g, color: f.saved ? g : (isLight ? "#fff" : "#04121f") }}>
                {f.saved ? "Saved" : "Save"}
              </button>
              <button onClick={() => mutateFinding(f.id, { fav: !f.fav })}
                className="rounded-md px-2 py-[4px] text-[8px] font-bold"
                style={{ background: alpha(g, 0.1), color: g }}>
                <Pin className="inline h-2.5 w-2.5" />
              </button>
              <button onClick={() => removeFinding(f.id)}
                className="rounded-md px-2 py-[4px] text-[8px] font-bold opacity-60"
                style={{ background: alpha(g, 0.06) }}>
                <Trash2 className="inline h-2.5 w-2.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/* Reports — built from findings the user saved                        */
/* ------------------------------------------------------------------ */

export function SavedPanel({ theme, isLight }: Common) {
  const e = useEngine();
  const s = useSkin(isLight);
  const g = theme.glow;
  const saved = e.findings.filter((f) => f.saved).sort((a, b) => b.when - a.when);
  const opps = saved.filter((f) => f.kind === "opportunity");
  const risks = saved.filter((f) => f.kind === "risk");
  const [title, setTitle] = useState("Botswana saved brief");

  if (saved.length === 0) {
    return (
      <div className={`rounded-xl border px-3 py-6 text-center ${s.card}`} style={{ borderColor: alpha(g, 0.14) }}>
        <FileText className="mx-auto h-4 w-4" style={{ color: g, opacity: 0.7 }} />
        <div className="mt-1.5 text-[9px] font-black">No saved findings yet</div>
        <div className={`mt-[3px] text-[7.5px] leading-snug ${s.muted}`}>
          Open Findings and swipe a card right — or tap “Save”.<br />Everything you keep is collected here.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      <div className={`rounded-xl border px-2 py-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
        <div className={`text-[6.5px] font-bold uppercase tracking-[0.2em] ${s.muted}`}>Collection title</div>
        <input
          value={title}
          onChange={(ev) => setTitle(ev.target.value)}
          className="w-full bg-transparent text-[11px] font-black outline-none"
        />
        <div className={`mt-[2px] text-[6.5px] uppercase tracking-[0.14em] ${s.muted}`}>
          {saved.length} saved · {opps.length} opportunities · {risks.length} risks · updated {ago(saved[0].when)}
        </div>
      </div>

      <div className="max-h-[300px] space-y-1.5 overflow-y-auto pr-0.5">
        {[["Opportunities", opps], ["Risks", risks]].map(([label, list]) => {
          const items = list as LiveFinding[];
          if (!items.length) return null;
          return (
            <div key={label as string}>
              <Group label={label as string} count={items.length}
                icon={label === "Risks" ? <AlertTriangle className="h-2.5 w-2.5" /> : <ArrowUpRight className="h-2.5 w-2.5" />}
                g={g} muted={s.muted} />
              {items.map((f) => (
                <div key={f.id} className={`mb-1 rounded-lg border px-2 py-[5px] ${s.card}`} style={{ borderColor: alpha(g, 0.14) }}>
                  <div className="flex items-center gap-1">
                    <span className="min-w-0 flex-1 truncate text-[9px] font-black">{f.title}</span>
                    <button onClick={() => mutateFinding(f.id, { saved: false })} className="shrink-0 opacity-50">
                      <Trash2 className="h-2.5 w-2.5" />
                    </button>
                  </div>
                  <div className="text-[7.5px] leading-snug opacity-75">{f.detail}</div>
                  <div className={`mt-[2px] text-[6.5px] uppercase tracking-[0.12em] ${s.muted}`}>
                    {f.region} · {f.sector} · score {f.score} · {f.value}
                  </div>
                </div>
              ))}
            </div>
          );
        })}
      </div>

      <div className="flex gap-1">
        <Tap color={g} effect="glow" className="flex-1 rounded-lg py-1.5 text-center text-[8px] font-black uppercase tracking-[0.14em]"
          style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
          <Download className="mr-1 inline h-2.5 w-2.5" />Export
        </Tap>
        <Tap color={g} effect="squish" className="rounded-lg px-3 py-1.5 text-[8px] font-bold uppercase tracking-[0.14em]"
          style={{ background: alpha(g, 0.1), color: g }}>
          Share
        </Tap>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Signals — the user's own notes                                      */
/* ------------------------------------------------------------------ */

export function NotesPanel({ theme, isLight }: Common) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const { notes, add, remove, pin } = useNotes();
  const [text, setText] = useState("");
  const [tag, setTag] = useState(NOTE_TAGS[0]);

  const ordered = [...notes].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.when - a.when);

  return (
    <div className="space-y-1.5">
      <div className={`rounded-xl border px-2 py-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
        <div className={`mb-1 text-[6.5px] font-bold uppercase tracking-[0.2em] ${s.muted}`}>Write a note</div>
        <textarea
          value={text}
          onChange={(ev) => setText(ev.target.value)}
          rows={2}
          placeholder="Something you noticed, a lead, a question to follow up…"
          className="w-full resize-none bg-transparent text-[9px] font-semibold leading-snug outline-none placeholder:opacity-35"
        />
        <div className="mt-1 flex items-center gap-1">
          <div className="flex min-w-0 flex-1 gap-1 overflow-x-auto">
            {NOTE_TAGS.map((t) => (
              <button key={t} onClick={() => setTag(t)}
                className="shrink-0 rounded-full px-2 py-[2px] text-[7px] font-bold uppercase tracking-[0.1em]"
                style={tag === t ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
                {t}
              </button>
            ))}
          </div>
          <Tap color={g} effect="squish" onClick={() => { add(text, tag); setText(""); }}
            className="shrink-0 rounded-full px-2.5 py-[3px] text-[7.5px] font-black"
            style={{ background: text.trim() ? g : alpha(g, 0.12), color: text.trim() ? (isLight ? "#fff" : "#04121f") : g }}>
            <Plus className="inline h-2.5 w-2.5" />
          </Tap>
        </div>
      </div>

      {ordered.length === 0 ? (
        <div className={`rounded-xl border px-3 py-5 text-center text-[7.5px] ${s.card} ${s.muted}`} style={{ borderColor: alpha(g, 0.14) }}>
          Your notes live here — private notes you keep while the engine runs.
        </div>
      ) : (
        <div className="max-h-[320px] space-y-1 overflow-y-auto pr-0.5">
          <AnimatePresence initial={false}>
            {ordered.map((n) => (
              <motion.div key={n.id} layout initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, height: 0 }}
                drag="x" dragConstraints={{ left: 0, right: 0 }} dragElastic={0.3}
                onDragEnd={(_, info) => { if (info.offset.x < -90) remove(n.id); }}
                className={`rounded-lg border px-2 py-[5px] ${s.card}`}
                style={{ borderColor: n.pinned ? alpha(g, 0.5) : alpha(g, 0.14), background: n.pinned ? alpha(g, 0.06) : "transparent" }}>
                <div className="flex items-center gap-1">
                  <span className="rounded-full px-1.5 py-[1px] text-[6.5px] font-black uppercase tracking-[0.12em]"
                    style={{ background: alpha(g, 0.12), color: g }}>{n.tag}</span>
                  <span className={`ml-auto text-[6.5px] tabular-nums ${s.muted}`}>{ago(n.when)}</span>
                  <button onClick={() => pin(n.id)} className="shrink-0" style={{ color: n.pinned ? g : undefined, opacity: n.pinned ? 1 : 0.4 }}>
                    <Pin className="h-2.5 w-2.5" />
                  </button>
                </div>
                <div className="mt-[2px] whitespace-pre-wrap text-[8.5px] font-semibold leading-snug">{n.text}</div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
