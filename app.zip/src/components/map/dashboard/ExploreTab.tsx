import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { ArrowUpRight, ChevronDown, MapPin, Search, SlidersHorizontal, X } from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData, Place } from "../types";
import type { ThemeSpec } from "../themes";
import { alpha } from "../color";
import { Tap, useSkin } from "./ui";
import { BIZ_TYPES, LISTING_TYPES, MY_LISTINGS, PEOPLE_TYPES, groupsOf, type Cat } from "./exploreCats";

const DATA = raw as unknown as BotswanaData;

type Lens = "overview" | "people" | "business" | "listings" | "mine";

function hash(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}
const metric = (scope: string, salt: number, min: number, max: number) =>
  min + ((hash(scope + salt) % 1000) / 1000) * (max - min);

/** Scale the national category counts down to the selected place. */
function scaled(cats: Cat[], scope: string, salt: number) {
  const f = 0.06 + ((hash(scope + salt) % 1000) / 1000) * 0.9;
  return cats.map((c) => ({ ...c, n: Math.max(1, Math.round(c.n * f)), today: Math.round(c.today * f) }));
}

type Sort = "most" | "new" | "az";
const SORTS: { k: Sort; label: string }[] = [
  { k: "most", label: "Most" },
  { k: "new", label: "New today" },
  { k: "az", label: "A–Z" },
];

/** Explore — big clickable counters, then a clean "what and how many" browser. */
export function ExploreTab({
  theme, isLight, place, onSelectPlace,
}: {
  theme: ThemeSpec;
  isLight: boolean;
  place: Place | null;
  onSelectPlace?: (p: Place | null) => void;
}) {
  const s = useSkin(isLight);
  const g = theme.glow;
  const [lens, setLens] = useState<Lens>("overview");
  const [picker, setPicker] = useState(false);
  const [pq, setPq] = useState("");

  const scope = place?.name ?? "All Botswana";

  const people = useMemo(() => scaled(PEOPLE_TYPES, scope, 1), [scope]);
  const biz = useMemo(() => scaled(BIZ_TYPES, scope, 2), [scope]);
  const listings = useMemo(() => scaled(LISTING_TYPES, scope, 3), [scope]);

  const sum = (c: Cat[]) => c.reduce((a, b) => a + b.n, 0);
  const totals = {
    people: sum(people),
    business: sum(biz),
    listings: sum(listings),
  };

  const placeList = useMemo(() => {
    const all = DATA.places;
    if (!pq.trim()) return all.slice(0, 40);
    return all.filter((p) => p.name.toLowerCase().includes(pq.toLowerCase())).slice(0, 40);
  }, [pq]);

  const counters: { k: Lens; label: string; value: string }[] = [
    { k: "overview", label: "Overview", value: scope === "All Botswana" ? "Botswana" : scope },
    { k: "people", label: "People", value: totals.people.toLocaleString() },
    { k: "business", label: "Business", value: totals.business.toLocaleString() },
    { k: "listings", label: "Listings", value: totals.listings.toLocaleString() },
    { k: "mine", label: "My listings", value: String(MY_LISTINGS.length) },
  ];

  return (
    <div>
      {/* scope header */}
      <button onClick={() => setPicker((v) => !v)} className="flex w-full items-center gap-1.5 text-left">
        <MapPin className="h-3 w-3 shrink-0" style={{ color: g }} />
        <span className="min-w-0 truncate text-[16px] font-black leading-none">{scope}</span>
        <motion.span animate={{ rotate: picker ? 180 : 0 }} className="shrink-0 opacity-50">
          <ChevronDown className="h-3 w-3" />
        </motion.span>
        {place && (
          <span className="ml-auto shrink-0 rounded-full px-1.5 py-[1px] text-[6.5px] font-black uppercase tracking-[0.14em]"
            style={{ background: alpha(g, 0.12), color: g }}>
            {place.type}
          </span>
        )}
      </button>

      <AnimatePresence>
        {picker && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className={`mt-1.5 rounded-xl border p-1.5 ${s.card}`} style={{ borderColor: alpha(g, 0.16) }}>
              <div className="mb-1 flex items-center gap-1.5">
                <Search className="h-2.5 w-2.5 shrink-0 opacity-50" />
                <input value={pq} onChange={(e) => setPq(e.target.value)} autoFocus placeholder="Find a place"
                  className="min-w-0 flex-1 bg-transparent text-[9px] font-semibold outline-none placeholder:opacity-35" />
              </div>
              <button onClick={() => { onSelectPlace?.(null); setPicker(false); }}
                className="mb-[2px] block w-full rounded-md px-1.5 py-[4px] text-left text-[8.5px] font-black"
                style={!place ? { background: alpha(g, 0.14), color: g } : undefined}>
                All Botswana
              </button>
              <div className="max-h-[168px] overflow-y-auto">
                {placeList.map((p) => (
                  <button key={p.name} onClick={() => { onSelectPlace?.(p); setPicker(false); }}
                    className="flex w-full items-center gap-1 rounded-md px-1.5 py-[4px] text-left"
                    style={place?.name === p.name ? { background: alpha(g, 0.14) } : undefined}>
                    <span className="min-w-0 flex-1 truncate text-[8.5px] font-semibold">{p.name}</span>
                    <span className={`shrink-0 text-[6.5px] uppercase tracking-[0.14em] ${s.muted}`}>{p.type}</span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* the counters ARE the tabs */}
      <div className="-mx-0.5 mt-2 flex gap-1 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
        {counters.map((c) => {
          const on = lens === c.k;
          return (
            <Tap key={c.k} color={g} effect="squish" onClick={() => setLens(c.k)}
              className="min-w-[74px] shrink-0 rounded-xl border px-2 py-1.5 text-left"
              style={{
                borderColor: on ? alpha(g, 0.55) : alpha(g, 0.14),
                background: on ? alpha(g, 0.14) : "transparent",
              }}>
              <div className="truncate text-[12px] font-black leading-none tabular-nums" style={{ color: on ? g : undefined }}>
                {c.value}
              </div>
              <div className={`mt-[3px] truncate text-[6.5px] font-black uppercase tracking-[0.16em] ${on ? "" : s.muted}`}
                style={on ? { color: g } : undefined}>
                {c.label}
              </div>
            </Tap>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={lens} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.14 }}>
          {lens === "overview" && <Overview scope={scope} g={g} s={s} people={people} biz={biz} listings={listings} totals={totals} />}
          {lens === "people" && <Catalog cats={people} g={g} s={s} isLight={isLight} noun="people" scope={scope} />}
          {lens === "business" && <Catalog cats={biz} g={g} s={s} isLight={isLight} noun="businesses" scope={scope} />}
          {lens === "listings" && <Catalog cats={listings} g={g} s={s} isLight={isLight} noun="listings" scope={scope} />}
          {lens === "mine" && <Mine g={g} s={s} isLight={isLight} />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

/* ---------------- overview: minimal, no charts ---------------- */

function Overview({
  scope, g, s, people, biz, listings, totals,
}: {
  scope: string; g: string; s: ReturnType<typeof useSkin>;
  people: Cat[]; biz: Cat[]; listings: Cat[];
  totals: { people: number; business: number; listings: number };
}) {
  const top = (c: Cat[]) => [...c].sort((a, b) => b.n - a.n).slice(0, 6);
  const newToday = [...people, ...biz, ...listings].reduce((a, b) => a + b.today, 0);

  const facts: [string, string][] = [
    ["New today", newToday.toLocaleString()],
    ["Verified", `${Math.round(metric(scope, 7, 42, 92))}%`],
    ["Open to work", Math.round(totals.people * 0.18).toLocaleString()],
    ["Replies < 1h", `${Math.round(metric(scope, 8, 38, 86))}%`],
  ];

  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-4 gap-1">
        {facts.map(([k, v]) => (
          <div key={k} className="rounded-lg px-1.5 py-1" style={{ background: alpha(g, 0.07) }}>
            <div className="truncate text-[10px] font-black leading-none tabular-nums" style={{ color: g }}>{v}</div>
            <div className={`mt-[3px] truncate text-[6px] font-bold uppercase tracking-[0.12em] ${s.muted}`}>{k}</div>
          </div>
        ))}
      </div>

      <Group title="Who is here" g={g} s={s}>
        <div className="grid grid-cols-2 gap-x-3 gap-y-[4px]">
          {top(people).map((c) => (
            <div key={c.k} className="flex min-w-0 items-baseline gap-1.5 border-b pb-[3px]" style={{ borderColor: alpha(g, 0.09) }}>
              <span className="min-w-0 flex-1 truncate text-[8.5px] font-semibold">{c.k}</span>
              <span className="shrink-0 text-[8.5px] font-black tabular-nums" style={{ color: g }}>{c.n.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </Group>

      <Group title="Busiest business types" g={g} s={s}>
        <div className="flex flex-wrap gap-1">
          {top(biz).map((c) => (
            <span key={c.k} className="rounded-full px-2 py-[3px] text-[8px] font-bold" style={{ background: alpha(g, 0.08) }}>
              {c.k} <b className="tabular-nums" style={{ color: g }}>{c.n.toLocaleString()}</b>
            </span>
          ))}
        </div>
      </Group>

      <Group title="Most posted right now" g={g} s={s}>
        <div className="space-y-[3px]">
          {top(listings).slice(0, 4).map((c) => (
            <div key={c.k} className="flex items-baseline gap-2">
              <span className="min-w-0 flex-1 truncate text-[9px] font-black">{c.k}</span>
              <span className="shrink-0 text-[7px] font-bold" style={{ color: g }}>+{c.today} today</span>
              <span className={`w-[46px] shrink-0 text-right text-[8.5px] font-black tabular-nums ${s.muted}`}>{c.n.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </Group>
    </div>
  );
}

function Group({ title, g, s, children }: { title: string; g: string; s: ReturnType<typeof useSkin>; children: React.ReactNode }) {
  return (
    <div>
      <div className={`mb-1 text-[6.5px] font-black uppercase tracking-[0.22em] ${s.muted}`} style={{ color: alpha(g, 0.8) }}>{title}</div>
      {children}
    </div>
  );
}

/* ---------------- catalog: types + how many ---------------- */

function Catalog({
  cats, g, s, isLight, noun, scope,
}: {
  cats: Cat[]; g: string; s: ReturnType<typeof useSkin>; isLight: boolean; noun: string; scope: string;
}) {
  const [q, setQ] = useState("");
  const [group, setGroup] = useState<string | null>(null);
  const [sort, setSort] = useState<Sort>("most");
  const [open, setOpen] = useState<string | null>(null);
  const groups = useMemo(() => groupsOf(cats), [cats]);

  const shown = useMemo(() => {
    let list = cats;
    if (group) list = list.filter((c) => c.group === group);
    if (q.trim()) list = list.filter((c) => (c.k + c.group).toLowerCase().includes(q.toLowerCase()));
    const by: Record<Sort, (a: Cat, b: Cat) => number> = {
      most: (a, b) => b.n - a.n,
      new: (a, b) => b.today - a.today,
      az: (a, b) => a.k.localeCompare(b.k),
    };
    return [...list].sort(by[sort]);
  }, [cats, group, q, sort]);

  const max = Math.max(...shown.map((c) => c.n), 1);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-1.5 rounded-lg px-2 py-1" style={{ background: alpha(g, 0.06) }}>
        <Search className="h-2.5 w-2.5 shrink-0 opacity-50" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${noun} in ${scope}`}
          className="min-w-0 flex-1 bg-transparent text-[9px] font-semibold outline-none placeholder:opacity-35" />
        {q && <button onClick={() => setQ("")} className="shrink-0 opacity-50"><X className="h-2.5 w-2.5" /></button>}
      </div>

      <div className="flex items-center gap-1">
        <SlidersHorizontal className="h-2.5 w-2.5 shrink-0 opacity-40" />
        <div className="flex min-w-0 flex-1 gap-[3px] overflow-x-auto" style={{ scrollbarWidth: "none" }}>
          {SORTS.map((x) => (
            <button key={x.k} onClick={() => setSort(x.k)}
              className="shrink-0 rounded-full px-2 py-[2px] text-[7px] font-black uppercase tracking-[0.1em]"
              style={sort === x.k ? { background: g, color: isLight ? "#fff" : "#04121f" } : { background: alpha(g, 0.08) }}>
              {x.label}
            </button>
          ))}
          <span className="mx-[3px] w-px shrink-0" style={{ background: alpha(g, 0.2) }} />
          {groups.map((x) => (
            <button key={x} onClick={() => setGroup(group === x ? null : x)}
              className="shrink-0 rounded-full px-2 py-[2px] text-[7px] font-bold"
              style={group === x ? { background: alpha(g, 0.22), color: g } : { background: alpha(g, 0.06) }}>
              {x}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-1">
        {shown.map((c) => {
          const on = open === c.k;
          return (
            <Tap key={c.k} color={g} effect="squish" onClick={() => setOpen(on ? null : c.k)}
              className="relative overflow-hidden rounded-xl border px-2 py-1.5 text-left"
              style={{ borderColor: on ? alpha(g, 0.5) : alpha(g, 0.13), background: on ? alpha(g, 0.1) : "transparent" }}>
              <div className="absolute inset-y-0 left-0" style={{ width: `${(c.n / max) * 100}%`, background: alpha(g, 0.06) }} />
              <div className="relative flex items-baseline gap-1">
                <span className="min-w-0 flex-1 truncate text-[9px] font-black leading-tight">{c.k}</span>
                {c.today > 0 && <span className="shrink-0 text-[6.5px] font-black" style={{ color: g }}>+{c.today}</span>}
              </div>
              <div className="relative mt-[2px] text-[13px] font-black leading-none tabular-nums" style={{ color: g }}>
                {c.n.toLocaleString()}
              </div>
              <div className={`relative mt-[2px] truncate text-[6px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{c.group}</div>
              <AnimatePresence>
                {on && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                    className="relative overflow-hidden">
                    <div className="mt-1 flex items-center gap-1">
                      <span className="rounded-md px-1.5 py-[3px] text-[7px] font-black"
                        style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
                        Browse
                      </span>
                      <span className="rounded-md px-1.5 py-[3px] text-[7px] font-bold" style={{ background: alpha(g, 0.12), color: g }}>
                        Alert me
                      </span>
                      <ArrowUpRight className="ml-auto h-2.5 w-2.5" style={{ color: g }} />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </Tap>
          );
        })}
      </div>

      {shown.length === 0 && <div className={`py-4 text-center text-[8px] ${s.muted}`}>Nothing matches that filter.</div>}
    </div>
  );
}

/* ---------------- my listings ---------------- */

const STATUS: Record<string, string> = { live: "#22c55e", paused: "#f59e0b", draft: "#94a3b8", sold: "#38bdf8" };

function Mine({ g, s, isLight }: { g: string; s: ReturnType<typeof useSkin>; isLight: boolean }) {
  const [filter, setFilter] = useState<string | null>(null);
  const list = filter ? MY_LISTINGS.filter((m) => m.status === filter) : MY_LISTINGS;
  const views = MY_LISTINGS.reduce((a, b) => a + b.views, 0);
  const msgs = MY_LISTINGS.reduce((a, b) => a + b.msgs, 0);
  const saves = MY_LISTINGS.reduce((a, b) => a + b.saves, 0);

  return (
    <div className="space-y-1.5">
      <div className="grid grid-cols-3 gap-1">
        {([["Views", views], ["Saves", saves], ["Messages", msgs]] as [string, number][]).map(([k, v]) => (
          <div key={k} className="rounded-lg px-2 py-1" style={{ background: alpha(g, 0.07) }}>
            <div className="text-[12px] font-black leading-none tabular-nums" style={{ color: g }}>{v.toLocaleString()}</div>
            <div className={`mt-[3px] text-[6px] font-bold uppercase tracking-[0.14em] ${s.muted}`}>{k}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-1 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
        {["live", "paused", "draft", "sold"].map((x) => (
          <button key={x} onClick={() => setFilter(filter === x ? null : x)}
            className="shrink-0 rounded-full px-2 py-[2px] text-[7px] font-black uppercase tracking-[0.12em]"
            style={filter === x ? { background: STATUS[x], color: "#06121f" } : { background: alpha(g, 0.07) }}>
            {x}
          </button>
        ))}
        <Tap color={g} effect="squish" className="ml-auto shrink-0 rounded-full px-2.5 py-[2px] text-[7px] font-black uppercase tracking-[0.12em]"
          style={{ background: g, color: isLight ? "#fff" : "#04121f" }}>
          + New listing
        </Tap>
      </div>

      <div className="space-y-1">
        {list.map((m) => (
          <div key={m.id} className="rounded-xl border px-2 py-1.5" style={{ borderColor: alpha(g, 0.13) }}>
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: STATUS[m.status], boxShadow: `0 0 6px ${STATUS[m.status]}` }} />
              <span className="min-w-0 flex-1 truncate text-[10px] font-black leading-tight">{m.title}</span>
              <span className="shrink-0 text-[9px] font-black" style={{ color: g }}>{m.price}</span>
            </div>
            <div className={`mt-[2px] flex items-center gap-2 text-[6.5px] font-bold uppercase tracking-[0.12em] ${s.muted}`}>
              <span className="truncate">{m.type}</span>
              <span className="ml-auto shrink-0 tabular-nums">{m.views.toLocaleString()} views</span>
              <span className="shrink-0 tabular-nums">{m.msgs} msgs</span>
              <span className="shrink-0">{m.when}</span>
            </div>
            <div className="mt-1 flex gap-1">
              {["Edit", m.status === "live" ? "Pause" : "Publish", "Promote", "Delete"].map((a) => (
                <button key={a} className="flex-1 rounded-md py-[3px] text-[7px] font-bold"
                  style={{ background: alpha(g, 0.08), color: a === "Delete" ? "#f87171" : undefined }}>
                  {a}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
