import { useMemo, useState } from "react";
import { STATE_LABEL, uptime, useEngine } from "./engineLive";

/* ── Verity-styled shell (exact tokens from the reference UI) ───────────── */
const CSS = `
.v9{
  --bg-primary:#0a0a12; --bg-secondary:#12121e; --bg-glass:rgba(18,18,30,.75);
  --border-glass:rgba(0,240,255,.08); --color-true:#00f0ff; --color-accent:#7b61ff;
  --color-danger:#ff4466; --color-text:#e0e0e8; --color-text-dim:#5a5a72;
  --color-gate-bg:#16162a; --color-gate-border:#2a2a44;
  --true-glow:0 0 20px rgba(0,240,255,.4), 0 0 60px rgba(0,240,255,.1);
  --ease-expo:cubic-bezier(.16,1,.3,1); --ease-spring:cubic-bezier(.34,1.56,.64,1);
  --font-mono:'JetBrains Mono','Fira Code','SF Mono',monospace;
  font-family:var(--font-mono); background:var(--bg-primary); color:var(--color-text);
  border:1px solid var(--border-glass); border-radius:14px; overflow:hidden;
  user-select:none; display:flex; flex-direction:column; min-height:100%;
}
.v9 .bar{display:flex;align-items:center;justify-content:space-between;gap:.5rem;
  height:40px;padding:0 .6rem;background:linear-gradient(180deg,var(--bg-primary) 60%,transparent)}
.v9 .title{font-size:.55rem;font-weight:600;letter-spacing:.2em;text-transform:uppercase;opacity:.4}
.v9 .acts{display:flex;gap:.25rem;overflow-x:auto;scrollbar-width:none}
.v9 .acts::-webkit-scrollbar{display:none}
.v9 .btn{font-family:var(--font-mono);font-size:.5rem;font-weight:600;letter-spacing:.08em;
  text-transform:uppercase;color:var(--color-text-dim);background:var(--bg-glass);
  backdrop-filter:blur(20px) saturate(1.2);border:1px solid var(--border-glass);
  border-radius:8px;padding:.32rem .6rem;cursor:pointer;white-space:nowrap;
  transition:all .3s var(--ease-expo)}
.v9 .btn:hover{color:var(--color-true);border-color:rgba(0,240,255,.2);box-shadow:var(--true-glow)}
.v9 .btn.on{color:var(--color-true);border-color:rgba(0,240,255,.25);
  box-shadow:inset 0 0 20px rgba(0,240,255,.06),0 0 15px rgba(0,240,255,.08)}
.v9 .world{position:relative;padding:.6rem;flex:1;display:flex;flex-direction:column;min-height:0;
  background-image:radial-gradient(circle at 1px 1px,rgba(0,240,255,.025) 1px,transparent 1px);
  background-size:40px 40px}
.v9 .vitals{display:flex;flex-wrap:wrap;align-items:center;gap:.35rem;margin-bottom:.5rem}
.v9 .chip{display:flex;align-items:center;gap:.3rem;background:var(--bg-glass);
  border:1px solid var(--border-glass);border-radius:8px;padding:.28rem .5rem;font-size:.5rem;
  color:var(--color-text-dim)}
.v9 .chip b{color:var(--color-true);font-weight:600;font-variant-numeric:tabular-nums}
.v9 .led{width:6px;height:6px;border-radius:50%;background:var(--color-true);
  box-shadow:0 0 6px rgba(0,240,255,.5);animation:v9-pulse 2.2s ease-in-out infinite}
.v9 .led.dim{background:var(--color-text-dim);box-shadow:none;animation:none}
@keyframes v9-pulse{0%,100%{opacity:1}50%{opacity:.25}}
.v9 .surface{background:var(--bg-glass);backdrop-filter:blur(20px) saturate(1.2);
  border:1px solid var(--border-glass);border-radius:12px;padding:.5rem;
  flex:1;min-height:44vh;max-height:60vh;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--color-gate-border) transparent}
.v9 .surface::-webkit-scrollbar{width:4px}
.v9 .surface::-webkit-scrollbar-thumb{background:var(--color-gate-border);border-radius:2px}
.v9 .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:.4rem}
.v9 .gate{background:var(--color-gate-bg);border:1.5px solid var(--color-gate-border);
  border-radius:12px;padding:.45rem;display:flex;flex-direction:column;gap:2px;
  transition:border-color .3s var(--ease-expo),box-shadow .3s var(--ease-expo);cursor:pointer}
.v9 .gate.hot{border-color:rgba(0,240,255,.25);
  box-shadow:inset 0 0 20px rgba(0,240,255,.06),0 0 15px rgba(0,240,255,.08)}
.v9 .gate .nm{font-size:.52rem;font-weight:600;color:var(--color-text-dim);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.v9 .gate.hot .nm{color:var(--color-true)}
.v9 .gate .sub{font-size:.42rem;letter-spacing:.1em;text-transform:uppercase;color:var(--color-text-dim)}
.v9 .line{display:flex;gap:.4rem;padding:3px 2px;font-size:.5rem;color:var(--color-text-dim);
  border-bottom:1px solid rgba(255,255,255,.015)}
.v9 .line .who{color:var(--color-true);flex:0 0 auto;font-weight:600}
.v9 .line .txt{color:var(--color-text);min-width:0;flex:1}
.v9 .line .t{flex:0 0 auto;opacity:.5;font-size:.44rem}
.v9 table{width:100%;border-collapse:collapse;font-size:.5rem}
.v9 th{color:var(--color-true);font-weight:600;padding:3px 5px;text-align:left;
  border-bottom:1px solid var(--border-glass);position:sticky;top:0;background:var(--bg-secondary);z-index:2}
.v9 td{padding:3px 5px;color:var(--color-text-dim);border-bottom:1px solid rgba(255,255,255,.015)}
.v9 td.v1{color:var(--color-true)}
.v9 tr.active-row{background:rgba(0,240,255,.06)}
.v9 tr.active-row td{color:var(--color-text)}
.v9 .inspector{margin-top:.5rem;background:var(--bg-glass);border:1px solid var(--border-glass);
  border-radius:12px;padding:.5rem .7rem;font-size:.5rem;color:var(--color-text-dim)}
.v9 .inspector .ttl{font-size:.46rem;text-transform:uppercase;letter-spacing:.12em;margin-bottom:.3rem}
.v9 .row{display:flex;justify-content:space-between;gap:.5rem;padding:1px 0}
.v9 .row .val{color:var(--color-text);font-weight:600}
.v9 .row .val.true{color:var(--color-true)}
.v9 .empty{text-align:center;padding:1.2rem 0;color:var(--color-text-dim);font-size:.55rem;font-style:italic}
@media(max-width:760px){
  .v9 .grid{grid-template-columns:repeat(auto-fill,minmax(88px,1fr))}
  .v9 .surface{min-height:38vh;max-height:52vh}
}
`;

type Tab = "agents" | "reasoning" | "incoming" | "findings";
const TABS: { k: Tab; label: string }[] = [
  { k: "agents", label: "Agents" },
  { k: "reasoning", label: "Reason" },
  { k: "incoming", label: "Feed" },
  { k: "findings", label: "Findings" },
];

const clock = (t: number) =>
  new Date(t).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

/** v9 — our always-on engine, dressed in the Verity Engine interface language. */
export function WorkspaceV9() {
  const e = useEngine();
  const [tab, setTab] = useState<Tab>("agents");
  const [sel, setSel] = useState<string | null>(null);

  const active = useMemo(
    () => new Set(e.thoughts.slice(0, 6).map((t) => t.agent.id)),
    [e.thoughts],
  );
  const agents = useMemo(
    () => Object.keys(e.states).slice(0, e.agentCount),
    [e.states, e.agentCount],
  );
  const agentById = useMemo(
    () => new Map(e.thoughts.map((t) => [t.agent.id, t.agent])),
    [e.thoughts],
  );

  const inspected = e.findings.find((f) => f.id === sel) ?? e.findings[0];

  return (
    <div className="v9">
      <style>{CSS}</style>

      <div className="bar">
        <span className="title">Verity Engine</span>
        <div className="acts">
          {TABS.map((t) => (
            <button
              key={t.k}
              className={`btn${tab === t.k ? " on" : ""}`}
              onClick={() => setTab(t.k)}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="world">
        <div className="vitals">
          <span className="chip">
            <span className="led" />
            <b>{uptime(e.runtimeMs)}</b>
          </span>
          <span className="chip">agents <b>{e.agentCount}</b></span>
          <span className="chip">ops <b>{e.ops.toLocaleString()}</b></span>
          <span className="chip">findings <b>{e.findings.length}</b></span>
        </div>

        <div className="surface">
          {tab === "agents" && (
            <div className="grid">
              {agents.map((id) => {
                const a = agentById.get(id);
                const st = e.states[id];
                const hot = active.has(id);
                return (
                  <div key={id} className={`gate${hot ? " hot" : ""}`}>
                    <span className={`led${hot ? "" : " dim"}`} />
                    <span className="nm">{a?.name ?? id.toUpperCase()}</span>
                    <span className="sub">{st ? STATE_LABEL[st] : "idle"}</span>
                  </div>
                );
              })}
            </div>
          )}

          {tab === "reasoning" &&
            (e.thoughts.length === 0 ? (
              <div className="empty">awaiting first reasoning trace…</div>
            ) : (
              e.thoughts.slice(0, 40).map((t) => (
                <div key={t.id} className="line">
                  <span className="who">{t.agent.name}</span>
                  <span className="txt">{t.text}</span>
                  <span className="t">{clock(t.when)}</span>
                </div>
              ))
            ))}

          {tab === "incoming" &&
            (e.feed.length === 0 ? (
              <div className="empty">no packets received yet…</div>
            ) : (
              e.feed.slice(0, 40).map((f) => (
                <div key={f.id} className="line">
                  <span className="who">{f.src.kind.toUpperCase()}</span>
                  <span className="txt">{f.text}</span>
                  <span className="t">{clock(f.when)}</span>
                </div>
              ))
            ))}

          {tab === "findings" && (
            <table>
              <thead>
                <tr>
                  <th>Finding</th>
                  <th>Region</th>
                  <th>Score</th>
                </tr>
              </thead>
              <tbody>
                {e.findings.slice(0, 40).map((f) => (
                  <tr
                    key={f.id}
                    className={f.id === inspected?.id ? "active-row" : ""}
                    onClick={() => setSel(f.id)}
                  >
                    <td>{f.title}</td>
                    <td>{f.region}</td>
                    <td className="v1">{f.score}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {inspected && (
          <div className="inspector">
            <div className="ttl">Inspector</div>
            <div className="row"><span>signal</span><span className="val">{inspected.title}</span></div>
            <div className="row"><span>kind</span><span className="val true">{inspected.kind}</span></div>
            <div className="row"><span>sector</span><span className="val">{inspected.sector}</span></div>
            <div className="row"><span>confidence</span><span className="val true">{inspected.confidence}%</span></div>
            <div className="row"><span>value</span><span className="val">{inspected.value}</span></div>
          </div>
        )}
      </div>
    </div>
  );
}
