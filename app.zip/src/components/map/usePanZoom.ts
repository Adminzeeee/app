import { useCallback, useEffect, useRef, useState } from "react";
import { animate } from "framer-motion";

export interface Camera {
  x: number; // translate in css pixels
  y: number;
  scale: number;
}

interface UsePanZoomOpts {
  minScale?: number;
  maxScale?: number;
  containerRef: React.RefObject<HTMLDivElement | null>;
  contentSize: { w: number; h: number }; // viewBox size in svg units (rendered 1:1 at scale=1 into container)
}

/** Returns camera + gesture handlers. Camera maps content coords -> screen: screen = coord * scale + offset. */
export function usePanZoom({ minScale = 0.3, maxScale = 12, containerRef, contentSize }: UsePanZoomOpts) {
  const [camera, setCamera] = useState<Camera>({ x: 0, y: 0, scale: 1 });
  const cameraRef = useRef(camera);
  cameraRef.current = camera;

  // fit content into container initially
  const fit = useCallback(
    (padding = 40, animateFit = true) => {
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const s = Math.min(
        (rect.width - padding * 2) / contentSize.w,
        (rect.height - padding * 2) / contentSize.h,
      );
      const x = (rect.width - contentSize.w * s) / 2;
      const y = (rect.height - contentSize.h * s) / 2;
      if (animateFit) flyTo({ x, y, scale: s }, 0.9);
      else setCamera({ x, y, scale: s });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [containerRef, contentSize.w, contentSize.h],
  );

  // fly to a specific camera
  const flyTo = useCallback((target: Camera, duration = 0.8) => {
    const start = cameraRef.current;
    const controls = animate(0, 1, {
      duration,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (t) => {
        setCamera({
          x: start.x + (target.x - start.x) * t,
          y: start.y + (target.y - start.y) * t,
          scale: start.scale + (target.scale - start.scale) * t,
        });
      },
    });
    return controls;
  }, []);

  // fly so that a content point ends up at container center, at given scale
  const flyToPoint = useCallback(
    (px: number, py: number, targetScale?: number, duration = 1.1) => {
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const s = targetScale ?? Math.max(cameraRef.current.scale, 4);
      const x = rect.width / 2 - px * s;
      const y = rect.height / 2 - py * s;
      flyTo({ x, y, scale: s }, duration);
    },
    [flyTo, containerRef],
  );

  // wheel zoom
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      const cam = cameraRef.current;
      const factor = Math.exp(-e.deltaY * 0.0015);
      const newScale = clamp(cam.scale * factor, minScale, maxScale);
      const k = newScale / cam.scale;
      setCamera({
        scale: newScale,
        x: cx - (cx - cam.x) * k,
        y: cy - (cy - cam.y) * k,
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [containerRef, minScale, maxScale]);

  // pointer/touch: pan + pinch + inertia + double tap
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const pointers = new Map<number, { x: number; y: number }>();
    let lastPanTime = 0;
    let vx = 0, vy = 0;
    let lastX = 0, lastY = 0;
    let pinchStartDist = 0;
    let pinchStartScale = 1;
    let pinchStartMid = { x: 0, y: 0 };
    let pinchStartCam: Camera = { x: 0, y: 0, scale: 1 };
    let inertiaRaf = 0;
    let lastTap = 0;
    let moved = false;

    const stopInertia = () => {
      if (inertiaRaf) { cancelAnimationFrame(inertiaRaf); inertiaRaf = 0; }
    };

    const onDown = (e: PointerEvent) => {
      stopInertia();
      (e.target as Element).setPointerCapture?.(e.pointerId);
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      moved = false;
      if (pointers.size === 1) {
        lastX = e.clientX; lastY = e.clientY;
        lastPanTime = performance.now();
        vx = 0; vy = 0;
      } else if (pointers.size === 2) {
        const [p1, p2] = Array.from(pointers.values());
        pinchStartDist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
        const rect = el.getBoundingClientRect();
        pinchStartMid = { x: (p1.x + p2.x) / 2 - rect.left, y: (p1.y + p2.y) / 2 - rect.top };
        pinchStartCam = { ...cameraRef.current };
        pinchStartScale = cameraRef.current.scale;
      }
    };
    const onMove = (e: PointerEvent) => {
      if (!pointers.has(e.pointerId)) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pointers.size === 1) {
        const dx = e.clientX - lastX;
        const dy = e.clientY - lastY;
        if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
        const now = performance.now();
        const dt = Math.max(1, now - lastPanTime);
        vx = dx / dt; vy = dy / dt;
        lastPanTime = now;
        lastX = e.clientX; lastY = e.clientY;
        setCamera((c) => ({ ...c, x: c.x + dx, y: c.y + dy }));
      } else if (pointers.size === 2) {
        moved = true;
        const [p1, p2] = Array.from(pointers.values());
        const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
        const rect = el.getBoundingClientRect();
        const mid = { x: (p1.x + p2.x) / 2 - rect.left, y: (p1.y + p2.y) / 2 - rect.top };
        const k = dist / pinchStartDist;
        const newScale = clamp(pinchStartScale * k, minScale, maxScale);
        // anchor at pinch midpoint (accounting for midpoint drift)
        const dxMid = mid.x - pinchStartMid.x;
        const dyMid = mid.y - pinchStartMid.y;
        const factor = newScale / pinchStartCam.scale;
        setCamera({
          scale: newScale,
          x: pinchStartMid.x - (pinchStartMid.x - pinchStartCam.x) * factor + dxMid,
          y: pinchStartMid.y - (pinchStartMid.y - pinchStartCam.y) * factor + dyMid,
        });
      }
    };
    const onUp = (e: PointerEvent) => {
      pointers.delete(e.pointerId);
      if (pointers.size === 0) {
        // inertia
        const friction = 0.94;
        const step = () => {
          vx *= friction; vy *= friction;
          if (Math.abs(vx) < 0.02 && Math.abs(vy) < 0.02) { inertiaRaf = 0; return; }
          setCamera((c) => ({ ...c, x: c.x + vx * 16, y: c.y + vy * 16 }));
          inertiaRaf = requestAnimationFrame(step);
        };
        if (Math.hypot(vx, vy) > 0.15) inertiaRaf = requestAnimationFrame(step);

        // double tap
        const now = performance.now();
        if (!moved && now - lastTap < 300) {
          const rect = el.getBoundingClientRect();
          const cx = e.clientX - rect.left;
          const cy = e.clientY - rect.top;
          const cam = cameraRef.current;
          const newScale = clamp(cam.scale * 2, minScale, maxScale);
          const k = newScale / cam.scale;
          const target: Camera = {
            scale: newScale,
            x: cx - (cx - cam.x) * k,
            y: cy - (cy - cam.y) * k,
          };
          flyTo(target, 0.5);
          lastTap = 0;
        } else if (!moved) {
          lastTap = now;
        }
      }
    };

    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerup", onUp);
    el.addEventListener("pointercancel", onUp);
    return () => {
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointercancel", onUp);
      stopInertia();
    };
  }, [containerRef, minScale, maxScale, flyTo]);

  return { camera, setCamera, fit, flyTo, flyToPoint };
}

function clamp(n: number, a: number, b: number) { return Math.max(a, Math.min(b, n)); }
