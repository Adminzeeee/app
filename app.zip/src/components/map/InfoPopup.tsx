import { motion } from "framer-motion";
import type { Place, PlaceType } from "./types";
import type { ThemeSpec } from "./themes";
import { X } from "lucide-react";

interface Props {
  place: Place;
  theme: ThemeSpec;
  onClose: () => void;
}

const DESCRIPTIONS: Record<string, string> = {
  Gaborone: "Capital of Botswana. Political, financial and cultural heart, home to Parliament and the University of Botswana.",
  Francistown: "Second-largest city, historic mining hub in the North-East, known as the 'Capital of the North'.",
  Maun: "Gateway to the Okavango Delta. Departure point for safaris and mokoro canoe expeditions.",
  Kasane: "Northern town at the four-country border. Entry to Chobe National Park and its legendary elephant herds.",
  Kanye: "Traditional Bangwaketse capital. Highland town on the edge of the Kalahari, known for weaving.",
  Molepolole: "Largest village in the country and seat of the Bakwena. A cultural stronghold near Kgale escarpments.",
  Serowe: "Historic royal village of the Bangwato. Birthplace of Sir Seretse Khama.",
  "Selebi-Phikwe": "Once a copper–nickel mining town, now diversifying its economy.",
  Palapye: "Central crossroads town, home to the Morupule power station.",
  Mahalapye: "Rail town on the Gaborone–Francistown corridor.",
  Lobatse: "Beef processing capital, seat of the High Court.",
  Jwaneng: "Home to the world's richest diamond mine by value.",
  Ghanzi: "Cattle country in the western Kalahari, Bushman heritage.",
  Tshabong: "Remote southern outpost bordering the Kgalagadi.",
  Shakawe: "Panhandle town at the top of the Okavango, on the Namibian border.",
  Orapa: "Diamond mining town operated by Debswana.",
  Letlhakane: "Neighbouring diamond mining community to Orapa.",
  Sowa: "Soda ash town on the edge of the Makgadikgadi Pans.",
  Ramotswa: "Bakgatla capital just south of Gaborone.",
  Mochudi: "Cultural centre of the Bakgatla ba Kgafela.",
  Thamaga: "Village famed for the Thamaga Pottery cooperative.",
  Tonota: "Growing settlement along the A1 north of Francistown.",
  Bobonong: "Bobirwa heartland in the far east.",
  "Chobe NP": "Legendary national park with the largest elephant concentration on Earth.",
  "Okavango Delta": "UNESCO World Heritage inland delta — a shimmering oasis in the Kalahari.",
  "Central Kalahari": "One of the largest game reserves in the world. Home of the San.",
  "Makgadikgadi Pans": "Vast salt pans, remnants of an ancient super-lake.",
  "Tsodilo Hills": "UNESCO site with thousands of ancient San rock paintings — the 'Louvre of the Desert'.",
  "Nxai Pan": "Iconic baobab-dotted salt flats north of the Makgadikgadi.",
};

const TYPE_LABEL: Record<PlaceType, string> = {
  capital: "Capital City", city: "City", town: "Town",
  village: "Village", park: "Protected Area", landmark: "Landmark",
};

export function InfoPopup({ place, theme, onClose }: Props) {
  const isLight = theme.ui === "glass-light";
  const desc = DESCRIPTIONS[place.name] ?? "A location in Botswana.";
  return (
    <motion.div
      initial={{ y: 40, opacity: 0, scale: 0.96 }}
      animate={{ y: 0, opacity: 1, scale: 1 }}
      exit={{ y: 40, opacity: 0, scale: 0.98 }}
      transition={{ type: "spring", stiffness: 320, damping: 30 }}
      className={`pointer-events-auto absolute inset-x-3 bottom-3 sm:left-auto sm:right-6 sm:bottom-6 sm:w-[360px] rounded-3xl border p-5 backdrop-blur-2xl shadow-2xl ${
        isLight
          ? "bg-white/60 border-white/70 text-slate-900"
          : "bg-white/8 border-white/15 text-white"
      }`}
      style={{
        boxShadow: isLight
          ? "0 20px 60px -20px rgba(30,50,120,0.35)"
          : `0 20px 60px -10px ${theme.glow}, 0 0 0 1px rgba(255,255,255,0.05) inset`,
      }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span
              className="inline-block h-2 w-2 rounded-full"
              style={{ background: theme.markerCore[place.type], boxShadow: `0 0 12px ${theme.markerCore[place.type]}` }}
            />
            <span className="text-[10px] uppercase tracking-[0.2em] opacity-70">
              {TYPE_LABEL[place.type]}
            </span>
          </div>
          <h3 className="mt-1 truncate text-2xl font-semibold tracking-tight">{place.name}</h3>
        </div>
        <button
          onClick={onClose}
          className={`grid h-8 w-8 place-items-center rounded-full transition ${
            isLight ? "bg-slate-900/10 hover:bg-slate-900/20" : "bg-white/10 hover:bg-white/20"
          }`}
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <p className={`mt-3 text-sm leading-relaxed ${isLight ? "text-slate-700" : "text-white/80"}`}>{desc}</p>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <Stat label="Latitude" value={fmtCoord(place.lat, "N", "S")} light={isLight} />
        <Stat label="Longitude" value={fmtCoord(place.lon, "E", "W")} light={isLight} />
      </div>
    </motion.div>
  );
}

function Stat({ label, value, light }: { label: string; value: string; light: boolean }) {
  return (
    <div className={`rounded-2xl px-3 py-2 ${light ? "bg-slate-900/5" : "bg-white/5"}`}>
      <div className="text-[10px] uppercase tracking-widest opacity-60">{label}</div>
      <div className="mt-0.5 font-mono text-sm">{value}</div>
    </div>
  );
}

function fmtCoord(v: number, pos: string, neg: string) {
  const s = v >= 0 ? pos : neg;
  const a = Math.abs(v);
  const d = Math.floor(a);
  const m = ((a - d) * 60).toFixed(2);
  return `${d}° ${m}′ ${s}`;
}
