import { useEffect, useRef } from "react";
import * as maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

interface Props {
  lon: number;
  lat: number;
  zoom: number;
  pitch: number;
  dark: boolean;
}

export default function RealMapLayer({ lon, lat, zoom, pitch, dark }: Props) {
  const ref = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);

  useEffect(() => {
    if (!ref.current || mapRef.current) return;
    const map = new maplibregl.Map({
      container: ref.current,
      style: {
        version: 8,
        sources: {
          osm: {
            type: "raster",
            tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
            tileSize: 256,
            maxzoom: 19,
            attribution: "© OpenStreetMap contributors",
          },
        },
        layers: [{ id: "osm", type: "raster", source: "osm" }],
      },
      center: [lon, lat],
      zoom: Math.max(0, Math.min(19, zoom)),
      pitch,
      attributionControl: { compact: true },
      interactive: false,
    });
    mapRef.current = map;

    // The container is absolutely positioned; make sure MapLibre measures it
    // once layout has settled (otherwise it renders at zero height).
    const resize = () => map.resize();
    const ro = new ResizeObserver(resize);
    ro.observe(ref.current);
    requestAnimationFrame(resize);

    return () => {
      ro.disconnect();
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    map.jumpTo({ center: [lon, lat], zoom: Math.max(0, Math.min(19, zoom)), pitch });
  }, [lon, lat, zoom, pitch]);

  return (
    <div
      ref={ref}
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        filter: dark ? "invert(1) hue-rotate(180deg) brightness(0.9) contrast(0.95)" : undefined,
      }}
    />
  );
}
