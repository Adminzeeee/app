import { useEffect, useRef } from "react";

export type WeatherType =
  | "off"
  | "rain"
  | "heavy-rain"
  | "snow"
  | "fog"
  | "sandstorm"
  | "lightning";

export const WEATHER_OPTIONS: { key: WeatherType; label: string }[] = [
  { key: "off", label: "Clear" },
  { key: "heavy-rain", label: "Storm" },
  { key: "lightning", label: "Lightning" },
];

interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  l: number;
  s: number;
}

/**
 * GPU-friendly canvas weather. Sits above the map, below the HUD.
 */
export function WeatherLayer({
  type,
  isLight,
}: {
  type: WeatherType;
  isLight: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (type === "off" || type === "fog") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0;
    let h = 0;
    let raf = 0;
    const dpr = Math.min(2, window.devicePixelRatio || 1);

    const resize = () => {
      const r = canvas.getBoundingClientRect();
      w = r.width;
      h = r.height;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const density =
      type === "heavy-rain"
        ? 280
        : type === "rain"
        ? 150
        : type === "snow"
        ? 130
        : type === "sandstorm"
        ? 240
        : type === "lightning"
        ? 200
        : 0;

    const reset = (p: P) => {
      p.x = Math.random() * (w || 400);
      p.y = -20 - Math.random() * (h || 400);
      if (type === "snow") {
        p.vx = -0.25 + Math.random() * 0.5;
        p.vy = 0.55 + Math.random() * 1.2;
        p.l = 0;
        p.s = 1 + Math.random() * 2.6;
      } else if (type === "sandstorm") {
        p.x = -20 - Math.random() * (w || 400);
        p.y = Math.random() * (h || 400);
        p.vx = 5 + Math.random() * 8;
        p.vy = 0.3 + Math.random() * 0.9;
        p.l = 10 + Math.random() * 22;
        p.s = 1;
      } else {
        p.vx = type === "heavy-rain" ? 3.2 : 1.4;
        p.vy = 8 + Math.random() * 10;
        p.l = 10 + Math.random() * 16;
        p.s = 1;
      }
    };

    const particles: P[] = Array.from({ length: density }, () => {
      const p: P = { x: 0, y: 0, vx: 0, vy: 0, l: 0, s: 0 };
      reset(p);
      p.y = Math.random() * (h || 400);
      return p;
    });

    let flashT = 0;
    let flashNext = performance.now() + 2500 + Math.random() * 4000;

    const loop = () => {
      ctx.clearRect(0, 0, w, h);

      if (type === "snow") {
        ctx.fillStyle = isLight ? "rgba(255,255,255,0.95)" : "rgba(240,248,255,0.92)";
        for (const p of particles) {
          p.x += p.vx + Math.sin((p.y + p.s) * 0.02) * 0.4;
          p.y += p.vy;
          if (p.y > h + 4) reset(p);
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (type === "sandstorm") {
        for (const p of particles) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x > w + 20) {
            p.x = -20;
            p.y = Math.random() * h;
          }
          ctx.strokeStyle = `rgba(230,180,110,${0.14 + Math.random() * 0.18})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.l, p.y - 1);
          ctx.stroke();
        }
      } else {
        // rain, heavy-rain, lightning (also draws rain)
        const strokeCol =
          type === "lightning"
            ? "rgba(200,220,255,0.55)"
            : isLight
            ? "rgba(80,110,180,0.55)"
            : "rgba(180,210,255,0.55)";
        ctx.strokeStyle = strokeCol;
        ctx.lineWidth = type === "heavy-rain" ? 1.4 : 1.1;
        for (const p of particles) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.y > h + 4) reset(p);
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 1.2, p.y - p.l);
          ctx.stroke();
        }

        if (type === "lightning") {
          const now = performance.now();
          if (now > flashNext) {
            flashT = 240;
            flashNext = now + 3000 + Math.random() * 5000;
          }
          if (flashT > 0) {
            ctx.fillStyle = `rgba(255,255,255,${(flashT / 240) * 0.55})`;
            ctx.fillRect(0, 0, w, h);
            // rough bolt
            if (flashT > 180) {
              ctx.strokeStyle = "rgba(255,255,255,0.95)";
              ctx.lineWidth = 2;
              ctx.beginPath();
              let bx = w * (0.2 + Math.random() * 0.6);
              let by = 0;
              ctx.moveTo(bx, by);
              while (by < h * 0.7) {
                bx += (Math.random() - 0.5) * 40;
                by += 20 + Math.random() * 30;
                ctx.lineTo(bx, by);
              }
              ctx.stroke();
            }
            flashT -= 16;
          }
        }
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [type, isLight]);

  if (type === "off") return null;

  if (type === "fog") {
    return (
      <div className="pointer-events-none absolute inset-0 z-[7] overflow-hidden">
        <div
          className="absolute -inset-[10%] animate-fog-a"
          style={{
            background:
              "radial-gradient(ellipse at 20% 30%, rgba(255,255,255,0.42), transparent 55%), radial-gradient(ellipse at 70% 60%, rgba(255,255,255,0.28), transparent 55%)",
            mixBlendMode: isLight ? "normal" : "screen",
            filter: "blur(2px)",
          }}
        />
        <div
          className="absolute -inset-[10%] animate-fog-b"
          style={{
            background:
              "radial-gradient(ellipse at 80% 25%, rgba(210,220,240,0.35), transparent 60%), radial-gradient(ellipse at 30% 75%, rgba(230,235,250,0.28), transparent 55%)",
            mixBlendMode: isLight ? "normal" : "screen",
            filter: "blur(3px)",
          }}
        />
        <style>{`
          @keyframes fog-a { 0%{transform:translate3d(0,0,0)} 50%{transform:translate3d(5%,-2%,0)} 100%{transform:translate3d(0,0,0)} }
          @keyframes fog-b { 0%{transform:translate3d(0,0,0)} 50%{transform:translate3d(-4%,3%,0)} 100%{transform:translate3d(0,0,0)} }
          .animate-fog-a{animation: fog-a 28s ease-in-out infinite}
          .animate-fog-b{animation: fog-b 36s ease-in-out infinite}
        `}</style>
      </div>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none absolute inset-0 z-[7] h-full w-full"
    />
  );
}
