/* Stylised regional / world views drawn in the same language as the national
 * map — flat vector shapes, theme palette, glow accents. No raster tiles. */
import { motion } from "framer-motion";
import type { ThemeSpec } from "./themes";
import { alpha } from "./color";

interface Shape { name: string; d: string; cx: number; cy: number; hero?: boolean }

/* Rough, deliberately stylised SADC outlines in a 0..100 box. */
const SADC: Shape[] = [
  { name: "Angola", d: "M8,14 L34,12 L38,20 L37,34 L20,36 L12,32 Z", cx: 23, cy: 24 },
  { name: "Zambia", d: "M38,20 L58,17 L66,24 L62,34 L46,36 L37,34 Z", cx: 50, cy: 26 },
  { name: "Malawi", d: "M66,24 L71,22 L73,34 L68,36 L65,30 Z", cx: 69, cy: 29 },
  { name: "Tanzania", d: "M58,4 L80,6 L82,18 L71,22 L58,17 Z", cx: 70, cy: 12 },
  { name: "Mozambique", d: "M68,36 L82,30 L86,48 L74,66 L66,60 L70,46 Z", cx: 76, cy: 47 },
  { name: "Zimbabwe", d: "M46,36 L62,34 L68,36 L66,50 L52,52 L44,44 Z", cx: 56, cy: 43 },
  { name: "Namibia", d: "M12,32 L20,36 L37,34 L38,48 L30,62 L22,74 L14,70 L10,48 Z", cx: 24, cy: 50 },
  { name: "Botswana", d: "M38,48 L44,44 L52,52 L54,62 L48,72 L36,72 L30,62 Z", cx: 43, cy: 60, hero: true },
  { name: "South Africa", d: "M22,74 L30,62 L36,72 L48,72 L54,62 L66,60 L70,74 L58,90 L38,94 L24,86 Z", cx: 46, cy: 79 },
  { name: "Eswatini", d: "M64,74 L69,73 L69,79 L64,79 Z", cx: 66.5, cy: 76 },
  { name: "Lesotho", d: "M50,80 L57,79 L58,85 L51,86 Z", cx: 54, cy: 82.5 },
];

export function StylizedRegion({
  region, theme, isLight,
}: { region: "southern" | "world"; theme: ThemeSpec; isLight: boolean }) {
  const g = theme.glow;
  const ink = isLight ? "#0f172a" : "#e6f0ff";

  return (
    <div className="absolute inset-0 overflow-hidden">
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" className="h-full w-full">
        <defs>
          <linearGradient id="srHero" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={g} stopOpacity="0.85" />
            <stop offset="1" stopColor={g} stopOpacity="0.45" />
          </linearGradient>
          <pattern id="srGrid" width="5" height="5" patternUnits="userSpaceOnUse">
            <path d="M5 0 L0 0 0 5" fill="none" stroke={alpha(g, 0.14)} strokeWidth="0.15" />
          </pattern>
        </defs>

        <rect x="0" y="0" width="100" height="100" fill="url(#srGrid)" />

        {region === "southern" ? (
          <g>
            {SADC.map((c, i) => (
              <motion.path
                key={c.name} d={c.d}
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04, duration: 0.5 }}
                fill={c.hero ? "url(#srHero)" : alpha(g, 0.1)}
                stroke={c.hero ? g : alpha(ink, 0.35)}
                strokeWidth={c.hero ? 0.6 : 0.3}
                strokeLinejoin="round"
              />
            ))}
            {SADC.map((c) => (
              <text
                key={`t${c.name}`} x={c.cx} y={c.cy} textAnchor="middle"
                fontSize={c.hero ? 2.6 : 1.9}
                fontWeight={c.hero ? 900 : 600}
                fill={c.hero ? (isLight ? "#ffffff" : "#04121f") : ink}
                opacity={c.hero ? 1 : 0.6}
                style={{ letterSpacing: "0.06em", textTransform: "uppercase" }}
              >
                {c.name}
              </text>
            ))}
          </g>
        ) : (
          <g>
            <circle cx="50" cy="50" r="38" fill={alpha(g, 0.07)} stroke={alpha(g, 0.35)} strokeWidth="0.3" />
            {[-30, -15, 0, 15, 30].map((lat) => (
              <ellipse key={lat} cx="50" cy={50 + lat * 0.9} rx={38 * Math.cos((lat / 45) * 1.1)} ry="0.4"
                fill="none" stroke={alpha(g, 0.22)} strokeWidth="0.22" />
            ))}
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <ellipse key={i} cx="50" cy="50" rx={38 * Math.abs(Math.cos((i / 6) * Math.PI))} ry="38"
                fill="none" stroke={alpha(g, 0.18)} strokeWidth="0.22" />
            ))}
            {[[38, 34], [55, 30], [64, 46], [30, 60], [70, 66], [46, 72], [58, 55]].map(([x, y], i) => (
              <g key={i}>
                <motion.circle cx={x} cy={y} r="1.1" fill={g}
                  animate={{ opacity: [0.35, 1, 0.35] }} transition={{ duration: 2.4, delay: i * 0.3, repeat: Infinity }} />
                <motion.circle cx={x} cy={y} r="1.1" fill="none" stroke={g} strokeWidth="0.2"
                  animate={{ r: [1.1, 5], opacity: [0.6, 0] }} transition={{ duration: 2.4, delay: i * 0.3, repeat: Infinity }} />
              </g>
            ))}
            <motion.circle cx="50" cy="61" r="2.2" fill={g}
              animate={{ scale: [1, 1.25, 1] }} transition={{ duration: 2, repeat: Infinity }} />
            <text x="50" y="68" textAnchor="middle" fontSize="2.4" fontWeight={900} fill={ink} opacity={0.8}>BOTSWANA</text>
          </g>
        )}
      </svg>

      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: `radial-gradient(ellipse at 50% 55%, transparent 40%, ${alpha(g, 0.12)} 100%)` }}
      />
    </div>
  );
}
