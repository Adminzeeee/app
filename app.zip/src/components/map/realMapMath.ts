/** Browser-safe conversions between the stylised SVG space and real-world coords. */

/** Linear fit derived from the dataset: svg units -> lon/lat. */
export function svgToLonLat(x: number, y: number) {
  return { lon: 0.0098680214 * x + 19.72863008, lat: -0.0098640932 * y - 17.40515732 };
}

/** svg-units-per-pixel -> web mercator zoom */
export function scaleToZoom(scale: number, lat: number) {
  const cos = Math.cos((lat * Math.PI) / 180);
  const metersPerPixel = (0.0098680214 * 111320 * cos) / Math.max(0.0001, scale);
  return Math.log2((156543.03392 * cos) / metersPerPixel);
}
