import type { MapTheme } from "./types";

export interface ThemeSpec {
  name: string;
  bg: string;
  vignette: string;
  countryFill: string;
  countryStroke: string;
  districtFill: string;
  districtStroke: string;
  districtHoverFill: string;
  glow: string;
  gridColor: string;
  grid: boolean;
  particleColor: string;
  labelColor: string;
  labelHalo: string;
  markerCore: Record<string, string>;
  markerRing: string;
  ui: "glass-dark" | "glass-light";
  /** Frosted-glass surfaces for cards/panels. */
  glass?: boolean;
  /** Optional advanced visual effects layer (new premium themes). */
  fx?: {
    tilt?: number;
    scan?: boolean;
    aurora?: boolean;
    stars?: boolean;
    caustics?: boolean;
    ember?: boolean;
    prism?: boolean;
    horizon?: boolean;
    ripple?: boolean;
    /** soft volumetric bloom blobs */
    bloom?: boolean;
    /** sweeping light rays */
    rays?: boolean;
    /** orbiting satellite rings */
    orbit?: boolean;
    /** animated depth mesh */
    mesh?: boolean;
  };
}



export const THEMES: Record<MapTheme, ThemeSpec> = {
  light: {
    name: "Daylight",
    bg: "radial-gradient(ellipse at 30% 20%, #f5f8ff 0%, #e6ecf8 60%, #d5dcec 100%)",
    vignette: "radial-gradient(ellipse at center, transparent 60%, rgba(80,90,120,0.18) 100%)",
    countryFill: "url(#bw-country-light)",
    countryStroke: "rgba(40,60,110,0.5)",
    districtFill: "rgba(255,255,255,0.55)",
    districtStroke: "rgba(60,80,140,0.2)",
    districtHoverFill: "rgba(120,160,255,0.18)",
    glow: "rgba(50,90,200,0.7)",
    gridColor: "rgba(40,60,110,0.05)",
    grid: false,
    particleColor: "rgba(80,120,200,0.5)",
    labelColor: "#0d1a3a",
    labelHalo: "rgba(255,255,255,0.9)",
    markerCore: {
      capital: "#ff4d6d", city: "#3a6dff", town: "#5b7cff",
      village: "#7a8ec2", park: "#0fb36a", landmark: "#d97706",
    },
    markerRing: "rgba(60,100,220,0.75)",
    ui: "glass-light",
  },
  blueprint: {
    name: "Blueprint",
    bg: "linear-gradient(180deg, #0a1f4d 0%, #061436 100%)",
    vignette: "radial-gradient(ellipse at center, transparent 65%, rgba(0,10,40,0.75) 100%)",
    countryFill: "rgba(120,190,255,0.06)",
    countryStroke: "rgba(150,220,255,0.9)",
    districtFill: "rgba(120,190,255,0.03)",
    districtStroke: "rgba(150,220,255,0.35)",
    districtHoverFill: "rgba(150,220,255,0.12)",
    glow: "rgba(180,230,255,0.9)",
    gridColor: "rgba(150,220,255,0.12)",
    grid: true,
    particleColor: "rgba(200,240,255,0.6)",
    labelColor: "#dff2ff",
    labelHalo: "rgba(6,20,54,0.9)",
    markerCore: {
      capital: "#ffffff", city: "#bfe9ff", town: "#8fd0ff",
      village: "#6fbaff", park: "#a8ffdc", landmark: "#ffe58a",
    },
    markerRing: "rgba(200,240,255,0.9)",
    ui: "glass-dark",
  },
  midnight: {
    name: "Midnight",
    bg: "linear-gradient(180deg, #000000 0%, #05070f 100%)",
    vignette: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.9) 100%)",
    countryFill: "rgba(255,255,255,0.03)",
    countryStroke: "rgba(255,255,255,0.35)",
    districtFill: "rgba(255,255,255,0.02)",
    districtStroke: "rgba(255,255,255,0.12)",
    districtHoverFill: "rgba(255,255,255,0.08)",
    glow: "rgba(255,255,255,0.6)",
    gridColor: "rgba(255,255,255,0.04)",
    grid: false,
    particleColor: "rgba(255,255,255,0.4)",
    labelColor: "#ffffff",
    labelHalo: "rgba(0,0,0,0.9)",
    markerCore: {
      capital: "#ffffff", city: "#e5e7eb", town: "#9ca3af",
      village: "#6b7280", park: "#f9fafb", landmark: "#fef3c7",
    },
    markerRing: "rgba(255,255,255,0.8)",
    ui: "glass-dark",
  },
  mist: {
    name: "Mist",
    bg: "linear-gradient(180deg, #edf4f6 0%, #dce6e9 100%)",
    vignette: "radial-gradient(ellipse at center, transparent 68%, rgba(51,65,85,0.12) 100%)",
    countryFill: "rgba(255,255,255,0.7)",
    countryStroke: "#526a73",
    districtFill: "rgba(255,255,255,0.3)",
    districtStroke: "rgba(82,106,115,0.18)",
    districtHoverFill: "rgba(2,132,199,0.10)",
    glow: "#0284c7",
    gridColor: "rgba(82,106,115,0.04)",
    grid: false,
    particleColor: "rgba(2,132,199,0.3)",
    labelColor: "#18323b",
    labelHalo: "rgba(237,244,246,0.94)",
    markerCore: { capital: "#be123c", city: "#0284c7", town: "#0891b2", village: "#64748b", park: "#16a34a", landmark: "#ca8a04" },
    markerRing: "rgba(2,132,199,0.65)",
    ui: "glass-light",
  },
};
