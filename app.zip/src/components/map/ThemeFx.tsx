import { useCallback, useEffect, useRef, useState } from "react";
import type { ThemeSpec } from "./themes";
import { alpha } from "./color";

/**
 * Advanced per-theme visual effects layer.
 * Everything here animates transform / opacity only, so it stays GPU friendly.
 */
export function ThemeFx({ theme }: { theme: ThemeSpec }) {
  const fx = theme.fx;
  if (!fx) return null;

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" style={{ zIndex: 6 }}>
      {fx.stars && <Stars color={theme.particleColor} />}
      {fx.prism && <Prism glow={theme.glow} />}
      {fx.scan && <Scan glow={theme.glow} />}
      {fx.caustics && <Caustics glow={theme.glow} />}
      {fx.ember && <Ember glow={theme.glow} />}
      {fx.horizon && <Horizon glow={theme.glow} grid={theme.gridColor} />}
      {fx.bloom && <Bloom glow={theme.glow} />}
      {fx.rays && <Rays glow={theme.glow} />}
      {fx.orbit && <Orbit glow={theme.glow} />}
      {fx.mesh && <Mesh glow={theme.glow} />}
      <style>{`
        @keyframes fx-twinkle { 0%,100%{opacity:.15;transform:scale(.7)} 50%{opacity:1;transform:scale(1.15)} }
        @keyframes fx-scan { from{transform:translate3d(0,-30%,0)} to{transform:translate3d(0,130%,0)} }
        @keyframes fx-spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes fx-drift { 0%,100%{transform:translate3d(-4%,0,0) scale(1)} 50%{transform:translate3d(4%,3%,0) scale(1.12)} }
        @keyframes fx-rise { from{transform:translate3d(0,10%,0);opacity:0} 25%{opacity:.9} to{transform:translate3d(0,-120%,0);opacity:0} }
        @keyframes fx-ripple { from{transform:scale(.2);opacity:.55} to{transform:scale(1);opacity:0} }
        @keyframes fx-breathe { 0%,100%{transform:translate3d(0,0,0) scale(1);opacity:.35} 50%{transform:translate3d(2%,-3%,0) scale(1.25);opacity:.7} }
        @keyframes fx-sweep { from{transform:translate3d(-60%,0,0) rotate(12deg)} to{transform:translate3d(160%,0,0) rotate(12deg)} }
        @keyframes fx-orbit { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes fx-meshpan { from{background-position:0 0} to{background-position:120px 120px} }
      `}</style>
    </div>
  );
}

function Bloom({ glow }: { glow: string }) {
  return (
    <>
      {[0, 1, 2, 3].map((i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            left: `${8 + i * 24}%`,
            top: `${10 + ((i * 29) % 62)}%`,
            width: 220 + i * 60,
            height: 220 + i * 60,
            background: `radial-gradient(circle at 40% 40%, ${alpha(glow, 0.5)}, transparent 68%)`,
            filter: "blur(42px)",
            mixBlendMode: "screen",
            animation: `fx-breathe ${11 + i * 2.6}s ease-in-out ${i * 1.7}s infinite`,
            willChange: "transform, opacity",
          }}
        />
      ))}
    </>
  );
}

function Rays({ glow }: { glow: string }) {
  return (
    <>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="absolute -top-1/4 h-[150%] w-[22%]"
          style={{
            background: `linear-gradient(90deg, transparent, ${alpha(glow, 0.28)}, transparent)`,
            filter: "blur(18px)",
            mixBlendMode: "screen",
            animation: `fx-sweep ${9 + i * 4}s linear ${i * 3}s infinite`,
            willChange: "transform",
          }}
        />
      ))}
    </>
  );
}

function Orbit({ glow }: { glow: string }) {
  return (
    <div className="absolute left-1/2 top-1/2 h-0 w-0">
      {[0, 1, 2].map((i) => {
        const size = 280 + i * 190;
        return (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              left: -size / 2,
              top: -size / 2,
              width: size,
              height: size,
              border: `1px solid ${alpha(glow, 0.22 - i * 0.05)}`,
              transform: `rotateX(70deg)`,
              animation: `fx-orbit ${26 + i * 14}s linear infinite`,
              willChange: "transform",
            }}
          >
            <span
              className="absolute rounded-full"
              style={{
                left: "50%",
                top: -3,
                width: 6,
                height: 6,
                background: glow,
                boxShadow: `0 0 14px ${glow}`,
              }}
            />
          </div>
        );
      })}
    </div>
  );
}

function Mesh({ glow }: { glow: string }) {
  return (
    <div
      className="absolute inset-0 opacity-[0.14]"
      style={{
        backgroundImage: `linear-gradient(${alpha(glow, 0.5)} 1px, transparent 1px), linear-gradient(90deg, ${alpha(glow, 0.5)} 1px, transparent 1px)`,
        backgroundSize: "120px 120px",
        maskImage: "radial-gradient(ellipse at 50% 55%, black 10%, transparent 72%)",
        animation: "fx-meshpan 18s linear infinite",
      }}
    />
  );
}


function Stars({ color }: { color: string }) {
  const dots = Array.from({ length: 46 }, (_, i) => ({
    x: ((i * 37) % 100) + ((i % 3) * 0.7),
    y: ((i * 61) % 100) + ((i % 5) * 0.4),
    s: 1 + (i % 3) * 0.7,
    d: 1.8 + (i % 7) * 0.45,
    delay: (i % 11) * 0.31,
  }));
  return (
    <>
      {dots.map((d, i) => (
        <span
          key={i}
          className="absolute rounded-full"
          style={{
            left: `${d.x}%`,
            top: `${d.y}%`,
            width: d.s,
            height: d.s,
            background: color,
            boxShadow: `0 0 ${d.s * 3}px ${color}`,
            animation: `fx-twinkle ${d.d}s ease-in-out ${d.delay}s infinite`,
          }}
        />
      ))}
    </>
  );
}

function Prism({ glow }: { glow: string }) {
  return (
    <div
      className="absolute left-1/2 top-1/2 h-[160%] w-[160%] -translate-x-1/2 -translate-y-1/2 opacity-[0.16]"
      style={{
        background: `conic-gradient(from 0deg, transparent 0deg, ${glow} 40deg, transparent 90deg, #ff6ec7 150deg, transparent 200deg, #7dd3fc 260deg, transparent 320deg)`,
        filter: "blur(38px)",
        mixBlendMode: "screen",
        animation: "fx-spin 34s linear infinite",
        willChange: "transform",
      }}
    />
  );
}

function Scan({ glow }: { glow: string }) {
  return (
    <>
      <div
        className="absolute inset-x-0 h-24 opacity-30"
        style={{
          background: `linear-gradient(180deg, transparent, ${glow}55, transparent)`,
          animation: "fx-scan 4.6s linear infinite",
          willChange: "transform",
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.10]"
        style={{
          backgroundImage: `repeating-linear-gradient(180deg, ${glow} 0px, ${glow} 1px, transparent 1px, transparent 4px)`,
        }}
      />
    </>
  );
}

function Caustics({ glow }: { glow: string }) {
  return (
    <>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="absolute rounded-full opacity-25"
          style={{
            left: `${12 + i * 28}%`,
            top: `${18 + i * 21}%`,
            width: 260,
            height: 200,
            background: `radial-gradient(ellipse at center, ${glow}, transparent 70%)`,
            filter: "blur(30px)",
            animation: `fx-drift ${9 + i * 3}s ease-in-out ${i * 1.4}s infinite`,
            willChange: "transform",
          }}
        />
      ))}
    </>
  );
}

function Ember({ glow }: { glow: string }) {
  const bits = Array.from({ length: 26 }, (_, i) => ({
    x: (i * 41) % 100,
    s: 1.5 + (i % 4),
    d: 5 + (i % 6) * 1.4,
    delay: (i % 9) * 0.7,
  }));
  return (
    <>
      {bits.map((b, i) => (
        <span
          key={i}
          className="absolute bottom-0 rounded-full"
          style={{
            left: `${b.x}%`,
            width: b.s,
            height: b.s,
            background: glow,
            boxShadow: `0 0 ${b.s * 4}px ${glow}`,
            animation: `fx-rise ${b.d}s linear ${b.delay}s infinite`,
            willChange: "transform, opacity",
          }}
        />
      ))}
    </>
  );
}

function Horizon({ glow, grid }: { glow: string; grid: string }) {
  return (
    <div className="absolute inset-x-0 bottom-0 h-1/2 overflow-hidden" style={{ perspective: 260 }}>
      <div
        className="absolute inset-0 origin-bottom"
        style={{
          transform: "rotateX(72deg)",
          backgroundImage: `linear-gradient(${grid} 1px, transparent 1px), linear-gradient(90deg, ${grid} 1px, transparent 1px)`,
          backgroundSize: "44px 44px",
          maskImage: "linear-gradient(180deg, transparent, black 45%)",
          WebkitMaskImage: "linear-gradient(180deg, transparent, black 45%)",
        }}
      />
      <div
        className="absolute inset-x-0 top-0 h-px"
        style={{ background: glow, boxShadow: `0 0 18px 3px ${glow}` }}
      />
    </div>
  );
}

/* ---------------- touch ripples ---------------- */

export interface Ripple { id: number; x: number; y: number }

export function useRipples() {
  const idRef = useRef(0);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const spawn = useCallback((x: number, y: number) => {
    const id = ++idRef.current;
    setRipples((r) => [...r.slice(-6), { id, x, y }]);
    window.setTimeout(() => setRipples((r) => r.filter((p) => p.id !== id)), 800);
  }, []);
  return { ripples, spawn };
}

export function RippleLayer({ ripples, color }: { ripples: Ripple[]; color: string }) {
  useEffect(() => undefined, []);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" style={{ zIndex: 12 }}>
      {ripples.map((r) => (
        <span
          key={r.id}
          className="absolute rounded-full"
          style={{
            left: r.x - 70,
            top: r.y - 70,
            width: 140,
            height: 140,
            border: `1.5px solid ${color}`,
            boxShadow: `0 0 24px ${alpha(color, 0.4)}, inset 0 0 24px ${alpha(color, 0.27)}`,
            animation: "fx-ripple 0.75s cubic-bezier(0.22,1,0.36,1) forwards",
            willChange: "transform, opacity",
          }}
        />
      ))}
      <style>{`@keyframes fx-ripple { from{transform:scale(.15);opacity:.6} to{transform:scale(1);opacity:0} }`}</style>
    </div>
  );
}
