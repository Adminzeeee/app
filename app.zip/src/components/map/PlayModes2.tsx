/* Premium modes 2–3 — both camera-driven ("map-focus"): the map flies to a
 * real place and these two overlays present that same place two very
 * different ways (broadcast vs. dossier), always in lockstep with the fly. */
import { AnimatePresence, motion } from "framer-motion";
import { Radio, TrendingDown, TrendingUp } from "lucide-react";
import type { ThemeSpec } from "./themes";
import { alpha } from "./color";
import { PLACE_CYCLE, statsFor, clockIndex } from "./playData";

export { clockIndex } from "./playData";

const EASE = [0.22, 1, 0.36, 1] as const;

/** Consumed directly by BotswanaMap to fly the camera to each place. */
export const SPOTLIGHT_MS = 6400;
export const SPOTLIGHTS = PLACE_CYCLE.map((name) => {
  const s = statsFor(name);
  return { place: name, district: s.district, scale: s.scale };
});

function useSyncedPlace() {
  const i = clockIndex(PLACE_CYCLE.length, SPOTLIGHT_MS);
  return statsFor(PLACE_CYCLE[i]);
}

/* ---------------- 2 · Broadcast Live (news-broadcast style) ---------------- */

function BroadcastLive({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSyncedPlace();
  const text = isLight ? "#0f172a" : "#ffffff";
  return (
    <div className="absolute inset-0">
      {/* top bug */}
      <div className="absolute left-3 top-3 flex items-center gap-1.5 rounded-md px-2 py-1 backdrop-blur-md"
        style={{ background: alpha("#ef4444", 0.16) }}>
        <motion.span animate={{ opacity: [1, 0.25, 1] }} transition={{ duration: 1.2, repeat: Infinity }}
          className="h-1.5 w-1.5 rounded-full" style={{ background: "#ef4444" }} />
        <span className="text-[9px] font-black uppercase tracking-[0.3em] text-red-500">Live</span>
        <Radio className="h-3 w-3" style={{ color: theme.glow }} />
        <span className="hidden text-[9px] font-black uppercase tracking-[0.3em] sm:inline" style={{ color: theme.glow }}>Botswana Now</span>
      </div>

      {/* side dossier card, top-right, docked so it never collides with lower third */}
      <AnimatePresence mode="wait">
        <motion.div key={s.name} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.35, ease: EASE }}
          className="absolute right-2 top-3 w-[50%] max-w-[220px] rounded-lg border p-1.5 backdrop-blur-xl sm:right-3 sm:p-2"
          style={{ borderColor: alpha(theme.glow, 0.3), background: alpha(isLight ? "#ffffff" : "#04060d", 0.72) }}>
          <div className="truncate text-[7.5px] font-black uppercase tracking-[0.25em] sm:text-[8px] sm:tracking-[0.3em]" style={{ color: theme.glow }}>{s.district}</div>
          <div className="mt-0.5 grid grid-cols-2 gap-1 sm:gap-1.5">
            {s.table.slice(0, 4).map((t) => (
              <div key={t.metric} className="min-w-0">
                <div className="truncate text-[11px] font-black tabular-nums sm:text-[13px]" style={{ color: text }}>{t.value}</div>
                <div className="truncate text-[6.5px] font-bold uppercase tracking-[0.08em] opacity-55 sm:text-[7px] sm:tracking-[0.1em]" style={{ color: text }}>{t.metric}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* lower-third */}
      <div className="absolute inset-x-0 bottom-0">
        <div className="h-1 w-full" style={{ background: `linear-gradient(90deg, ${theme.glow}, transparent)` }} />
        <div className="p-2.5 sm:p-3" style={{ background: `linear-gradient(0deg, ${alpha(isLight ? "#ffffff" : "#04060d", 0.94)}, transparent)` }}>
          <AnimatePresence mode="wait">
            <motion.div key={s.name} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.5, ease: EASE }}>
              <div className="flex items-center gap-2">
                <span className="rounded px-1.5 py-[2px] text-[8.5px] font-black uppercase tracking-[0.15em] text-white sm:text-[9px] sm:tracking-[0.2em]" style={{ background: theme.glow }}>
                  {s.name}
                </span>
                <span className="text-[8.5px] font-bold uppercase tracking-[0.15em] opacity-60 sm:text-[9px] sm:tracking-[0.2em]" style={{ color: text }}>{s.timestamp}</span>
              </div>
              <div className="mt-1 max-w-[560px] text-[12.5px] font-black leading-tight sm:text-[19px]" style={{ color: text, fontFamily: "'Sora',sans-serif" }}>
                {s.headline}
              </div>
              <div className="mt-0.5 max-w-[520px] text-[9.5px] font-medium opacity-70 sm:text-[10px]" style={{ color: text }}>{s.subhead}</div>
            </motion.div>
          </AnimatePresence>
          <div className="mt-2 overflow-hidden whitespace-nowrap border-t border-current/10 pt-1.5" style={{ color: theme.glow }}>
            <motion.div className="inline-block text-[8.5px] font-bold sm:text-[9px]" animate={{ x: ["0%", "-50%"] }}
              transition={{ duration: 22, repeat: Infinity, ease: "linear" }}>
              {PLACE_CYCLE.map((n) => `  •  ${statsFor(n).headline.toUpperCase()}`).join(" ").repeat(2)}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- 3 · Metric Dossier (overlay cards + table) ---------------- */

function MetricDossier({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSyncedPlace();
  const text = isLight ? "#0f172a" : "#ffffff";
  const max = Math.max(...s.history);
  const surface = alpha(isLight ? "#ffffff" : "#04060d", 0.86);
  return (
    <div
      className="pointer-events-none absolute inset-x-2 bottom-2 top-auto flex max-h-[56vh] w-auto flex-col justify-end gap-2 overflow-y-auto rounded-xl border px-3 py-2.5 backdrop-blur-xl sm:inset-x-auto sm:inset-y-0 sm:right-0 sm:top-0 sm:bottom-0 sm:max-h-none sm:w-[58%] sm:max-w-[440px] sm:justify-center sm:overflow-visible sm:rounded-none sm:border-0 sm:border-l sm:px-4 sm:py-0"
      style={{ borderColor: alpha(theme.glow, 0.2), background: surface }}
    >
      <AnimatePresence mode="wait">
        <motion.div key={s.name} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.45, ease: EASE }}>
          <div className="text-[8px] font-black uppercase tracking-[0.3em] sm:text-[9px] sm:tracking-[0.4em]" style={{ color: theme.glow }}>{s.district} · dossier</div>
          <div className="mt-0.5 truncate text-[20px] font-black leading-none sm:text-[32px]" style={{ color: text, fontFamily: "'Sora',sans-serif" }}>{s.name}</div>

          {/* sparkline */}
          <svg viewBox="0 0 200 44" className="mt-2 h-7 w-full max-w-[280px] sm:h-9">
            <motion.polyline
              points={s.history.map((v, i) => `${(i / (s.history.length - 1)) * 200},${44 - (v / max) * 40}`).join(" ")}
              fill="none" stroke={theme.glow} strokeWidth="2" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
              transition={{ duration: 1.1, ease: EASE }} style={{ filter: `drop-shadow(0 0 6px ${alpha(theme.glow, 0.6)})` }} />
          </svg>

          {/* table */}
          <div className="mt-2 divide-y divide-current/10 rounded-lg border" style={{ borderColor: alpha(theme.glow, 0.2) }}>
            {s.table.slice(0, 5).map((row, k) => (
              <motion.div key={row.metric} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 + k * 0.06, ease: EASE }}
                className="flex items-center justify-between gap-2 px-2 py-1 sm:py-1.5">
                <span className="min-w-0 truncate text-[9px] font-semibold opacity-70 sm:text-[10px]" style={{ color: text }}>{row.metric}</span>
                <span className="shrink-0 text-[10px] font-black tabular-nums sm:text-[11px]" style={{ color: text }}>{row.value}</span>
                <span className="flex shrink-0 items-center gap-0.5 text-[8.5px] font-bold tabular-nums sm:text-[9px]" style={{ color: row.up ? "#34d399" : "#f87171" }}>
                  {row.up ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}{row.delta}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

export function PlayLayer2({ mode, theme, isLight }: { mode: number; theme: ThemeSpec; isLight: boolean }) {
  if (mode === 2) return <BroadcastLive theme={theme} isLight={isLight} />;
  if (mode === 3) return <MetricDossier theme={theme} isLight={isLight} />;
  return null;
}
