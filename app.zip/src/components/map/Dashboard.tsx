import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Compass, LayoutGrid, Palette } from "lucide-react";
import type { MapTheme, Place } from "./types";
import { THEMES, type ThemeSpec } from "./themes";
import { alpha } from "./color";
import { Tap, useSkin } from "./dashboard/ui";
import { ExploreShell } from "./dashboard/ExploreShell";
import { SayShell } from "./dashboard/SayShell";
import { WorkspaceShell } from "./dashboard/WorkspaceShell";
import { LAYOUTS, LAYOUT_KEY, type LayoutSpec } from "./dashboard/layouts";

interface Props {
  theme: ThemeSpec;
  place: Place | null;
  totalPlaces: number;
  totalDistricts: number;
  onSelectPlace?: (p: Place | null) => void;
}

type TabKey = "explore" | "workspace" | "say";

const TABS: { key: TabKey; label: string; icon: React.ReactNode }[] = [
  { key: "explore", label: "Explore", icon: <Compass className="h-3.5 w-3.5" /> },
  { key: "workspace", label: "Workspace", icon: null },
  { key: "say", label: "Have your say", icon: null },
];


export function Dashboard({ theme, place, onSelectPlace }: Props) {
  const [tab, setTab] = useState<TabKey>("explore");
  const [dashTheme, setDashTheme] = useState<MapTheme | "inherit">("inherit");
  const [themeOpen, setThemeOpen] = useState(false);
  const [layoutId, setLayoutId] = useState(7);
  const [layoutOpen, setLayoutOpen] = useState(false);

  useEffect(() => {
    const saved = Number(window.localStorage.getItem(LAYOUT_KEY));
    if (LAYOUTS.some((x) => x.id === saved)) setLayoutId(saved);
  }, []);

  useEffect(() => {
    try { window.localStorage.setItem(LAYOUT_KEY, String(layoutId)); } catch { /* ignore */ }
  }, [layoutId]);

  const L = LAYOUTS.find((x) => x.id === layoutId)!;
  const t = dashTheme === "inherit" ? theme : THEMES[dashTheme];
  const isLight = t.ui === "glass-light";
  const s = useSkin(isLight);
  const scope = place?.name ?? "Botswana";

  const nav = (
    <TabBar
      L={L} t={t} isLight={isLight} tab={tab} setTab={setTab}
      onTheme={() => { setThemeOpen((v) => !v); setLayoutOpen(false); }}
      onLayout={() => { setLayoutOpen((v) => !v); setThemeOpen(false); }}
    />
  );

  return (
    <div
      className={`relative flex h-full min-h-0 flex-col ${isLight ? "text-slate-900" : "text-white"}`}
      style={{ fontFamily: L.font, letterSpacing: L.tracking, background: t.bg }}
    >
      <div
        className="flex min-h-0 flex-1 flex-col"
        style={{ zoom: L.zoom, background: L.tint ? alpha(t.glow, L.tint) : undefined }}
      >
        {L.tabPos === "top" && nav}

        {/* layout switcher */}
        <AnimatePresence>
          {layoutOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-y px-2.5 py-1.5"
              style={{ borderColor: alpha(t.glow, 0.18) }}
            >
              <div className={`mb-1 text-[7px] font-black uppercase tracking-[0.18em] ${s.muted}`}>
                Dashboard layout
              </div>
              <div className="grid grid-cols-2 gap-1">
                {LAYOUTS.map((x) => (
                  <button
                    key={x.id}
                    onClick={() => { setLayoutId(x.id); setLayoutOpen(false); }}
                    className="rounded-md border px-1.5 py-1 text-left"
                    style={{
                      borderColor: layoutId === x.id ? t.glow : alpha(t.glow, 0.2),
                      background: layoutId === x.id ? alpha(t.glow, 0.16) : "transparent",
                    }}
                  >
                    <div className="text-[9px] font-black">{x.id}. {x.name}</div>
                    <div className={`truncate text-[7.5px] ${s.muted}`}>{x.blurb}</div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* theme switcher */}
        <AnimatePresence>
          {themeOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-y px-2.5 py-1"
              style={{ borderColor: alpha(t.glow, 0.18) }}
            >
              <div className={`mb-1 text-[7px] font-black uppercase tracking-[0.18em] ${s.muted}`}>
                Dashboard theme (map keeps the main theme)
              </div>
              <div className="flex flex-wrap gap-1">
                <button
                  onClick={() => setDashTheme("inherit")}
                  className="rounded-full px-2 py-[2px] text-[8px] font-bold"
                  style={dashTheme === "inherit" ? { background: t.glow, color: isLight ? "#fff" : "#04121f" } : { background: alpha(t.glow, 0.12) }}
                >
                  Match map
                </button>
                {(Object.keys(THEMES) as MapTheme[]).map((k) => (
                  <button
                    key={k}
                    onClick={() => setDashTheme(k)}
                    className="flex items-center gap-1 rounded-full border px-1.5 py-[2px] text-[8px] font-bold"
                    style={{
                      borderColor: dashTheme === k ? THEMES[k].glow : alpha(t.glow, 0.2),
                      background: dashTheme === k ? alpha(THEMES[k].glow, 0.18) : "transparent",
                    }}
                  >
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: THEMES[k].glow, boxShadow: `0 0 6px ${THEMES[k].glow}` }} />
                    <span className="truncate">{THEMES[k].name}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* body */}
        <div className={`min-h-0 flex-1 overflow-y-auto pb-2 pt-1.5 ${L.tabs === "rail" ? "pl-1 pr-2.5" : "px-2.5"}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={tab + layoutId}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.18 }}
            >
              {tab === "explore" && (
                <ExploreShell theme={t} isLight={isLight} place={place} onSelectPlace={onSelectPlace} />
              )}
              {tab === "workspace" && <WorkspaceShell theme={t} isLight={isLight} scope={scope} />}
              {tab === "say" && <SayShell theme={t} isLight={isLight} />}
            </motion.div>
          </AnimatePresence>
        </div>

        {L.tabPos === "bottom" && nav}
      </div>
    </div>
  );
}

/* ---------------- tab chrome, one per layout ---------------- */

function TabBar({
  L, t, isLight, tab, setTab, onTheme, onLayout,
}: {
  L: LayoutSpec; t: ThemeSpec; isLight: boolean;
  tab: TabKey; setTab: (k: TabKey) => void;
  onTheme: () => void; onLayout: () => void;
}) {
  const s = useSkin(isLight);
  const accent = "#f59e0b";
  const label = (x: string) => (L.upper ? x.toUpperCase() : x);

  const tools = (
    <>
      <Tap
        color={t.glow} effect="squish" onClick={onLayout} title="Dashboard layout"
        className={`grid h-[22px] w-[24px] shrink-0 place-items-center ${s.chip}`}
        style={{ borderRadius: L.radius }}
      >
        <LayoutGrid className="h-3 w-3" style={{ color: t.glow }} />
      </Tap>
      <Tap
        color={t.glow} effect="squish" onClick={onTheme} title="Dashboard theme"
        className={`grid h-[22px] w-[24px] shrink-0 place-items-center ${s.chip}`}
        style={{ borderRadius: L.radius }}
      >
        <Palette className="h-3 w-3" style={{ color: t.glow }} />
      </Tap>
    </>
  );

  /* side rail */
  if (L.tabs === "rail") {
    return (
      <div className="flex items-center gap-1 px-2.5 pb-1 pt-1.5">
        <div className="flex items-center gap-1">
          {TABS.map((x) => (
            <Tap
              key={x.key} color={t.glow} effect="squish" onClick={() => setTab(x.key)}
              className="flex items-center gap-1.5 px-2 py-[5px] text-[10px] font-bold"
              style={{
                borderRadius: L.radius,
                background: tab === x.key ? alpha(x.key === "explore" ? accent : t.glow, 0.2) : "transparent",
                color: tab === x.key ? (x.key === "explore" ? accent : t.glow) : undefined,
                opacity: tab === x.key ? 1 : 0.6,
              }}
            >
              {x.icon}
              <span>{label(x.label)}</span>
            </Tap>
          ))}
        </div>
        <div className="ml-auto flex gap-1">{tools}</div>
      </div>
    );
  }

  /* underline / editorial */
  if (L.tabs === "underline") {
    return (
      <div className="flex items-end gap-3 border-b px-3 pb-1 pt-2" style={{ borderColor: alpha(t.glow, 0.18) }}>
        {TABS.map((x) => {
          const on = tab === x.key;
          const c = x.key === "explore" ? accent : t.glow;
          return (
            <button
              key={x.key} onClick={() => setTab(x.key)}
              className="relative flex items-center gap-1.5 pb-1 text-[12px] font-extrabold"
              style={{ fontFamily: L.headFont, color: on ? c : undefined, opacity: on ? 1 : 0.45 }}
            >
              {x.icon}
              {label(x.label)}
              {on && <motion.span layoutId="ul" className="absolute -bottom-[5px] left-0 h-[2px] w-full" style={{ background: c }} />}
            </button>
          );
        })}
        <div className="ml-auto flex gap-1 pb-1">{tools}</div>
      </div>
    );
  }

  /* full-width segments / studio */
  if (L.tabs === "segment") {
    return (
      <div>
        <div className="flex" style={{ borderBottom: `1px solid ${alpha(t.glow, 0.2)}` }}>
          {TABS.map((x) => {
            const on = tab === x.key;
            const c = x.key === "explore" ? accent : t.glow;
            return (
              <button
                key={x.key} onClick={() => setTab(x.key)}
                className="flex-1 px-1 py-2 text-[9px] font-black"
                style={{
                  fontFamily: L.headFont, letterSpacing: "0.16em",
                  background: on ? c : "transparent",
                  color: on ? (isLight ? "#fff" : "#05101c") : undefined,
                  opacity: on ? 1 : 0.5,
                }}
              >
                {label(x.label)}
              </button>
            );
          })}
        </div>
        <div className="flex justify-end gap-1 px-2 py-1">{tools}</div>
      </div>
    );
  }

  /* bottom console bar */
  if (L.tabs === "bar") {
    return (
      <div className="flex items-stretch border-t" style={{ borderColor: alpha(t.glow, 0.25) }}>
        {TABS.map((x) => {
          const on = tab === x.key;
          const c = x.key === "explore" ? accent : t.glow;
          return (
            <button
              key={x.key} onClick={() => setTab(x.key)}
              className="flex flex-1 flex-col items-center gap-[2px] py-1.5 text-[8px] font-black"
              style={{ color: on ? c : undefined, opacity: on ? 1 : 0.5, background: on ? alpha(c, 0.12) : "transparent" }}
            >
              {x.icon}
              {label(x.label)}
            </button>
          );
        })}
        <div className="flex items-center gap-1 border-l px-1" style={{ borderColor: alpha(t.glow, 0.25) }}>{tools}</div>
      </div>
    );
  }

  /* pill (soft) + chip (classic) */
  const pill = L.tabs === "pill";
  return (
    <div className="flex items-center gap-1 px-2.5 pb-1 pt-1.5">
      {TABS.map((x) => {
        const on = tab === x.key;
        const c = x.key === "explore" ? accent : t.glow;
        if (x.key === "explore" && !pill) {
          return (
            <Tap
              key={x.key} color={c} effect="glow" onClick={() => setTab(x.key)} title="Explore"
              className="grid h-[22px] w-[30px] shrink-0 place-items-center"
              style={
                on
                  ? { background: c, color: "#1a1206", boxShadow: `0 0 10px ${alpha(c, 0.6)}`, borderRadius: L.radius }
                  : { background: alpha(c, 0.18), color: c, borderRadius: L.radius }
              }
            >
              {x.icon}
            </Tap>
          );
        }
        return (
          <Tap
            key={x.key} color={c} effect="squish" onClick={() => setTab(x.key)}
            className={`flex min-w-0 flex-1 items-center justify-center gap-1 px-1 py-[5px] text-[10px] font-bold ${
              on ? "" : s.chip
            }`}
            style={{
              borderRadius: pill ? 999 : L.radius,
              background: on ? c : undefined,
              color: on ? (isLight && x.key !== "explore" ? "#fff" : "#0a1220") : undefined,
            }}
          >
            {x.icon}
            <span className="truncate">{label(x.label)}</span>
          </Tap>
        );
      })}
      {tools}
    </div>
  );
}
