import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { Check, ClipboardList, RefreshCw } from "lucide-react";

interface Question {
  q: string;
  options: string[];
}

const QUESTIONS: Question[] = [
  { q: "Have you visited Botswana?", options: ["Many times", "Once", "Not yet", "Someday"] },
  { q: "What draws you most?", options: ["Okavango Delta", "Kalahari desert", "Wildlife", "Culture"] },
  { q: "Travel style?", options: ["Luxury lodge", "Mobile safari", "Self-drive", "Backpack"] },
  { q: "Best season for you?", options: ["Dry (May-Oct)", "Green (Nov-Apr)", "Shoulder", "Not sure"] },
  { q: "Trip length?", options: ["Weekend", "1 week", "2 weeks", "3+ weeks"] },
  { q: "Would you recommend Botswana?", options: ["Absolutely", "Probably", "Maybe", "Undecided"] },
];

export function SurveyWidget({
  isLight,
  glow,
  shellCls,
}: {
  isLight: boolean;
  glow: string;
  shellCls: string;
}) {
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const done = i >= QUESTIONS.length;
  const cur = QUESTIONS[Math.min(i, QUESTIONS.length - 1)];

  const pick = (opt: string) => {
    setAnswers((a) => [...a, opt]);
    setTimeout(() => setI((v) => v + 1), 220);
  };
  const reset = () => {
    setAnswers([]);
    setI(0);
  };

  const pct = (Math.min(i, QUESTIONS.length) / QUESTIONS.length) * 100;

  return (
    <div
      className={`w-[240px] rounded-2xl px-3 py-2.5 backdrop-blur-2xl ${shellCls}`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <ClipboardList className="h-3 w-3" style={{ color: glow }} />
          <span className="text-[9px] font-bold uppercase tracking-[0.2em] opacity-70">
            Quick survey
          </span>
        </div>
        <span className="text-[9px] tabular-nums opacity-60">
          {Math.min(i + (done ? 0 : 1), QUESTIONS.length)}/{QUESTIONS.length}
        </span>
      </div>

      <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-current/10">
        <motion.div
          className="h-full rounded-full"
          style={{ background: glow, boxShadow: `0 0 6px ${glow}` }}
          initial={false}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>

      <AnimatePresence mode="wait">
        {!done ? (
          <motion.div
            key={`q-${i}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="mt-2 text-[11.5px] font-semibold leading-snug">
              {cur.q}
            </div>
            <div className="mt-2 grid grid-cols-1 gap-1">
              {cur.options.map((o) => (
                <button
                  key={o}
                  onClick={() => pick(o)}
                  className={`rounded-lg border border-current/15 px-2 py-1.5 text-left text-[10.5px] font-medium transition active:scale-[0.98] ${
                    isLight
                      ? "bg-slate-900/5 hover:bg-slate-900/10"
                      : "bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {o}
                </button>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="done"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-2"
          >
            <div className="flex items-center gap-1.5 text-[11px] font-bold">
              <Check className="h-3 w-3" style={{ color: glow }} />
              Thanks — survey complete.
            </div>
            <div className="mt-1 max-h-[64px] overflow-y-auto pr-1 text-[9.5px] leading-tight opacity-70">
              {answers.map((a, idx) => (
                <div key={idx} className="truncate">
                  <span className="opacity-60">Q{idx + 1}:</span> {a}
                </div>
              ))}
            </div>
            <button
              onClick={reset}
              className="mt-2 inline-flex items-center gap-1 rounded-full border border-current/20 bg-current/5 px-2.5 py-0.5 text-[9.5px] font-semibold hover:bg-current/10"
            >
              <RefreshCw className="h-2.5 w-2.5" />
              Retake
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
