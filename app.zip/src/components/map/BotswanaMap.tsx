import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ChevronDown, Cloud, CloudRain, Eye, EyeOff, Globe2, Layers, LayoutGrid, Maximize2, Minus, Palette, Pause, Play,
  Plus, Radio, Settings2, Sparkles, Waves, X, Zap,
} from "lucide-react";
import raw from "@/data/botswana.json";
import type { BotswanaData, MapTheme, Place, PlaceType } from "./types";
import { THEMES } from "./themes";
import { alpha } from "./color";
import { usePanZoom } from "./usePanZoom";
import { Marker } from "./Marker";
import { NorthEastDetail, NE_CENTER } from "./NorthEastDetail";
import { lazy, Suspense } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { svgToLonLat, scaleToZoom } from "./realMapMath";

const RealMapLayer = lazy(() => import("./RealMapLayer"));
import { StylizedRegion } from "./StylizedRegion";
import { Dashboard } from "./Dashboard";
import { HudLayer, DEFAULT_TICKER, TICKER_TEMPLATES, type TickerConfig } from "./HudLayer";
import { PlayLayer, PLAY_MODES, type PlayMode } from "./PlayModes";
import { SPOTLIGHTS, SPOTLIGHT_MS, clockIndex } from "./PlayModes2";
import { WeatherLayer, WEATHER_OPTIONS, type WeatherType } from "./WeatherLayer";
import { ThemeFx, RippleLayer, useRipples } from "./ThemeFx";
import { Copilot } from "./Copilot";
import { CommitsFloaty } from "./CommitsFloaty";
import { EventsFloaty } from "./EventsFloaty";

const DATA = raw as unknown as BotswanaData;
const [vbX, vbY, vbW, vbH] = DATA.viewBox;

const TYPES: { key: PlaceType; label: string }[] = [
  { key: "capital", label: "Capital" },
  { key: "city", label: "Cities" },
  { key: "town", label: "Towns" },
  { key: "village", label: "Villages" },
  { key: "park", label: "Parks" },
  { key: "landmark", label: "Landmarks" },
];

const SLIDESHOW_PICKS = [
  "Gaborone", "Okavango Delta", "Chobe NP", "Tsodilo Hills",
  "Makgadikgadi Pans", "Francistown", "Central Kalahari",
  "Maun", "Kubu Island", "Kgalagadi TP", "Kasane",
];

// map place name → district name for slideshow pulse
const PLACE_TO_DISTRICT: Record<string, string> = {
  Gaborone: "Gaborone",
  "Okavango Delta": "North-West",
  "Chobe NP": "North-West",
  "Tsodilo Hills": "North-West",
  "Makgadikgadi Pans": "Central",
  Francistown: "Francistown",
  "Central Kalahari": "Ghanzi",
  Maun: "North-West",
  "Kubu Island": "Central",
  "Kgalagadi TP": "Kgalagadi",
  Kasane: "North-West",
};

/* --- geometry: find which district polygon contains a point --- */
const DISTRICT_POLYS: { name: string; pts: [number, number][] }[] = DATA.districts.map((d) => {
  const nums = (d.path.match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
  const pts: [number, number][] = [];
  for (let i = 0; i + 1 < nums.length; i += 2) pts.push([nums[i], nums[i + 1]]);
  return { name: d.name, pts };
});

function districtAt(x: number, y: number): string | null {
  for (const d of DISTRICT_POLYS) {
    let inside = false;
    const pts = d.pts;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const [xi, yi] = pts[i], [xj, yj] = pts[j];
      if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-9) + xi) inside = !inside;
    }
    if (inside) return d.name;
  }
  return null;
}

type PaletteFx = "flat" | "glow" | "emboss" | "pulse" | "shimmer" | "outline" | "depth";

interface PaletteSpec {
  colors: string[];
  fx: PaletteFx;
  label: string;
}

const DISTRICT_PALETTES: Record<string, PaletteSpec> = {
  vibrant: { label: "Vibrant", fx: "flat", colors: ["#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899"] },
  pastel:  { label: "Pastel", fx: "flat", colors: ["#fca5a5", "#fdba74", "#fde68a", "#86efac", "#a5f3fc", "#93c5fd", "#c4b5fd", "#f9a8d4"] },
  earth:   { label: "Earth", fx: "emboss", colors: ["#78350f", "#a16207", "#65a30d", "#0f766e", "#155e75", "#3730a3", "#6b21a8", "#9d174d"] },
  neon:    { label: "Neon Glow", fx: "glow", colors: ["#ff00d4", "#00ffcc", "#ffff00", "#00d4ff", "#ff6ec7", "#88ff00", "#ff5500", "#c000ff"] },
  mono:    { label: "Mono", fx: "flat", colors: ["#171717", "#404040", "#525252", "#737373", "#a3a3a3", "#d4d4d4", "#e5e5e5", "#f5f5f5"] },
  plasma:  { label: "Plasma Pulse", fx: "pulse", colors: ["#7c3aed", "#a21caf", "#db2777", "#e11d48", "#f97316", "#facc15", "#22d3ee", "#2563eb"] },
  aurora:  { label: "Aurora Shimmer", fx: "shimmer", colors: ["#5eead4", "#34d399", "#4ade80", "#a3e635", "#38bdf8", "#818cf8", "#c084fc", "#f472b6"] },
  ember:   { label: "Ember Glow", fx: "glow", colors: ["#7f1d1d", "#b91c1c", "#ea580c", "#f59e0b", "#fbbf24", "#fde047", "#fb7185", "#f43f5e"] },
  relief:  { label: "Relief 3D", fx: "depth", colors: ["#0f766e", "#0e7490", "#1d4ed8", "#4338ca", "#6d28d9", "#9333ea", "#c026d3", "#db2777"] },
  wire:    { label: "Wireframe", fx: "outline", colors: ["#22d3ee", "#38bdf8", "#818cf8", "#a78bfa", "#f472b6", "#fb923c", "#facc15", "#4ade80"] },
  sand:    { label: "Sandstone", fx: "emboss", colors: ["#fef3c7", "#fde68a", "#fcd34d", "#f5d0a9", "#e7c496", "#d6ad7b", "#c19a6b", "#a1785a"] },
  jewel:   { label: "Jewel Depth", fx: "depth", colors: ["#065f46", "#047857", "#0369a1", "#1e40af", "#5b21b6", "#86198f", "#9f1239", "#a16207"] },
};


type RegionKey = "botswana" | "southern" | "world";
const REGIONS: { key: RegionKey; label: string; hint: string; lon: number; lat: number; zoom: number }[] = [
  { key: "botswana", label: "Botswana", hint: "Stylised national map with districts and places.", lon: 24.6, lat: -22.3, zoom: 5.2 },
  { key: "southern", label: "Southern Africa", hint: "Regional view across the SADC neighbourhood.", lon: 25.5, lat: -20.5, zoom: 3.4 },
  { key: "world", label: "World", hint: "Global view — watch signals arrive from everywhere.", lon: 12, lat: 8, zoom: 1.3 },
];

const HUD_PACKS = ["Classic", "Neural", "Kinetic", "Mesh", "Ops", "Studio"];

export function BotswanaMap() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [theme, setTheme] = useState<MapTheme>("light");
  const [selected, setSelected] = useState<Place | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [showLabels, setShowLabels] = useState(false);
  const [showDistricts, setShowDistricts] = useState(true);
  const [showGrid, setShowGrid] = useState(false);
  const [showTicker, setShowTicker] = useState(false);
  const [playMode, setPlayMode] = useState<PlayMode>(1);
  const [modeMenu, setModeMenu] = useState(false);
  const [autoplay, setAutoplay] = useState(false);
  const [markerSize, setMarkerSize] = useState(0);
  const [weather, setWeather] = useState<WeatherType>("off");
  const [showHud, setShowHud] = useState(false);
  const [hudPreset, setHudPreset] = useState(0);
  const [visibleTypes, setVisibleTypes] = useState<Record<PlaceType, boolean>>({
    capital: false, city: false, town: false, village: false, park: false, landmark: false,
  });
  const [districtPalette] = useState<keyof typeof DISTRICT_PALETTES>("vibrant");
  const [region, setRegion] = useState<RegionKey>("botswana");
  const [districtColors, setDistrictColors] = useState<Record<string, string>>({});
  const [districtPulse, setDistrictPulse] = useState<Record<string, number>>({});
  const [splitPct, setSplitPct] = useState(28); // top map percentage
  const [tickerCfg, setTickerCfg] = useState<TickerConfig>(DEFAULT_TICKER);
  const [tickerTpl, setTickerTpl] = useState("Signal");
  const [labelScale, setLabelScale] = useState(0);
  const [autoCycle, setAutoCycle] = useState(false);
  const [focusFx, setFocusFx] = useState<{ key: number; district: string | null; style: number }>({ key: 0, district: null, style: 0 });
  const t = THEMES[theme];
  const pfx = DISTRICT_PALETTES[districtPalette].fx;
  const { ripples, spawn } = useRipples();

  // Live container size so the SVG can render vector-crisp at every zoom level
  // (transforming an inner <g> instead of CSS-scaling the whole <svg>).
  const [boxSize, setBoxSize] = useState({ w: 0, h: 0 });
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const r = el.getBoundingClientRect();
      setBoxSize({ w: Math.round(r.width), h: Math.round(r.height) });
    });
    ro.observe(el);
    const r = el.getBoundingClientRect();
    setBoxSize({ w: Math.round(r.width), h: Math.round(r.height) });
    return () => ro.disconnect();
  }, []);


  // reset per-district colors when palette changes
  useEffect(() => { setDistrictColors({}); }, [districtPalette]);

  const { camera, setCamera, fit } = usePanZoom({
    containerRef,
    contentSize: { w: vbW, h: vbH },
    minScale: 0.06,
    maxScale: 16000,
  });

  // North-East district high-detail sample
  const [threeD, setThreeD] = useState(true);
  const flyNorthEast = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const s = 26;
    setCamera({ scale: s, x: rect.width / 2 - NE_CENTER.x * s, y: rect.height / 2 - NE_CENTER.y * s });
  }, [setCamera]);

  useEffect(() => {
    const pad = window.innerWidth < 640 ? 16 : 32;
    fit(pad, false);
  }, [fit, splitPct]);

  useEffect(() => {
    const onResize = () => fit(window.innerWidth < 640 ? 16 : 32, false);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [fit]);

  const filteredPlaces = useMemo(
    () => DATA.places.filter((p) => visibleTypes[p.type]),
    [visibleTypes]
  );

  const visibleLabels = useMemo(() => {
    if (!showLabels) return [];
    return filteredPlaces.filter((p) => {
      if (p.type === "capital" || p.type === "park" || p.type === "landmark") return true;
      if (p.type === "city") return camera.scale >= 0.55;
      if (p.type === "town") return camera.scale >= 1.2;
      if (p.type === "village") return camera.scale >= 2.4;
      return true;
    });
  }, [camera.scale, filteredPlaces, showLabels]);

  // Select a place: fly in with a rotating set of camera transitions, light up
  // its district and fire the focus effects.
  const fxStyle = useRef(0);
  const handleSelect = useCallback((p: Place) => {
    setSelected(p);
    markInteraction();
    const style = fxStyle.current++ % 4;
    const dist = districtAt(p.x, p.y);
    setFocusFx({ key: Date.now(), district: dist, style });
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    if (rect.width < 20) return;
    const fitScale = Math.min((rect.width - 32) / vbW, (rect.height - 32) / vbH);
    const target = fitScale * (style === 0 ? 4.2 : style === 1 ? 3.1 : style === 2 ? 5.4 : 2.4);
    const tx = rect.width / 2 - p.x * target;
    const ty = rect.height * (style === 3 ? 0.42 : 0.5) - p.y * target;
    const start = { ...cameraRef.current };
    // style 1 pulls back before diving in; others ease straight through
    const dur = style === 2 ? 1.35 : style === 1 ? 1.15 : 0.9;
    const t0 = performance.now();
    const ease = (u: number) => 1 - Math.pow(1 - u, style === 3 ? 5 : 3);
    const step = () => {
      const u = Math.min(1, (performance.now() - t0) / (dur * 1000));
      const e = ease(u);
      const dip = style === 1 ? 1 - Math.sin(u * Math.PI) * 0.22 : 1;
      const swing = style === 2 ? Math.sin(u * Math.PI) * 26 : 0;
      setCamera({
        x: start.x + (tx - start.x) * e + swing,
        y: start.y + (ty - start.y) * e,
        scale: (start.scale + (target - start.scale) * e) * dip,
      });
      markInteraction();
      if (u < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setCamera]);

  const handleDistrictClick = useCallback((name: string) => {
    const palette = DISTRICT_PALETTES[districtPalette].colors;
    setDistrictColors((prev) => {
      const current = prev[name];
      const idx = current ? palette.indexOf(current) : -1;
      const next = palette[(idx + 1) % palette.length];
      return { ...prev, [name]: next };
    });
  }, [districtPalette]);

  // Long-press a district to clear its color (revert to empty).
  const holdRef = useRef<{ id: number | null; fired: boolean }>({ id: null, fired: false });
  const handleDistrictHoldStart = useCallback((name: string) => {
    holdRef.current.fired = false;
    if (holdRef.current.id) window.clearTimeout(holdRef.current.id);
    holdRef.current.id = window.setTimeout(() => {
      holdRef.current.fired = true;
      setDistrictColors((prev) => {
        if (!(name in prev)) return prev;
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }, 550);
  }, []);
  const handleDistrictHoldEnd = useCallback(() => {
    if (holdRef.current.id) {
      window.clearTimeout(holdRef.current.id);
      holdRef.current.id = null;
    }
  }, []);

  const shuffleDistrictColors = () => {
    const palette = DISTRICT_PALETTES[districtPalette].colors;
    const next: Record<string, string> = {};
    DATA.districts.forEach((d) => {
      next[d.name] = palette[Math.floor(Math.random() * palette.length)];
    });
    setDistrictColors(next);
  };

  // slideshow — cycles selection AND gently drifts the camera (no zoom-in),
  // so the map "breathes" while the auto tour runs.
  const slideRef = useRef({ i: 0 });
  useEffect(() => {
    if (!autoplay) return;
    let cancelled = false;
    const tick = () => {
      if (cancelled) return;
      const name = SLIDESHOW_PICKS[slideRef.current.i % SLIDESHOW_PICKS.length];
      slideRef.current.i++;
      const p = DATA.places.find((x) => x.name === name);
      if (p) setSelected(p);
      // Light the district up and shut on each slideshow beat.
      const districtName = PLACE_TO_DISTRICT[name];
      if (districtName && playModeRef.current === 1) {
        setDistrictPulse((prev) => ({
          ...prev,
          [districtName]: (prev[districtName] ?? 0) + 1,
        }));
      }
    };
    tick();
    const id = window.setInterval(tick, 3200);
    return () => { cancelled = true; clearInterval(id); };
  }, [autoplay]);

  const playModeRef = useRef(playMode);
  playModeRef.current = playMode;

  // User-controlled zoom multiplier applied on top of the drift scale.
  // Lets zoom-in / zoom-out / fit work WHILE the auto tour is running.
  const userZoomRef = useRef(1);
  // While the user pans/zooms/taps the map, the auto-tour drift stands down so
  // interaction always wins; it re-bases from wherever the user left the camera.
  const lastTouchRef = useRef(0);
  const cameraRef = useRef(camera);
  cameraRef.current = camera;
  const selectedRef = useRef(selected);
  selectedRef.current = selected;
  const markInteraction = useCallback(() => { lastTouchRef.current = performance.now(); }, []);

  // Continuous camera drift while auto tour is on — pans around the map
  // at fully-fit (smallest) scale with only very subtle breathing. GPU-friendly.
  // Recomputes base geometry whenever the map container resizes (e.g. when the
  // user drags the split handle) so the country never drifts out of frame.
  useEffect(() => {
    if (!autoplay) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setAutoplay(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [autoplay]);

  const layoutOf = (m: PlayMode) => PLAY_MODES.find((x) => x.id === m)!.layout;

  // Auto-cycle: walk every play template in a loop while playing.
  useEffect(() => {
    if (!autoplay || !autoCycle) return;
    const id = window.setInterval(() => {
      setPlayMode((m) => {
        const i = PLAY_MODES.findIndex((x) => x.id === m);
        return PLAY_MODES[(i + 1) % PLAY_MODES.length].id;
      });
    }, 15000);
    return () => window.clearInterval(id);
  }, [autoplay, autoCycle]);

  useEffect(() => {
    if (!autoplay || layoutOf(playMode) === "map-focus") return;
    const el = containerRef.current;
    if (!el) return;
    let baseScale = 1, baseX = 0, baseY = 0, ampX = 0, ampY = 0;
    let rect = el.getBoundingClientRect();
    const recalc = () => {
      rect = el.getBoundingClientRect();
      if (rect.width < 20 || rect.height < 20) return;
      const pad = window.innerWidth < 640 ? 16 : 32;
      baseScale = Math.min(
        (rect.width - pad * 2) / vbW,
        (rect.height - pad * 2) / vbH,
      );
      baseX = (rect.width - vbW * baseScale) / 2;
      baseY = (rect.height - vbH * baseScale) / 2;
      ampX = Math.min(70, rect.width * 0.07);
      ampY = Math.min(55, rect.height * 0.06);
    };
    recalc();
    const ro = new ResizeObserver(recalc);
    ro.observe(el);
    let t0 = performance.now();
    let raf = 0;
    let paused = false;
    // Cinematic phase machine: the camera changes its mind every few seconds —
    // sweeps, slow orbits, dollies, diagonal glides and short held beats — and
    // every transition is critically damped so it never snaps.
    const PHASES = ["sweep", "orbit", "dolly", "glide", "hold", "swing"] as const;
    let phase: (typeof PHASES)[number] = "sweep";
    let phaseStart = performance.now();
    let phaseLen = 7000;
    let seed = 0;
    let sx = 0, sy = 0, sz = 1; // smoothed offsets
    const nextPhase = (now: number) => {
      seed++;
      const pick = PHASES[(seed * 3 + Math.floor(Math.random() * 3)) % PHASES.length];
      phase = pick;
      phaseLen = pick === "hold" ? 700 + Math.random() * 900 : 5500 + Math.random() * 6000;
      phaseStart = now;
    };
    const loop = () => {
      const now = performance.now();
      if (now - lastTouchRef.current < 2200) {
        // user is driving — hand the camera over
        paused = true;
        raf = requestAnimationFrame(loop);
        return;
      }
      if (paused) {
        // re-base the drift on the camera the user left behind
        paused = false;
        t0 = now;
        const cam = cameraRef.current;
        baseScale = cam.scale;
        baseX = cam.x;
        baseY = cam.y;
        userZoomRef.current = 1;
        sx = 0; sy = 0; sz = 1;
        nextPhase(now);
      }
      if (now - phaseStart > phaseLen) nextPhase(now);
      const t = (now - t0) / 1000;
      const p = (now - phaseStart) / 1000;
      let tx = 0, ty = 0, tz = 1;
      if (phase === "sweep") {
        tx = Math.sin(t * 0.32 + seed) * ampX * 1.25;
        ty = Math.sin(t * 0.19) * ampY * 0.5;
        tz = 1 + Math.sin(t * 0.22) * 0.03;
      } else if (phase === "orbit") {
        tx = Math.cos(t * 0.42) * ampX;
        ty = Math.sin(t * 0.42) * ampY;
        tz = 1 + Math.sin(t * 0.5) * 0.02;
      } else if (phase === "dolly") {
        tz = 1 + Math.sin(p * 0.35) * 0.16;
        tx = Math.sin(t * 0.16) * ampX * 0.4;
        ty = Math.cos(t * 0.13) * ampY * 0.4;
      } else if (phase === "glide") {
        const u = Math.min(1, p / 6);
        tx = (-1 + 2 * u) * ampX * ((seed % 2) ? 1 : -1);
        ty = (1 - 2 * u) * ampY * 0.8;
        tz = 1 + u * 0.06;
      } else if (phase === "swing") {
        tx = Math.sin(t * 0.9) * ampX * 0.55;
        ty = Math.sin(t * 0.45) * ampY * 1.1;
        tz = 1 - Math.abs(Math.sin(t * 0.3)) * 0.05;
      } // "hold" keeps targets at the last smoothed pose
      if (phase === "hold") { tx = sx; ty = sy; tz = sz; }
      const k = phase === "hold" ? 0.12 : 0.035;
      sx += (tx - sx) * k;
      sy += (ty - sy) * k;
      sz += (tz - sz) * k;
      const uz = userZoomRef.current;
      const scale = baseScale * sz * uz;
      const cx = rect.width / 2;
      const cy = rect.height / 2;
      const x = cx - (cx - baseX) * (scale / baseScale) + sx;
      const y = cy - (cy - baseY) * (scale / baseScale) + sy;
      setCamera({ x, y, scale });
      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [autoplay, setCamera, playMode]);

  // City spotlight — fly the camera into each highlighted place in lockstep
  // with the overlay copy, then hold while its stats read out.
  useEffect(() => {
    if (!autoplay || layoutOf(playMode) !== "map-focus") return;
    const el = containerRef.current;
    if (!el) return;
    let raf = 0;
    const loop = () => {
      const rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 20) {
        const spot = SPOTLIGHTS[clockIndex(SPOTLIGHTS.length, SPOTLIGHT_MS)];
        const place = DATA.places.find((pl) => pl.name === spot.place);
        if (place) {
          const fitScale = Math.min((rect.width - 40) / vbW, (rect.height - 40) / vbH);
          const target = fitScale * spot.scale;
          const tx = rect.width * 0.26 - place.x * target;
          const ty = rect.height * 0.5 - place.y * target;
          const cam = cameraRef.current;
          const k = 0.045;
          setCamera({
            x: cam.x + (tx - cam.x) * k,
            y: cam.y + (ty - cam.y) * k,
            scale: cam.scale + (target - cam.scale) * k,
          });
          const name = spot.place;
          if (selectedRef.current?.name !== name) {
            const p2 = DATA.places.find((x) => x.name === name);
            if (p2) setSelected(p2);
          }
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [autoplay, playMode, setCamera]);

  const zoomBy = (factor: number) => {
    // While auto tour is running, adjust the user-zoom multiplier so the
    // drift loop keeps owning the camera but at the user's chosen zoom.
    markInteraction();
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.width / 2, cy = rect.height / 2;
    const newScale = Math.max(0.25, Math.min(16000, camera.scale * factor));
    const k = newScale / camera.scale;
    const deltaY = -Math.log(k) / 0.0015;
    el.dispatchEvent(new WheelEvent("wheel", {
      deltaY, clientX: rect.left + cx, clientY: rect.top + cy, bubbles: true, cancelable: true,
    }));
  };

  const fitOrReset = () => {
    markInteraction();
    fit(window.innerWidth < 640 ? 16 : 32, true);
  };

  // Real map (OpenStreetMap tiles) auto-swaps in as you zoom past district level
  const REAL_IN = 12;
  const REAL_FULL = 26;
  const realOpacity = Math.max(0, Math.min(1, (camera.scale - REAL_IN) / (REAL_FULL - REAL_IN)));
  const realView = useMemo(() => {
    const cxSvg = (boxSize.w / 2 - camera.x) / camera.scale + vbX;
    const cySvg = (boxSize.h / 2 - camera.y) / camera.scale + vbY;
    const { lon, lat } = svgToLonLat(cxSvg, cySvg);
    return { lon, lat, zoom: scaleToZoom(camera.scale, lat) };
  }, [camera.x, camera.y, camera.scale, boxSize.w, boxSize.h, vbX, vbY]);

  const isLight = t.ui === "glass-light";
  const glassBtn = isLight
    ? "border-transparent bg-transparent text-slate-900 hover:bg-black/[0.06]"
    : "border-transparent bg-transparent text-white hover:bg-white/10 [text-shadow:0_1px_6px_rgba(0,0,0,0.6)]";
  const playLayout = PLAY_MODES.find((m) => m.id === playMode)!.layout;
  const mapShift =
    autoplay && playLayout === "map-left"
      ? "translateX(-24%) scale(0.82)"
      : undefined;
  const glass = isLight
    ? "bg-white/80 text-slate-900 border-white/70"
    : "bg-white/[0.06] text-white border-white/10";

  // Split-resize drag — writes pane heights straight to the DOM while dragging
  // (no React re-render per frame, so the heavy SVG map never re-lays out), and
  // commits to state only once the gesture ends.
  const topPaneRef = useRef<HTMLDivElement | null>(null);
  const botPaneRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{ startY: number; startPct: number; h: number; last: number } | null>(null);
  const onSplitPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const container = e.currentTarget.parentElement as HTMLElement;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragRef.current = {
      startY: e.clientY,
      startPct: splitPct,
      h: container.getBoundingClientRect().height,
      last: splitPct,
    };
  };
  const onSplitPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    if (!d) return;
    const dy = e.clientY - d.startY;
    const next = Math.max(18, Math.min(86, d.startPct + (dy / d.h) * 100));
    if (Math.abs(next - d.last) < 0.15) return;
    d.last = next;
    if (topPaneRef.current) topPaneRef.current.style.height = `${next}%`;
    if (botPaneRef.current) botPaneRef.current.style.height = `${100 - next}%`;
  };
  const onSplitPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    e.currentTarget.releasePointerCapture?.(e.pointerId);
    dragRef.current = null;
    if (d) setSplitPct(d.last);
  };


  return (
    <div
      className="relative flex h-[100dvh] w-full flex-col overflow-hidden select-none"
      style={{ fontFamily: "'Manrope', system-ui, sans-serif" }}
    >
      {/* MAP HALF */}
      <div
        ref={topPaneRef}
        className="relative overflow-hidden"
        onPointerDown={(e) => {
          if (!t.fx?.ripple) return;
          const r = e.currentTarget.getBoundingClientRect();
          spawn(e.clientX - r.left, e.clientY - r.top);
        }}
        style={{
          height: `${splitPct}%`,
          background: t.bg,
          touchAction: "none",
          perspective: t.fx?.tilt ? "1200px" : undefined,
        }}
      >
        <ThemeFx theme={t} />

        {(t.grid || showGrid) && (
          <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-60">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke={t.gridColor} strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        )}

        <div
          ref={containerRef}
          className="absolute inset-0"
          onClick={() => setSelected(null)}
          onPointerDownCapture={markInteraction}
          onPointerMoveCapture={(e) => { if (e.buttons) markInteraction(); }}
          onWheelCapture={markInteraction}

          style={
            {
                  transform: [
                    mapShift,
                    t.fx?.tilt ? `rotateX(${t.fx.tilt * 0.34}deg) rotateZ(${t.fx.tilt * 0.06}deg)` : null,
                  ].filter(Boolean).join(" ") || undefined,
                  opacity: autoplay && playLayout === "full" ? 0 : 1,
                  transformStyle: t.fx?.tilt ? "preserve-3d" : undefined,
                  transition: "transform 900ms cubic-bezier(0.22,1,0.36,1), opacity 600ms ease",
                }
          }
        >
          <svg
            width="100%"
            height="100%"
            viewBox={`0 0 ${Math.max(1, boxSize.w)} ${Math.max(1, boxSize.h)}`}
            className="absolute left-0 top-0 h-full w-full"
            shapeRendering="geometricPrecision"
            textRendering="geometricPrecision"
          >
            <g transform={`translate(${camera.x} ${camera.y}) scale(${camera.scale}) translate(${-vbX} ${-vbY})`}>

            <defs>
              <radialGradient id="bw-country-dark" cx="35%" cy="30%" r="80%">
                <stop offset="0%" stopColor="#2a3c78" stopOpacity="0.95" />
                <stop offset="55%" stopColor="#12204a" stopOpacity="0.9" />
                <stop offset="100%" stopColor="#0a1330" stopOpacity="1" />
              </radialGradient>
              <radialGradient id="bw-country-light" cx="35%" cy="30%" r="80%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="60%" stopColor="#f0f4ff" />
                <stop offset="100%" stopColor="#dbe4fb" />
              </radialGradient>
              <radialGradient id="bw-country-sat" cx="40%" cy="35%" r="80%">
                <stop offset="0%" stopColor="#6b7a3a" />
                <stop offset="45%" stopColor="#3f4d24" />
                <stop offset="100%" stopColor="#1e2711" />
              </radialGradient>
            </defs>

            {/* Country fill */}
            <path
              d={DATA.country}
              fill={t.countryFill}
              stroke={t.countryStroke}
              strokeWidth={1.2 / camera.scale}
              strokeLinejoin="round"
            />

            {/* Districts */}
            {showDistricts && (
              <g>
                {DATA.districts.map((d) => {
                  const isHover = hovered === d.name;
                  const custom = districtColors[d.name];
                  const fill = custom
                    ? (isHover ? shade(custom, 1.15) : custom)
                    : (isHover ? t.districtHoverFill : t.districtFill);
                  const pulseKey = districtPulse[d.name] ?? 0;
                  const off = 2.2 / camera.scale;
                  return (
                    <g key={d.name}>
                      {/* 3D relief / emboss understrata */}
                      {custom && (pfx === "depth" || pfx === "emboss") && (
                        <>
                          <path
                            d={d.path}
                            fill={shade(custom, pfx === "depth" ? 0.35 : 0.55)}
                            transform={`translate(${off} ${off * 1.5})`}
                            style={{ pointerEvents: "none" }}
                            opacity={pfx === "depth" ? 0.85 : 0.5}
                          />
                          {pfx === "depth" && (
                            <path
                              d={d.path}
                              fill={shade(custom, 0.5)}
                              transform={`translate(${off * 0.5} ${off * 0.75})`}
                              style={{ pointerEvents: "none" }}
                              opacity={0.7}
                            />
                          )}
                        </>
                      )}
                      <motion.path
                        d={d.path}
                        initial={false}
                        animate={
                          custom && pfx === "shimmer"
                            ? { fill: [custom, shade(custom, 1.45), custom] }
                            : custom && pfx === "pulse"
                            ? { fill, fillOpacity: [0.4, 0.78, 0.4] }
                            : { fill }
                        }
                        transition={
                          custom && (pfx === "shimmer" || pfx === "pulse")
                            ? { duration: pfx === "pulse" ? 2.6 : 4.2, repeat: Infinity, ease: "easeInOut" }
                            : { duration: 0.35, ease: "easeOut" }
                        }
                        stroke={custom && pfx === "outline" ? custom : t.districtStroke}
                        strokeWidth={(custom && pfx === "outline" ? 1.6 : 0.6) / camera.scale}
                        fillOpacity={
                          custom ? (pfx === "outline" ? 0.12 : pfx === "depth" ? 0.92 : 0.55) : 1
                        }
                        style={{
                          cursor: "pointer",
                          filter:
                            custom && pfx === "glow"
                              ? `drop-shadow(0 0 ${5 / camera.scale}px ${custom}) drop-shadow(0 0 ${12 / camera.scale}px ${custom})`
                              : custom && pfx === "outline"
                              ? `drop-shadow(0 0 ${3 / camera.scale}px ${custom})`
                              : undefined,
                        }}
                        onPointerEnter={() => setHovered(d.name)}
                        onPointerLeave={() => { setHovered(null); handleDistrictHoldEnd(); }}
                        onPointerDown={(e) => { e.stopPropagation(); handleDistrictHoldStart(d.name); }}
                        onPointerUp={handleDistrictHoldEnd}
                        onPointerCancel={handleDistrictHoldEnd}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (holdRef.current.fired) { holdRef.current.fired = false; return; }
                          handleDistrictClick(d.name);
                        }}
                      />
                      {/* specular sheen for 3D palettes */}
                      {custom && pfx === "depth" && (
                        <path
                          d={d.path}
                          fill="none"
                          stroke={shade(custom, 1.9)}
                          strokeWidth={0.9 / camera.scale}
                          opacity={0.5}
                          transform={`translate(${-off * 0.4} ${-off * 0.5})`}
                          style={{ pointerEvents: "none" }}
                        />
                      )}
                      {pulseKey > 0 && (
                        <motion.path
                          key={"pulse-" + d.name + "-" + pulseKey}
                          d={d.path}
                          fill={custom ?? t.glow}
                          initial={{ opacity: 0.16 }}
                          animate={{ opacity: 0 }}
                          transition={{ duration: 1.8, ease: "easeOut" }}
                          style={{ pointerEvents: "none" }}
                        />
                      )}
                    </g>
                  );
                })}
              </g>
            )}


            {/* North-East district — deep-zoom detail sample */}
            {realOpacity < 1 && (
              <g opacity={1 - realOpacity}>
                <NorthEastDetail scale={camera.scale} isLight={isLight} threeD={threeD} accent={t.glow} />
              </g>
            )}

            {/* rim highlight */}
            <path
              d={DATA.country}
              fill="none"
              stroke={t.glow}
              strokeWidth={0.5 / camera.scale}
              opacity="0.35"
            />

            {/* markers */}
            <g style={{ transform: `scale(${markerSize})`, transformOrigin: "center" }}>
              {filteredPlaces.map((p) => (
                <Marker
                  key={p.name}
                  place={p}
                  scale={camera.scale}
                  theme={t}
                  selected={selected?.name === p.name}
                  onSelect={handleSelect}
                />
              ))}
            </g>




            {/* selected place — district wash, focus rings, marker + name */}
            {selected && (
              <g key={focusFx.key} style={{ pointerEvents: "none" }}>
                {focusFx.district && (
                  <motion.path
                    d={DATA.districts.find((d) => d.name === focusFx.district)?.path}
                    fill={t.glow}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.07 }}
                    transition={{ duration: 1.1, ease: "easeOut" }}
                    stroke={t.glow}
                    strokeWidth={0.7 / camera.scale}
                    strokeOpacity={0.35}
                  />
                )}
                <motion.circle
                  cx={selected.x}
                  cy={selected.y}
                  r={6 / camera.scale}
                  fill="none"
                  stroke={t.glow}
                  strokeWidth={0.8 / camera.scale}
                  initial={{ opacity: 0.3, scale: 0.6 }}
                  animate={{ opacity: 0, scale: 2.6 }}
                  transition={{ duration: 3.2, repeat: Infinity, ease: "easeOut" }}
                  style={{ transformOrigin: `${selected.x}px ${selected.y}px` }}
                />
                <motion.circle
                  cx={selected.x}
                  cy={selected.y}
                  r={3.4 / camera.scale}
                  fill={t.glow}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 320, damping: 18 }}
                  style={{ transformOrigin: `${selected.x}px ${selected.y}px`, filter: `drop-shadow(0 0 ${6 / camera.scale}px ${t.glow})` }}
                />
                <line
                  x1={selected.x} y1={selected.y - 6 / camera.scale}
                  x2={selected.x} y2={selected.y - 20 / camera.scale}
                  stroke={t.glow} strokeWidth={0.9 / camera.scale} opacity={0.7}
                />
                <motion.text
                  x={selected.x}
                  y={selected.y - 23 / camera.scale}
                  textAnchor="middle"
                  fontSize={13 / camera.scale}
                  fontFamily="'Sora', system-ui, sans-serif"
                  fontWeight={800}
                  fill={t.labelColor}
                  stroke={t.labelHalo}
                  strokeWidth={(13 / camera.scale) * 0.28}
                  paintOrder="stroke"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                  style={{ paintOrder: "stroke fill", letterSpacing: "0.04em" }}
                >
                  {selected.name}
                </motion.text>
              </g>
            )}

            {/* labels — sized in screen pixels with gentle zoom compensation so
                they stay legible when zoomed in and never oversized when zoomed out */}
            {showLabels && (
              <g style={{ pointerEvents: "none" }}>
                {visibleLabels.map((p) => {
                  const isPark = p.type === "park" || p.type === "landmark";
                  const basePx =
                    p.type === "capital" ? 15 :
                    p.type === "city" ? 12.5 :
                    p.type === "town" ? 11 :
                    isPark ? 10.5 : 9.5;
                  // zoom compensation: shrink a little when far out, grow a little when deep in
                  const comp = Math.min(1.5, Math.max(0.68, Math.pow(camera.scale, 0.22)));
                  const px = basePx * comp * labelScale;
                  const fontSize = px / camera.scale;
                  const dy = (-(px * 0.85) - (p.type === "capital" ? 4 : 2)) / camera.scale;
                  return (
                    <text
                      key={"lb-" + p.name}
                      x={p.x}
                      y={p.y + dy}
                      textAnchor="middle"
                      fontSize={fontSize}
                      fontFamily="'Plus Jakarta Sans', 'Sora', system-ui, sans-serif"
                      fontWeight={p.type === "capital" ? 800 : isPark ? 600 : 650}
                      fill={t.labelColor}
                      stroke={t.labelHalo}
                      strokeWidth={fontSize * 0.26}
                      strokeLinejoin="round"
                      strokeLinecap="round"
                      paintOrder="stroke"
                      style={{
                        letterSpacing: isPark ? "0.14em" : "0.005em",
                        paintOrder: "stroke fill",
                      }}
                    >
                      {isPark ? p.name.toUpperCase() : p.name}
                    </text>
                  );
                })}
              </g>
            )}
            </g>
          </svg>

          {/* Real OpenStreetMap tiles fade in on deep zoom */}
          {realOpacity > 0 && (
            <ClientOnly fallback={null}>
              <Suspense fallback={null}>
                <div
                  className="pointer-events-none absolute inset-0 overflow-hidden"
                  style={{ opacity: realOpacity, transition: "opacity 200ms linear" }}
                >
                  <RealMapLayer
                    lon={realView.lon}
                    lat={realView.lat}
                    zoom={realView.zoom}
                    pitch={threeD ? 50 : 0}
                    dark={!isLight}
                  />
                </div>
              </Suspense>
            </ClientOnly>
          )}

          {region !== "botswana" && (
            <div className="absolute inset-0 overflow-hidden" style={{ background: t.bg ?? undefined }}>
              <StylizedRegion region={region as "southern" | "world"} theme={t} isLight={isLight} />
              <div className="pointer-events-none absolute left-3 top-3 rounded-md border border-current/20 bg-current/10 px-2 py-1 text-[9px] font-bold uppercase tracking-[0.16em] backdrop-blur-md">
                {REGIONS.find((r) => r.key === region)!.label}
              </div>
            </div>
          )}


          <div
            className="pointer-events-none absolute inset-0"
            style={{ background: t.vignette }}
          />
        </div>

        {/* Top bar */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-1.5 p-2">
          <button
            onClick={() => setSettingsOpen(true)}
            className={`pointer-events-auto flex items-center gap-1 rounded-md border px-1.5 py-1 ${glassBtn}`}
          >
            <Settings2 className="h-3 w-3" />
            <span className="text-[10px] font-semibold tracking-wide">Options</span>
          </button>

          <div className="pointer-events-auto flex items-center gap-1.5">
            <button
              onClick={() => {
                // Clean → Classic → Neural → Kinetic → Mesh → Ops → Studio → Clean
                if (!showHud) { setShowHud(true); setHudPreset(0); return; }
                if (hudPreset >= HUD_PACKS.length - 1) { setShowHud(false); return; }
                setHudPreset((v) => v + 1);
              }}
               className={`flex items-center gap-1 rounded-md border px-1.5 py-1 ${glassBtn}`}
              title="Cycle overlay card packs"
            >
              {showHud ? <Layers className="h-3 w-3" /> : <LayoutGrid className="h-3 w-3 opacity-60" />}
              <span className="text-[10px] font-semibold">
                {showHud ? HUD_PACKS[hudPreset] : "Clean"}
              </span>
            </button>
            <div className="relative">
              <div className={`flex items-center rounded-md border ${glassBtn}`}>
                <button onClick={() => setAutoplay((v) => !v)} className="flex items-center gap-1 p-1" title="Play">
                  {autoplay ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                  <span className="hidden text-[10px] font-semibold sm:inline">
                    {autoplay ? PLAY_MODES.find((m) => m.id === playMode)!.name : `Mode ${playMode}`}
                  </span>
                </button>
                <button onClick={() => setModeMenu((v) => !v)} className="px-1 py-1" title="Choose play template">
                  <ChevronDown className="h-3 w-3" />
                </button>
              </div>
              <AnimatePresence>
                {modeMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -6, scale: 0.97 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -6, scale: 0.97 }}
                    className={`absolute right-0 top-8 z-30 max-h-[60vh] w-[200px] overflow-y-auto overscroll-contain rounded-lg border backdrop-blur-2xl ${
                      isLight ? "border-black/10 bg-white/90 text-slate-900" : "border-white/10 bg-[#080c18]/92 text-white"
                    }`}
                    style={{ WebkitOverflowScrolling: "touch", touchAction: "pan-y" }}
                    onPointerDownCapture={(e) => e.stopPropagation()}
                    onWheelCapture={(e) => e.stopPropagation()}
                  >
                    <button
                      onClick={() => { setAutoCycle((v) => !v); setAutoplay(true); }}
                      className="sticky top-0 z-10 flex w-full items-center gap-1.5 border-b border-current/10 px-2 py-1.5 text-left backdrop-blur-2xl"
                      style={{ background: autoCycle ? alpha(t.glow, 0.18) : "transparent" }}
                    >
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: autoCycle ? t.glow : "currentColor", opacity: autoCycle ? 1 : 0.3 }} />
                      <span className="text-[10px] font-bold">Auto-cycle all templates</span>
                      <span className="ml-auto text-[8px] opacity-60">{autoCycle ? "on" : "off"}</span>
                    </button>
                    {PLAY_MODES.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => { setPlayMode(m.id); setModeMenu(false); setAutoplay(true); }}
                        className={`flex w-full items-start gap-1.5 px-2 py-1 text-left hover:bg-current/5 ${
                          playMode === m.id ? "bg-current/10" : ""
                        }`}
                      >
                        <span className="mt-[1px] text-[9px] font-black tabular-nums" style={{ color: t.glow }}>{m.id}</span>
                        <span className="min-w-0">
                          <span className="block truncate text-[10px] font-bold">{m.name}</span>
                          <span className="block truncate text-[8px] opacity-60">{m.blurb}</span>
                        </span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>

        {/* Right controls */}
        <div className="pointer-events-none absolute right-3 top-1/2 z-10 -translate-y-1/2">
           <div className={`pointer-events-auto flex flex-col rounded-md border ${glassBtn}`}>
            <CtrlBtn onClick={() => zoomBy(1.6)} label="Zoom in"><Plus className="h-3 w-3" /></CtrlBtn>
            <CtrlBtn onClick={() => zoomBy(1 / 1.6)} label="Zoom out"><Minus className="h-3 w-3" /></CtrlBtn>
            <CtrlBtn onClick={fitOrReset} label="Fit"><Maximize2 className="h-3 w-3" /></CtrlBtn>
            <CtrlBtn onClick={flyNorthEast} label="North-East sample">
              <span className="text-[9px] font-bold leading-none">NE</span>
            </CtrlBtn>
            <CtrlBtn onClick={() => setThreeD((v) => !v)} label="3D buildings">
              <span className={`text-[9px] font-bold leading-none ${threeD ? "" : "opacity-40"}`}>3D</span>
            </CtrlBtn>
            <CtrlBtn onClick={() => setShowLabels((v) => !v)} label="Labels">
              {showLabels ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
            </CtrlBtn>
          </div>
        </div>

         {/* Zoom readout */}
        <div className={`pointer-events-none absolute bottom-3 right-3 z-10 text-[10px] font-mono ${isLight ? "text-slate-900/70" : "text-white/70 [text-shadow:0_1px_6px_rgba(0,0,0,0.6)]"}`}>
          ×{camera.scale.toFixed(2)}
        </div>

        {/* Weather effects (rain / snow / fog / etc) */}
        <WeatherLayer type={weather} isLight={isLight} />

        {/* Adaptive AI HUD — floating, edge-hugging, GPU-friendly */}
         <HudLayer isLight={isLight} glow={t.glow} autoplay={autoplay} preset={hudPreset} showCards={showHud} ticker={tickerCfg} />

        <PlayLayer mode={playMode} theme={t} isLight={isLight} active={autoplay} />

        {/* Always-reachable exit for full-bleed play templates */}
        {autoplay && (
          <div className="pointer-events-none absolute right-3 top-3 z-[20] flex items-center gap-1.5">
            <button
              onClick={() => setPlayMode((m) => (((m % PLAY_MODES.length) + 1) as PlayMode))}
              className="pointer-events-auto rounded-md border border-white/20 bg-black/45 px-2 py-1 text-[9.5px] font-bold text-white backdrop-blur-md hover:bg-black/65"
              title="Next template"
            >
              Next
            </button>
            <button
              onClick={() => setAutoplay(false)}
              className="pointer-events-auto flex items-center gap-1 rounded-md border border-white/20 bg-black/45 px-2 py-1 text-[9.5px] font-bold text-white backdrop-blur-md hover:bg-black/65"
              title="Exit play mode (Esc)"
            >
              <X className="h-3 w-3" /> Exit
            </button>
          </div>
        )}

        {/* Touch ripples */}
        <RippleLayer ripples={ripples} color={t.glow} />




        {/* Hover district label */}
        <AnimatePresence>
          {hovered && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              className={`pointer-events-none absolute bottom-14 left-1/2 -translate-x-1/2 text-[10px] font-semibold ${isLight ? "text-slate-900" : "text-white [text-shadow:0_1px_6px_rgba(0,0,0,0.6)]"}`}
            >
              {hovered} district
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* SPLIT HANDLE */}
      <div
        onPointerDown={onSplitPointerDown}
        onPointerMove={onSplitPointerMove}
        onPointerUp={onSplitPointerUp}
        onPointerCancel={onSplitPointerUp}
        className={`group relative z-20 h-1.5 shrink-0 cursor-row-resize ${
          isLight ? "bg-slate-200" : "bg-white/10"
        }`}
        style={{ touchAction: "none" }}
      >
        <div className={`pointer-events-none absolute left-1/2 top-1/2 h-0.5 w-10 -translate-x-1/2 -translate-y-1/2 rounded-full ${
          isLight ? "bg-slate-400" : "bg-white/40"
        }`} />
      </div>

      {/* DASHBOARD HALF */}
      <div ref={botPaneRef} className="relative min-h-0 flex-1 overflow-hidden" style={{ height: `${100 - splitPct}%`, background: t.bg }}>
        <Dashboard
          theme={t}
          place={selected}
          totalPlaces={DATA.places.length}
          totalDistricts={DATA.districts.length}
          onSelectPlace={setSelected}
        />
        {!showTicker && (
          <style>{`.hud-ticker{display:none}`}</style>
        )}
      </div>

      {/* Floating draggable AI copilot */}
      <Copilot isLight={isLight} glow={t.glow} />
      <CommitsFloaty isLight={isLight} glow={t.glow} />
      <EventsFloaty isLight={isLight} glow={t.glow} />


      {/* Settings sheet */}
      <AnimatePresence>
        {settingsOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSettingsOpen(false)}
              className="fixed inset-0 z-40 bg-black/40 backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
              className={`fixed inset-y-0 right-0 z-50 flex w-[min(300px,92vw)] flex-col overflow-y-auto border-l p-2 backdrop-blur-2xl ${glass}`}
              style={{
                boxShadow: isLight
                  ? "-20px 0 60px -20px rgba(30,50,120,0.35)"
                  : `-20px 0 60px -10px ${t.glow}`,
              }}
            >
              <div className="flex items-center justify-between border-b border-current/10 pb-1.5">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5" />
                  <h2 className="text-[13px] font-bold" style={{ fontFamily: "'Sora',sans-serif" }}>
                    Map settings
                  </h2>
                </div>
                <button
                  onClick={() => setSettingsOpen(false)}
                  className="grid h-7 w-7 place-items-center rounded-md bg-current/10 hover:bg-current/20"
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <Section title="Theme">
                <div className="grid grid-cols-3 gap-1">
                  {(Object.keys(THEMES) as MapTheme[]).map((key) => {
                    const spec = THEMES[key];
                    const active = key === theme;
                    return (
                      <button
                        key={key}
                        onClick={() => setTheme(key)}
                        className={`group relative h-7 overflow-hidden rounded-md border px-1.5 text-left transition ${
                          active
                            ? "border-current/60 ring-2 ring-current/30"
                            : "border-current/15 hover:border-current/40"
                        }`}
                        style={{ background: spec.bg }}
                      >
                        <div className="flex items-center gap-1.5">
                          <span
                            className="h-1.5 w-1.5 shrink-0 rounded-full"
                            style={{ background: spec.glow, boxShadow: `0 0 8px ${spec.glow}` }}
                          />
                          <span
                            className="truncate text-[8px] font-semibold"
                            style={{
                              color: spec.ui === "glass-light" ? "#0f172a" : "#fff",
                              fontFamily: "'Sora',sans-serif",
                            }}
                          >
                            {spec.name}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </Section>


              

              <Section title="Layers" icon={<Layers className="h-4 w-4" />}>
                <div className="grid grid-cols-3 gap-1">
                  {TYPES.map((tp) => {
                    const on = visibleTypes[tp.key];
                    return (
                      <button
                        key={tp.key}
                        onClick={() =>
                          setVisibleTypes((v) => ({ ...v, [tp.key]: !v[tp.key] }))
                        }
                        className={`flex h-7 min-w-0 items-center rounded-md border px-1.5 text-[9px] transition ${
                          on
                            ? "border-current/50 bg-current/10"
                            : "border-current/10 opacity-60"
                        }`}
                      >
                        <span className="flex min-w-0 items-center gap-1">
                          <span
                            className="h-1.5 w-1.5 shrink-0 rounded-full"
                            style={{
                              background: t.markerCore[tp.key],
                              boxShadow: on ? `0 0 8px ${t.markerCore[tp.key]}` : "none",
                            }}
                          />
                          <span className="truncate font-medium">{tp.label}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-1 flex flex-wrap gap-1 text-[9px]">
                  <MiniBtn onClick={() => setVisibleTypes({ capital: true, city: true, town: true, village: true, park: true, landmark: true })}>All</MiniBtn>
                  <MiniBtn onClick={() => setVisibleTypes({ capital: true, city: false, town: true, village: true, park: false, landmark: false })}>Towns only</MiniBtn>
                  <MiniBtn onClick={() => setVisibleTypes({ capital: false, city: false, town: false, village: false, park: true, landmark: true })}>Nature</MiniBtn>
                </div>
              </Section>

              <Section title="Marker size">
                <input
                  type="range"
                  min={0}
                  max={2}
                  step={0.05}
                  value={markerSize}
                  onChange={(e) => setMarkerSize(Number(e.target.value))}
                  className="w-full accent-current"
                />
                <div className="mt-0.5 text-[9px] opacity-60">×{markerSize.toFixed(2)}</div>
              </Section>

              <Section title="Label size">
                <input
                  type="range"
                  min={0}
                  max={1.6}
                  step={0.05}
                  value={labelScale}
                  onChange={(e) => setLabelScale(Number(e.target.value))}
                  className="w-full accent-current"
                />
                <div className="mt-0.5 text-[9px] opacity-60">×{labelScale.toFixed(2)} · auto-compensated for zoom</div>
              </Section>

              



              <Section title="Map region" icon={<Globe2 className="h-4 w-4" />}>
                <div className="grid grid-cols-3 gap-1">
                  {REGIONS.map((r) => {
                    const active = r.key === region;
                    return (
                      <button
                        key={r.key}
                        onClick={() => setRegion(r.key)}
                        className={`flex h-7 min-w-0 items-center justify-center rounded-md border px-1.5 text-[9px] transition ${
                          active ? "border-current/50 bg-current/10" : "border-current/10 opacity-70 hover:opacity-100"
                        }`}
                      >
                        <span className="truncate font-medium">{r.label}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-0.5 text-[9px] opacity-60">{REGIONS.find((r) => r.key === region)?.hint}</div>
              </Section>

              <Section title="Map split">
                <input
                  type="range"
                  min={28}
                  max={82}
                  step={1}
                  value={splitPct}
                  onChange={(e) => setSplitPct(Number(e.target.value))}
                  className="w-full accent-current"
                />
                <div className="mt-0.5 text-[9px] opacity-60">Map {Math.round(splitPct)}% · Dashboard {Math.round(100 - splitPct)}%</div>
              </Section>

              <Section title="Display">
                <ToggleRow label="Show labels" value={showLabels} onChange={setShowLabels} />
                <ToggleRow label="Show districts" value={showDistricts} onChange={setShowDistricts} />
                <ToggleRow label="Show grid overlay" value={showGrid} onChange={setShowGrid} />
                <ToggleRow label="Auto tour" value={autoplay} onChange={setAutoplay} />
              </Section>

              <Section title="Weather effects" icon={<CloudRain className="h-4 w-4" />}>
                <div className="grid grid-cols-3 gap-1">

                  {WEATHER_OPTIONS.map((w) => {
                    const active = w.key === weather;
                    const Icon =
                      w.key === "off"
                        ? Sparkles
                        : w.key === "rain" || w.key === "heavy-rain"
                        ? CloudRain
                        : w.key === "lightning"
                        ? Zap
                        : w.key === "fog"
                        ? Cloud
                        : w.key === "snow"
                        ? Cloud
                        : Waves;
                    return (
                      <button
                        key={w.key}
                        onClick={() => setWeather(w.key)}
                        className={`flex h-7 min-w-0 items-center rounded-md border px-1.5 text-[9px] transition ${
                          active
                            ? "border-current/50 bg-current/10"
                            : "border-current/10 opacity-70 hover:opacity-100"
                        }`}
                      >
                        <span className="flex min-w-0 items-center gap-1">
                          <Icon className="h-3 w-3 shrink-0" />
                          <span className="truncate font-medium">{w.label}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </Section>





              <div className="mt-2 text-[8px] uppercase tracking-[0.15em] opacity-50">
                {DATA.places.length} locations · {DATA.districts.length} districts · {Object.keys(THEMES).length} themes
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function shade(hex: string, factor: number) {
  const m = hex.replace("#", "");
  if (m.length !== 6) return hex;
  const r = Math.min(255, Math.round(parseInt(m.slice(0, 2), 16) * factor));
  const g = Math.min(255, Math.round(parseInt(m.slice(2, 4), 16) * factor));
  const b = Math.min(255, Math.round(parseInt(m.slice(4, 6), 16) * factor));
  return `rgb(${r},${g},${b})`;
}

function Section({
  title, icon, children,
}: { title: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="mt-1.5 border-b border-current/10 pb-1.5">
      <div className="mb-1 flex items-center gap-1.5 text-[8px] font-semibold uppercase tracking-[0.12em] opacity-60">
        {icon}
        <span>{title}</span>
      </div>
      <div>{children}</div>
    </section>
  );
}

function ToggleRow({
  label, value, onChange,
}: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="mb-0.5 flex h-6 w-full items-center justify-between px-1 text-[9px]"
    >
      <span className="font-medium">{label}</span>
      <span
        className={`relative h-3.5 w-6 rounded-full transition ${
          value ? "bg-current/70" : "bg-current/20"
        }`}
      >
        <span
          className="absolute top-0.5 h-2.5 w-2.5 rounded-full bg-white transition"
          style={{ left: value ? "12px" : "2px" }}
        />
      </span>
    </button>
  );
}


function SliderRow({
  label, value, min, max, step, onChange, suffix = "", digits = 0,
}: {
  label: string; value: number; min: number; max: number; step: number;
  onChange: (v: number) => void; suffix?: string; digits?: number;
}) {
  return (
    <div className="mb-1 flex items-center gap-2">
      <span className="w-[62px] shrink-0 text-[9px] font-medium opacity-80">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1 flex-1 accent-current"
      />
      <span className="w-[34px] shrink-0 text-right text-[8px] font-mono opacity-60">
        {value.toFixed(digits)}{suffix}
      </span>
    </div>
  );
}

function MiniBtn({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="rounded-md border border-current/20 bg-current/5 px-2 py-0.5 text-[9px] font-medium hover:bg-current/10"
    >
      {children}
    </button>
  );
}

function CtrlBtn({ children, onClick, label }: { children: React.ReactNode; onClick: () => void; label: string }) {
  return (
    <button
      aria-label={label}
      onClick={onClick}
      className="grid h-9 w-9 place-items-center rounded-xl transition hover:bg-white/10 active:scale-95"
    >
      {children}
    </button>
  );
}
