import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { Activity, Boxes, Cpu, Orbit, Radar as RadarIcon, Type, Waves } from "lucide-react";
import { alpha } from "./color";

/** Transparent HUD card shell — only border + blur, never a filled background. */
export function ghost(isLight: boolean) {
  return `border ${isLight ? "border-slate-900/12 text-slate-900" : "border-white/12 text-white"} bg-transparent backdrop-blur-[2px]`;
}

function Head({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="mb-1 flex items-center gap-1 text-[8px] font-bold uppercase tracking-[0.2em] opacity-65">
      {icon}
      {label}
    </div>
  );
}

/* ---------- 1 · NEURAL: self-drawing mindmap ---------- */

export function NeuralCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  const nodes = useMemo(
    () => [
      { x: 50, y: 42, r: 9, t: "BW" },
      { x: 16, y: 16, r: 5, t: "Delta" },
      { x: 86, y: 20, r: 5, t: "Chobe" },
      { x: 14, y: 70, r: 5, t: "Kgalag" },
      { x: 88, y: 72, r: 5, t: "Gabs" },
      { x: 50, y: 84, r: 4, t: "Ghanzi" },
    ],
    [],
  );
  return (
    <div className={`w-[128px] bg-transparent px-2 py-1.5 ${isLight ? "text-slate-900" : "text-white"}`}>
      <Head icon={<Cpu className="h-2.5 w-2.5" />} label="Neural map" />
      <svg viewBox="0 0 100 100" className="h-[86px] w-full overflow-visible">
        {nodes.slice(1).map((n, i) => (
          <motion.line
            key={i}
            x1={50} y1={42} x2={n.x} y2={n.y}
            stroke={glow} strokeWidth={0.7} strokeDasharray="70"
            initial={{ strokeDashoffset: 70, opacity: 0.2 }}
            animate={{ strokeDashoffset: [70, 0, 70], opacity: [0.2, 0.9, 0.2] }}
            transition={{ duration: 4 + i * 0.5, repeat: Infinity, ease: "easeInOut", delay: i * 0.3 }}
          />
        ))}
        {nodes.map((n, i) => (
          <g key={n.t}>
            <motion.circle
              cx={n.x} cy={n.y} r={n.r}
              fill={alpha(glow, 0.18)} stroke={glow} strokeWidth={0.8}
              animate={{ r: [n.r, n.r * 1.18, n.r] }}
              transition={{ duration: 2.6, repeat: Infinity, delay: i * 0.25 }}
            />
            <text x={n.x} y={n.y + n.r + 6} textAnchor="middle" fontSize="5.5" fill="currentColor" opacity={0.7}>
              {n.t}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ---------- 2 · MOTION: animated vector loop (lottie-style) ---------- */

export function MotionCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  return (
    <div className={`w-[116px] bg-transparent px-2 py-1.5 ${isLight ? "text-slate-900" : "text-white"}`}>
      <Head icon={<Orbit className="h-2.5 w-2.5" />} label="Orbital" />
      <svg viewBox="0 0 100 100" className="h-[78px] w-full">
        {[34, 24, 15].map((r, i) => (
          <motion.ellipse
            key={r}
            cx="50" cy="50" rx={r} ry={r * 0.42}
            fill="none" stroke={glow} strokeWidth={0.8} opacity={0.5}
            animate={{ rotate: i % 2 ? -360 : 360 }}
            transition={{ duration: 12 + i * 5, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "50px 50px" }}
          />
        ))}
        {[0, 1, 2].map((i) => (
          <motion.circle
            key={i} r={2.6} fill={glow}
            animate={{ rotate: 360 }}
            transition={{ duration: 6 + i * 3, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "50px 50px", filter: `drop-shadow(0 0 4px ${glow})` }}
            cx={50 + [34, 24, 15][i]} cy={50}
          />
        ))}
        <motion.circle
          cx="50" cy="50" r="6" fill={alpha(glow, 0.35)} stroke={glow} strokeWidth="0.8"
          animate={{ r: [6, 7.6, 6] }} transition={{ duration: 2, repeat: Infinity }}
        />
      </svg>
    </div>
  );
}

/* ---------- 3 · TYPE: kinetic typography ---------- */

const WORDS = ["OKAVANGO", "KALAHARI", "MAKGADIKGADI", "TSODILO", "CHOBE", "GABORONE"];

export function KineticTextCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setI((v) => (v + 1) % WORDS.length), 2400);
    return () => window.clearInterval(id);
  }, []);
  const w = WORDS[i];
  return (
    <div className={`w-[136px] rounded-2xl px-2.5 py-2 ${ghost(isLight)}`}>
      <Head icon={<Type className="h-2.5 w-2.5" />} label="Signal text" />
      <div className="flex h-[34px] items-center overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div key={w} className="flex" initial="h" animate="s" exit="e">
            {w.split("").map((ch, k) => (
              <motion.span
                key={k}
                variants={{
                  h: { opacity: 0, y: 12, rotateX: -80 },
                  s: { opacity: 1, y: 0, rotateX: 0 },
                  e: { opacity: 0, y: -10 },
                }}
                transition={{ delay: k * 0.03, duration: 0.3 }}
                className="text-[13px] font-black leading-none"
                style={{ fontFamily: "'Sora',sans-serif", color: glow, textShadow: `0 0 10px ${alpha(glow, 0.5)}` }}
              >
                {ch}
              </motion.span>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
      <motion.div
        className="h-[2px] rounded-full"
        style={{ background: glow }}
        animate={{ scaleX: [0, 1, 0] }}
        transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}

/* ---------- 4 · FLUX: animated line network ---------- */

export function FluxCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  const pts = useMemo(
    () => Array.from({ length: 9 }, (_, i) => ({ x: 8 + ((i * 37) % 84), y: 12 + ((i * 53) % 76) })),
    [],
  );
  return (
    <div className={`w-[124px] rounded-2xl px-2 py-1.5 ${ghost(isLight)}`}>
      <Head icon={<Waves className="h-2.5 w-2.5" />} label="Flux mesh" />
      <svg viewBox="0 0 100 100" className="h-[80px] w-full">
        {pts.map((p, i) =>
          pts.slice(i + 1).map((q, j) => {
            const d = Math.hypot(p.x - q.x, p.y - q.y);
            if (d > 42) return null;
            return (
              <motion.line
                key={`${i}-${j}`}
                x1={p.x} y1={p.y} x2={q.x} y2={q.y}
                stroke={glow} strokeWidth={0.4}
                animate={{ opacity: [0.1, 0.65, 0.1] }}
                transition={{ duration: 3 + ((i + j) % 4), repeat: Infinity, delay: (i + j) * 0.12 }}
              />
            );
          }),
        )}
        {pts.map((p, i) => (
          <motion.circle
            key={i} cx={p.x} cy={p.y} r={1.8} fill={glow}
            animate={{ cy: [p.y, p.y + (i % 2 ? 5 : -5), p.y] }}
            transition={{ duration: 4 + (i % 3), repeat: Infinity, ease: "easeInOut" }}
          />
        ))}
      </svg>
    </div>
  );
}

/* ---------- 5 · VITALS: multi-gauge cluster ---------- */

const VITALS = [
  { k: "CPU", v: 74, hue: 18 },
  { k: "LINK", v: 92, hue: 152 },
  { k: "AI", v: 86, hue: 208 },
];

export function VitalsCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  return (
    <div className={`w-[136px] rounded-2xl px-2.5 py-2 ${ghost(isLight)}`}>
      <Head icon={<Activity className="h-2.5 w-2.5" />} label="Vitals" />
      <div className="flex items-center justify-between">
        {VITALS.map((v, i) => {
          const r = 15;
          const c = 2 * Math.PI * r;
          const color = `hsl(${(v.hue + i * 14) % 360} 88% 58%)`;
          return (
            <div key={v.k} className="relative h-9 w-9">
              <svg viewBox="0 0 36 36" className="-rotate-90">
                <circle cx="18" cy="18" r={r} fill="none" stroke="currentColor" opacity={0.12} strokeWidth="2.5" />
                <motion.circle
                   cx="18" cy="18" r={r} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
                  strokeDasharray={c}
                  animate={{ strokeDashoffset: [c, c * (1 - v.v / 100), c * (1 - (v.v - 6) / 100), c * (1 - v.v / 100)] }}
                  transition={{ duration: 4, repeat: Infinity, delay: i * 0.3, ease: "easeInOut" }}
                   style={{ filter: `drop-shadow(0 0 4px ${color})` }}
                />
              </svg>
               <motion.div animate={{ color: [color, glow, color] }} transition={{ duration: 4, repeat: Infinity, delay: i * 0.3 }} className="absolute inset-0 grid place-items-center text-[7.5px] font-black">{v.k}</motion.div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- 6 · GRID: pure animated grid, no chrome ---------- */

export function GridDrawCard({ glow }: { glow: string }) {
  return (
    <div className="w-[124px] bg-transparent">
      <div className="mb-1 text-[8px] font-bold uppercase tracking-[0.2em] opacity-60">Grid draw</div>
      <svg viewBox="0 0 100 60" className="h-[60px] w-full">
        {Array.from({ length: 7 }).map((_, i) => (
          <motion.line
            key={`h${i}`} x1={0} x2={100} y1={i * 10} y2={i * 10}
            stroke={glow} strokeWidth={0.35} strokeDasharray="100"
            initial={{ strokeDashoffset: 100 }}
            animate={{ strokeDashoffset: [100, 0, 100] }}
            transition={{ duration: 5, repeat: Infinity, delay: i * 0.18 }}
          />
        ))}
        {Array.from({ length: 11 }).map((_, i) => (
          <motion.line
            key={`v${i}`} y1={0} y2={60} x1={i * 10} x2={i * 10}
            stroke={glow} strokeWidth={0.35} strokeDasharray="60"
            initial={{ strokeDashoffset: 60 }}
            animate={{ strokeDashoffset: [60, 0, 60] }}
            transition={{ duration: 5, repeat: Infinity, delay: i * 0.12 }}
          />
        ))}
        <motion.rect
          width="10" height="10" fill={alpha(glow, 0.4)}
          animate={{ x: [0, 40, 80, 30, 0], y: [0, 20, 40, 10, 0] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
        />
      </svg>
    </div>
  );
}

/* ---------- 7 · SCAN: radar sweep ---------- */

export function ScanCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  return (
    <div className={`w-[112px] rounded-2xl px-2 py-1.5 ${ghost(isLight)}`}>
      <Head icon={<RadarIcon className="h-2.5 w-2.5" />} label="Sweep" />
      <div className="relative h-[74px] w-full">
        <svg viewBox="0 0 100 100" className="h-full w-full">
          {[40, 28, 16].map((r) => (
            <circle key={r} cx="50" cy="50" r={r} fill="none" stroke={glow} strokeWidth="0.4" opacity={0.35} />
          ))}
          <motion.g
            animate={{ rotate: 360 }}
            transition={{ duration: 3.6, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "50px 50px" }}
          >
            <path d="M50 50 L90 50 A40 40 0 0 0 78 22 Z" fill={alpha(glow, 0.28)} />
            <line x1="50" y1="50" x2="90" y2="50" stroke={glow} strokeWidth="0.8" />
          </motion.g>
          {[[68, 38], [38, 66], [60, 70]].map(([x, y], i) => (
            <motion.circle
              key={i} cx={x} cy={y} r="2" fill={glow}
              animate={{ opacity: [0.15, 1, 0.15] }}
              transition={{ duration: 3.6, repeat: Infinity, delay: i * 1.1 }}
            />
          ))}
        </svg>
      </div>
    </div>
  );
}

/* ---------- 8 · STACK: animated stat stack ---------- */

const STACK = [
  { k: "Uplink", v: 96 },
  { k: "Sensors", v: 71 },
  { k: "Yield", v: 84 },
  { k: "Latency", v: 38 },
];

export function StackCard({ isLight, glow }: { isLight: boolean; glow: string }) {
  return (
    <div className={`w-[130px] rounded-2xl px-2.5 py-2 ${ghost(isLight)}`}>
      <Head icon={<Boxes className="h-2.5 w-2.5" />} label="Stack" />
      <div className="space-y-1">
        {STACK.map((r, i) => (
          <div key={r.k}>
            <div className="flex items-center justify-between text-[8.5px] font-semibold opacity-75">
              <span>{r.k}</span>
              <span className="tabular-nums">{r.v}</span>
            </div>
            <div className="h-[3px] w-full overflow-hidden rounded-full" style={{ background: alpha(glow, 0.12) }}>
              <motion.div
                className="h-full rounded-full"
                style={{ background: glow, boxShadow: `0 0 6px ${glow}` }}
                animate={{ width: [`${r.v * 0.4}%`, `${r.v}%`, `${r.v * 0.7}%`, `${r.v}%`] }}
                transition={{ duration: 5 + i, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
