/* Premium mode 5 — Insight Terminal (map-focus): camera snap-zooms through
 * places while a bottom-docked analyst terminal renders bars/sparkline/table
 * for the same place — polished, monospace, tick-driven. */
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import type { ThemeSpec } from "./themes";
import { alpha } from "./color";
import { PLACE_CYCLE, statsFor, clockIndex } from "./playData";
import { SPOTLIGHT_MS } from "./PlayModes2";

const EASE = [0.22, 1, 0.36, 1] as const;
const MONO = "'JetBrains Mono','SFMono-Regular',ui-monospace,monospace";

function useSyncedPlace() {
  const [, force] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => force((v) => v + 1), 400);
    return () => window.clearInterval(id);
  }, []);
  const i = clockIndex(PLACE_CYCLE.length, SPOTLIGHT_MS);
  return statsFor(PLACE_CYCLE[i]);
}

function useTick() {
  const [n, setN] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setN((v) => v + 1), 1000);
    return () => window.clearInterval(id);
  }, []);
  return n;
}

function InsightTerminal({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSyncedPlace();
  const tick = useTick();
  const text = isLight ? "#0f172a" : "#eaf1ff";
  const maxHist = Math.max(...s.history);
  const maxSector = Math.max(...s.sectorMix.map((m) => m.value));
  const surface0 = alpha(isLight ? "#ffffff" : "#03050c", 0.96);
  const surface1 = alpha(isLight ? "#ffffff" : "#03050c", 0.78);

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0">
      <div className="h-[2px] w-full" style={{ background: `linear-gradient(90deg, transparent, ${theme.glow}, transparent)` }} />
      <div
        className="grid max-h-[46vh] grid-cols-1 gap-2 overflow-y-auto p-2.5 backdrop-blur-xl sm:grid-cols-3 sm:gap-3 sm:p-3"
        style={{ background: `linear-gradient(0deg, ${surface0}, ${surface1})`, borderTop: `1px solid ${alpha(theme.glow, 0.25)}` }}
      >
        {/* header + live tick row */}
        <div className="col-span-1 flex items-center justify-between gap-2 sm:col-span-3">
          <div className="flex items-center gap-2">
            <span className="rounded px-1.5 py-[2px] text-[8px] font-black uppercase tracking-[0.25em] text-white" style={{ background: theme.glow }}>
              Terminal
            </span>
            <AnimatePresence mode="wait">
              <motion.div key={s.name} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.35, ease: EASE }} className="min-w-0">
                <div className="truncate text-[12px] font-black leading-none" style={{ color: text, fontFamily: "'Sora',sans-serif" }}>{s.name}</div>
                <div className="truncate text-[7.5px] font-bold uppercase tracking-[0.14em] opacity-55" style={{ color: text }}>{s.district} · {s.type}</div>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <motion.span animate={{ opacity: [1, 0.2, 1] }} transition={{ duration: 1, repeat: Infinity }}
              className="h-1.5 w-1.5 rounded-full" style={{ background: "#34d399" }} />
            <span className="text-[8px] font-bold tabular-nums opacity-60" style={{ color: text, fontFamily: MONO }}>
              {new Date(Date.now() - (tick % 60) * 0).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </span>
          </div>
        </div>

        {/* sparkline */}
        <AnimatePresence mode="wait">
          <motion.div key={s.name + "-spark"} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}>
            <div className="text-[7px] font-black uppercase tracking-[0.2em] opacity-50" style={{ color: text }}>Sentiment trend</div>
            <svg viewBox="0 0 160 34" className="mt-0.5 h-[30px] w-full">
              <motion.polyline
                points={s.history.map((v, i) => `${(i / (s.history.length - 1)) * 160},${34 - (v / maxHist) * 30}`).join(" ")}
                fill="none" stroke={theme.glow} strokeWidth="2" strokeLinecap="round"
                initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1, ease: EASE }}
                style={{ filter: `drop-shadow(0 0 6px ${alpha(theme.glow, 0.6)})` }} />
            </svg>
          </motion.div>
        </AnimatePresence>

        {/* animated column bars */}
        <AnimatePresence mode="wait">
          <motion.div key={s.name + "-bars"} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}>
            <div className="text-[7px] font-black uppercase tracking-[0.2em] opacity-50" style={{ color: text }}>Sector mix</div>
            <div className="mt-0.5 flex h-[30px] items-end gap-1">
              {s.sectorMix.slice(0, 6).map((m, k) => (
                <div key={m.label} className="flex min-w-0 flex-1 flex-col items-center justify-end gap-[2px]">
                  <motion.div initial={{ height: 0 }} animate={{ height: `${(m.value / maxSector) * 24}px` }}
                    transition={{ duration: 0.6, delay: k * 0.05, ease: EASE }}
                    className="w-full rounded-t" style={{ background: theme.glow, boxShadow: `0 0 6px ${alpha(theme.glow, 0.6)}` }} />
                </div>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* compact sortable-looking data table */}
        <AnimatePresence mode="wait">
          <motion.div key={s.name + "-table"} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}>
            <div className="flex items-center justify-between text-[7px] font-black uppercase tracking-[0.2em] opacity-50" style={{ color: text }}>
              <span>Metric</span><span>Value ↕</span>
            </div>
            <div className="mt-0.5 divide-y" style={{ borderColor: alpha(theme.glow, 0.12) }}>
              {s.table.slice(0, 4).map((row) => (
                <div key={row.metric} className="flex items-center justify-between gap-1.5 py-[3px]" style={{ borderColor: alpha(theme.glow, 0.1) }}>
                  <span className="min-w-0 flex-1 truncate text-[8px] font-semibold opacity-65" style={{ color: text }}>{row.metric}</span>
                  <span className="shrink-0 text-[9.5px] font-black tabular-nums" style={{ color: text, fontFamily: MONO }}>{row.value}</span>
                  <span className="flex shrink-0 items-center gap-0.5 text-[7.5px] font-bold tabular-nums" style={{ color: row.up ? "#34d399" : "#f87171" }}>
                    {row.up ? <ArrowUpRight className="h-2.5 w-2.5" /> : <ArrowDownRight className="h-2.5 w-2.5" />}{row.delta}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

export function PlayLayer4({ mode, theme, isLight }: { mode: number; theme: ThemeSpec; isLight: boolean }) {
  if (mode === 5) return <InsightTerminal theme={theme} isLight={isLight} />;
  return null;
}
