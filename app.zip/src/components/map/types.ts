export type PlaceType = "capital" | "city" | "town" | "village" | "park" | "landmark";

export interface Place {
  name: string;
  type: PlaceType;
  x: number;
  y: number;
  lon: number;
  lat: number;
}

export interface District {
  name: string;
  path: string;
}

export interface BotswanaData {
  viewBox: [number, number, number, number];
  country: string;
  districts: District[];
  places: Place[];
}

export type MapTheme =
  | "light"
  | "blueprint"
  | "midnight"
  | "mist";


