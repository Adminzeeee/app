/* Collaborative community events calendar — dummy social data. */

export type EventCategory = "Market" | "Culture" | "Sports" | "Civic" | "Health" | "Education";

export interface Comment {
  id: string;
  user: string;
  avatarColor: string;
  text: string;
  when: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  category: EventCategory;
  date: string;       // YYYY-MM-DD
  time: string;        // "09:00"
  endTime?: string;
  location: string;
  blurb: string;
  color: string;
  going: number;
  attendees: { name: string; color: string }[];
  reactions: { emoji: string; count: number }[];
  comments: Comment[];
  createdBy: string;
}

export const CATEGORY_COLORS: Record<EventCategory, string> = {
  Market: "#f59e0b",
  Culture: "#a855f7",
  Sports: "#22c55e",
  Civic: "#3b82f6",
  Health: "#ef4444",
  Education: "#14b8a6",
};

export const CATEGORIES: EventCategory[] = ["Market", "Culture", "Sports", "Civic", "Health", "Education"];

function pad(n: number) { return String(n).padStart(2, "0"); }
export const TODAY = new Date();
const y = TODAY.getFullYear();
const m = TODAY.getMonth();
const d = TODAY.getDate();
const iso = (day: number) => `${y}-${pad(m + 1)}-${pad(Math.min(28, Math.max(1, day)))}`;

export const EVENTS: CalendarEvent[] = [
  {
    id: "e1", title: "Saturday Market Day", category: "Market", date: iso(d), time: "09:00", endTime: "14:00",
    location: "Gaborone West Community Ground",
    blurb: "Fresh produce, crafts and live music. Vendor stalls open at 8am for setup.",
    color: CATEGORY_COLORS.Market, going: 128,
    attendees: [{ name: "Kabo", color: "#f59e0b" }, { name: "Thato", color: "#22c55e" }, { name: "Neo", color: "#3b82f6" }, { name: "Lorato", color: "#a855f7" }],
    reactions: [{ emoji: "🔥", count: 34 }, { emoji: "🙌", count: 21 }, { emoji: "🍊", count: 12 }],
    comments: [
      { id: "c1", user: "Thato", avatarColor: "#22c55e", text: "Bringing extra tomatoes this week!", when: "2h ago" },
      { id: "c2", user: "Neo", avatarColor: "#3b82f6", text: "Is the music starting at 10 again?", when: "1h ago" },
    ],
    createdBy: "Ward Market Committee",
  },
  {
    id: "e2", title: "Notwane Riverbank Clean-up", category: "Civic", date: iso(d + 1), time: "07:00", endTime: "10:00",
    location: "Notwane River, near the old bridge",
    blurb: "Gloves and bags provided. Meet at the old bridge car park.",
    color: CATEGORY_COLORS.Civic, going: 42,
    attendees: [{ name: "Onalenna", color: "#3b82f6" }, { name: "Kagiso", color: "#ef4444" }],
    reactions: [{ emoji: "🌍", count: 19 }, { emoji: "💪", count: 8 }],
    comments: [{ id: "c3", user: "Onalenna", avatarColor: "#3b82f6", text: "Council is sending extra bins this time.", when: "5h ago" }],
    createdBy: "Green Botswana Initiative",
  },
  {
    id: "e3", title: "Free Health Screening Clinic", category: "Health", date: iso(d + 2), time: "08:30", endTime: "13:00",
    location: "Mogoditshane Health Post",
    blurb: "Blood pressure, glucose and eye checks. No appointment needed.",
    color: CATEGORY_COLORS.Health, going: 76,
    attendees: [{ name: "Lesego", color: "#ef4444" }, { name: "Boitumelo", color: "#f59e0b" }, { name: "Kabo", color: "#22c55e" }],
    reactions: [{ emoji: "❤️", count: 27 }],
    comments: [{ id: "c4", user: "Lesego", avatarColor: "#ef4444", text: "Bring your clinic card if you have one.", when: "1d ago" }],
    createdBy: "Mogoditshane Health Volunteers",
  },
  {
    id: "e4", title: "Ward 14 Water Supply Meeting", category: "Civic", date: iso(d - 1), time: "17:00", endTime: "19:00",
    location: "Ward 14 Kgotla",
    blurb: "Vote on the new borehole budget. Quorum of 25 residents needed.",
    color: CATEGORY_COLORS.Civic, going: 31,
    attendees: [{ name: "Tumelo", color: "#3b82f6" }, { name: "Refilwe", color: "#a855f7" }],
    reactions: [{ emoji: "💧", count: 14 }],
    comments: [],
    createdBy: "Ward 14 Council",
  },
  {
    id: "e5", title: "Traditional Dance Showcase", category: "Culture", date: iso(d + 4), time: "16:00", endTime: "19:00",
    location: "Main Mall Amphitheatre",
    blurb: "Local troupes celebrate heritage month with dance and drumming.",
    color: CATEGORY_COLORS.Culture, going: 210,
    attendees: [{ name: "Neo", color: "#3b82f6" }, { name: "Lorato", color: "#a855f7" }, { name: "Thato", color: "#22c55e" }],
    reactions: [{ emoji: "💃", count: 51 }, { emoji: "🥁", count: 22 }],
    comments: [{ id: "c5", user: "Lorato", avatarColor: "#a855f7", text: "Last year's show was incredible, don't miss it!", when: "3h ago" }],
    createdBy: "Gaborone Cultural Council",
  },
  {
    id: "e6", title: "Numeracy Drop-in Tutoring", category: "Education", date: iso(d + 3), time: "14:00", endTime: "16:00",
    location: "Block 8 Primary School",
    blurb: "Volunteers help grades 1-7 with maths homework and drills.",
    color: CATEGORY_COLORS.Education, going: 19,
    attendees: [{ name: "Kagiso", color: "#ef4444" }],
    reactions: [{ emoji: "📚", count: 9 }],
    comments: [],
    createdBy: "Block 8 PTA",
  },
  {
    id: "e7", title: "Inter-ward Football Friendly", category: "Sports", date: iso(d + 6), time: "15:00", endTime: "17:00",
    location: "Bontleng Sports Ground",
    blurb: "Ward 9 vs Ward 14 — bring your colours and cheer loudly.",
    color: CATEGORY_COLORS.Sports, going: 95,
    attendees: [{ name: "Kabo", color: "#22c55e" }, { name: "Neo", color: "#3b82f6" }],
    reactions: [{ emoji: "⚽", count: 33 }, { emoji: "🔥", count: 18 }],
    comments: [{ id: "c6", user: "Kabo", avatarColor: "#22c55e", text: "Ward 14 is bringing a brass band apparently 😂", when: "6h ago" }],
    createdBy: "Bontleng Sports Club",
  },
  {
    id: "e8", title: "Tlokweng Co-op Fresh Sale", category: "Market", date: iso(d - 2), time: "10:00", endTime: "15:00",
    location: "Tlokweng Co-op Stand 4",
    blurb: "Surplus oranges and greens at reduced prices while stock lasts.",
    color: CATEGORY_COLORS.Market, going: 54,
    attendees: [{ name: "Boitumelo", color: "#f59e0b" }],
    reactions: [{ emoji: "🍊", count: 25 }],
    comments: [],
    createdBy: "Tlokweng Farmers Co-op",
  },
];
