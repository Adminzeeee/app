import { memo, useMemo } from "react";
import DATA from "@/data/botswana.json";

/**
 * High-detail procedural sample for the North-East District.
 * Streets / blocks / buildings / parks / water appear progressively as you zoom,
 * Google-Maps style, with optional pseudo-3D building extrusion.
 */

const NE_PATH = (DATA as any).districts.find((d: any) => d.name === "North-East")?.path as string;

function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Town = { name: string; x: number; y: number; r: number; rot: number; seed: number; major?: boolean };

const TOWNS: Town[] = [
  { name: "Masunga", x: 806, y: 349, r: 7.5, rot: 18, seed: 11, major: true },
  { name: "Tonota", x: 784.1, y: 408.4, r: 8.5, rot: -12, seed: 22, major: true },
  { name: "Tati Siding", x: 793, y: 396, r: 4.2, rot: 32, seed: 33 },
  { name: "Matsiloje", x: 816, y: 380, r: 3.6, rot: -25, seed: 44 },
  { name: "Mapoka", x: 812, y: 338, r: 3.4, rot: 8, seed: 55 },
  { name: "Ramokgwebana", x: 820, y: 322, r: 4.0, rot: -6, seed: 66 },
  { name: "Sebina", x: 772, y: 362, r: 3.8, rot: 21, seed: 77 },
  { name: "Zwenshambe", x: 788, y: 342, r: 2.8, rot: -18, seed: 88 },
];

interface Building { x: number; y: number; w: number; h: number; ht: number; kind: 0 | 1 | 2 }
interface TownGeo {
  town: Town;
  streets: { x1: number; y1: number; x2: number; y2: number; major: boolean }[];
  blocks: { x: number; y: number; w: number; h: number }[];
  parks: { x: number; y: number; w: number; h: number }[];
  buildings: Building[];
}

function buildTown(t: Town): TownGeo {
  const rnd = mulberry32(t.seed);
  const streets: TownGeo["streets"] = [];
  const blocks: TownGeo["blocks"] = [];
  const parks: TownGeo["parks"] = [];
  const buildings: Building[] = [];

  const span = t.r;
  const cell = span / (t.major ? 5 : 3.2);
  const cols = Math.round((span * 2) / cell);
  const rows = cols;

  for (let i = 0; i <= cols; i++) {
    const x = -span + i * cell;
    streets.push({ x1: x, y1: -span, x2: x + (rnd() - 0.5) * cell * 0.35, y2: span, major: i % 3 === 0 });
  }
  for (let j = 0; j <= rows; j++) {
    const y = -span + j * cell;
    streets.push({ x1: -span, y1: y, x2: span, y2: y + (rnd() - 0.5) * cell * 0.35, major: j % 3 === 0 });
  }

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      const bx = -span + i * cell + cell * 0.09;
      const by = -span + j * cell + cell * 0.09;
      const bw = cell * 0.82;
      const bh = cell * 0.82;
      const distC = Math.hypot(bx + bw / 2, by + bh / 2) / span;
      if (distC > 1.02) continue;
      const roll = rnd();
      if (roll < 0.1) { parks.push({ x: bx, y: by, w: bw, h: bh }); continue; }
      blocks.push({ x: bx, y: by, w: bw, h: bh });

      // buildings inside the block
      const density = distC < 0.35 ? 4 : distC < 0.7 ? 3 : 2;
      for (let a = 0; a < density; a++) {
        for (let b = 0; b < density; b++) {
          if (rnd() < 0.22) continue;
          const pw = bw / density;
          const ph = bh / density;
          const w = pw * (0.5 + rnd() * 0.38);
          const h = ph * (0.5 + rnd() * 0.38);
          const core = distC < 0.3;
          const ht = (core ? 0.28 : distC < 0.65 ? 0.16 : 0.09) * (0.5 + rnd()) * (t.major ? 1 : 0.65);
          buildings.push({
            x: bx + a * pw + (pw - w) / 2,
            y: by + b * ph + (ph - h) / 2,
            w, h, ht,
            kind: core ? 2 : rnd() < 0.3 ? 1 : 0,
          });
        }
      }
    }
  }
  return { town: t, streets, blocks, parks, buildings };
}

const GEO = TOWNS.map(buildTown);

// inter-town highways
const HIGHWAYS: string[] = (() => {
  const rnd = mulberry32(9001);
  const out: string[] = [];
  const links: [number, number][] = [[1, 2], [2, 3], [3, 0], [0, 4], [4, 5], [6, 1], [7, 0], [6, 7], [2, 6]];
  for (const [a, b] of links) {
    const A = TOWNS[a], B = TOWNS[b];
    const mx = (A.x + B.x) / 2 + (rnd() - 0.5) * 8;
    const my = (A.y + B.y) / 2 + (rnd() - 0.5) * 8;
    out.push(`M${A.x} ${A.y} Q${mx} ${my} ${B.x} ${B.y}`);
  }
  return out;
})();

const RIVERS: string[] = [
  "M760 316 C776 336 770 356 786 372 C800 386 796 404 812 418",
  "M837 330 C820 344 818 360 800 372 C786 382 782 396 784 410",
];

interface Props { scale: number; isLight: boolean; threeD: boolean; accent: string }

function NorthEastDetailImpl({ scale, isLight, threeD, accent }: Props) {
  const showRoads = scale >= 4;
  const showTowns = scale >= 10;
  const showBlocks = scale >= 22;
  const showBuildings = scale >= 38;
  const showNames = scale >= 8;

  const C = useMemo(() => (isLight ? {
    land: "#eef2e6", landEdge: "#c9d3bb", water: "#9fc6e8",
    road: "#ffffff", roadEdge: "#d8dcd2", hwy: "#f7c469", hwyEdge: "#d09a2e",
    block: "#e3e7db", park: "#c7e3b4",
    roof: "#e9e6df", wall: "#cbc7bd", wallDark: "#b3aea3", shadow: "#00000022",
    text: "#3d4636",
  } : {
    land: "#131a17", landEdge: "#2b3a33", water: "#14374f",
    road: "#3c4a44", roadEdge: "#222d28", hwy: "#c58f2c", hwyEdge: "#6d4c14",
    block: "#1b2420", park: "#1d3324",
    roof: "#333d38", wall: "#242d29", wallDark: "#1a221e", shadow: "#00000055",
    text: "#c9d6cd",
  }), [isLight]);

  if (!NE_PATH || scale < 3) return null;
  const inv = 1 / scale;

  return (
    <g style={{ pointerEvents: "none" }}>
      <defs>
        <clipPath id="ne-clip"><path d={NE_PATH} /></clipPath>
      </defs>

      <g clipPath="url(#ne-clip)">
        {/* land base */}
        <path d={NE_PATH} fill={C.land} />

        {/* rivers */}
        {RIVERS.map((d, i) => (
          <path key={i} d={d} fill="none" stroke={C.water} strokeWidth={1.1} opacity={0.85} strokeLinecap="round" />
        ))}

        {/* highways */}
        {showRoads && HIGHWAYS.map((d, i) => (
          <g key={i}>
            <path d={d} fill="none" stroke={C.hwyEdge} strokeWidth={0.9} strokeLinecap="round" />
            <path d={d} fill="none" stroke={C.hwy} strokeWidth={0.55} strokeLinecap="round" />
          </g>
        ))}

        {/* towns */}
        {showTowns && GEO.map((g) => (
          <g key={g.town.name} transform={`translate(${g.town.x} ${g.town.y}) rotate(${g.town.rot})`}>
            {/* urban footprint */}
            <circle r={g.town.r * 1.05} fill={C.block} opacity={isLight ? 0.6 : 0.75} />

            {/* streets */}
            {g.streets.map((s, i) => (
              <g key={i}>
                <line x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2} stroke={C.roadEdge} strokeWidth={s.major ? 0.34 : 0.2} strokeLinecap="round" />
                <line x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2} stroke={C.road} strokeWidth={s.major ? 0.24 : 0.12} strokeLinecap="round" />
              </g>
            ))}

            {/* blocks + parks */}
            {showBlocks && (
              <g>
                {g.blocks.map((b, i) => (
                  <rect key={`b${i}`} x={b.x} y={b.y} width={b.w} height={b.h} rx={0.06} fill={C.block} opacity={0.9} />
                ))}
                {g.parks.map((p, i) => (
                  <rect key={`p${i}`} x={p.x} y={p.y} width={p.w} height={p.h} rx={0.12} fill={C.park} opacity={0.95} />
                ))}
              </g>
            )}

            {/* buildings */}
            {showBuildings && (
              <g>
                {g.buildings.map((b, i) => {
                  const ox = threeD ? -b.ht * 0.55 : 0;
                  const oy = threeD ? -b.ht : 0;
                  if (!threeD) {
                    return <rect key={i} x={b.x} y={b.y} width={b.w} height={b.h} fill={C.roof} stroke={C.wallDark} strokeWidth={0.012} />;
                  }
                  const x0 = b.x, y0 = b.y, x1 = b.x + b.w, y1 = b.y + b.h;
                  return (
                    <g key={i}>
                      {/* footprint shadow */}
                      <rect x={x0} y={y0} width={b.w} height={b.h} fill={C.shadow} />
                      {/* left wall */}
                      <polygon
                        points={`${x0},${y0} ${x0 + ox},${y0 + oy} ${x0 + ox},${y1 + oy} ${x0},${y1}`}
                        fill={C.wallDark}
                      />
                      {/* bottom wall */}
                      <polygon
                        points={`${x0},${y1} ${x0 + ox},${y1 + oy} ${x1 + ox},${y1 + oy} ${x1},${y1}`}
                        fill={C.wall}
                      />
                      {/* roof */}
                      <rect
                        x={x0 + ox} y={y0 + oy} width={b.w} height={b.h}
                        fill={b.kind === 2 ? C.roof : b.kind === 1 ? C.wall : C.roof}
                        stroke={C.wallDark} strokeWidth={0.01}
                      />
                    </g>
                  );
                })}
              </g>
            )}
          </g>
        ))}

        {/* town labels */}
        {showNames && GEO.map((g) => (
          <text
            key={`t-${g.town.name}`}
            x={g.town.x}
            y={g.town.y - g.town.r - 3 * inv}
            textAnchor="middle"
            fontSize={Math.max(2.2, 11 * inv)}
            fontWeight={700}
            fill={C.text}
            stroke={isLight ? "#ffffff" : "#000000"}
            strokeWidth={Math.max(2.2, 11 * inv) * 0.22}
            paintOrder="stroke"
            style={{ letterSpacing: "0.04em" }}
          >
            {g.town.name}
          </text>
        ))}
      </g>

      {/* district outline accent */}
      <path d={NE_PATH} fill="none" stroke={accent} strokeWidth={1.2 * inv} opacity={0.6} />
    </g>
  );
}

export const NorthEastDetail = memo(
  NorthEastDetailImpl,
  (a, b) =>
    a.isLight === b.isLight &&
    a.threeD === b.threeD &&
    a.accent === b.accent &&
    Math.abs(a.scale - b.scale) < 0.5 &&
    lodBucket(a.scale) === lodBucket(b.scale),
);

function lodBucket(s: number) {
  return [3, 4, 8, 10, 22, 38].filter((t) => s >= t).length;
}

export const NE_CENTER = { x: 800, y: 365 };
