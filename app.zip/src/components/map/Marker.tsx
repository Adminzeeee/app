import { memo } from "react";
import type { Place, PlaceType } from "./types";
import type { ThemeSpec } from "./themes";

interface Props {
  place: Place;
  scale: number;
  selected: boolean;
  theme: ThemeSpec;
  onSelect: (p: Place) => void;
}

const SIZE: Record<PlaceType, number> = {
  capital: 8, city: 6.5, town: 5, village: 3.8, park: 5.5, landmark: 5.5,
};

const SHAPES: Record<PlaceType, "star" | "dot" | "diamond" | "leaf"> = {
  capital: "star", city: "dot", town: "dot", village: "dot", park: "leaf", landmark: "diamond",
};

function MarkerImpl({ place, scale, selected, theme, onSelect }: Props) {
  const invS = 1 / scale;
  const r = SIZE[place.type] * invS;
  const color = theme.markerCore[place.type] ?? theme.markerCore.city;
  const shape = SHAPES[place.type];

  return (
    <g
      transform={`translate(${place.x} ${place.y})`}
      style={{ cursor: "pointer" }}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => { e.stopPropagation(); onSelect(place); }}
    >
      {/* core shape */}
      {shape === "dot" && (
        <>
          <circle r={r * 1.6} fill={color} opacity={0.18} />
          <circle r={r} fill={color} />
          <circle r={r * 0.4} fill="#fff" opacity={0.9} />
        </>
      )}
      {shape === "star" && (
        <>
          <circle r={r * 2.2} fill={color} opacity={0.22} />
          <StarPath r={r * 1.6} fill={color} />
        </>
      )}
      {shape === "diamond" && (
        <>
          <circle r={r * 1.6} fill={color} opacity={0.18} />
          <DiamondPath r={r * 1.2} fill={color} />
        </>
      )}
      {shape === "leaf" && (
        <>
          <circle r={r * 1.6} fill={color} opacity={0.18} />
          <LeafPath r={r * 1.3} fill={color} />
        </>
      )}

      {selected && (
        <circle
          r={r * 2.8}
          fill="none"
          stroke={color}
          strokeWidth={1.4 * invS}
        />
      )}
      {/* hitbox */}
      <circle r={Math.max(r * 3, 12 * invS)} fill="transparent" />
    </g>
  );
}

export const Marker = memo(MarkerImpl, (a, b) =>
  a.selected === b.selected &&
  a.theme === b.theme &&
  a.place === b.place &&
  Math.abs(a.scale - b.scale) < 0.02
);

function StarPath({ r, fill }: { r: number; fill: string }) {
  const pts: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = (Math.PI / 5) * i - Math.PI / 2;
    const rr = i % 2 === 0 ? r : r * 0.45;
    pts.push(`${Math.cos(a) * rr},${Math.sin(a) * rr}`);
  }
  return <polygon points={pts.join(" ")} fill={fill} />;
}
function DiamondPath({ r, fill }: { r: number; fill: string }) {
  return <polygon points={`0,${-r} ${r},0 0,${r} ${-r},0`} fill={fill} />;
}
function LeafPath({ r, fill }: { r: number; fill: string }) {
  return <path d={`M0,${-r} C${r},${-r} ${r},${r} 0,${r} C${-r},${r} ${-r},${-r} 0,${-r} Z`} fill={fill} />;
}
