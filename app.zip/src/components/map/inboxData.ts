/** Rich dummy data model + seed content for the Messages / Alert Center. */

export type SenderKind = "person" | "app" | "survey";
export type Category = "survey" | "group" | "app" | "person";

export interface Sender {
  id: string;
  name: string;
  kind: SenderKind;
  role?: string;
  avatar?: string;
  verified?: boolean;
}

export interface ThreadMessage {
  id: string;
  senderId: string;
  text: string;
  at: number;
  system?: boolean;
}

export interface PollOption {
  id: string;
  label: string;
  votes: number;
}

export interface Poll {
  question: string;
  options: PollOption[];
  closesAt: number;
  myVote?: string;
}

export interface ChecklistItem {
  id: string;
  label: string;
  done: boolean;
  assignee?: string;
}

export interface RoleAssignment {
  userId: string;
  name: string;
  label: string;
  avatar?: string;
}

export interface ContributionPool {
  target: number;
  raised: number;
  currency: string;
  contributors: number;
  deadline: number;
}

export interface ThreadMeta {
  roles?: RoleAssignment[];
  tasks?: ChecklistItem[];
  pool?: ContributionPool;
  poll?: Poll;
  deadline?: number;
  memberCount?: number;
  memberAvatars?: string[];
  sourceSurvey?: string;
  matchScore?: number;
}

export type ThreadKind =
  | "dm"
  | "group-pool"
  | "crowdfund"
  | "employment"
  | "partnership"
  | "announcement"
  | "survey-nudge"
  | "system";

export interface Thread {
  id: string;
  category: Category;
  kind: ThreadKind;
  title: string;
  subtitle?: string;
  participants: Sender[];
  messages: ThreadMessage[];
  unread: number;
  pinned?: boolean;
  archived?: boolean;
  muted?: boolean;
  updatedAt: number;
  meta?: ThreadMeta;
}

export interface NotificationPrefs {
  categories: Record<Category, boolean>;
  quietHours: { enabled: boolean; from: string; to: string };
  autoJoinGroups: boolean;
  digest: "off" | "daily" | "weekly";
}

export const DEFAULT_PREFS: NotificationPrefs = {
  categories: { survey: true, group: true, app: true, person: true },
  quietHours: { enabled: true, from: "22:00", to: "06:30" },
  autoJoinGroups: false,
  digest: "daily",
};

const FIRST = ["Naledi", "Tebogo", "Amogelang", "Boitumelo", "Kagiso", "Lesego", "Thato", "Onalenna", "Katlego", "Refilwe", "Bontle", "Tumelo", "Neo", "Kabelo", "Lorato", "Gaone", "Otsile", "Masego", "Tshepo", "Keitumetse", "Mpho", "Ofentse", "Wame", "Reneilwe", "Karabo", "Baitshepi", "Goitseone", "Tirelo", "Oratile", "Segametsi"];
const LAST = ["Moeti", "Rapula", "Kgosi", "Seretse", "Modise", "Mmusi", "Ntsima", "Dikgang", "Setlhare", "Ramaphane", "Kegakilwe", "Molosiwa", "Phiri", "Tau", "Mokgosi", "Kealotswe", "Pitso", "Sebina", "Motlhagodi", "Gaborone"];
const ROLES_POOL = ["GIS analyst", "Field agent", "Farmer", "Teacher", "Driver", "Student", "Nurse", "Trader", "Mechanic", "Herder", "Shopkeeper", "Solar technician", "Water engineer", "Youth organiser"];
const DISTRICTS = ["Gaborone", "Maun", "Francistown", "Ghanzi", "Kasane", "Serowe", "Kanye", "Mahalapye", "Palapye", "Lobatse"];

function seededRand(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function avatarFor(seed: string) {
  return `https://i.pravatar.cc/160?u=${encodeURIComponent(seed)}`;
}

export function generateMembers(count: number, seed = 42): Sender[] {
  const rnd = seededRand(seed);
  const out: Sender[] = [];
  for (let i = 0; i < count; i++) {
    const first = FIRST[Math.floor(rnd() * FIRST.length)];
    const last = LAST[Math.floor(rnd() * LAST.length)];
    const role = ROLES_POOL[Math.floor(rnd() * ROLES_POOL.length)];
    const district = DISTRICTS[Math.floor(rnd() * DISTRICTS.length)];
    const id = `m${i}-${first}${last}`;
    out.push({
      id,
      name: `${first} ${last}`,
      kind: "person",
      role: `${role} · ${district}`,
      avatar: avatarFor(id),
    });
  }
  return out;
}

export const APP_SENDER: Sender = { id: "app", name: "Botswana Insights", kind: "app", role: "Product team", verified: true };
export const SURVEY_SENDER: Sender = { id: "survey-engine", name: "Survey Engine", kind: "survey", role: "Automated insights" };

const GROUP_BUY_MEMBERS = generateMembers(103, 7);
const now = Date.now();

const groupBuyRoles: RoleAssignment[] = [
  { userId: GROUP_BUY_MEMBERS[0].id, name: GROUP_BUY_MEMBERS[0].name, label: "Organiser", avatar: GROUP_BUY_MEMBERS[0].avatar },
  { userId: GROUP_BUY_MEMBERS[1].id, name: GROUP_BUY_MEMBERS[1].name, label: "Logistics", avatar: GROUP_BUY_MEMBERS[1].avatar },
  { userId: GROUP_BUY_MEMBERS[2].id, name: GROUP_BUY_MEMBERS[2].name, label: "Treasurer", avatar: GROUP_BUY_MEMBERS[2].avatar },
  { userId: GROUP_BUY_MEMBERS[3].id, name: GROUP_BUY_MEMBERS[3].name, label: "Supplier liaison", avatar: GROUP_BUY_MEMBERS[3].avatar },
];

export const THREADS: Thread[] = [
  {
    id: "t-groupbuy-solar",
    category: "group",
    kind: "group-pool",
    title: "Solar Borehole Pump — Group Buy",
    subtitle: "Auto-created from your survey answer",
    participants: [SURVEY_SENDER, ...GROUP_BUY_MEMBERS],
    unread: 6,
    pinned: true,
    updatedAt: now - 4 * 60e3,
    meta: {
      sourceSurvey: "Kgalagadi Water Reliability — Wave 14",
      memberCount: GROUP_BUY_MEMBERS.length,
      memberAvatars: GROUP_BUY_MEMBERS.slice(0, 8).map((m) => m.avatar!),
      roles: groupBuyRoles,
      deadline: now + 6 * 86400e3,
      pool: { target: 185000, raised: 132400, currency: "BWP", contributors: 97, deadline: now + 6 * 86400e3 },
      tasks: [
        { id: "tk1", label: "Confirm supplier quote (SolarFlow BW)", done: true, assignee: groupBuyRoles[3].name },
        { id: "tk2", label: "Lock delivery route to Tsabong", done: true, assignee: groupBuyRoles[1].name },
        { id: "tk3", label: "Collect final headcount per village", done: false, assignee: groupBuyRoles[0].name },
        { id: "tk4", label: "Open escrow pool for contributions", done: false, assignee: groupBuyRoles[2].name },
        { id: "tk5", label: "Schedule installation crews", done: false },
      ],
      poll: {
        question: "Which pump supplier should we lock in?",
        closesAt: now + 2 * 86400e3,
        myVote: "opt2",
        options: [
          { id: "opt1", label: "SolarFlow BW — 185,000 BWP total", votes: 61 },
          { id: "opt2", label: "Kalahari Pump Co. — 171,000 BWP total", votes: 34 },
          { id: "opt3", label: "Need more info", votes: 8 },
        ],
      },
    },
    messages: [
      { id: "m1", senderId: "survey-engine", system: true, at: now - 6 * 86400e3, text: "You said you'd be Interested in a solar borehole pump group buy — we matched you with 102 other households in Kgalagadi. This thread was created automatically." },
      { id: "m2", senderId: groupBuyRoles[0].userId, at: now - 5 * 86400e3, text: "Welcome everyone! I'll be coordinating this. Let's settle the supplier by Thursday." },
      { id: "m3", senderId: groupBuyRoles[3].userId, at: now - 3 * 86400e3, text: "Got two quotes in — posted a poll above, vote by Friday please." },
      { id: "m4", senderId: GROUP_BUY_MEMBERS[9].id, at: now - 2 * 86400e3, text: "Voted. Kalahari Pump Co. also services Tshabong so easier for maintenance." },
      { id: "m5", senderId: groupBuyRoles[2].userId, at: now - 30 * 60e3, text: "Pool is at 132,400 / 185,000 BWP — 6 days left. Please send contributions before the deadline." },
      { id: "m6", senderId: GROUP_BUY_MEMBERS[41].id, at: now - 4 * 60e3, text: "Just contributed my share 🙌" },
    ],
  },
  {
    id: "t-crowdfund-school",
    category: "group",
    kind: "crowdfund",
    title: "Tsholofelo Primary Solar Crowdfund",
    subtitle: "Auto-created · Education infrastructure survey",
    participants: [SURVEY_SENDER, ...generateMembers(46, 11)],
    unread: 1,
    updatedAt: now - 2 * 3600e3,
    meta: {
      sourceSurvey: "School Infrastructure Gaps — Wave 9",
      memberCount: 47,
      memberAvatars: generateMembers(6, 11).map((m) => m.avatar!),
      pool: { target: 62000, raised: 40850, currency: "BWP", contributors: 46, deadline: now + 11 * 86400e3 },
      deadline: now + 11 * 86400e3,
      tasks: [
        { id: "c1", label: "Get school board sign-off", done: true },
        { id: "c2", label: "Publish itemised budget", done: true },
        { id: "c3", label: "Reach 75% funding", done: false },
      ],
    },
    messages: [
      { id: "cm1", senderId: "survey-engine", system: true, at: now - 9 * 86400e3, text: "Because you flagged 'unreliable electricity' for this school in the infrastructure survey, you've been added to the funding circle." },
      { id: "cm2", senderId: generateMembers(1, 11)[0].id, at: now - 2 * 3600e3, text: "40,850 raised so far — thank you all! Sharing progress photos this weekend." },
    ],
  },
  {
    id: "t-employment-drone",
    category: "survey",
    kind: "employment",
    title: "Job match: Drone Survey Technician — Maun",
    subtitle: "Automated from your skills survey",
    participants: [SURVEY_SENDER],
    unread: 1,
    updatedAt: now - 5 * 3600e3,
    meta: {
      sourceSurvey: "Youth Skills & Employment — Wave 6",
      matchScore: 92,
      tasks: [
        { id: "j1", label: "Review employer profile", done: false },
        { id: "j2", label: "Confirm availability", done: false },
        { id: "j3", label: "Send intro message", done: false },
      ],
    },
    messages: [
      { id: "jm1", senderId: "survey-engine", system: true, at: now - 5 * 3600e3, text: "Based on your survey answers (drone certification, GIS experience), you're a 92% match for a Drone Survey Technician role with a Maun mapping outfit. Reply to express interest and we'll introduce you." },
    ],
  },
  {
    id: "t-partnership-agro",
    category: "survey",
    kind: "partnership",
    title: "Partnership match: Agro-processing co-op",
    subtitle: "Automated from your business interests survey",
    participants: [SURVEY_SENDER],
    unread: 0,
    updatedAt: now - 26 * 3600e3,
    meta: {
      sourceSurvey: "Rural Enterprise & Trade — Wave 3",
      matchScore: 78,
    },
    messages: [
      { id: "pm1", senderId: "survey-engine", system: true, at: now - 26 * 3600e3, text: "You and 3 other respondents in Serowe both want to start sorghum processing. We've grouped you into a potential co-op — want an introduction thread?" },
      { id: "pm2", senderId: "survey-engine", system: true, at: now - 25 * 3600e3, text: "Reply 'yes' any time and we'll open the group automatically." },
    ],
  },
  {
    id: "t-survey-nudge-1",
    category: "survey",
    kind: "survey-nudge",
    title: "Your household survey answers may be outdated",
    subtitle: "Survey Engine",
    participants: [SURVEY_SENDER],
    unread: 1,
    updatedAt: now - 40 * 60e3,
    messages: [
      { id: "sn1", senderId: "survey-engine", system: true, at: now - 40 * 60e3, text: "It's been 14 days since your last update in the South-East household wave. Water access or income answers changed? Update takes under a minute." },
    ],
  },
  {
    id: "t-survey-nudge-2",
    category: "survey",
    kind: "survey-nudge",
    title: "New follow-up questions ready",
    subtitle: "Survey Engine",
    participants: [SURVEY_SENDER],
    unread: 0,
    muted: true,
    updatedAt: now - 3 * 86400e3,
    messages: [
      { id: "sn2", senderId: "survey-engine", system: true, at: now - 3 * 86400e3, text: "Following your 'Interested' tap on the solar group buy, we have 3 quick follow-up questions to help size the order." },
    ],
  },
  {
    id: "t-app-announce-1",
    category: "app",
    kind: "announcement",
    title: "Directory 2.0 is live",
    subtitle: "Botswana Insights",
    participants: [APP_SENDER],
    unread: 1,
    updatedAt: now - 3 * 3600e3,
    messages: [
      { id: "an1", senderId: "app", system: true, at: now - 3 * 3600e3, text: "You can now filter the Directory by verified skill and district. Try it from the map toolbar — new drone mappers just joined in Ghanzi." },
    ],
  },
  {
    id: "t-app-announce-2",
    category: "app",
    kind: "announcement",
    title: "Scheduled maintenance — Sunday 02:00",
    subtitle: "Botswana Insights",
    participants: [APP_SENDER],
    unread: 0,
    updatedAt: now - 2 * 86400e3,
    messages: [
      { id: "an2", senderId: "app", system: true, at: now - 2 * 86400e3, text: "We're upgrading the sensor mesh pipeline Sunday 02:00–02:40 CAT. Live broadcasts may briefly pause." },
    ],
  },
  {
    id: "t-app-announce-3",
    category: "app",
    kind: "announcement",
    title: "Welcome to Kgosi Insights",
    subtitle: "Botswana Insights",
    participants: [APP_SENDER],
    unread: 0,
    archived: true,
    updatedAt: now - 20 * 86400e3,
    messages: [
      { id: "an3", senderId: "app", system: true, at: now - 20 * 86400e3, text: "Thanks for joining. Answer surveys to unlock group buys, funding pools and job matches tailored to your district." },
    ],
  },
  {
    id: "t-dm-naledi",
    category: "person",
    kind: "dm",
    title: "Naledi Moeti",
    subtitle: "GIS analyst · Gaborone",
    participants: [{ id: "f1", name: "Naledi Moeti", kind: "person", role: "GIS analyst · Gaborone", avatar: avatarFor("f1") }],
    unread: 2,
    updatedAt: now - 6e5,
    messages: [
      { id: "d1", senderId: "f1", at: now - 6e5, text: "Shared the new district shapefile." },
      { id: "d2", senderId: "f1", at: now - 5.6e5, text: "Boundaries for Kweneng shifted slightly — worth a re-render." },
    ],
  },
  {
    id: "t-dm-tebogo",
    category: "person",
    kind: "dm",
    title: "Tebogo Rapula",
    subtitle: "Drone mapper · Maun",
    participants: [{ id: "f2", name: "Tebogo Rapula", kind: "person", role: "Drone mapper · Maun", avatar: avatarFor("f2") }],
    unread: 0,
    updatedAt: now - 36e5,
    messages: [{ id: "d3", senderId: "f2", at: now - 36e5, text: "LiDAR pass over Chobe is done." }],
  },
  {
    id: "t-dm-amo",
    category: "person",
    kind: "dm",
    title: "Amogelang K.",
    subtitle: "Field lead · Ghanzi",
    participants: [{ id: "f3", name: "Amogelang K.", kind: "person", role: "Field lead · Ghanzi", avatar: avatarFor("f3") }],
    unread: 1,
    updatedAt: now - 144e5,
    messages: [{ id: "d4", senderId: "f3", at: now - 144e5, text: "Survey wave 14 uploaded." }],
  },
  {
    id: "t-dm-boi",
    category: "person",
    kind: "dm",
    title: "Boitumelo S.",
    subtitle: "Economist · Francistown",
    participants: [{ id: "f4", name: "Boitumelo S.", kind: "person", role: "Economist · Francistown", avatar: avatarFor("f4") }],
    unread: 0,
    muted: true,
    updatedAt: now - 864e5,
    messages: [{ id: "d5", senderId: "f4", at: now - 864e5, text: "GDP revision looks solid." }],
  },
];

export function allSenders(threads: Thread[]): Record<string, Sender> {
  const out: Record<string, Sender> = { app: APP_SENDER, "survey-engine": SURVEY_SENDER };
  threads.forEach((t) => t.participants.forEach((p) => { out[p.id] = p; }));
  return out;
}

export const DM_REPLIES = [
  "Got it — pushing the update now.",
  "Nice. I'll fold that into the next survey wave.",
  "Can you drop the coordinates? I'll re-run the pass.",
  "Agreed. Let's review it on the call tomorrow.",
  "Uploaded to the shared bucket, check the /raw folder.",
];
