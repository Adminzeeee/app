import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { X } from "lucide-react";
import { alpha } from "./color";
import { THREADS } from "./inboxData";
import { InboxApp } from "./inbox/InboxApp";

/** Brand mark for the copilot — layered delta/compass glyph. */
export function KgosiMark({ size = 20, color = "#0ea5e9", solid = false }: { size?: number; color?: string; solid?: boolean }) {
  const id = `kg${Math.round(size)}${solid ? "s" : "o"}`;
  const base = solid ? "#0b1020" : color;
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <defs>
        <linearGradient id={id} x1="6" y1="3" x2="26" y2="29" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={base} />
          <stop offset="1" stopColor={base} stopOpacity={solid ? 1 : 0.55} />
        </linearGradient>
      </defs>
      <path d="M16 2.4 5.6 7.1v8.3c0 6.4 4.3 11.4 10.4 14.2 6.1-2.8 10.4-7.8 10.4-14.2V7.1L16 2.4Z" fill={`url(#${id})`} opacity={solid ? 1 : 0.14} />
      <path d="M16 2.4 5.6 7.1v8.3c0 6.4 4.3 11.4 10.4 14.2 6.1-2.8 10.4-7.8 10.4-14.2V7.1L16 2.4Z" stroke={`url(#${id})`} strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M10.4 18.2 9.1 10.6l4 3.1L16 8.9l2.9 4.8 4-3.1-1.3 7.6h-11.2Z" fill={solid ? color : `url(#${id})`} />
      <rect x="10.4" y="19.6" width="11.2" height="1.9" rx="0.95" fill={solid ? color : `url(#${id})`} />
      <circle cx="16" cy="6.2" r="1.5" fill={solid ? color : `url(#${id})`} />
    </svg>
  );
}

/** Floating trigger + panel wrapping the Messages / Alert Center. */
export function Copilot({ isLight, glow }: { isLight: boolean; glow: string }) {
  const [open, setOpen] = useState(false);
  const draggedRef = { current: false } as { current: boolean };

  const panel = isLight ? "border-slate-900/10 bg-white/90 text-slate-900" : "border-white/12 bg-[#080b16]/90 text-white";
  const unread = THREADS.reduce((s, t) => s + (t.archived || t.muted ? 0 : t.unread), 0);

  return (
    <motion.div
      drag
      dragMomentum={false}
      dragElastic={0.05}
      onDragStart={() => { draggedRef.current = true; }}
      onDragEnd={() => { window.setTimeout(() => { draggedRef.current = false; }, 60); }}
      className="fixed bottom-5 right-4 z-[60] flex flex-col items-end gap-2"
      style={{ touchAction: "none" }}
    >
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
            className={`flex h-[min(58vh,420px)] min-h-[260px] w-[min(86vw,312px)] flex-col overflow-hidden rounded-2xl border backdrop-blur-2xl ${panel}`}
            style={{ boxShadow: `0 18px 44px -18px rgba(0,0,0,0.55), 0 0 0 1px ${alpha(glow, 0.14)}, inset 0 1px 0 ${alpha("#ffffff", isLight ? 0.4 : 0.06)}`, maxWidth: "86vw", maxHeight: "74vh" }}
            onPointerDown={(e) => e.stopPropagation()}
          >
            <div className={`flex items-center gap-1.5 border-b px-2.5 py-1.5 ${isLight ? "border-slate-900/[0.06]" : "border-white/[0.07]"}`}>
              <span className="grid h-5 w-5 place-items-center rounded-full" style={{ background: alpha(glow, 0.16), boxShadow: `0 0 10px ${alpha(glow, 0.35)}` }}>
                <KgosiMark size={12} color={glow} />
              </span>
              <span className="text-[11px] font-bold tracking-tight" style={{ fontFamily: "'Sora',sans-serif" }}>Messages</span>
              <button aria-label="Close" onClick={() => setOpen(false)} className={`ml-auto grid h-5 w-5 place-items-center rounded-lg ${isLight ? "bg-slate-900/[0.05]" : "bg-white/[0.06]"}`}>
                <X className="h-3 w-3" />
              </button>
            </div>
            <InboxApp isLight={isLight} glow={glow} />
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => { if (!draggedRef.current) setOpen((v) => !v); }}
        className="relative grid h-12 w-12 place-items-center rounded-full border backdrop-blur-2xl"
        style={{
          background: `radial-gradient(circle at 32% 28%, ${glow}, ${alpha(glow, 0.33)} 60%, transparent 100%)`,
          borderColor: alpha(glow, 0.4),
          boxShadow: `0 10px 30px -8px ${glow}, 0 0 0 6px ${alpha(glow, 0.07)}`,
          cursor: "grab",
        }}
        aria-label="Open messages"
      >
        <motion.span animate={{ scale: [1, 1.12, 1] }} transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }} className="grid place-items-center">
          <KgosiMark size={22} color="#0b1020" solid />
        </motion.span>
        {!open && unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white shadow">
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </motion.button>
    </motion.div>
  );
}
