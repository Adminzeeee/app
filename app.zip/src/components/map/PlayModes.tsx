import type { ThemeSpec } from "./themes";
import { PlayLayer2 } from "./PlayModes2";
import { PlayLayer3 } from "./PlayModes3";
import { PlayLayer4 } from "./PlayModes4";
import { PlayLayer5 } from "./PlayModes5";

export type PlayMode = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;

export const PLAY_MODES: { id: PlayMode; name: string; blurb: string; layout: "map" | "map-left" | "full" | "map-focus" }[] = [
  { id: 1, name: "Drift tour", blurb: "Breathing camera across the country", layout: "map" },
  { id: 2, name: "Broadcast Live", blurb: "News-style lower third, live per place", layout: "map-focus" },
  { id: 3, name: "Metric Dossier", blurb: "Docked briefing card + table, per place", layout: "map-focus" },
  { id: 4, name: "Field Journal", blurb: "Editorial dispatch, docked right", layout: "map-left" },
  { id: 5, name: "Insight Terminal", blurb: "Charts & table dashboard, snap-zoom camera", layout: "map-focus" },
  { id: 6, name: "Situation Room", blurb: "Command deck: live status rail + incident ticker", layout: "map-focus" },
  { id: 7, name: "Signal Scope", blurb: "Radar sweep over live signal clusters", layout: "map" },
  { id: 8, name: "Investor Brief", blurb: "Boardroom slide: thesis, numbers, upside", layout: "map-left" },
  { id: 9, name: "Pulse Grid", blurb: "Small-multiples grid of every district pulse", layout: "full" },
  { id: 10, name: "Depth Atlas", blurb: "Cartographic layer with annotated place cards", layout: "map" },
];

export function PlayLayer({
  mode, theme, isLight, active,
}: { mode: PlayMode; theme: ThemeSpec; isLight: boolean; active: boolean }) {
  if (!active || mode === 1) return null;
  return (
    <div className="pointer-events-none absolute inset-0 z-[12] overflow-hidden">
      {(mode === 2 || mode === 3) && <PlayLayer2 mode={mode} theme={theme} isLight={isLight} />}
      {mode === 4 && <PlayLayer3 mode={mode} theme={theme} isLight={isLight} />}
      {mode === 5 && <PlayLayer4 mode={mode} theme={theme} isLight={isLight} />}
      {mode >= 6 && <PlayLayer5 mode={mode} theme={theme} isLight={isLight} />}
    </div>
  );
}

