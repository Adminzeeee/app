import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useRef, useState } from "react";
import {
  CalendarDays, ChevronLeft, ChevronRight, Heart, MapPin, MessageCircle,
  Plus, Send, Sparkles, Users, X,
} from "lucide-react";
import { alpha } from "./color";
import { CATEGORIES, CATEGORY_COLORS, EVENTS, TODAY, type CalendarEvent, type EventCategory } from "./eventsData";

const WEEKDAYS = ["S", "M", "T", "W", "T", "F", "S"];

function ymd(dt: Date) {
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}
function isHappeningNow(ev: CalendarEvent) {
  if (ev.date !== ymd(new Date())) return false;
  const now = new Date();
  const [sh, sm] = ev.time.split(":").map(Number);
  const start = sh * 60 + sm;
  const cur = now.getHours() * 60 + now.getMinutes();
  const end = ev.endTime ? (() => { const [eh, em] = ev.endTime!.split(":").map(Number); return eh * 60 + em; })() : start + 120;
  return cur >= start && cur <= end;
}

export function EventsFloaty({ isLight, glow }: { isLight: boolean; glow: string }) {
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(new Date(TODAY.getFullYear(), TODAY.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState(ymd(new Date()));
  const [filter, setFilter] = useState<EventCategory | "All">("All");
  const [events, setEvents] = useState<CalendarEvent[]>(EVENTS);
  const [detail, setDetail] = useState<CalendarEvent | null>(null);
  const [composing, setComposing] = useState(false);
  const [draftText, setDraftText] = useState("");
  const [draftTitle, setDraftTitle] = useState("");
  const dragged = useRef(false);

  const panel = isLight
    ? "border-slate-900/10 bg-white/85 text-slate-900"
    : "border-white/12 bg-[#070c17]/85 text-white";
  const soft = isLight ? "bg-slate-900/[0.06]" : "bg-white/[0.08]";
  const muted = isLight ? "text-slate-500" : "text-white/50";
  const accent = glow;

  const happeningNow = useMemo(() => events.filter(isHappeningNow), [events]);

  const filtered = useMemo(
    () => events.filter((e) => filter === "All" || e.category === filter),
    [events, filter],
  );

  const monthDays = useMemo(() => {
    const year = cursor.getFullYear(), month = cursor.getMonth();
    const first = new Date(year, month, 1);
    const startOffset = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: (Date | null)[] = Array.from({ length: startOffset }, () => null);
    for (let i = 1; i <= daysInMonth; i++) cells.push(new Date(year, month, i));
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [cursor]);

  const eventsByDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const e of filtered) {
      if (!map.has(e.date)) map.set(e.date, []);
      map.get(e.date)!.push(e);
    }
    return map;
  }, [filtered]);

  const dayEvents = eventsByDay.get(selectedDate) ?? [];

  const toggleGoing = (id: string) => {
    setEvents((prev) => prev.map((e) => (e.id === id ? { ...e, going: e.going + 1, attendees: [...e.attendees, { name: "You", color: accent }] } : e)));
  };

  const addComment = (id: string, text: string) => {
    if (!text.trim()) return;
    setEvents((prev) => prev.map((e) => (e.id === id
      ? { ...e, comments: [...e.comments, { id: `n${Date.now()}`, user: "You", avatarColor: accent, text, when: "now" }] }
      : e)));
  };

  const submitDraft = () => {
    if (!draftTitle.trim()) return;
    const ev: CalendarEvent = {
      id: `u${Date.now()}`, title: draftTitle, category: "Civic", date: selectedDate, time: "12:00",
      location: "Community submission", blurb: draftText || "New community event.", color: CATEGORY_COLORS.Civic,
      going: 1, attendees: [{ name: "You", color: accent }], reactions: [], comments: [], createdBy: "You",
    };
    setEvents((prev) => [ev, ...prev]);
    setDraftTitle(""); setDraftText(""); setComposing(false);
  };

  return (
    <motion.div
      drag dragMomentum={false} dragElastic={0.05}
      onDragStart={() => { dragged.current = true; }}
      onDragEnd={() => { window.setTimeout(() => { dragged.current = false; }, 60); }}
      className="fixed bottom-5 left-4 z-[60] flex flex-col items-start gap-2"
      style={{ touchAction: "none" }}
    >
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
            onPointerDown={(e) => e.stopPropagation()}
            className={`flex h-[min(68vh,520px)] w-[min(92vw,344px)] flex-col overflow-hidden rounded-2xl border backdrop-blur-2xl ${panel}`}
            style={{ boxShadow: `0 24px 60px -20px rgba(0,0,0,0.6), 0 0 0 1px ${alpha(accent, 0.16)}` }}
          >
            {/* header */}
            <div className="flex items-center gap-1.5 border-b border-current/10 px-2.5 py-1.5">
              <span className="grid h-5 w-5 place-items-center rounded-full" style={{ background: alpha(accent, 0.18) }}>
                <CalendarDays className="h-3 w-3" style={{ color: accent }} />
              </span>
              <span className="text-[11.5px] font-bold" style={{ fontFamily: "'Sora',sans-serif" }}>Community Events</span>
              {happeningNow.length > 0 && (
                <span className="ml-1 flex items-center gap-1 rounded-full px-1.5 py-[1px] text-[7px] font-black uppercase" style={{ background: alpha("#ef4444", 0.2), color: "#ef4444" }}>
                  <motion.span animate={{ opacity: [1, 0.2, 1] }} transition={{ duration: 1.4, repeat: Infinity }} className="h-1 w-1 rounded-full bg-red-500" />
                  live now
                </span>
              )}
              <button aria-label="Close events" onClick={() => setOpen(false)} className={`ml-auto grid h-5 w-5 place-items-center rounded-md ${soft}`}>
                <X className="h-3 w-3" />
              </button>
            </div>

            {/* calendar header */}
            <div className="flex items-center gap-1 px-2.5 pt-1.5">
              <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} className={`grid h-5 w-5 place-items-center rounded-md ${soft}`}>
                <ChevronLeft className="h-3 w-3" />
              </button>
              <span className="flex-1 text-center text-[10px] font-bold">
                {cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" })}
              </span>
              <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} className={`grid h-5 w-5 place-items-center rounded-md ${soft}`}>
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            {/* grid */}
            <div className="px-2.5 pt-1">
              <div className="grid grid-cols-7 gap-[2px]">
                {WEEKDAYS.map((w, i) => (
                  <div key={i} className={`text-center text-[7px] font-black uppercase ${muted}`}>{w}</div>
                ))}
                {monthDays.map((day, i) => {
                  if (!day) return <div key={i} />;
                  const key = ymd(day);
                  const dEvents = eventsByDay.get(key) ?? [];
                  const isSelected = key === selectedDate;
                  const isToday = key === ymd(new Date());
                  return (
                    <button key={i} onClick={() => setSelectedDate(key)}
                      className="relative flex aspect-square flex-col items-center justify-center rounded-md text-[9px] font-bold"
                      style={isSelected ? { background: accent, color: "#04121f" } : isToday ? { border: `1px solid ${alpha(accent, 0.6)}` } : undefined}>
                      {day.getDate()}
                      {dEvents.length > 0 && (
                        <span className="absolute bottom-[2px] flex gap-[1.5px]">
                          {dEvents.slice(0, 3).map((e, idx) => (
                            <span key={idx} className="h-[3px] w-[3px] rounded-full" style={{ background: isSelected ? "#04121f" : e.color }} />
                          ))}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* filters */}
            <div className="mt-1.5 flex flex-wrap gap-1 px-2.5">
              <button onClick={() => setFilter("All")}
                className={`rounded-full px-1.5 py-[2px] text-[8px] font-bold ${filter === "All" ? "" : `${soft} ${muted}`}`}
                style={filter === "All" ? { background: alpha(accent, 0.9), color: "#04121f" } : undefined}>All</button>
              {CATEGORIES.map((c) => (
                <button key={c} onClick={() => setFilter(c)}
                  className={`rounded-full px-1.5 py-[2px] text-[8px] font-bold ${filter === c ? "" : `${soft} ${muted}`}`}
                  style={filter === c ? { background: CATEGORY_COLORS[c], color: "#04121f" } : undefined}>{c}</button>
              ))}
            </div>

            {/* day events + composer */}
            <div className="min-h-0 flex-1 overflow-y-auto px-2.5 pb-2.5 pt-1.5">
              <div className="mb-1 flex items-center gap-1">
                <span className={`text-[8px] font-black uppercase tracking-[0.18em] ${muted}`}>
                  {new Date(selectedDate).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}
                </span>
                <button onClick={() => setComposing((v) => !v)} className="ml-auto flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[8px] font-bold" style={{ background: alpha(accent, 0.18), color: accent }}>
                  <Plus className="h-2.5 w-2.5" />New
                </button>
              </div>

              <AnimatePresence>
                {composing && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                    className="mb-1.5 overflow-hidden rounded-lg border border-current/10 p-1.5">
                    <input value={draftTitle} onChange={(e) => setDraftTitle(e.target.value)} placeholder="Event title..."
                      className={`mb-1 w-full rounded-md px-1.5 py-1 text-[9px] outline-none ${soft}`} />
                    <textarea value={draftText} onChange={(e) => setDraftText(e.target.value)} placeholder="What's happening?" rows={2}
                      className={`mb-1 w-full resize-none rounded-md px-1.5 py-1 text-[9px] outline-none ${soft}`} />
                    <button onClick={submitDraft} className="w-full rounded-md py-1 text-[9px] font-bold" style={{ background: accent, color: "#04121f" }}>
                      Post event
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {dayEvents.length === 0 && !composing && (
                <div className={`rounded-lg border border-dashed border-current/15 py-3 text-center text-[8.5px] ${muted}`}>
                  No events yet — be the first to add one.
                </div>
              )}

              <div className="space-y-1.5">
                {dayEvents.map((ev) => (
                  <EventCard key={ev.id} ev={ev} soft={soft} muted={muted} onOpen={() => setDetail(ev)} onGo={() => toggleGoing(ev.id)} live={isHappeningNow(ev)} />
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* detail / feed modal */}
      <AnimatePresence>
        {detail && (
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.94 }}
            onPointerDown={(e) => e.stopPropagation()}
            className={`flex h-[min(60vh,420px)] w-[min(90vw,330px)] flex-col overflow-hidden rounded-2xl border backdrop-blur-2xl ${panel}`}
            style={{ boxShadow: `0 24px 60px -20px rgba(0,0,0,0.6)` }}
          >
            <div className="flex items-center gap-1.5 border-b border-current/10 px-2.5 py-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: detail.color }} />
              <span className="truncate text-[10.5px] font-bold">{detail.title}</span>
              <button onClick={() => setDetail(null)} className={`ml-auto grid h-5 w-5 place-items-center rounded-md ${soft}`}>
                <X className="h-3 w-3" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto px-2.5 py-2">
              <div className={`flex items-center gap-1 text-[8.5px] ${muted}`}>
                <MapPin className="h-2.5 w-2.5" />{detail.location} · {detail.time}{detail.endTime ? `–${detail.endTime}` : ""}
              </div>
              <div className="mt-1 text-[9.5px] leading-relaxed">{detail.blurb}</div>
              <div className="mt-1.5 flex items-center gap-1.5">
                <div className="flex -space-x-1.5">
                  {detail.attendees.slice(0, 5).map((a, i) => (
                    <span key={i} className="grid h-5 w-5 place-items-center rounded-full border text-[7px] font-black" style={{ background: alpha(a.color, 0.6), borderColor: "rgba(255,255,255,0.4)" }}>{a.name[0]}</span>
                  ))}
                </div>
                <span className={`text-[8.5px] font-bold`}>{detail.going} going</span>
                <button onClick={() => toggleGoing(detail.id)} className="ml-auto rounded-full px-2 py-[3px] text-[8.5px] font-bold" style={{ background: accent, color: "#04121f" }}>
                  I'm going
                </button>
              </div>
              <div className="mt-1.5 flex gap-1">
                {detail.reactions.map((r, i) => (
                  <span key={i} className={`flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[8.5px] ${soft}`}>{r.emoji} {r.count}</span>
                ))}
                <button className={`flex items-center gap-1 rounded-full px-1.5 py-[2px] text-[8.5px] ${soft}`}>
                  <Heart className="h-2.5 w-2.5" />React
                </button>
              </div>
              <div className={`mt-2 mb-1 flex items-center gap-1 text-[8px] font-black uppercase tracking-[0.18em] ${muted}`}>
                <MessageCircle className="h-2.5 w-2.5" />Comments
              </div>
              <div className="space-y-1.5">
                {detail.comments.map((c) => (
                  <div key={c.id} className="flex items-start gap-1.5">
                    <span className="mt-[1px] grid h-4.5 w-4.5 h-[18px] w-[18px] shrink-0 place-items-center rounded-full text-[7px] font-black" style={{ background: alpha(c.avatarColor, 0.6) }}>{c.user[0]}</span>
                    <div className="min-w-0">
                      <div className="text-[8.5px]"><b>{c.user}</b> <span className={muted}>· {c.when}</span></div>
                      <div className="text-[8.5px] leading-snug">{c.text}</div>
                    </div>
                  </div>
                ))}
                {detail.comments.length === 0 && <div className={`text-[8.5px] ${muted}`}>No comments yet.</div>}
              </div>
            </div>
            <CommentBox soft={soft} accent={accent} onSend={(t) => addComment(detail.id, t)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* floating button */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => { if (!dragged.current) setOpen((v) => !v); }}
        className="relative grid h-12 w-12 place-items-center rounded-full border backdrop-blur-2xl"
        style={{
          background: `radial-gradient(circle at 32% 28%, ${accent}, ${alpha(accent, 0.3)} 60%, transparent 100%)`,
          borderColor: alpha(accent, 0.45),
          boxShadow: `0 10px 30px -8px ${accent}, 0 0 0 6px ${alpha(accent, 0.07)}`,
          cursor: "grab",
        }}
        aria-label="Community events"
      >
        <CalendarDays className="h-5 w-5" style={{ color: "#0b1020" }} />
        {happeningNow.length > 0 && (
          <motion.span className="absolute inset-0 rounded-full border" style={{ borderColor: alpha("#ef4444", 0.7) }}
            animate={{ scale: [1, 1.4], opacity: [0.7, 0] }} transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut" }} />
        )}
      </motion.button>
    </motion.div>
  );
}

function EventCard({ ev, soft, muted, onOpen, onGo, live }: {
  ev: CalendarEvent; soft: string; muted: string; onOpen: () => void; onGo: () => void; live: boolean;
}) {
  return (
    <div className="rounded-xl border border-current/10 p-1.5" style={{ background: alpha(ev.color, 0.05) }}>
      <button onClick={onOpen} className="flex w-full items-start gap-1.5 text-left">
        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg" style={{ background: alpha(ev.color, 0.18) }}>
          <Sparkles className="h-3 w-3" style={{ color: ev.color }} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1">
            <span className="truncate text-[10px] font-bold">{ev.title}</span>
            {live && (
              <span className="flex items-center gap-[2px] rounded px-1 text-[6.5px] font-black uppercase" style={{ background: alpha("#ef4444", 0.2), color: "#ef4444" }}>
                now
              </span>
            )}
          </div>
          <div className={`flex items-center gap-1 truncate text-[7.5px] ${muted}`}>
            <MapPin className="h-2 w-2" />{ev.location} · {ev.time}
          </div>
        </div>
      </button>
      <div className="mt-1 flex items-center gap-1">
        <div className="flex -space-x-1.5">
          {ev.attendees.slice(0, 3).map((a, i) => (
            <span key={i} className="grid h-4 w-4 place-items-center rounded-full border text-[6px] font-black" style={{ background: alpha(a.color, 0.55), borderColor: "rgba(255,255,255,0.4)" }}>{a.name[0]}</span>
          ))}
        </div>
        <span className={`flex items-center gap-[2px] text-[7.5px] ${muted}`}><Users className="h-2.5 w-2.5" />{ev.going}</span>
        <button onClick={onGo} className="ml-auto rounded-full px-1.5 py-[2px] text-[7.5px] font-bold" style={{ background: alpha(ev.color, 0.18), color: ev.color }}>
          I'm going
        </button>
      </div>
    </div>
  );
}

function CommentBox({ soft, accent, onSend }: { soft: string; accent: string; onSend: (text: string) => void }) {
  const [val, setVal] = useState("");
  return (
    <div className="flex items-center gap-1.5 border-t border-current/10 px-2 py-1.5">
      <input value={val} onChange={(e) => setVal(e.target.value)} placeholder="Add a comment..."
        onKeyDown={(e) => { if (e.key === "Enter") { onSend(val); setVal(""); } }}
        className={`min-w-0 flex-1 rounded-full px-2 py-1 text-[9px] outline-none ${soft}`} />
      <button onClick={() => { onSend(val); setVal(""); }} className="grid h-6 w-6 shrink-0 place-items-center rounded-full" style={{ background: accent, color: "#04121f" }} aria-label="Send comment">
        <Send className="h-3 w-3" />
      </button>
    </div>
  );
}
