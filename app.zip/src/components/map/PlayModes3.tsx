/* Premium mode 4 — "Field Journal": editorial/blog docked panel (map-left
 * layout shrinks + shifts the map to make room on the right). */
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import type { ThemeSpec } from "./themes";
import { alpha } from "./color";
import { PLACE_CYCLE, statsFor } from "./playData";

const EASE = [0.22, 1, 0.36, 1] as const;
const MS = 8200;

function useCycle(len: number, ms: number) {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setI((v) => (v + 1) % len), ms);
    return () => window.clearInterval(id);
  }, [len, ms]);
  return i;
}

function FieldJournal({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const i = useCycle(PLACE_CYCLE.length, MS);
  const s = statsFor(PLACE_CYCLE[i]);
  const text = isLight ? "#0f172a" : "#f4f4f5";
  const max = Math.max(...s.sectorMix.map((m) => m.value));

  return (
    <div
      className="pointer-events-none absolute inset-x-2 bottom-2 top-auto flex max-h-[62vh] w-auto flex-col overflow-y-auto rounded-xl border px-3.5 py-3 backdrop-blur-xl sm:inset-x-auto sm:inset-y-0 sm:right-0 sm:top-0 sm:bottom-0 sm:w-[46%] sm:min-w-[260px] sm:max-w-[420px] sm:max-h-none sm:justify-center sm:overflow-hidden sm:rounded-none sm:border-0 sm:px-4 sm:py-6"
      style={{
        borderColor: alpha(theme.glow, 0.2),
        background: `linear-gradient(90deg, transparent, ${alpha(isLight ? "#ffffff" : "#050810", 0.94)} 18%)`,
      }}
    >
      <AnimatePresence mode="wait">
        <motion.div key={s.name} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }}
          transition={{ duration: 0.6, ease: EASE }}>
          <div className="text-[8px] font-black uppercase tracking-[0.3em] sm:text-[9px] sm:tracking-[0.4em]" style={{ color: theme.glow }}>Field journal · {s.district}</div>
          <h2 className="mt-1 text-[18px] font-black leading-[1.1] sm:text-[28px]" style={{ color: text, fontFamily: "Georgia, 'Times New Roman', serif" }}>
            {s.headline}
          </h2>
          <div className="mt-1 text-[8.5px] uppercase tracking-[0.2em] opacity-55 sm:text-[9.5px] sm:tracking-[0.25em]" style={{ color: text }}>
            By the field desk · {s.timestamp}
          </div>

          <p className="mt-2.5 max-w-[340px] text-[11px] leading-relaxed sm:mt-3 sm:text-[12px]" style={{ color: text, opacity: 0.82, fontFamily: "Georgia, serif" }}>
            {s.name} counts {s.population.toLocaleString()} registered residents and {s.businesses.toLocaleString()} active
            businesses this wave, with {s.leadingSector.toLowerCase()} leading local activity. Sentiment sits at {s.sentiment}
            out of 100, {s.growthPct >= 0 ? "up" : "down"} {Math.abs(s.growthPct)}% since the last survey.
          </p>

          <blockquote className="mt-2.5 hidden border-l-2 pl-2.5 text-[11.5px] italic sm:mt-3 sm:block" style={{ borderColor: theme.glow, color: text, opacity: 0.85 }}>
            &ldquo;{s.quote}&rdquo;
            <div className="mt-1 text-[9px] not-italic uppercase tracking-[0.22em] opacity-55">{s.quoteWho}</div>
          </blockquote>

          <div className="mt-2.5 space-y-1 sm:mt-3">
            {s.sectorMix.slice(0, 3).map((m, k) => (
              <div key={m.label} className="flex items-center gap-2">
                <span className="w-[64px] shrink-0 truncate text-[8px] font-bold uppercase tracking-[0.06em] opacity-60 sm:w-[76px] sm:text-[8.5px] sm:tracking-[0.08em]" style={{ color: text }}>{m.label}</span>
                <div className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full" style={{ background: alpha(theme.glow, 0.14) }}>
                  <motion.div initial={{ width: 0 }} animate={{ width: `${(m.value / max) * 100}%` }}
                    transition={{ duration: 0.8, delay: k * 0.08, ease: EASE }}
                    className="h-full rounded-full" style={{ background: theme.glow }} />
                </div>
                <span className="w-6 shrink-0 text-right text-[9px] font-black tabular-nums" style={{ color: theme.glow }}>{m.value}</span>
              </div>
            ))}
          </div>

          <div className="mt-2.5 flex gap-1 sm:mt-3">
            {PLACE_CYCLE.map((_, k) => (
              <span key={k} className="h-[2px] flex-1 rounded-full" style={{ background: k === i ? theme.glow : alpha(text, 0.16) }} />
            ))}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

export function PlayLayer3({ mode, theme, isLight }: { mode: number; theme: ThemeSpec; isLight: boolean }) {
  if (mode === 4) return <FieldJournal theme={theme} isLight={isLight} />;
  return null;
}
