import { motion, useMotionValue, useTransform } from "framer-motion";
import { useMemo, useState } from "react";
import {
  Archive, Bell, BellOff, Check, CheckCheck, ChevronLeft,
  Pin, Search, Send, Settings2, Sparkles, Vote,
} from "lucide-react";
import { alpha } from "../color";
import {
  DEFAULT_PREFS, DM_REPLIES, THREADS, allSenders,
  type Category, type NotificationPrefs, type Thread, type ThreadMessage,
} from "../inboxData";

const uid = () => Math.random().toString(36).slice(2);

function timeAgo(ts: number) {
  const d = Date.now() - ts;
  if (d < 6e4) return "now";
  if (d < 36e5) return `${Math.round(d / 6e4)}m`;
  if (d < 864e5) return `${Math.round(d / 36e5)}h`;
  if (d < 6048e5) return `${Math.round(d / 864e5)}d`;
  return new Date(ts).toLocaleDateString();
}

/** Derive a compact category tag + color from a thread's kind/category. */
function tagFor(thread: Thread): { label: string; color: string } {
  if (thread.meta?.poll) return { label: "poll", color: "#a78bfa" };
  switch (thread.kind) {
    case "group-pool": return { label: "pool", color: "#34d399" };
    case "crowdfund": return { label: "fund", color: "#2dd4bf" };
    case "employment": return { label: "job", color: "#fbbf24" };
    case "partnership": return { label: "group", color: "#818cf8" };
    case "announcement": return { label: "ad", color: "#f472b6" };
    case "survey-nudge": return { label: "survey", color: "#38bdf8" };
    case "dm": return { label: "dm", color: "#60a5fa" };
    default: return { label: "alert", color: "#fb7185" };
  }
}

export function InboxApp({ isLight, glow }: { isLight: boolean; glow: string }) {
  const [threads, setThreads] = useState<Thread[]>(THREADS);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [view, setView] = useState<"list" | "settings">("list");
  const [showSearch, setShowSearch] = useState(false);
  const [q, setQ] = useState("");
  const [prefs, setPrefs] = useState<NotificationPrefs>(DEFAULT_PREFS);
  const [draft, setDraft] = useState("");

  const senders = useMemo(() => allSenders(threads), [threads]);
  const active = threads.find((t) => t.id === activeId) ?? null;

  const soft = isLight ? "bg-slate-900/[0.05]" : "bg-white/[0.06]";
  const muted = isLight ? "text-slate-500" : "text-white/45";

  const visible = useMemo(() => {
    return threads
      .filter((t) => !t.archived)
      .filter((t) => {
        if (!q.trim()) return true;
        const hay = (t.title + " " + (t.subtitle ?? "") + " " + t.messages.map((m) => m.text).join(" ")).toLowerCase();
        return hay.includes(q.toLowerCase());
      })
      .sort((a, b) =>
        Number(!!b.pinned) - Number(!!a.pinned) ||
        Number(b.unread > 0) - Number(a.unread > 0) ||
        b.updatedAt - a.updatedAt
      );
  }, [threads, q]);

  const totalUnread = threads.reduce((s, t) => s + (t.archived || t.muted ? 0 : t.unread), 0);

  const patch = (id: string, fn: (t: Thread) => Thread) => setThreads((cur) => cur.map((t) => (t.id === id ? fn(t) : t)));

  const openThread = (id: string) => { setActiveId(id); patch(id, (t) => ({ ...t, unread: 0 })); };

  const sendReply = () => {
    if (!active || !draft.trim()) return;
    const text = draft.trim();
    setDraft("");
    const mine: ThreadMessage = { id: uid(), senderId: "me", text, at: Date.now() };
    patch(active.id, (t) => ({ ...t, messages: [...t.messages, mine], updatedAt: Date.now() }));
    window.setTimeout(() => {
      const replyFrom = active.participants.find((p) => p.kind === "person") ?? active.participants[0];
      const reply: ThreadMessage = {
        id: uid(),
        senderId: replyFrom?.id ?? "app",
        system: replyFrom?.kind !== "person",
        at: Date.now(),
        text: replyFrom?.kind === "person" ? DM_REPLIES[Math.floor(Math.random() * DM_REPLIES.length)] : "Noted — thanks for the update.",
      };
      patch(active.id, (t) => ({ ...t, messages: [...t.messages, reply], updatedAt: Date.now() }));
    }, 900 + Math.random() * 700);
  };

  const vote = (optId: string) => {
    if (!active?.meta?.poll) return;
    patch(active.id, (t) => {
      if (!t.meta?.poll) return t;
      const already = t.meta.poll.myVote;
      const options = t.meta.poll.options.map((o) => {
        if (o.id === optId && already !== optId) return { ...o, votes: o.votes + 1 };
        if (o.id === already && already !== optId) return { ...o, votes: Math.max(0, o.votes - 1) };
        return o;
      });
      return { ...t, meta: { ...t.meta, poll: { ...t.meta.poll, options, myVote: optId } } };
    });
  };

  const toggleTask = (taskId: string) => {
    if (!active?.meta?.tasks) return;
    patch(active.id, (t) => {
      if (!t.meta?.tasks) return t;
      return { ...t, meta: { ...t.meta, tasks: t.meta.tasks.map((tk) => (tk.id === taskId ? { ...tk, done: !tk.done } : tk)) } };
    });
  };

  /* ---------- SETTINGS ---------- */
  if (view === "settings") {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <PaneHeader title="Notification settings" muted={muted} onBack={() => setView("list")} />
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-3">
          <Group label="Categories" muted={muted}>
            {(["survey", "group", "app", "person"] as Category[]).map((c) => (
              <ToggleRow key={c} label={c === "survey" ? "Surveys" : c === "group" ? "Groups & pools" : c === "app" ? "App announcements" : "People"}
                on={prefs.categories[c]} glow={glow} soft={soft}
                onToggle={() => setPrefs((p) => ({ ...p, categories: { ...p.categories, [c]: !p.categories[c] } }))} />
            ))}
          </Group>
          <Group label="Quiet hours" muted={muted}>
            <ToggleRow label={`${prefs.quietHours.from} – ${prefs.quietHours.to}`} on={prefs.quietHours.enabled} glow={glow} soft={soft}
              onToggle={() => setPrefs((p) => ({ ...p, quietHours: { ...p.quietHours, enabled: !p.quietHours.enabled } }))} />
          </Group>
          <Group label="Auto-join matched groups" muted={muted}>
            <ToggleRow label="Join group buys / pools automatically when a survey match happens" on={prefs.autoJoinGroups} glow={glow} soft={soft}
              onToggle={() => setPrefs((p) => ({ ...p, autoJoinGroups: !p.autoJoinGroups }))} />
          </Group>
          <Group label="Digest frequency" muted={muted}>
            <div className="flex gap-1">
              {(["off", "daily", "weekly"] as const).map((d) => (
                <button key={d} onClick={() => setPrefs((p) => ({ ...p, digest: d }))}
                  className={`flex-1 rounded-lg px-2 py-1 text-[10px] font-bold capitalize ${prefs.digest === d ? "text-black" : soft}`}
                  style={prefs.digest === d ? { background: glow } : undefined}>
                  {d}
                </button>
              ))}
            </div>
          </Group>
          <div className={`text-[9px] ${muted}`}>Preferences apply on this device only.</div>
        </div>
      </div>
    );
  }

  /* ---------- THREAD DETAIL ---------- */
  if (active) {
    const meta = active.meta;
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <PaneHeader
          title={active.title}
          subtitle={active.subtitle}
          muted={muted}
          onBack={() => setActiveId(null)}
          right={
            <div className="flex items-center gap-1">
              <IconBtn label="Pin" soft={soft} active={!!active.pinned} glow={glow} onClick={() => patch(active.id, (t) => ({ ...t, pinned: !t.pinned }))}><Pin className="h-3 w-3" /></IconBtn>
              <IconBtn label="Mute" soft={soft} active={!!active.muted} glow={glow} onClick={() => patch(active.id, (t) => ({ ...t, muted: !t.muted }))}>{active.muted ? <BellOff className="h-3 w-3" /> : <Bell className="h-3 w-3" />}</IconBtn>
              <IconBtn label="Archive" soft={soft} active={!!active.archived} glow={glow} onClick={() => { patch(active.id, (t) => ({ ...t, archived: !t.archived })); setActiveId(null); }}><Archive className="h-3 w-3" /></IconBtn>
            </div>
          }
        />

        <div className="min-h-0 flex-1 space-y-2.5 overflow-y-auto px-2.5 py-2">
          {meta && (meta.pool || meta.tasks || meta.poll || meta.roles || meta.memberAvatars || typeof meta.matchScore === "number") && (
            <div className={`space-y-2.5 rounded-xl p-2.5 ${soft}`}>
              {meta.sourceSurvey && (
                <div className={`flex items-center gap-1 text-[9px] font-semibold uppercase tracking-[0.14em] ${muted}`}>
                  <Sparkles className="h-2.5 w-2.5" style={{ color: glow }} />
                  From: {meta.sourceSurvey}
                </div>
              )}
              {typeof meta.matchScore === "number" && (
                <div className="flex items-center gap-2">
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-current/10">
                    <div className="h-full rounded-full" style={{ width: `${meta.matchScore}%`, background: glow }} />
                  </div>
                  <span className="text-[10px] font-bold" style={{ color: glow }}>{meta.matchScore}% match</span>
                </div>
              )}
              {(meta.memberAvatars || meta.memberCount) && (
                <div className="flex items-center gap-1.5">
                  <div className="flex -space-x-1.5">
                    {(meta.memberAvatars ?? []).slice(0, 6).map((a, i) => (
                      <img key={i} src={a} alt="" className="h-5 w-5 rounded-full object-cover" style={{ boxShadow: `0 0 0 1.5px ${isLight ? "#fff" : "#080b16"}` }} />
                    ))}
                  </div>
                  <span className={`text-[10px] font-semibold ${muted}`}>{meta.memberCount} members</span>
                  {meta.deadline && <span className={`ml-auto text-[9.5px] font-semibold ${muted}`}>Deadline {timeAgo(meta.deadline).replace("-", "")} left</span>}
                </div>
              )}
              {meta.pool && (
                <div>
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="text-[11px] font-bold">{meta.pool.currency} {meta.pool.raised.toLocaleString()} <span className={`font-medium ${muted}`}>/ {meta.pool.target.toLocaleString()}</span></span>
                    <span className={`text-[9.5px] ${muted}`}>{meta.pool.contributors} contributors</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-current/10">
                    <motion.div className="h-full rounded-full" style={{ background: glow }}
                      initial={{ width: 0 }} animate={{ width: `${Math.min(100, (meta.pool.raised / meta.pool.target) * 100)}%` }} transition={{ duration: 0.6 }} />
                  </div>
                </div>
              )}
              {meta.roles && (
                <div className="flex flex-wrap gap-1">
                  {meta.roles.map((r) => (
                    <span key={r.userId} className="flex items-center gap-1 rounded-full py-0.5 pl-0.5 pr-2 text-[9.5px] font-semibold" style={{ background: alpha(glow, 0.13), color: glow }}>
                      {r.avatar && <img src={r.avatar} alt="" className="h-3.5 w-3.5 rounded-full object-cover" />}
                      {r.name.split(" ")[0]} · {r.label}
                    </span>
                  ))}
                </div>
              )}
              {meta.poll && (
                <div>
                  <div className="mb-1 flex items-center gap-1 text-[10.5px] font-bold"><Vote className="h-3 w-3" style={{ color: glow }} /> {meta.poll.question}</div>
                  {meta.poll.options.map((o) => {
                    const totalVotes = meta.poll!.options.reduce((s, x) => s + x.votes, 0) || 1;
                    const pct = Math.round((o.votes / totalVotes) * 100);
                    const mine = meta.poll!.myVote === o.id;
                    return (
                      <button key={o.id} onClick={() => vote(o.id)} className="relative mb-1 block w-full overflow-hidden rounded-lg text-left">
                        <div className="absolute inset-0" style={{ width: `${pct}%`, background: alpha(glow, mine ? 0.28 : 0.12) }} />
                        <div className="relative flex items-center justify-between px-2 py-1">
                          <span className="text-[10px] font-semibold">{mine && <Check className="mr-1 inline h-2.5 w-2.5" />}{o.label}</span>
                          <span className={`text-[9.5px] ${muted}`}>{pct}%</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
              {meta.tasks && (
                <div className="space-y-1">
                  <div className={`text-[9px] font-bold uppercase tracking-[0.14em] ${muted}`}>Checklist</div>
                  {meta.tasks.map((tsk) => (
                    <button key={tsk.id} onClick={() => toggleTask(tsk.id)} className="flex w-full items-center gap-1.5 text-left">
                      <span className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-[4px]" style={{ background: tsk.done ? glow : "transparent", boxShadow: `inset 0 0 0 1.3px ${tsk.done ? glow : alpha(glow, 0.4)}` }}>
                        {tsk.done && <Check className="h-2.5 w-2.5" style={{ color: "#04060d" }} />}
                      </span>
                      <span className={`text-[10.5px] ${tsk.done ? `line-through ${muted}` : ""}`}>{tsk.label}</span>
                      {tsk.assignee && <span className={`ml-auto shrink-0 text-[9px] ${muted}`}>{tsk.assignee.split(" ")[0]}</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {active.messages.map((m) => {
            const sender = senders[m.senderId];
            const isMe = m.senderId === "me";
            if (m.system) {
              return (
                <div key={m.id} className={`rounded-lg px-2 py-1.5 text-[10.5px] leading-relaxed ${soft}`}>
                  <span className="mr-1 font-bold" style={{ color: glow }}>{sender?.name ?? "Automated"}</span>
                  {m.text}
                </div>
              );
            }
            return (
              <motion.div key={m.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={isMe ? "flex justify-end" : "flex items-start gap-1.5"}>
                {!isMe && sender?.avatar && <img src={sender.avatar} alt="" className="mt-0.5 h-5 w-5 shrink-0 rounded-full object-cover" />}
                <div className={`max-w-[80%] rounded-2xl px-2.5 py-1.5 text-[11px] font-medium ${isMe ? "rounded-br-sm" : `rounded-bl-sm ${soft}`}`} style={isMe ? { background: glow, color: "#04060d" } : undefined}>
                  {!isMe && sender && active.participants.length > 1 && <div className="text-[9px] font-bold opacity-70">{sender.name}</div>}
                  {m.text}
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="border-t border-current/10 p-1.5">
          <div className={`flex items-center gap-1.5 rounded-xl px-2 py-1 ${soft}`}>
            <input value={draft} onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); sendReply(); } }}
              placeholder="Reply…" className="min-w-0 flex-1 bg-transparent py-1 text-[11px] outline-none placeholder:opacity-50" />
            <button onClick={sendReply} disabled={!draft.trim()} aria-label="Send" className="grid h-6 w-6 shrink-0 place-items-center rounded-lg disabled:opacity-40" style={{ background: glow, color: "#04060d" }}>
              <Send className="h-3 w-3" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ---------- LIST ---------- */
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className={`mx-2 mt-1.5 mb-1 flex items-center gap-1 rounded-lg px-1.5 py-1 ${soft}`}>
        {showSearch ? (
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onBlur={() => { if (!q.trim()) setShowSearch(false); }}
            placeholder="Search…"
            className="min-w-0 flex-1 bg-transparent px-0.5 text-[10.5px] outline-none placeholder:opacity-50"
          />
        ) : (
          <span className={`flex-1 truncate px-0.5 text-[9.5px] font-semibold uppercase tracking-[0.12em] ${muted}`}>
            {totalUnread > 0 ? `${totalUnread} unread` : "All caught up"}
          </span>
        )}
        <IconBtn label="Search" soft="" glow={glow} onClick={() => setShowSearch((v) => !v)}><Search className="h-3 w-3" /></IconBtn>
        <IconBtn label="Settings" soft="" glow={glow} onClick={() => setView("settings")}><Settings2 className="h-3 w-3" /></IconBtn>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-1.5 pb-1.5">
        {visible.map((t) => (
          <SwipeRow key={t.id} thread={t} soft={soft} muted={muted} glow={glow}
            onOpen={() => openThread(t.id)}
            onArchive={() => patch(t.id, (x) => ({ ...x, archived: !x.archived }))}
            onMute={() => patch(t.id, (x) => ({ ...x, muted: !x.muted }))} />
        ))}
        {visible.length === 0 && <div className={`py-10 text-center text-[10.5px] ${muted}`}>Nothing here.</div>}
        {totalUnread > 0 && (
          <button onClick={() => setThreads((cur) => cur.map((t) => ({ ...t, unread: 0 })))}
            className={`mx-1 mt-1 flex w-[calc(100%-8px)] items-center justify-center gap-1 rounded-lg px-2 py-1.5 text-[10px] font-bold ${soft} ${muted}`}>
            <CheckCheck className="h-3 w-3" /> Mark all as read ({totalUnread})
          </button>
        )}
      </div>
    </div>
  );
}

function SwipeRow({
  thread, soft, muted, glow, onOpen, onArchive, onMute,
}: {
  thread: Thread; soft: string; muted: string; glow: string;
  onOpen: () => void; onArchive: () => void; onMute: () => void;
}) {
  const x = useMotionValue(0);
  const actionOpacity = useTransform(x, [-90, -20, 0], [1, 0.35, 0]);
  const last = thread.messages[thread.messages.length - 1];
  const tag = tagFor(thread);

  return (
    <div className="relative mb-1 overflow-hidden rounded-lg">
      <motion.div style={{ opacity: actionOpacity }} className="absolute inset-0 flex items-center justify-end gap-2 bg-current/10 pr-3">
        <button onClick={onMute} aria-label="Mute" className="grid h-6 w-6 place-items-center rounded-full bg-black/20"><BellOff className="h-3 w-3" /></button>
        <button onClick={onArchive} aria-label="Archive" className="grid h-6 w-6 place-items-center rounded-full bg-black/30"><Archive className="h-3 w-3" /></button>
      </motion.div>
      <motion.div
        drag="x" dragConstraints={{ left: -100, right: 0 }} dragElastic={0.08} style={{ x }}
        onDragEnd={(_e, info) => { if (info.offset.x < -70) onArchive(); else void x.set(0); }}
        onPointerDown={(e) => e.stopPropagation()}
        className={`relative flex items-center gap-1.5 rounded-lg px-1.5 py-1.5 ${soft}`}
      >
        <button className="flex min-w-0 flex-1 items-center gap-1.5 text-left" onClick={onOpen}>
          <span
            className="shrink-0 rounded-[4px] px-1 py-[1.5px] text-center text-[6.5px] font-bold uppercase tracking-[0.06em]"
            style={{ background: alpha(tag.color, 0.16), color: tag.color }}
          >
            {tag.label}
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex items-center gap-1">
              {thread.pinned && <Pin className="h-2.5 w-2.5 shrink-0" style={{ color: glow }} />}
              <span className="truncate text-[10.5px] font-semibold">{thread.title}</span>
              <span className={`ml-auto shrink-0 text-[8.5px] ${muted}`}>{timeAgo(thread.updatedAt)}</span>
            </span>
            <span className="mt-[1px] flex items-center gap-1">
              <span className={`min-w-0 flex-1 truncate text-[9.5px] ${muted}`}>{last?.text ?? thread.subtitle}</span>
              {thread.muted && <BellOff className={`h-2.5 w-2.5 shrink-0 ${muted}`} />}
              {thread.unread > 0 && !thread.muted && (
                <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: glow }} />
              )}
            </span>
          </span>
        </button>
      </motion.div>
    </div>
  );
}

function PaneHeader({ title, subtitle, muted, onBack, right }: { title: string; subtitle?: string; muted: string; onBack: () => void; right?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 border-b border-current/10 px-2 py-1.5">
      <button onClick={onBack} className={`grid h-5 w-5 shrink-0 place-items-center rounded-md ${muted}`} aria-label="Back"><ChevronLeft className="h-3.5 w-3.5" /></button>
      <span className="min-w-0">
        <span className="block truncate text-[11px] font-bold">{title}</span>
        {subtitle && <span className={`block truncate text-[8.5px] ${muted}`}>{subtitle}</span>}
      </span>
      {right && <div className="ml-auto flex items-center gap-1">{right}</div>}
    </div>
  );
}

function Group({ label, children, muted }: { label: string; children: React.ReactNode; muted: string }) {
  return (
    <div>
      <div className={`mb-1 text-[8.5px] font-bold uppercase tracking-[0.2em] ${muted}`}>{label}</div>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function ToggleRow({ label, on, onToggle, glow, soft }: { label: string; on: boolean; onToggle: () => void; glow: string; soft: string }) {
  return (
    <div className={`flex items-center gap-2 rounded-lg px-2 py-1.5 ${soft}`}>
      <span className="min-w-0 flex-1 text-[10.5px] font-semibold">{label}</span>
      <button onClick={onToggle} className="h-5 w-9 shrink-0 rounded-full p-[2px] transition" style={{ background: on ? glow : alpha("#888888", 0.25) }}>
        <motion.span layout className="block h-4 w-4 rounded-full bg-white shadow" style={{ marginLeft: on ? 16 : 0 }} />
      </button>
    </div>
  );
}

function IconBtn({ children, onClick, label, soft, active, glow }: { children: React.ReactNode; onClick: () => void; label: string; soft: string; active?: boolean; glow?: string }) {
  return (
    <button aria-label={label} title={label} onClick={onClick} className={`grid h-6 w-6 shrink-0 place-items-center rounded-lg ${active ? "" : soft} hover:opacity-80`} style={active && glow ? { background: alpha(glow, 0.22), color: glow } : undefined}>
      {children}
    </button>
  );
}
