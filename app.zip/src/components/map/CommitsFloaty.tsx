import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useRef, useState } from "react";
import {
  Bell, Check, CheckCircle2, ChevronDown, Clock, Handshake, ShieldCheck, X, XCircle,
} from "lucide-react";
import { alpha } from "./color";
import {
  LEDGER, PROFILE, UPCOMING, type Commitment, type CommitStatus,
} from "./commitsData";

function countdown(dueAt: string) {
  const diff = new Date(dueAt).getTime() - Date.now();
  if (diff <= 0) return "due now";
  const h = Math.floor(diff / 3_600_000);
  if (h < 1) return `${Math.max(1, Math.floor(diff / 60_000))}m left`;
  if (h < 24) return `${h}h left`;
  return `${Math.floor(h / 24)}d left`;
}

export function CommitsFloaty({ isLight, glow }: { isLight: boolean; glow: string }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Commitment[]>(UPCOMING);
  const [proofFor, setProofFor] = useState<Commitment | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const dragged = useRef(false);

  const panel = isLight
    ? "border-slate-900/10 bg-white/90 text-slate-900"
    : "border-white/12 bg-[#070c17]/90 text-white";
  const soft = isLight ? "bg-slate-900/[0.05]" : "bg-white/[0.07]";
  const muted = isLight ? "text-slate-500" : "text-white/50";
  const accent = glow;

  const setStatus = (id: string, status: CommitStatus) =>
    setItems((prev) => prev.map((c) => (c.id === id ? { ...c, status } : c)));

  const needsAnswer = useMemo(() => items.filter((c) => c.status === "pending" || c.status === "snoozed"), [items]);
  const committed = useMemo(() => items.filter((c) => c.status === "committed"), [items]);
  const pendingCount = needsAnswer.length;

  return (
    <motion.div
      drag dragMomentum={false} dragElastic={0.05}
      onDragStart={() => { dragged.current = true; }}
      onDragEnd={() => { window.setTimeout(() => { dragged.current = false; }, 60); }}
      className="fixed bottom-5 left-4 z-[60] flex flex-col items-start gap-2"
      style={{ touchAction: "none" }}
    >
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
            onPointerDown={(e) => e.stopPropagation()}
            className={`flex h-[min(60vh,440px)] w-[min(90vw,320px)] flex-col overflow-hidden rounded-2xl border backdrop-blur-2xl ${panel}`}
            style={{ boxShadow: `0 24px 60px -20px rgba(0,0,0,0.6), 0 0 0 1px ${alpha(accent, 0.16)}` }}
          >
            {/* header */}
            <div className="flex items-center gap-1.5 border-b border-current/10 px-2.5 py-1.5">
              <span className="grid h-5 w-5 place-items-center rounded-full" style={{ background: alpha(accent, 0.18) }}>
                <Handshake className="h-3 w-3" style={{ color: accent }} />
              </span>
              <span className="text-[11.5px] font-bold" style={{ fontFamily: "'Sora',sans-serif" }}>Commitments</span>
              <button aria-label="Close commitments" onClick={() => setOpen(false)} className={`ml-auto grid h-5 w-5 place-items-center rounded-md ${soft}`}>
                <X className="h-3 w-3" />
              </button>
            </div>

            {/* standing strip — simplified */}
            <div className="flex items-center gap-2 border-b border-current/10 px-2.5 py-1.5">
              <ShieldCheck className="h-4 w-4 shrink-0" style={{ color: accent }} />
              <span className="text-[9.5px] font-bold">{PROFILE.reliability}% reliable</span>
              <div className="h-1 flex-1 overflow-hidden rounded-full" style={{ background: alpha(accent, 0.15) }}>
                <div className="h-full rounded-full" style={{ width: `${PROFILE.reliability}%`, background: accent }} />
              </div>
              {pendingCount > 0 && (
                <span className={`flex shrink-0 items-center gap-1 text-[8.5px] font-bold ${muted}`}>
                  <Bell className="h-2.5 w-2.5" />{pendingCount}
                </span>
              )}
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto px-2.5 py-2">
              {needsAnswer.length > 0 && (
                <Section title={`Needs your answer (${needsAnswer.length})`} muted={muted}>
                  {needsAnswer.map((c) => (
                    <SimpleCard key={c.id} c={c} soft={soft} muted={muted} setStatus={setStatus} />
                  ))}
                </Section>
              )}

              {committed.length > 0 && (
                <Section title={`Committed (${committed.length})`} muted={muted}>
                  {committed.map((c) => (
                    <SimpleCard key={c.id} c={c} soft={soft} muted={muted} setStatus={setStatus} onProof={() => setProofFor(c)} />
                  ))}
                </Section>
              )}

              {needsAnswer.length === 0 && committed.length === 0 && (
                <div className={`py-6 text-center text-[10.5px] ${muted}`}>You're all caught up.</div>
              )}

              {/* history — collapsed by default */}
              <button
                onClick={() => setHistoryOpen((v) => !v)}
                className={`mt-2 flex w-full items-center justify-center gap-1 rounded-lg py-1.5 text-[9.5px] font-bold ${soft} ${muted}`}
              >
                History
                <ChevronDown className={`h-3 w-3 transition-transform ${historyOpen ? "rotate-180" : ""}`} />
              </button>
              <AnimatePresence>
                {historyOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="mt-1.5 space-y-1">
                      {LEDGER.map((l) => (
                        <div key={l.id} className="flex items-center gap-1.5 rounded-lg border border-current/10 px-1.5 py-1">
                          {l.result === "honored"
                            ? <CheckCircle2 className="h-3 w-3 shrink-0" style={{ color: "#22c55e" }} />
                            : <XCircle className="h-3 w-3 shrink-0" style={{ color: "#ef4444" }} />}
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-[9px] font-bold">{l.title}</div>
                            <div className={`text-[7.5px] ${muted}`}>{l.when} · {l.category}</div>
                          </div>
                        </div>
                      ))}
                      <div className={`px-1 pt-0.5 text-[8px] ${muted}`}>
                        {PROFILE.honored} honored · {PROFILE.broken} broken · {PROFILE.collabs} collabs
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* proof modal */}
      <AnimatePresence>
        {proofFor && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
            onPointerDown={(e) => e.stopPropagation()}
            className={`w-[min(84vw,300px)] rounded-xl border p-2.5 backdrop-blur-2xl ${panel}`}
            style={{ boxShadow: `0 20px 50px -18px rgba(0,0,0,0.6)` }}
          >
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" style={{ color: accent }} />
              <span className="text-[10px] font-bold">Confirm you followed through</span>
            </div>
            <div className={`mt-1 text-[8.5px] ${muted}`}>{proofFor.ask}</div>
            <div className="mt-2 flex gap-1.5">
              <button
                onClick={() => { setStatus(proofFor.id, "honored"); setProofFor(null); }}
                className="flex-1 rounded-lg py-1.5 text-[9px] font-bold" style={{ background: accent, color: "#04121f" }}>
                Confirm honored
              </button>
              <button onClick={() => setProofFor(null)} className={`rounded-lg px-2.5 py-1.5 text-[9px] font-bold ${soft}`}>Later</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* floating button */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => { if (!dragged.current) setOpen((v) => !v); }}
        className="relative grid h-12 w-12 place-items-center rounded-full border backdrop-blur-2xl"
        style={{
          background: `radial-gradient(circle at 32% 28%, ${accent}, ${alpha(accent, 0.3)} 60%, transparent 100%)`,
          borderColor: alpha(accent, 0.45),
          boxShadow: `0 10px 30px -8px ${accent}, 0 0 0 6px ${alpha(accent, 0.07)}`,
          cursor: "grab",
        }}
        aria-label="Commitments"
      >
        <Handshake className="h-5 w-5" style={{ color: "#0b1020" }} />
        {pendingCount > 0 && (
          <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full text-[8px] font-black"
            style={{ background: "#ef4444", color: "#fff" }}>
            {pendingCount}
          </span>
        )}
      </motion.button>
    </motion.div>
  );
}

function Section({ title, muted, children }: { title: string; muted: string; children: React.ReactNode }) {
  return (
    <div className="mb-2">
      <div className={`mb-1 text-[8px] font-black uppercase tracking-[0.18em] ${muted}`}>{title}</div>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

/** One commitment: what, who asked, when due, and exactly two primary actions. */
function SimpleCard({ c, soft, muted, setStatus, onProof }: {
  c: Commitment; soft: string; muted: string; setStatus: (id: string, s: CommitStatus) => void; onProof?: () => void;
}) {
  const color = c.color;
  const isCommitted = c.status === "committed";
  const isHonored = c.status === "honored";
  const isDeclined = c.status === "declined";

  return (
    <div className="rounded-xl border border-current/10 p-2">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="text-[10.5px] font-bold leading-snug">{c.ask}</div>
          <div className={`mt-[2px] text-[8.5px] ${muted}`}>Asked by {c.partners?.[0] ?? "your community"} · {c.location}</div>
        </div>
        <span className="flex shrink-0 items-center gap-1 text-[8.5px] font-bold" style={{ color: isHonored ? "#22c55e" : muted ? undefined : undefined }}>
          <Clock className={`h-2.5 w-2.5 ${muted}`} />
          <span className={muted}>{countdown(c.dueAt)}</span>
        </span>
      </div>

      <div className="mt-2 flex gap-1.5">
        {isHonored ? (
          <span className="flex flex-1 items-center justify-center gap-1 rounded-lg py-1.5 text-[9px] font-bold" style={{ background: alpha("#22c55e", 0.16), color: "#22c55e" }}>
            <CheckCircle2 className="h-3 w-3" />Done
          </span>
        ) : isDeclined ? (
          <span className={`flex flex-1 items-center justify-center gap-1 rounded-lg py-1.5 text-[9px] font-bold ${soft} ${muted}`}>
            <XCircle className="h-3 w-3" />Declined
          </span>
        ) : isCommitted ? (
          <button
            onClick={onProof}
            className="flex flex-1 items-center justify-center gap-1 rounded-lg py-1.5 text-[9px] font-bold"
            style={{ background: color, color: "#04121f" }}
          >
            <Check className="h-3 w-3" />Mark done
          </button>
        ) : (
          <>
            <button
              onClick={() => setStatus(c.id, "committed")}
              className="flex flex-1 items-center justify-center gap-1 rounded-lg py-1.5 text-[9px] font-bold"
              style={{ background: color, color: "#04121f" }}
            >
              <Check className="h-3 w-3" />Commit
            </button>
            <button
              onClick={() => setStatus(c.id, "declined")}
              className={`flex flex-1 items-center justify-center gap-1 rounded-lg py-1.5 text-[9px] font-bold ${soft}`}
            >
              <X className="h-3 w-3" />Decline
            </button>
          </>
        )}
      </div>
    </div>
  );
}
