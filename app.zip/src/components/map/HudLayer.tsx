import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  Brain,
  Camera,
  Cpu,
  Gauge,
  Radio,
  Satellite,
  Signal,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Waves,
  Zap,
  X,
} from "lucide-react";
import { alpha } from "./color";
import { SurveyWidget } from "./SurveyWidget";

import {
  FluxCard, GridDrawCard, KineticTextCard, MotionCard, NeuralCard, ScanCard, StackCard, VitalsCard,
} from "./HudCards";

/**
 * Adaptive AI HUD overlay for the Botswana map.
 *
 * Design goals:
 *  - GPU-friendly: animates transform + opacity only
 *  - Edge-hugging widgets that never intrude on the country silhouette,
 *    the top bar, the right zoom rail, the compass, or the scale chip.
 *  - Responsive to any phone width/orientation.
 *  - Widgets cycle their content and gently drift so the surface feels alive.
 */

export interface TickerConfig {
  /** "auto" = theme glow, "rainbow" = per-item palette, or any CSS color. */
  color: string;
  size: number;
  weight: number;
  speed: number;
  gap: number;
  tracking: number;
  bgOpacity: number;
  blur: number;
  uppercase: boolean;
  glowText: boolean;
  showIcon: boolean;
  fade: boolean;
  direction: "ltr" | "rtl";
  separator: string;
  mode: "news" | "metrics" | "mixed";
  /** CSS font-family stack used by the bottom ticker. */
  font: string;
  /** Render each item as a card/chip. */
  chips: boolean;
  /** Chip outline instead of filled chip. */
  outline: boolean;
  /** Chip corner radius. */
  radius: number;
}

export const DEFAULT_TICKER: TickerConfig = {
  color: "auto",
  size: 9,
  weight: 700,
  speed: 42,
  gap: 34,
  tracking: 0.04,
  bgOpacity: 0.35,
  blur: 2,
  uppercase: false,
  glowText: false,
  showIcon: true,
  fade: true,
  direction: "ltr",
  separator: "•",
  mode: "mixed",
  font: "'Manrope', system-ui, sans-serif",
  chips: false,
  outline: false,
  radius: 999,
};

/** Ready-made bottom-ticker looks — distinct fonts, colors, chips and motion. */
export const TICKER_TEMPLATES: { name: string; cfg: TickerConfig }[] = [
  { name: "Signal", cfg: DEFAULT_TICKER },
  {
    name: "Transparent",
    cfg: {
      ...DEFAULT_TICKER,
      bgOpacity: 0,
      blur: 0,
      chips: false,
      outline: false,
      showIcon: false,
      fade: false,
      glowText: false,
      size: 10,
      weight: 600,
      separator: "none",
    },
  },
  {
    name: "Newsroom",
    cfg: {
      ...DEFAULT_TICKER, mode: "news", font: "'Sora', system-ui, sans-serif", size: 10.5, weight: 600,
      color: "auto", tracking: 0, gap: 46, bgOpacity: 0.6, blur: 6, separator: "|", chips: false, uppercase: false, speed: 58,
    },
  },
  {
    name: "Terminal",
    cfg: {
      ...DEFAULT_TICKER, mode: "metrics", font: "'JetBrains Mono', ui-monospace, monospace", size: 9, weight: 500,
      color: "#22c55e", uppercase: true, tracking: 0.1, gap: 28, bgOpacity: 0.75, blur: 0, glowText: true,
      separator: "::", speed: 30, chips: false,
    },
  },
  {
    name: "Cards",
    cfg: {
      ...DEFAULT_TICKER, font: "'Plus Jakarta Sans', system-ui, sans-serif", size: 9.5, weight: 700,
      chips: true, outline: false, radius: 8, gap: 10, bgOpacity: 0.18, blur: 8, separator: "none",
      color: "auto", speed: 50,
    },
  },
  {
    name: "Outline",
    cfg: {
      ...DEFAULT_TICKER, font: "'Sora', system-ui, sans-serif", size: 9, weight: 800, uppercase: true,
      chips: true, outline: true, radius: 999, gap: 10, bgOpacity: 0, blur: 0, separator: "none",
      color: "rainbow", tracking: 0.1, speed: 46, showIcon: false,
    },
  },
  {
    name: "Neon",
    cfg: {
      ...DEFAULT_TICKER, font: "'Sora', system-ui, sans-serif", size: 10, weight: 900, uppercase: true,
      color: "rainbow", glowText: true, bgOpacity: 0.85, blur: 10, tracking: 0.14, gap: 40,
      separator: "◆", speed: 26, chips: false,
    },
  },
  {
    name: "Minimal",
    cfg: {
      ...DEFAULT_TICKER, mode: "news", font: "'Manrope', system-ui, sans-serif", size: 9, weight: 500,
      color: "auto", bgOpacity: 0, blur: 0, showIcon: false, fade: true, separator: "·",
      tracking: 0.02, gap: 52, speed: 70, chips: false,
    },
  },
];


interface HudLayerProps {
  isLight: boolean;
  glow: string;
  autoplay: boolean;
  /** Card category: 0 = classic, 1..5 = alternate card packs. */
  preset?: number;
  showCards?: boolean;
  ticker?: TickerConfig;
}


// ---------- data pools ----------

const METRIC_POOL = [
  { label: "AI Confidence", value: 87, unit: "%", trend: 2.4, icon: Brain },
  { label: "Signal Integrity", value: 94, unit: "%", trend: 1.1, icon: Signal },
  { label: "Coverage Index", value: 76, unit: "%", trend: -0.6, icon: Satellite },
  { label: "Neural Sync", value: 91, unit: "%", trend: 3.2, icon: Cpu },
  { label: "Data Freshness", value: 82, unit: "%", trend: 0.8, icon: Activity },
];

const SPARK_POOL = [
  { label: "Tourism Idx", series: [12, 18, 14, 22, 19, 26, 24, 30, 28, 34], delta: +8.4 },
  { label: "GDP Pulse", series: [40, 38, 42, 41, 44, 46, 45, 48, 47, 50], delta: +2.1 },
  { label: "Rainfall mm", series: [8, 12, 10, 14, 9, 6, 11, 15, 18, 14], delta: -3.2 },
  { label: "Air Quality", series: [55, 52, 58, 50, 48, 45, 47, 44, 42, 40], delta: -6.7 },
  { label: "Wildlife Flow", series: [20, 22, 25, 23, 28, 30, 27, 32, 35, 33], delta: +4.9 },
];

const BAR_POOL = [
  { label: "Districts Live", bars: [70, 82, 55, 90, 66, 78, 44, 88] },
  { label: "Sector Load", bars: [40, 66, 82, 55, 91, 48, 72, 60] },
  { label: "Grid Draw", bars: [30, 44, 62, 71, 55, 88, 40, 66] },
];

const INSIGHT_POOL = [
  "Kalahari corridor +12% wildlife flux",
  "Okavango salinity within nominal band",
  "Gaborone air quality trending clean",
  "Chobe river gauge stable · 24h",
  "Tsodilo micro-climate anomaly noted",
  "Makgadikgadi salt reflectance ↑ 3.4%",
  "Francistown grid load steady",
  "Central Kalahari heat index +1.8°",
];

const TICKER_ITEMS = [
  "◆ LIVE — Kalahari sensor mesh online",
  "▲ Okavango flood pulse +0.42m",
  "◇ Chobe elephant transit +7.1%",
  "● Gaborone metro pop 267k",
  "▲ Tourism index Q3 +8.4%",
  "◆ Rainfall anomaly Ngamiland",
  "◇ Solar yield 92% nominal",
  "▲ Diamond output stable",
  "● AI survey pass 41 / 96",
];

/** Longer news-style sentences for the bottom ticker. */
const NEWS_ITEMS = [
  "Gaborone — Cabinet approves P2.4bn national fibre backbone, first phase lands in Kweneng by Q3.",
  "Maun — Okavango floodwaters arrive three weeks early; lodge occupancy jumps to 91% for the season.",
  "Francistown — New solar-plus-storage park breaks ground, targeting 120MW and 400 local jobs.",
  "Kasane — Chobe elephant corridor survey records highest dry-season transit count in nine years.",
  "Selebi-Phikwe — Copper reprocessing venture signs offtake deal with two Asian refiners.",
  "Jwaneng — Underground extension study clears feasibility, extending mine life to 2054.",
  "Ghanzi — Rangeland restoration pilot cuts soil loss 18% across twelve participating farms.",
  "Serowe — Digital land registry goes live; title transfers now settle in under 72 hours.",
  "Lobatse — Beef export volumes recover 12% year-on-year as EU quota utilisation improves.",
  "Tsodilo — UNESCO grant funds 3D scanning of 4,500 rock art panels for public archive.",
  "Palapye — University research hub launches AI lab focused on drought forecasting.",
  "Kgalagadi — Cross-border wildlife telemetry network expands to 240 collared animals.",
];


// ---------- utils ----------

function useCycle<T>(items: T[], ms: number, active = true) {
  const [i, setI] = useState(0);
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setI((x) => (x + 1) % items.length), ms);
    return () => window.clearInterval(id);
  }, [items.length, ms, active]);
  return items[i];
}

function useJitter(seed: number, ms: number, range = 3) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setN((v) => v + 1), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  const dx = Math.sin((n + seed) * 0.9) * range;
  const dy = Math.cos((n + seed) * 0.7) * range;
  return { dx, dy };
}

// ---------- card shell ----------

function shell(isLight: boolean) {
  return isLight
    ? "border border-slate-900/12 bg-transparent text-slate-900"
    : "border border-white/12 bg-transparent text-white";
}


function Chip({
  children,
  isLight,
  glow,
}: {
  children: React.ReactNode;
  isLight: boolean;
  glow: string;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-[0.18em] ${
        isLight ? "bg-slate-900/5 text-slate-700" : "bg-white/10"
      }`}
      style={{ boxShadow: `0 0 8px ${glow}` }}
    >
      {children}
    </span>
  );
}

// ---------- widgets ----------

function ProgressRing({
  metric,
  isLight,
  glow,
}: {
  metric: (typeof METRIC_POOL)[number];
  isLight: boolean;
  glow: string;
}) {
  const r = 18;
  const c = 2 * Math.PI * r;
  const off = c * (1 - metric.value / 100);
  const Icon = metric.icon;
  const up = metric.trend >= 0;
  return (
    <div
      className={`flex items-center gap-2.5 rounded-2xl px-2.5 py-2 backdrop-blur-2xl ${shell(
        isLight,
      )}`}
    >
      <div className="relative h-11 w-11 shrink-0">
        <svg viewBox="0 0 44 44" className="h-11 w-11 -rotate-90">
          <circle
            cx="22"
            cy="22"
            r={r}
            fill="none"
            stroke={isLight ? "rgba(15,23,42,0.08)" : "rgba(255,255,255,0.1)"}
            strokeWidth="3.5"
          />
          <motion.circle
            cx="22"
            cy="22"
            r={r}
            fill="none"
            stroke={glow}
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeDasharray={c}
            initial={false}
            animate={{ strokeDashoffset: off }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            style={{ filter: `drop-shadow(0 0 4px ${glow})` }}
          />
        </svg>
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <Icon className="h-3.5 w-3.5" style={{ color: glow }} />
        </div>
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-1 text-[9px] font-semibold uppercase tracking-[0.2em] opacity-70">
          {metric.label}
        </div>
        <div className="mt-0.5 flex items-baseline gap-1.5">
          <span
            className="text-lg font-black leading-none tabular-nums"
            style={{ fontFamily: "'Sora',sans-serif" }}
          >
            {metric.value}
            <span className="text-[10px] opacity-70">{metric.unit}</span>
          </span>
          <span
            className={`inline-flex items-center gap-0.5 text-[9px] font-bold ${
              up ? "text-emerald-400" : "text-rose-400"
            }`}
          >
            {up ? (
              <TrendingUp className="h-2.5 w-2.5" />
            ) : (
              <TrendingDown className="h-2.5 w-2.5" />
            )}
            {up ? "+" : ""}
            {metric.trend.toFixed(1)}%
          </span>
        </div>
      </div>
    </div>
  );
}

function Sparkline({
  data,
  isLight,
  glow,
}: {
  data: (typeof SPARK_POOL)[number];
  isLight: boolean;
  glow: string;
}) {
  const w = 78;
  const h = 26;
  const min = Math.min(...data.series);
  const max = Math.max(...data.series);
  const path = data.series
    .map((v, i) => {
      const x = (i / (data.series.length - 1)) * w;
      const y = h - ((v - min) / Math.max(1, max - min)) * h;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  const area = `${path} L${w},${h} L0,${h} Z`;
  const up = data.delta >= 0;
  return (
    <div
      className={`flex items-center gap-2.5 rounded-2xl px-2.5 py-2 backdrop-blur-2xl ${shell(
        isLight,
      )}`}
    >
      <div className="min-w-0">
        <div className="text-[9px] font-semibold uppercase tracking-[0.2em] opacity-70">
          {data.label}
        </div>
        <div className="mt-0.5 flex items-baseline gap-1.5">
          <span
            className={`text-sm font-black tabular-nums ${up ? "text-emerald-400" : "text-rose-400"}`}
            style={{ fontFamily: "'Sora',sans-serif" }}
          >
            {up ? "+" : ""}
            {data.delta.toFixed(1)}%
          </span>
        </div>
      </div>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        width={w}
        height={h}
        className="shrink-0 overflow-visible"
      >
        <defs>
          <linearGradient id={`spark-${data.label}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={glow} stopOpacity="0.55" />
            <stop offset="100%" stopColor={glow} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill={`url(#spark-${data.label})`} />
        <path
          d={path}
          fill="none"
          stroke={glow}
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ filter: `drop-shadow(0 0 3px ${glow})` }}
        />
      </svg>
    </div>
  );
}

function BarWidget({
  data,
  isLight,
  glow,
}: {
  data: (typeof BAR_POOL)[number];
  isLight: boolean;
  glow: string;
}) {
  return (
    <div
      className={`rounded-2xl px-2.5 py-2 backdrop-blur-2xl ${shell(isLight)}`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="text-[9px] font-semibold uppercase tracking-[0.2em] opacity-70">
          {data.label}
        </div>
        <Waves className="h-3 w-3 opacity-60" />
      </div>
      <div className="mt-1.5 flex h-6 items-end gap-[3px]">
        {data.bars.map((_v, i) => {
          // Music-visualizer style: each bar dances continuously with its own
          // phase & speed. Pure transform → GPU friendly.
          const dur = 0.55 + (i % 5) * 0.09;
          const delay = (i * 0.07) % 0.5;
          const lo = 0.18 + ((i * 37) % 30) / 100;
          const mid = 0.55 + ((i * 53) % 45) / 100;
          const hi = 0.9 - ((i * 29) % 20) / 100;
          return (
            <motion.span
              key={i}
              animate={{ scaleY: [lo, hi, mid, hi * 0.85, lo] }}
              transition={{
                duration: dur,
                ease: "easeInOut",
                repeat: Infinity,
                delay,
              }}
              className="w-[5px] origin-bottom rounded-sm"
              style={{
                height: "100%",
                background: glow,
                boxShadow: `0 0 6px ${glow}`,
                willChange: "transform",
              }}
            />
          );
        })}
      </div>
    </div>
  );
}

function PredictionBadge({
  isLight,
  glow,
  text,
}: {
  isLight: boolean;
  glow: string;
  text: string;
}) {
  return (
    <div
      className={`flex max-w-[220px] items-start gap-2 rounded-2xl px-2.5 py-2 backdrop-blur-2xl ${shell(
        isLight,
      )}`}
    >
      <span
        className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full"
        style={{
          background: `radial-gradient(circle at 30% 30%, ${glow}, transparent 70%)`,
          boxShadow: `0 0 10px ${glow}`,
        }}
      >
        <Sparkles className="h-3 w-3" />
      </span>
      <div className="min-w-0">
        <div className="flex items-center gap-1">
          <Chip isLight={isLight} glow={glow}>AI · Live</Chip>
        </div>
        <div className="mt-1 line-clamp-2 text-[10.5px] font-medium leading-tight">
          {text}
        </div>
      </div>
    </div>
  );
}

function StatusPill({
  isLight,
  glow,
  autoplay,
}: {
  isLight: boolean;
  glow: string;
  autoplay: boolean;
}) {
  return (
    <div
      className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 backdrop-blur-2xl ${shell(isLight)}`}
    >
      <motion.span
        className="h-1.5 w-1.5 rounded-full"
        style={{ background: glow, boxShadow: `0 0 6px ${glow}` }}
        animate={{ opacity: [1, 0.35, 1] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
      />
      <span className="text-[9px] font-bold uppercase tracking-[0.22em]">
        {autoplay ? "Auto Recon" : "Standby"}
      </span>
    </div>
  );
}

// ---------- ticker ----------

function Ticker({
  isLight, glow, position, cfg,
}: { isLight: boolean; glow: string; position: "top" | "bottom"; cfg?: TickerConfig }) {
  const c = { ...DEFAULT_TICKER, ...(cfg ?? {}) };
  const source =
    position === "top"
      ? TICKER_ITEMS
      : c.mode === "news"
      ? NEWS_ITEMS
      : c.mode === "metrics"
      ? TICKER_ITEMS
      : [...NEWS_ITEMS, ...TICKER_ITEMS];
  const base = c.uppercase ? source.map((s) => s.toUpperCase()) : source;
  const items = [...base, ...base];
  const isBottom = position === "bottom";
  const reverse = isBottom && c.direction === "rtl";

  return (
    <div
      className={`hud-ticker pointer-events-none absolute inset-x-0 z-[9] w-full overflow-hidden ${
        position === "top"
          ? "top-0 border-b border-slate-900/10 bg-white px-2 py-[2px] text-slate-900"
          : `bottom-0 border-t ${shell(isLight)}`
      }`}
      style={
        isBottom
          ? {
              paddingTop: 2,
              paddingBottom: 2,
              paddingLeft: 6,
              paddingRight: 6,
              backdropFilter: `blur(${c.blur}px)`,
              background:
                c.bgOpacity <= 0
                  ? "transparent"
                  : isLight
                  ? `rgba(255,255,255,${c.bgOpacity})`
                  : `rgba(6,10,22,${c.bgOpacity})`,
            }
          : undefined
      }
    >
      <div className="flex items-center gap-2">
        {(!isBottom || c.showIcon) && (
          <span
            className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-full"
            style={{ background: glow, boxShadow: `0 0 6px ${glow}` }}
          >
            <Radio className="h-2 w-2 text-black/70" />
          </span>
        )}
        <div className="relative flex-1 overflow-hidden">
          <motion.div
            className="flex items-center whitespace-nowrap uppercase"
            animate={{ x: reverse ? ["-50%", "0%"] : ["0%", "-50%"] }}
            transition={{ duration: isBottom ? c.speed : 14, ease: "linear", repeat: Infinity }}
            style={{
              willChange: "transform",
              gap: isBottom ? `${c.gap}px` : 24,
              fontSize: isBottom ? c.size : 8,
              fontWeight: isBottom ? c.weight : 900,
              fontFamily: isBottom ? c.font : undefined,
              letterSpacing: isBottom ? `${c.tracking}em` : "0.12em",
              textTransform: isBottom && !c.uppercase ? "none" : "uppercase",
            }}
          >
            {items.map((it, i) => {
              const palette = ["#ef4444", "#f59e0b", "#22c55e", "#06b6d4", "#a78bfa", "#ec4899"];
              const color = isBottom
                ? c.color === "auto"
                  ? glow
                  : c.color === "rainbow"
                  ? palette[i % palette.length]
                  : c.color
                : palette[i % palette.length];
              const chip = isBottom && c.chips;
              return (
                <span
                  key={i}
                  style={{
                    color,
                    textShadow: isBottom && !c.glowText ? "none" : `0 0 6px ${color}66`,
                    ...(chip
                      ? {
                          padding: "2px 8px",
                          borderRadius: c.radius,
                          background: c.outline ? "transparent" : alpha(color, 0.14),
                          boxShadow: `inset 0 0 0 1px ${alpha(color, c.outline ? 0.65 : 0.22)}`,
                        }
                      : null),
                  }}
                >
                  {it}
                  {isBottom && !chip && c.separator !== "none" && (
                    <span className="ml-[inherit] opacity-40"> {c.separator} </span>
                  )}
                </span>
              );
            })}
          </motion.div>

          {c.fade && (
            <>
              <span
                className="pointer-events-none absolute inset-y-0 left-0 w-6"
                style={{
                  background: `linear-gradient(to right, ${
                    isLight ? "rgba(255,255,255,0.85)" : "rgba(10,15,30,0.7)"
                  }, transparent)`,
                }}
              />
              <span
                className="pointer-events-none absolute inset-y-0 right-0 w-6"
                style={{
                  background: `linear-gradient(to left, ${
                    isLight ? "rgba(255,255,255,0.85)" : "rgba(10,15,30,0.7)"
                  }, transparent)`,
                }}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}


// ---------- roaming pop-up insight ----------

const POP_SLOTS = [
  { top: "22%", left: "10%" },
  { top: "30%", right: "10%" },
  { top: "58%", left: "8%" },
  { top: "62%", right: "12%" },
  { top: "44%", left: "50%", translate: true },
];

function RoamingInsight({
  isLight,
  glow,
  autoplay,
}: {
  isLight: boolean;
  glow: string;
  autoplay: boolean;
}) {
  const [idx, setIdx] = useState(0);
  const [slotI, setSlotI] = useState(0);
  useEffect(() => {
    const interval = autoplay ? 4200 : 6800;
    const id = window.setInterval(() => {
      setIdx((v) => (v + 1) % INSIGHT_POOL.length);
      setSlotI((v) => (v + 1) % POP_SLOTS.length);
    }, interval);
    return () => window.clearInterval(id);
  }, [autoplay]);

  const slot = POP_SLOTS[slotI];
  const style: React.CSSProperties = {
    top: slot.top,
    left: slot.left,
    right: slot.right,
    transform: slot.translate ? "translate(-50%, -50%)" : undefined,
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-[11]">
      <AnimatePresence mode="wait">
        <motion.div
          key={idx}
          initial={{ opacity: 0, y: 10, scale: 0.94 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -8, scale: 0.96 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="absolute"
          style={style}
        >
          <PredictionBadge
            isLight={isLight}
            glow={glow}
            text={INSIGHT_POOL[idx]}
          />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ---------- draggable + optionally pinch-resizable slot ----------

function DraggableSlot({
  children,
  className,
  delay = 0,
  amp = 4,
  duration = 6,
  containerRef,
  resizable = true,
  autoplay = false,
  roamSeed = 0,
}: {
  children: React.ReactNode;
  className: string;
  delay?: number;
  amp?: number;
  duration?: number;
  containerRef: React.RefObject<HTMLDivElement | null>;
  resizable?: boolean;
  autoplay?: boolean;
  roamSeed?: number;
}) {
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const startDist = useRef(0);
  const startScale = useRef(1);
  const [userScale, setUserScale] = useState<number | null>(null);
  const [pinching, setPinching] = useState(false);
  const [removed, setRemoved] = useState(false);

  // When autoplay is on, widgets start smaller so they don't cover the map
  // and float over a wider path so they "dodge" as the camera moves.
  const autoScale = autoplay ? 0.72 : 1;
  const scale = userScale ?? autoScale;
  const driftAmp = autoplay ? amp * 3.2 : amp;
  const driftDur = autoplay ? duration * 0.75 : duration;

  // Roaming offset while autoplay is on — each widget follows its own slow
  // Lissajous path so the corners feel alive without ever crossing the country.
  const [roam, setRoam] = useState({ x: 0, y: 0 });
  useEffect(() => {
    if (!autoplay) { setRoam({ x: 0, y: 0 }); return; }
    let raf = 0;
    const t0 = performance.now() + roamSeed * 137;
    const loop = () => {
      const el = containerRef.current;
      const w = el?.clientWidth ?? 360;
      const h = el?.clientHeight ?? 480;
      const ax = Math.min(60, w * 0.12);
      const ay = Math.min(45, h * 0.09);
      const t = (performance.now() - t0) / 1000;
      setRoam({
        x: Math.sin(t * 0.35 + roamSeed) * ax + Math.cos(t * 0.22) * ax * 0.35,
        y: Math.cos(t * 0.31 + roamSeed * 0.7) * ay + Math.sin(t * 0.18) * ay * 0.4,
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [autoplay, containerRef, roamSeed]);

  const onPointerDown = (e: React.PointerEvent) => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (resizable && pointers.current.size === 2) {
      const [a, b] = Array.from(pointers.current.values());
      startDist.current = Math.hypot(b.x - a.x, b.y - a.y) || 1;
      startScale.current = scale;
      setPinching(true);
    }
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (resizable && pointers.current.size === 2) {
      const [a, b] = Array.from(pointers.current.values());
      const d = Math.hypot(b.x - a.x, b.y - a.y);
      const s = Math.max(0.35, Math.min(6.5, startScale.current * (d / startDist.current)));
      setUserScale(s);
    }
  };
  const onPointerUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) setPinching(false);
  };

  if (removed) return null;
  return (
    <motion.div
      className={`pointer-events-auto absolute z-[10] ${className}`}
      drag={!pinching}
      dragMomentum={false}
      dragElastic={0.08}
      dragConstraints={containerRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      whileDrag={{ zIndex: 40, cursor: "grabbing" }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1, x: roam.x, y: roam.y }}
      transition={{
        opacity: { duration: 0.6, delay },
        x: { type: "spring", stiffness: 24, damping: 14, mass: 0.9 },
        y: { type: "spring", stiffness: 24, damping: 14, mass: 0.9 },
      }}
      style={{ touchAction: "none", cursor: "grab" }}
    >
      <div className="absolute -right-1 -top-1 z-50 flex gap-0.5 opacity-40 transition-opacity hover:opacity-100">
        <button aria-label="Make card smaller" onPointerDown={(e) => e.stopPropagation()} onClick={() => setUserScale(Math.max(0.35, scale - 0.15))} className="grid h-4 w-4 place-items-center rounded-full border border-current/20 bg-background/70 text-[9px]">−</button>
        <button aria-label="Make card larger" onPointerDown={(e) => e.stopPropagation()} onClick={() => setUserScale(Math.min(6.5, scale + 0.15))} className="grid h-4 w-4 place-items-center rounded-full border border-current/20 bg-background/70 text-[9px]">+</button>
        <button aria-label="Remove card" onPointerDown={(e) => e.stopPropagation()} onClick={() => setRemoved(true)} className="grid h-4 w-4 place-items-center rounded-full border border-current/20 bg-background/70"><X className="h-2.5 w-2.5" /></button>
      </div>
      <motion.div
        animate={{
          y: [0, -driftAmp, 0, driftAmp * 0.6, 0],
          x: [0, driftAmp * 0.6, 0, -driftAmp * 0.6, 0],
          scale,
        }}
        transition={{
          y: { duration: driftDur, repeat: Infinity, ease: "easeInOut", delay },
          x: { duration: driftDur * 1.3, repeat: Infinity, ease: "easeInOut", delay },
          scale: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
        }}
        style={{ transformOrigin: "center", willChange: "transform" }}
      >
        {children}
      </motion.div>
    </motion.div>
  );
}

// ---------- picture widget ----------

const PICTURES = [
  { url: "https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=400&q=70", caption: "Okavango · dawn" },
  { url: "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?auto=format&fit=crop&w=400&q=70", caption: "Chobe · elephants" },
  { url: "https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=400&q=70", caption: "Kalahari · dunes" },
  { url: "https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=400&q=70", caption: "Delta · flood pulse" },
  { url: "https://images.unsplash.com/photo-1502581827181-9cf3c3ee0106?auto=format&fit=crop&w=400&q=70", caption: "Makgadikgadi · salt" },
];

function PictureWidget({ isLight, glow }: { isLight: boolean; glow: string }) {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setI((v) => (v + 1) % PICTURES.length), 3600);
    return () => window.clearInterval(id);
  }, []);
  const pic = PICTURES[i];
  return (
    <div
      className={`overflow-hidden rounded-2xl backdrop-blur-2xl ${shell(isLight)}`}
      style={{ width: 112 }}
    >
      <div className="relative h-16 w-full overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.img
            key={pic.url + i}
            src={pic.url}
            alt={pic.caption}
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.04 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0 h-full w-full object-cover"
            draggable={false}
          />
        </AnimatePresence>
        <span
          className="pointer-events-none absolute right-1 top-1 grid h-4 w-4 place-items-center rounded-full"
          style={{ background: glow, boxShadow: `0 0 6px ${glow}` }}
        >
          <Camera className="h-2.5 w-2.5 text-black/70" />
        </span>
      </div>
      <div className="flex items-center justify-between px-2 py-1">
        <span className="truncate text-[9px] font-bold uppercase tracking-[0.18em] opacity-80">
          {pic.caption}
        </span>
        <span className="ml-1 text-[8px] tabular-nums opacity-60">
          {i + 1}/{PICTURES.length}
        </span>
      </div>
    </div>
  );
}



// ---------- root HUD ----------

const SLOTS = [
  { cls: "left-2 top-[62px] sm:left-3 sm:top-[68px]", delay: 0.1, amp: 3, dur: 7, seed: 0.4 },
  { cls: "right-2 top-[62px] sm:right-3 sm:top-[68px]", delay: 0.25, amp: 3, dur: 6.5, seed: 1.7 },
  { cls: "bottom-[74px] left-2 sm:left-3 sm:bottom-[80px]", delay: 0.45, amp: 4, dur: 8, seed: 2.9 },
  { cls: "bottom-[74px] right-2 sm:right-3 sm:bottom-[80px]", delay: 0.6, amp: 3, dur: 7.2, seed: 4.2 },
  { cls: "left-1/2 top-[52%] -translate-x-1/2 -translate-y-1/2", delay: 0.75, amp: 5, dur: 9, seed: 5.6 },
  { cls: "right-2 top-1/2 -translate-y-1/2 sm:right-16", delay: 0.9, amp: 3, dur: 7.8, seed: 7.3 },
];

export function HudLayer({ isLight, glow, autoplay, preset = 0, showCards = true, ticker }: HudLayerProps) {
  const metric = useCycle(METRIC_POOL, 4200);
  const metric2 = useCycle(METRIC_POOL, 5100);
  const spark = useCycle(SPARK_POOL, 3800);
  const bar = useCycle(BAR_POOL, 5400);
  const insight = useCycle(INSIGHT_POOL, autoplay ? 4200 : 6800);

  const g = useMemo(() => glow, [glow]);
  const rootRef = useRef<HTMLDivElement>(null);

  const packs: React.ReactNode[][] = [
    // 0 · Classic
    [
      <ProgressRing metric={metric} isLight={isLight} glow={g} />,
      <Sparkline data={spark} isLight={isLight} glow={g} />,
      <BarWidget data={bar} isLight={isLight} glow={g} />,
      <ProgressRing metric={metric2} isLight={isLight} glow={g} />,
      <PictureWidget isLight={isLight} glow={g} />,
      <PredictionBadge isLight={isLight} glow={g} text={insight} />,
    ],
    // 1 · Neural
    [
      <NeuralCard isLight={isLight} glow={g} />,
      <KineticTextCard isLight={isLight} glow={g} />,
      <StackCard isLight={isLight} glow={g} />,
      <VitalsCard isLight={isLight} glow={g} />,
      <PredictionBadge isLight={isLight} glow={g} text={insight} />,
      <ScanCard isLight={isLight} glow={g} />,
    ],
    // 2 · Kinetic
    [
      <MotionCard isLight={isLight} glow={g} />,
      <KineticTextCard isLight={isLight} glow={g} />,
      <GridDrawCard glow={g} />,
      <FluxCard isLight={isLight} glow={g} />,
      <ScanCard isLight={isLight} glow={g} />,
      <Sparkline data={spark} isLight={isLight} glow={g} />,
    ],
    // 3 · Mesh
    [
      <FluxCard isLight={isLight} glow={g} />,
      <NeuralCard isLight={isLight} glow={g} />,
      <GridDrawCard glow={g} />,
      <StackCard isLight={isLight} glow={g} />,
      <MotionCard isLight={isLight} glow={g} />,
      <PredictionBadge isLight={isLight} glow={g} text={insight} />,
    ],
    // 4 · Ops
    [
      <VitalsCard isLight={isLight} glow={g} />,
      <ProgressRing metric={metric} isLight={isLight} glow={g} />,
      <StackCard isLight={isLight} glow={g} />,
      <ScanCard isLight={isLight} glow={g} />,
      <SurveyWidget isLight={isLight} glow={g} shellCls={shell(isLight)} />,
      <BarWidget data={bar} isLight={isLight} glow={g} />,
    ],
    // 5 · Studio
    [
      <PictureWidget isLight={isLight} glow={g} />,
      <KineticTextCard isLight={isLight} glow={g} />,
      <MotionCard isLight={isLight} glow={g} />,
      <NeuralCard isLight={isLight} glow={g} />,
      <GridDrawCard glow={g} />,
      <VitalsCard isLight={isLight} glow={g} />,
    ],
  ];

  const cards = packs[((preset % packs.length) + packs.length) % packs.length];

  return (
    <div ref={rootRef} className="pointer-events-none absolute inset-0 z-[8] overflow-hidden">
      {/* top news ticker removed */}
      <Ticker isLight={isLight} glow={g} position="bottom" cfg={ticker} />


      {showCards && cards.map((card, i) => {
        const slot = SLOTS[i % SLOTS.length];
        return (
          <DraggableSlot
            key={`${preset}-${i}`}
            className={slot.cls}
            delay={slot.delay}
            amp={slot.amp}
            duration={slot.dur}
            containerRef={rootRef}
            autoplay={autoplay}
            roamSeed={slot.seed}
          >
            {card}
          </DraggableSlot>
        );
      })}

      
    </div>
  );
}
