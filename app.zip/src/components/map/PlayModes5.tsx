/* Premium modes 6–10 — five new expert-grade dashboards.
 * 6 Situation Room · 7 Signal Scope · 8 Investor Brief · 9 Pulse Grid · 10 Depth Atlas */
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import type { ThemeSpec } from "./themes";
import { alpha } from "./color";
import { PLACE_CYCLE, statsFor, clockIndex } from "./playData";
import { SPOTLIGHT_MS } from "./PlayModes2";

const EASE = [0.22, 1, 0.36, 1] as const;
const MONO = "'JetBrains Mono','SFMono-Regular',ui-monospace,monospace";

function useCycle(len: number, ms: number) {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setI((v) => (v + 1) % len), ms);
    return () => window.clearInterval(id);
  }, [len, ms]);
  return i;
}
function useSyncedPlace() {
  const [, force] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => force((v) => v + 1), 400);
    return () => window.clearInterval(id);
  }, []);
  const i = clockIndex(PLACE_CYCLE.length, SPOTLIGHT_MS);
  return statsFor(PLACE_CYCLE[i]);
}

/* ---------------- 6 · SITUATION ROOM (full) ---------------- */

function SituationRoom({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSyncedPlace();
  const text = isLight ? "#0f172a" : "#eaf1ff";
  const bg = isLight ? "#eef2f8" : "#03050c";
  const panel = alpha(isLight ? "#ffffff" : "#0a0f1c", 0.66);

  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: bg }}>
      {/* radar sweep, centered */}
      <div className="absolute left-1/2 top-1/2 h-[70vmin] w-[70vmin] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-30"
        style={{ border: `1px solid ${alpha(theme.glow, 0.25)}` }}>
        <div className="absolute inset-[15%] rounded-full" style={{ border: `1px solid ${alpha(theme.glow, 0.2)}` }} />
        <div className="absolute inset-[35%] rounded-full" style={{ border: `1px solid ${alpha(theme.glow, 0.18)}` }} />
        <motion.div className="absolute inset-0 origin-center rounded-full"
          animate={{ rotate: 360 }} transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          style={{ background: `conic-gradient(${alpha(theme.glow, 0.35)} 0deg, transparent 60deg, transparent 360deg)` }} />
      </div>

      <div className="relative z-10 grid h-full grid-cols-2 gap-1.5 p-2 sm:grid-cols-4 sm:gap-2 sm:p-3">
        {/* top bar */}
        <div className="col-span-2 flex items-center gap-2 rounded-md px-2 py-1 backdrop-blur-md sm:col-span-4"
          style={{ background: panel, border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
          <motion.span animate={{ opacity: [1, 0.25, 1] }} transition={{ duration: 1.2, repeat: Infinity }}
            className="h-1.5 w-1.5 rounded-full" style={{ background: "#ef4444" }} />
          <span className="text-[8px] font-black uppercase tracking-[0.25em]" style={{ color: theme.glow }}>Situation Room · Live Ops</span>
          <span className="ml-auto truncate text-[8px] font-bold uppercase tracking-[0.15em] opacity-60" style={{ color: text }}>{s.name} · {s.district}</span>
        </div>

        {/* corner telemetry panels */}
        {[
          { label: "Population", value: s.population.toLocaleString(), delta: s.populationDelta, unit: "%" },
          { label: "Businesses", value: s.businesses.toLocaleString(), delta: s.businessDelta, unit: "" },
          { label: "Sentiment", value: `${s.sentiment}/100`, delta: s.growthPct, unit: "%" },
          { label: "Water Access", value: `${s.waterAccessPct}%`, delta: s.waterAccessPct - 70, unit: "pt" },
        ].map((c, k) => (
          <motion.div key={c.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: k * 0.06, duration: 0.4, ease: EASE }}
            className="min-w-0 rounded-md px-2 py-1.5 backdrop-blur-md"
            style={{ background: panel, border: `1px solid ${alpha(theme.glow, 0.18)}` }}>
            <div className="truncate text-[7px] font-black uppercase tracking-[0.15em] opacity-55" style={{ color: text }}>{c.label}</div>
            <div className="truncate text-[13px] font-black tabular-nums" style={{ color: text, fontFamily: MONO }}>{c.value}</div>
            <div className="flex items-center gap-0.5 text-[7.5px] font-bold" style={{ color: c.delta >= 0 ? "#34d399" : "#f87171" }}>
              {c.delta >= 0 ? <ArrowUpRight className="h-2.5 w-2.5" /> : <ArrowDownRight className="h-2.5 w-2.5" />}
              {Math.abs(c.delta).toFixed(1)}{c.unit}
            </div>
          </motion.div>
        ))}

        {/* center readout, spans remaining */}
        <div className="col-span-2 row-span-2 hidden min-h-0 rounded-md p-2 backdrop-blur-md sm:col-span-2 sm:block"
          style={{ background: panel, border: `1px solid ${alpha(theme.glow, 0.18)}` }}>
          <div className="text-[7px] font-black uppercase tracking-[0.2em] opacity-55" style={{ color: text }}>Sector activity feed</div>
          <div className="mt-1 space-y-1">
            {s.sectorMix.slice(0, 5).map((m, k) => (
              <div key={m.label} className="flex items-center gap-2">
                <span className="w-16 shrink-0 truncate text-[8px] font-bold uppercase opacity-60" style={{ color: text }}>{m.label}</span>
                <div className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full" style={{ background: alpha(theme.glow, 0.14) }}>
                  <motion.div initial={{ width: 0 }} animate={{ width: `${m.value}%` }} transition={{ duration: 0.7, delay: k * 0.05 }}
                    className="h-full rounded-full" style={{ background: theme.glow }} />
                </div>
                <span className="w-6 shrink-0 text-right text-[8px] font-black tabular-nums" style={{ color: theme.glow }}>{m.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* alert ticker bottom */}
        <div className="col-span-2 mt-auto flex items-center gap-2 self-end overflow-hidden rounded-md px-2 py-1 backdrop-blur-md sm:col-span-4"
          style={{ background: panel, border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
          <span className="shrink-0 rounded bg-red-500/80 px-1 py-[1px] text-[7px] font-black uppercase text-white">Alert</span>
          <div className="min-w-0 flex-1 overflow-hidden whitespace-nowrap">
            <motion.div className="inline-block text-[8px] font-bold" style={{ color: text }} animate={{ x: ["0%", "-50%"] }}
              transition={{ duration: 18, repeat: Infinity, ease: "linear" }}>
              {PLACE_CYCLE.map((n) => `  •  ${statsFor(n).headline}`).join(" ").repeat(2)}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- 7 · SIGNAL SCOPE (map-focus, top-docked HUD) ---------------- */

function SignalScope({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const s = useSyncedPlace();
  const text = "#eaf1ff";
  const maxSector = Math.max(...s.sectorMix.map((m) => m.value));
  const wavePts = Array.from({ length: 48 }, (_, i) => {
    const t = i / 47;
    const base = s.history[Math.floor(t * (s.history.length - 1))] / 100;
    const wob = Math.sin(t * Math.PI * 8 + s.sentiment) * 0.08;
    return `${t * 280},${40 - (base + wob) * 34}`;
  }).join(" ");

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0">
      <div
        className="max-h-[42vh] overflow-y-auto p-2.5 backdrop-blur-xl sm:p-3"
        style={{ background: `linear-gradient(180deg, ${alpha("#020308", 0.95)}, ${alpha("#020308", 0.75)})`, borderBottom: `1px solid ${alpha(theme.glow, 0.3)}` }}
      >
        <div className="flex items-center gap-2">
          <span className="rounded px-1.5 py-[2px] text-[8px] font-black uppercase tracking-[0.25em] text-black" style={{ background: theme.glow }}>Signal Scope</span>
          <span className="truncate text-[9px] font-bold uppercase tracking-[0.15em] opacity-70" style={{ color: text }}>{s.name} · {s.district}</span>
        </div>

        <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {/* oscilloscope */}
          <AnimatePresence mode="wait">
            <motion.div key={s.name + "-wave"} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
              className="rounded-md p-1.5" style={{ background: alpha(theme.glow, 0.06), border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
              <div className="text-[7px] font-black uppercase tracking-[0.2em] opacity-60" style={{ color: theme.glow, fontFamily: MONO }}>Waveform · sentiment</div>
              <svg viewBox="0 0 280 40" className="mt-0.5 h-[36px] w-full">
                <line x1={0} y1={20} x2={280} y2={20} stroke={alpha(theme.glow, 0.15)} strokeWidth={1} />
                <motion.polyline points={wavePts} fill="none" stroke={theme.glow} strokeWidth="1.6" strokeLinecap="round"
                  initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.1, ease: EASE }}
                  style={{ filter: `drop-shadow(0 0 5px ${alpha(theme.glow, 0.7)})` }} />
              </svg>
            </motion.div>
          </AnimatePresence>

          {/* spectrum bars */}
          <AnimatePresence mode="wait">
            <motion.div key={s.name + "-spec"} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
              className="rounded-md p-1.5" style={{ background: alpha(theme.glow, 0.06), border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
              <div className="text-[7px] font-black uppercase tracking-[0.2em] opacity-60" style={{ color: theme.glow, fontFamily: MONO }}>Spectrum · sector mix</div>
              <div className="mt-0.5 flex h-[36px] items-end gap-[3px]">
                {s.sectorMix.map((m, k) => (
                  <motion.div key={m.label} className="min-w-0 flex-1 rounded-t"
                    animate={{ height: [`${(m.value / maxSector) * 30}px`, `${(m.value / maxSector) * 20}px`, `${(m.value / maxSector) * 30}px`] }}
                    transition={{ duration: 1.4 + k * 0.15, repeat: Infinity, ease: "easeInOut" }}
                    style={{ background: theme.glow, boxShadow: `0 0 5px ${alpha(theme.glow, 0.6)}` }} />
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

/* ---------------- 8 · INVESTOR BRIEF (map-left, docked editorial) ---------------- */

function InvestorBrief({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const i = useCycle(PLACE_CYCLE.length, 7600);
  const s = statsFor(PLACE_CYCLE[i]);
  const text = isLight ? "#0f172a" : "#f4f4f5";
  const roi = (8 + (s.growthPct + s.sentiment / 10)).toFixed(1);
  const valuation = Math.round(s.businesses * 4200 + s.population * 180);

  return (
    <div
      className="pointer-events-none absolute inset-x-2 bottom-2 top-auto flex max-h-[62vh] w-auto flex-col overflow-y-auto rounded-xl border px-3.5 py-3 backdrop-blur-xl sm:inset-x-auto sm:inset-y-0 sm:right-0 sm:top-0 sm:bottom-0 sm:w-[44%] sm:min-w-[260px] sm:max-w-[400px] sm:max-h-none sm:justify-center sm:overflow-hidden sm:rounded-none sm:border-0 sm:px-4 sm:py-6"
      style={{ borderColor: alpha(theme.glow, 0.2), background: alpha(isLight ? "#ffffff" : "#07090f", 0.94) }}
    >
      <AnimatePresence mode="wait">
        <motion.div key={s.name} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.5, ease: EASE }}>
          <div className="text-[8px] font-black uppercase tracking-[0.3em] sm:text-[9px] sm:tracking-[0.4em]" style={{ color: theme.glow }}>Investor Brief · {s.district}</div>
          <h2 className="mt-1 text-[19px] font-black leading-tight sm:text-[26px]" style={{ color: text, fontFamily: "'Sora',sans-serif" }}>{s.name}</h2>
          <div className="mt-0.5 text-[9px] uppercase tracking-[0.18em] opacity-55" style={{ color: text, fontFamily: "Georgia, serif" }}>Confidential · market snapshot</div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <div className="rounded-lg p-2" style={{ background: alpha(theme.glow, 0.08), border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
              <div className="text-[7px] font-black uppercase tracking-[0.15em] opacity-55" style={{ color: text }}>Est. market value</div>
              <div className="text-[15px] font-black tabular-nums" style={{ color: text, fontFamily: MONO }}>P {valuation.toLocaleString()}</div>
            </div>
            <div className="rounded-lg p-2" style={{ background: alpha(theme.glow, 0.08), border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
              <div className="text-[7px] font-black uppercase tracking-[0.15em] opacity-55" style={{ color: text }}>Projected ROI</div>
              <div className="flex items-center gap-1 text-[15px] font-black tabular-nums" style={{ color: Number(roi) >= 8 ? "#34d399" : "#f87171", fontFamily: MONO }}>
                {Number(roi) >= 8 ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}{roi}%
              </div>
            </div>
          </div>

          <p className="mt-2.5 text-[11px] leading-relaxed sm:text-[12px]" style={{ color: text, opacity: 0.82, fontFamily: "Georgia, serif" }}>
            {s.name} shows {s.growthPct >= 0 ? "expanding" : "softening"} momentum, led by {s.leadingSector.toLowerCase()},
            with {s.businesses.toLocaleString()} active operators and a sentiment reading of {s.sentiment}/100.
          </p>

          <div className="mt-2.5 space-y-1 border-t pt-2" style={{ borderColor: alpha(theme.glow, 0.15) }}>
            {s.table.slice(0, 3).map((row) => (
              <div key={row.metric} className="flex items-center justify-between text-[9.5px]">
                <span className="opacity-65" style={{ color: text }}>{row.metric}</span>
                <span className="font-black tabular-nums" style={{ color: text, fontFamily: MONO }}>{row.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

/* ---------------- 9 · PULSE GRID (map-focus, small multiples) ---------------- */

function PulseGrid({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const text = isLight ? "#0f172a" : "#eaf1ff";
  const highlight = clockIndex(PLACE_CYCLE.length, 2200);

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0">
      <div
        className="grid max-h-[46vh] grid-cols-3 gap-1.5 overflow-y-auto p-2.5 backdrop-blur-xl sm:grid-cols-6 sm:gap-2 sm:p-3"
        style={{ background: `linear-gradient(0deg, ${alpha(isLight ? "#ffffff" : "#03050c", 0.95)}, ${alpha(isLight ? "#ffffff" : "#03050c", 0.75)})`, borderTop: `1px solid ${alpha(theme.glow, 0.25)}` }}
      >
        {PLACE_CYCLE.map((name, idx) => {
          const s = statsFor(name);
          const max = Math.max(...s.history);
          const on = idx === highlight;
          return (
            <div key={name} className="min-w-0 rounded-md p-1.5 transition-colors"
              style={{ background: on ? alpha(theme.glow, 0.14) : alpha(theme.glow, 0.04), border: `1px solid ${alpha(theme.glow, on ? 0.4 : 0.15)}` }}>
              <div className="truncate text-[7px] font-black uppercase tracking-[0.1em] opacity-70" style={{ color: text }}>{name}</div>
              <svg viewBox="0 0 100 24" className="mt-0.5 h-4 w-full">
                <polyline points={s.history.map((v, i) => `${(i / (s.history.length - 1)) * 100},${24 - (v / max) * 22}`).join(" ")}
                  fill="none" stroke={theme.glow} strokeWidth="1.6" strokeLinecap="round" opacity={on ? 1 : 0.6} />
              </svg>
              <div className="flex items-center justify-between text-[8px] font-black tabular-nums" style={{ color: text, fontFamily: MONO }}>
                {s.sentiment}
                <span className="flex items-center gap-0.5 text-[7px]" style={{ color: s.growthPct >= 0 ? "#34d399" : "#f87171" }}>
                  {s.growthPct >= 0 ? <ArrowUpRight className="h-2 w-2" /> : <ArrowDownRight className="h-2 w-2" />}{Math.abs(s.growthPct)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- 10 · DEPTH ATLAS (map, cartographic callouts) ---------------- */

const CORNERS = [
  "left-2 top-14 sm:left-4 sm:top-16",
  "right-2 top-14 sm:right-4 sm:top-16",
  "left-2 bottom-14 sm:left-4 sm:bottom-16",
  "right-2 bottom-14 sm:right-4 sm:bottom-16",
];

function DepthAtlas({ theme, isLight }: { theme: ThemeSpec; isLight: boolean }) {
  const i = useCycle(PLACE_CYCLE.length, 6800);
  const text = isLight ? "#0f172a" : "#eaf1ff";
  const names = [0, 1, 2, 3].map((k) => PLACE_CYCLE[(i + k) % PLACE_CYCLE.length]);

  return (
    <div className="absolute inset-0">
      {names.map((name, k) => {
        const s = statsFor(name);
        return (
          <AnimatePresence mode="wait" key={CORNERS[k]}>
            <motion.div key={name} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.5, delay: k * 0.08, ease: EASE }}
              className={`absolute w-[42%] max-w-[190px] rounded-md px-2 py-1.5 backdrop-blur-md ${CORNERS[k]}`}
              style={{ background: alpha(isLight ? "#ffffff" : "#04060d", 0.7), border: `1px solid ${alpha(theme.glow, 0.28)}` }}>
              <div className="flex items-center gap-1">
                <span className="h-1 w-3 shrink-0" style={{ background: theme.glow }} />
                <span className="truncate text-[9px] font-black uppercase tracking-[0.12em]" style={{ color: text }}>{name}</span>
              </div>
              <div className="mt-0.5 truncate text-[7px] font-bold tabular-nums opacity-60" style={{ color: text, fontFamily: MONO }}>
                {s.x.toFixed(1)} · {s.y.toFixed(1)} grid
              </div>
              <div className="truncate text-[7.5px] opacity-70" style={{ color: text }}>{s.district} · {s.type}</div>
            </motion.div>
          </AnimatePresence>
        );
      })}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 rounded-md px-2 py-1 text-[7.5px] font-black uppercase tracking-[0.2em] backdrop-blur-md sm:bottom-3"
        style={{ color: theme.glow, background: alpha(isLight ? "#ffffff" : "#04060d", 0.55), border: `1px solid ${alpha(theme.glow, 0.2)}` }}>
        Depth Atlas · cartographic layer
      </div>
    </div>
  );
}

export function PlayLayer5({ mode, theme, isLight }: { mode: number; theme: ThemeSpec; isLight: boolean }) {
  if (mode === 6) return <SituationRoom theme={theme} isLight={isLight} />;
  if (mode === 7) return <SignalScope theme={theme} isLight={isLight} />;
  if (mode === 8) return <InvestorBrief theme={theme} isLight={isLight} />;
  if (mode === 9) return <PulseGrid theme={theme} isLight={isLight} />;
  if (mode === 10) return <DepthAtlas theme={theme} isLight={isLight} />;
  return null;
}
