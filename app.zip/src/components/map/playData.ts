/* Deterministic place-aware data generator shared by all premium play modes.
 * Pulls real place/district geometry from botswana.json and derives stable,
 * repeatable "stats" per place name (same input → same output every render,
 * no randomness drift, no network) so every mode can be perfectly in sync
 * with the map camera as it visits a place. */
import raw from "@/data/botswana.json";
import type { BotswanaData } from "./types";

const DATA = raw as unknown as BotswanaData;

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** mulberry32 seeded PRNG — deterministic sequence for a given seed. */
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function rngFor(name: string, salt = "") {
  return mulberry32(hashStr(name + "::" + salt));
}

const DISTRICT_POLYS: { name: string; pts: [number, number][] }[] = DATA.districts.map((d) => {
  const nums = (d.path.match(/-?\d+(\.\d+)?/g) ?? []).map(Number);
  const pts: [number, number][] = [];
  for (let i = 0; i + 1 < nums.length; i += 2) pts.push([nums[i], nums[i + 1]]);
  return { name: d.name, pts };
});

export function districtFor(x: number, y: number): string {
  for (const d of DISTRICT_POLYS) {
    let inside = false;
    const pts = d.pts;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const [xi, yi] = pts[i], [xj, yj] = pts[j];
      if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-9) + xi) inside = !inside;
    }
    if (inside) return d.name;
  }
  return "Botswana";
}

/** The tour: real places from the atlas, ordered for a satisfying camera sweep. */
export const PLACE_CYCLE = [
  "Gaborone", "Francistown", "Maun", "Kasane", "Ghanzi", "Serowe",
  "Palapye", "Selebi-Phikwe", "Jwaneng", "Mahalapye", "Kanye", "Lobatse",
].filter((n) => DATA.places.some((p) => p.name === n));

export function placeMeta(name: string) {
  const p = DATA.places.find((x) => x.name === name);
  return {
    name,
    type: p?.type ?? "town",
    district: p ? districtFor(p.x, p.y) : "Botswana",
    x: p?.x ?? 500,
    y: p?.y ?? 500,
    lon: p?.lon ?? 24,
    lat: p?.lat ?? -22,
  };
}

const TYPE_BASE: Record<string, { pop: number; biz: number; scale: number }> = {
  capital: { pop: 9200, biz: 3100, scale: 3.2 },
  city: { pop: 5600, biz: 1600, scale: 3.6 },
  town: { pop: 2100, biz: 480, scale: 3.9 },
  village: { pop: 640, biz: 90, scale: 4.4 },
  park: { pop: 40, biz: 20, scale: 3.4 },
  landmark: { pop: 15, biz: 6, scale: 3.6 },
};

const SECTORS = ["Trade", "Tourism", "Agriculture", "Construction", "Logistics", "Mining", "Digital", "Water"] as const;
const CATEGORIES = ["Economy", "Water", "People", "Land", "Nature"] as const;

export interface PlaceStats {
  name: string;
  type: string;
  district: string;
  x: number; y: number;
  scale: number;
  population: number;
  populationDelta: number;
  businesses: number;
  businessDelta: number;
  sentiment: number;
  growthPct: number;
  waterAccessPct: number;
  connectivityPct: number;
  safetyIndex: number;
  responses: number;
  leadingSector: (typeof SECTORS)[number];
  history: number[];
  sectorMix: { label: string; value: number }[];
  categories: { label: string; value: number; leaves: string[] }[];
  headline: string;
  subhead: string;
  quote: string;
  quoteWho: string;
  table: { metric: string; value: string; delta: string; up: boolean }[];
  timestamp: string;
}

const round = (v: number, d = 0) => Math.round(v * 10 ** d) / 10 ** d;

export function statsFor(name: string): PlaceStats {
  const meta = placeMeta(name);
  const base = TYPE_BASE[meta.type] ?? TYPE_BASE.town;
  const r = rngFor(name);

  const population = Math.round(base.pop * (0.72 + r() * 0.65));
  const populationDelta = round(-2 + r() * 9, 1);
  const businesses = Math.round(base.biz * (0.6 + r() * 0.8));
  const businessDelta = Math.round(r() * 70) - 8;
  const sentiment = Math.round(38 + r() * 55);
  const growthPct = round(-6 + r() * 24, 1);
  const waterAccessPct = Math.round(48 + r() * 50);
  const connectivityPct = Math.round(40 + r() * 58);
  const safetyIndex = Math.round(45 + r() * 50);
  const responses = Math.round(300 + r() * 9200);
  const leadingSector = SECTORS[Math.floor(r() * SECTORS.length)];

  const history: number[] = [];
  let v = 30 + r() * 40;
  for (let i = 0; i < 14; i++) {
    v = Math.max(6, Math.min(96, v + (r() - 0.46) * 16));
    history.push(round(v, 1));
  }

  const sectorMix = SECTORS.map((s) => ({ label: s, value: Math.round(6 + r() * 94) }))
    .sort((a, b) => b.value - a.value).slice(0, 6);

  const categories = CATEGORIES.map((c) => ({
    label: c,
    value: Math.round(20 + r() * 78),
    leaves: Array.from({ length: 4 }, (_, k) => {
      const kinds: Record<string, string[]> = {
        Economy: ["Trade volume", "New SMEs", "Freight margin", "Wage growth", "Investment interest"],
        Water: ["Pump uptime", "Reservoir level", "Outage reports", "Borehole yield", "Sanitation coverage"],
        People: ["Registered voices", "Youth in work", "Skills demand", "Survey coverage", "Migration net"],
        Land: ["Plot supply", "Tenure disputes", "Density index", "Housing stress", "Zoning reviews"],
        Nature: ["Rainfall delta", "Wildlife activity", "Conservation intent", "Heritage visits", "Corridor shift"],
      };
      const opts = kinds[c];
      const label = opts[Math.floor(r() * opts.length)];
      const val = Math.round(r() * 100);
      return `${label} ${val}${r() > 0.5 ? "%" : ""}`;
    }),
  }));

  const headlineBank = [
    `${name} sentiment moves ${growthPct >= 0 ? "up" : "down"} ${Math.abs(growthPct)}% this wave`,
    `${leadingSector} leads registered activity in ${name}`,
    `${name} records ${businesses.toLocaleString()} active businesses`,
    `Water access holds at ${waterAccessPct}% across ${name}`,
    `${name} connectivity climbs to ${connectivityPct}%`,
  ];
  const headline = headlineBank[Math.floor(r() * headlineBank.length)];
  const subhead = `${meta.district} district · ${meta.type} · updated live from ${responses.toLocaleString()} directory & survey signals`;

  const quotes = [
    [`We are finally seeing ${leadingSector.toLowerCase()} demand catch up with supply here.`, `Local operator · ${name}`],
    [`People register faster than we can verify — that's a good problem.`, `Directory lead · ${name}`],
    [`Water is still the first thing people mention in every conversation.`, `Community rep · ${name}`],
    [`Young people here just need clients, not more training.`, `Hub coordinator · ${name}`],
  ];
  const [quote, quoteWho] = quotes[Math.floor(r() * quotes.length)];

  const table = [
    { metric: "Registered people", value: population.toLocaleString(), delta: `${populationDelta >= 0 ? "+" : ""}${populationDelta}%`, up: populationDelta >= 0 },
    { metric: "Active businesses", value: businesses.toLocaleString(), delta: `${businessDelta >= 0 ? "+" : ""}${businessDelta}`, up: businessDelta >= 0 },
    { metric: "Sentiment index", value: `${sentiment}/100`, delta: `${growthPct >= 0 ? "+" : ""}${growthPct}%`, up: growthPct >= 0 },
    { metric: "Water access", value: `${waterAccessPct}%`, delta: waterAccessPct > 70 ? "stable" : "watch", up: waterAccessPct > 70 },
    { metric: "Connectivity", value: `${connectivityPct}%`, delta: connectivityPct > 60 ? "+growing" : "lagging", up: connectivityPct > 60 },
    { metric: "Safety index", value: `${safetyIndex}/100`, delta: safetyIndex > 65 ? "+improving" : "monitor", up: safetyIndex > 65 },
  ];

  return {
    name, type: meta.type, district: meta.district, x: meta.x, y: meta.y,
    scale: base.scale,
    population, populationDelta, businesses, businessDelta, sentiment, growthPct,
    waterAccessPct, connectivityPct, safetyIndex, responses, leadingSector,
    history, sectorMix, categories, headline, subhead, quote, quoteWho, table,
    timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
  };
}

/** Deterministic wall-clock cycle so overlay + map camera stay in lockstep. */
export function clockIndex(len: number, ms: number) {
  return Math.floor(Date.now() / ms) % len;
}
