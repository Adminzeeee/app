import { createFileRoute } from "@tanstack/react-router";
import { BotswanaMap } from "@/components/map/BotswanaMap";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Experience 3" },
      { name: "description", content: "Botswana Command Center enhances map previews with an adaptive AI HUD, displaying dynamic data around the map." },
      { property: "og:title", content: "Experience 3" },
      { property: "og:description", content: "Botswana Command Center enhances map previews with an adaptive AI HUD, displaying dynamic data around the map." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <BotswanaMap />;
}
