import { createFileRoute } from "@tanstack/react-router";

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

const SYSTEM = `You are Kgosi, the AI copilot inside a Botswana geospatial command center app.
You help with Botswana geography, districts, towns, wildlife, economy, tourism, surveys,
and the local freelancer/business directory. Be concise: 1-4 short sentences unless asked
for more. Friendly, professional, no markdown headings.`;

export const Route = createFileRoute("/api/copilot")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as { messages?: ChatMessage[] };
        const messages = Array.isArray(body.messages) ? body.messages.slice(-14) : [];
        if (!messages.length) {
          return new Response(JSON.stringify({ error: "messages required" }), { status: 400 });
        }

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) {
          return new Response(JSON.stringify({ error: "AI is not configured" }), { status: 500 });
        }

        const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Lovable-API-Key": key },
          body: JSON.stringify({
            model: "openai/gpt-5.6-luna",
            reasoning_effort: "none",
            messages: [{ role: "system", content: SYSTEM }, ...messages],
          }),
        });

        if (!res.ok) {
          const text = await res.text();
          return new Response(
            JSON.stringify({ error: res.status === 429 ? "Rate limited — try again shortly." : res.status === 402 ? "AI credits exhausted." : text.slice(0, 300) }),
            { status: res.status, headers: { "Content-Type": "application/json" } },
          );
        }

        const data = (await res.json()) as {
          choices?: { message?: { content?: string } }[];
        };
        const reply = data.choices?.[0]?.message?.content ?? "I didn't catch that — try again?";
        return new Response(JSON.stringify({ reply }), {
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
