import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as { text?: string; voice?: string };
        const text = (body.text ?? "").slice(0, 3500);
        if (!text.trim()) {
          return new Response(JSON.stringify({ error: "text required" }), { status: 400 });
        }
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) {
          return new Response(JSON.stringify({ error: "AI is not configured" }), { status: 500 });
        }

        const res = await fetch("https://ai.gateway.lovable.dev/v1/audio/speech", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
          body: JSON.stringify({
            model: "openai/gpt-4o-mini-tts",
            input: text,
            voice: body.voice ?? "alloy",
            response_format: "mp3",
          }),
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          return new Response(
            JSON.stringify({
              error:
                res.status === 429 ? "Rate limited — try again shortly."
                  : res.status === 402 ? "AI credits exhausted."
                    : t.slice(0, 300),
            }),
            { status: res.status, headers: { "Content-Type": "application/json" } },
          );
        }

        return new Response(res.body, {
          headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" },
        });
      },
    },
  },
});
